/*
""" JScript Stub ------------------------------------- */
var args = ''; for (var i=0; i < WScript.arguments.length; i++) args += '"' + WScript.arguments(i) + '" ';
var folder = WScript.ScriptFullName; for (var i=0; i < 10; i++) { folder += '\\..'; if (new ActiveXObject("Scripting.FileSystemObject").FileExists(folder + '\\lib\\setup_project.cmd')) { project_folder = folder; break; } }
var cmd = 'cmd.exe /v:on /c call "' + project_folder + '\\lib\\setup_project.cmd" jscript & ' + 'cmd.exe /v:on /c ""!PYTHON_EXEC_DIR!/pythonw.exe" -x "' + WScript.ScriptFullName + '" ' + args + '"';
WScript.Quit(WScript.CreateObject("WScript.Shell").Run(cmd, 0, true))
/* Python script ------------------------------------------- """

#-------------------------------------------------------------------------------
# Name:        program_flash_using_atmel-ice.js
# Purpose:     This script allows ddm_motor.hex to be joined with a system
#              constants spreadsheet to produce 
#              support_scripts/ddm_motor_plus_sys_consts.hex and download
#              via an Atmel ICE programmer.
#
#              If the command option, 
#                  file=<spread sheet file>
#              is specified, the unit will be programmed automatically.
#
# Author:      Mike Morgan
#
# Created:     07/03/2016
# Copyright:   (c) Dyson 2016
#-------------------------------------------------------------------------------


# EMAG Script Details
"""
This script will combine the software from ddm_motor.hex to a selected system constants file
and produce support_scripts/ddm_motor.hex and will then try to download the image to a device via
an Atmel ICE programmer.

Note: Press escape to automatically use the system constants file emag_scripts/SoftwareDevSystemConstants.xlsx
"""
# End EMAG Script Details


import tkinter
from tkinter import filedialog
import sys
import time
import os
import json
import gui                       # Dyson Simplified Graphical User Interface library
import atmel_ice                 # Library for using the ATMEL ICE programmer

os.environ['EMAG_FILES_DEST'] = os.path.abspath('..') # <CLARIFY> WE DONT KNOW WHERE EMAG WILL KEEP 248F SPREADHSEETS YET

APP_TITLE = "Program using Atmel-ICE programmer"
APP_HELP  = "This script programs units using the Atmel ICE programmer"

    
#
# Over-ride the gui application
#    
class this_app(gui.app):
    #
    # Initialise the application
    #
    def __init__(self, *args, **kwargs):
        os.chdir(os.path.abspath(sys.argv[0]) + '/..')
        # Initialise the base class
        gui.app.__init__(self, *args, **kwargs)
        self.add_controls()
        self.update_controls()                  # Update all currently defined controls
            
    #
    # Define the controls
    #
    def add_controls(self):
        # Add 'Constants' button
        self.add_button(text='Constants',  func=self.constants_button_pressed, tooltip='Select constants spreadsheet')
        self.constants_text_ctrl = self.add_text(text='')
        self.newline()
        # Add 'Program' button
        self.program_button = self.add_button(text='Program',  func=self.program_button_pressed, tooltip='Program a device')
        self.newline()
            
        # Add text window
        self.newline()
        self.print_window_ctrl = self.add_print_window(width=80, height=15, span=99)
        # Redirect print to the window
        self.redirect_print(self.print_window_ctrl)
        
        self.software_file = os.path.abspath('ddm_motor.hex')
        
        self.constants_text_ctrl.change_text('Please select a constants file')
        self.constants_file = os.environ.get('EMAG_FILES_DEST') + '/dummy'
        
        self.program_button.config(state='disable')
        print('\n' * 50) # Make new text appear at the bottom
        print("This utility uses a Segger J-Link Plus to download to the device.")
        print("https://www.segger.com/products/debug-trace-probes")
        
        self.print_window_ctrl.bind("<Escape>", lambda event: self.revert_to_local_spreadsheet())
        self.parent.bind("<Escape>", lambda event: self.revert_to_local_spreadsheet())
        
        if len(sys.argv) > 1 and sys.argv[1][:5] == 'file=':
            self.constants_file = sys.argv[1][5:]
            self.program_button_pressed()
            sys.exit(0)
        
    def revert_to_local_spreadsheet(self):
        self.constants_file = os.getcwd() + '/SoftwareDevSystemConstants.xlsx'
        print("Local spreadsheet: %s " % self.constants_file)
        self.constants_text_ctrl.change_text(self.constants_file)
        self.test_program_button()

    def constants_button_pressed(self):
        file = filedialog.askopenfilename(filetypes=[("Constants Spreadsheets","*.xlsx")], 
                                          initialdir=os.path.abspath(self.constants_file + '/..'),
                                          title='Choose constants spreadsheet', parent=self)
        if file != '':
            self.constants_file = file
            self.constants_text_ctrl.change_text(self.constants_file)
            if os.access(self.constants_file, os.W_OK):
                print("Warning - This file is not read only!")
                time.sleep(0.1)
                print()
                time.sleep(0.1)
                print()
                time.sleep(0.1)
                print()
        self.test_program_button()
        
        
    def test_program_button(self):
        if not os.path.isfile(self.software_file):
            self.program_button.config(state='disable')
        elif not os.path.isfile(self.constants_file):
            self.program_button.config(state='disable')
        else:
            self.program_button.config(state='normal')
    
    
    def program_button_pressed(self):
        try:
            atmel_ice.test_for_app()
        except Exception as e:
            print(e)
            return
            
        import join_software_and_data as join
        
        image,json_data = join.join_software_and_data(self.software_file, self.constants_file)
        output_file = os.path.abspath('../support_scripts/ddm_motor_plus_sys_consts.hex')
        f = open(output_file, 'w')
        image.write_hex_file(f)
        json.dump(json_data, f)                 # Add the JSON data to the end of the file
        f.close()
        print("Downloading...")
        err = atmel_ice.download_app_from_file(output_file)
        if err != 0:
            print("Error %d" % err)
        else:
            print("Completed")
    
    # This function catches the script being closed performs actions required before the app closes. E.g. logging data
    def destroy(self):
        gui.app.destroy(self)
    
            
        
# This code starts the app if the file is executed rather than imported.
if __name__ == '__main__':
    sys_stdout = sys.stdout
    # Run the script
    app = this_app(parent=tkinter.Tk(), title=APP_TITLE, debug_level=0)
    app.mainloop()
    sys.stdout = sys_stdout


# End of Python script --------------------------------------- */
