#-------------------------------------------------------------------------------
# Name:        join software and data library
# Purpose:     Provide functions for joining software and system constants data
#
# This library basically provides the join_software_and_data() function.
#
# Author:      Mike Morgan
#
# Created:     01/12/2016
# Copyright:   (c) Dyson 2016
#-------------------------------------------------------------------------------

import os
import sys
import string
import time
import json
import project_xlrd as xlrd      # Library for reading Excel spreadsheets
import hex_file                  # Library for handling hex file data
import binascii
import math


debug_level = 0
TICKS_PER_US = 48
bootloader_size = 0x2400

def join_software_and_data_set_debug_level(level):
    global debug_level
    debug_level = level

#
# Define script error class
#
class ScriptError(ValueError):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)

# Define function for raising errors in script. Pre-pend the error message with the script name and re-raise.
def error(error_message):
    raise ScriptError("program_flash_cmd: %s" % error_message)

#
# Return an Excel style cell coordinate (e.g.  C33, BZ79) based on the coordiantes given.
# The coordinates range from 0 onwards. Maximum col coordinate is 17576
#
def ExcelCoord(row, col):
    str = ''
    if col >= 26*26:
        str = str + string.ascii_uppercase[(col // (26*26))-1]
        col = col % (26*26)
    if col >= 26:
        str = str + string.ascii_uppercase[(col // 26)-1]
        col = col % 26
    str = str + string.ascii_uppercase[col]
    str = str + '%d' % (row+1)
    return str


#
# This function scans the given worksheet for cells containing comments with 'EXCEL_PARSE:'. If a cell is found, it is added to
# the dictionary
#    key                         - The name specified with EXCEL_PARSE:name=example  (mandatory)
#    item[key]['value']          - The cell string value where the comment was found
#    item[key]['location']       - The location of the cell e.g. 'A7'
#    item[key]['worksheet_name'] - The name of the worksheet where the cell was found
#    item[key]['filename']       - The name of the worksheet where the cell was found
#    item[key]['full_location']  - filename:worksheet_name:cell_location
#
def scan_worksheet(worksheet, spreadsheet_filename, worksheet_name):
    result = dict()
    # Check if there is a prefix
    prefix=''
    search = 'EXCEL_PARSE:prefix='
    for row,col in worksheet.cell_note_map:
        cell_comments = worksheet.cell_note_map[row,col].text.replace('\n', ' ') + ' '
        if search in cell_comments:
            if prefix != '':
                error("Worksheet %s has more than one '%s'" % (worksheet_name, search))
            i = cell_comments.find(search) + len(search)
            prefix = cell_comments[cell_comments.find(search) + len(search):].split(' ')[0]

    # Iterate through every cell of the worksheet
    for row,col in worksheet.cell_note_map:
        # Note: row and col start from 0
        cell_comments = ''
        cell_text = ''
        d = dict()

        # Get the cell value and cell comments
        cell_comments = worksheet.cell_note_map[row,col].text.replace('\n', ' ') + ' '
        cell_text = str(worksheet.cell_value(row, col)).strip()
        # Add data about the cell
        d['value'] = cell_text
        d['location'] = ExcelCoord(row, col)
        d['worksheet_name'] = worksheet_name
        d['filename'] = spreadsheet_filename
        d['full_location'] = d['filename'] + ':' + d['worksheet_name'] + ':' + d['location']
        # Search the comments for EXCEL_PARSE:x=y  and add to 'd' as  d[x]=y
        while cell_comments.find('EXCEL_PARSE:') != -1:
            i = cell_comments.find('EXCEL_PARSE:');
            cell_comments = cell_comments[i + len('EXCEL_PARSE:'):]
            s = cell_comments.split('=')
            try:
                s[1] = s[1][:s[1].find(' ')]
            except:
                pass
            d[s[0]] = s[1]
                
        # If the cell type was not defined, set it to normal
        if not 'type' in d:
            d['type'] = 'normal'
            
        x = col
        # If the item is a 2D map, add the map.
        if d['type'] == '2D':
            # 2D map
            cell_data = []
            y = row
            while y < worksheet.nrows and str(worksheet.cell_value(y, col)).strip() != '':
                row_data = []
                x = col
                cols = len(worksheet.row(y))
                while x < cols and str(worksheet.cell_value(y, x)).strip() != '':
                    row_data.append(str(worksheet.cell_value(y, x)).strip())
                    x += 1
                y += 1
                cell_data.append(row_data)
            d['value'] = cell_data
            d['width'] = x - col
            d['height'] = y - row
            # Check the map has the same number of elements in all rows
            for row_data in cell_data:
                if len(row_data) != d['width']:
                    error("Table at %s:%s has uneven row lengths." % (worksheet_name, ExcelCoord(row, col)))
         
        # If the item is a 1D map, add the map. Add until we find an empty cell.
        if d['type'] == '1D_ACROSS':
            # 1D map downwards
            cell_data = []
            row_data = []
            x = col
            cols = len(worksheet.row(row))
            while x < cols and str(worksheet.cell_value(row, x)).strip() != '':
                row_data.append(str(worksheet.cell_value(row, x)).strip())
                x += 1
            cell_data.append(row_data)
            d['value'] = cell_data
            d['width'] = x - col
            d['height'] = 1
                    
        # If the item is a 1D map, add the map. Add until we find an empty cell.
        if d['type'] == '1D_DOWN':
            # 1D map downwards
            cell_data = []
            col_data = []
            y = row
            while y < worksheet.nrows and str(worksheet.cell_value(y, col)).strip() != '':
                col_data.append(str(worksheet.cell_value(y, col)).strip())
                y += 1
            cell_data.append(col_data)
            d['value'] = cell_data
            d['width'] = y - row  # Even though the map is vertical, we set the width - this makes the map formatting irrelevent
            d['height'] = 1
                    
        # Only add the cell if there was 'EXCEL_PARSE:name=x'. Add the cell to result using the name
        if 'name' in d:
            # Check there is not an existing cell with the same name.
            if prefix+d['name'] in result:
                cell1 = d['full_location']
                cell2 = result[d['name']]['full_location']
                raise Exception("Cell duplicate found: %s has same name as %s" % (cell1, cell2))
            # Add the cell to the collection of cells.
            if d['name'] != 'worksheet_type':
                result[prefix+d['name']] = d
            else:
                result[d['name']] = d
    
    # Return a dictionary of cells were the key is specified by 'EXCEL_PARSE:name='.
    
    return result
    
    
#
# This function scans the given spreadsheet. It returns two objects  general_data and mode_data.
# generat_data is a dict() of all GENERAL worksheets, mode_data is an array of dicts() of all MODE
# worksheets.  A cell with a comment 'EXCEL_PARSE:name=worksheet_type' and a value MODE or GENERAL
# will set the worksheet type. There may be server GENERAL worksheets where the data gets put into
# 'general_data'. A mode worksheet gets put into a single dict and added to the mode_data array.
#
# Each the key of the dict() if the name supplied in the comment   e.g.  EXCEL_PARSE:name=the_key
# This gives access to another dict
#    item[key]['value']          - The cell string value where the comment was found
#    item[key]['location']       - The location of the cell e.g. 'A7'
#    item[key]['worksheet_name'] - The name of the worksheet where the cell was found
#    item[key]['filename']       - The name of the worksheet where the cell was found
#    item[key]['full_location']  - filename:worksheet_name:cell_location
#    item[key]['comment_lhs']    - comment_rhs  e.g. EXCEL_PARSE:units=hello
#    
#
#    
def ReadSpreadsheet(spreadsheet_filename):
    general_data = dict()
    mode_data = []
    if debug_level >= 1:
        print("DEBUG: Opening spreadsheet %s" % spreadsheet_filename)
    try:
        workbook = xlrd.open_workbook(spreadsheet_filename)
    except:
        error("Unable to open .xls spreadsheet %s" % spreadsheet_filename)
    # Iterate through worksheets
    for worksheet_name in workbook.sheet_names():
        if debug_level >= 1:
            print("DEBUG: Opening worksheet %s" % worksheet_name)
        worksheet = workbook.sheet_by_name(worksheet_name)
        # Check that the worksheet has a comment
        if len(worksheet.cell_note_map) == 0:
            # Because of a bug in xlrd 0.9.3, worksheets get mixed up if one does not have a comment.
            # The worksheet without a comment will have to have a comment. The comment does not need to say anything.
            error("At least one worksheet is devoid of comments. Every worksheet must have at least one comment.")
        # Read all the cells into a dictionary
        worksheet_data = scan_worksheet(worksheet, spreadsheet_filename, worksheet_name)
        # If there were no data items, add one which specifies the 
        if len(worksheet_data) == 0:
            worksheet_data['worksheet_type'] = dict()
            worksheet_data['worksheet_type']['value'] = 'GENERAL'
            worksheet_data['worksheet_type']['worksheet_name'] = worksheet_name
            worksheet_data['worksheet_type']['spreadsheet'] = spreadsheet_filename
            worksheet_data['worksheet_type']['location'] = ''
            worksheet_data['worksheet_type']['full_location'] = ''
        
        if not 'worksheet_type' in worksheet_data:
            error("Worksheet '%s' does not seem to have a worksheet type defined" % worksheet_name)
        elif worksheet_data['worksheet_type']['value'] == 'GENERAL':
            # Add the items to general_data - but ensure there are not duplicates
            for key,item in worksheet_data.items():
                # Ensure the item has not been duplicated in another worksheet
                if key == 'worksheet_type':
                    pass # We don't add the worksheet type
                elif key in general_data:
                    error("Item '%s' duplicated in %s and %s" % (key, item['full_location'], general_data[key]['full_location']))
                else: # Add to general_data
                    general_data[key] = item
        elif worksheet_data['worksheet_type']['value'] == 'MODE':
            # Append the worksheet data to the array of mode worksheets
            mode_data.append(worksheet_data)
        else:
            error("Unknown worksheet type '%s' at %s" % (worksheet_data['worksheet_type']['value'], worksheet_data['worksheet_type']['full_location']))

    return general_data, mode_data

# Functions used for converting units. The names correspond to the units specified in the EMAG spreadsheet.
def US_TO_TICKS(value):   return value * TICKS_PER_US
def MS_TO_TICKS(value):   return value * TICKS_PER_US * 1000
def MHZ_TO_TICKS(value):  return TICKS_PER_US / value
def HZ_TO_TICKS(value):   return TICKS_PER_US * 1e6 / value
def KRPM_TO_TPR(value):   return (1000000.0 / ((value*1000.0)/60.0)) * TICKS_PER_US  # krpm to ticks per revolution
def TIMES_1000(value):    return value * 1000
def TIMES_10(value):      return value * 10
def TIMES_2(value):       return value * 2
def FP16(value):    return int((value * 1.0) * (1<<16))    # Represents values from +- 0.49998.. 0.00002
def FP15(value):    return int((value * 1.0) * (1<<15))   # Represents values from +- 0.99997.. 0.00003
def FP8(value):    return int((value * 1.0) * (1<<8))   # Represents values from +- 0.99997.. 0.00003
def ASCII_TO_HEX(value):  return int(ord(value))         # this is to return the hex


#
# This class handles the binary image
#
class ImageData():
    def __init__(self, hex):
        self.stored_addresses = dict()
        self.hex = hex
        self.data_ptr = hex.maxaddr() + 1  # This value is used to keep track of the data added to flash
        self.general_addr = None           # This value is address that the general data is stored at

    # This function is called when a struct member has 'func:version_string' in the comments.  It records where the version string should be stored.
    def version_string(self, member):
        if 'version_string_ptr' in self.stored_addresses:
            raise Exception("'func:version_string' has been specified twice")
        self.stored_addresses['version_string_ptr'] = self.hex.write_addr
        self.hex.write_value(0, 'uint32_t', description='Version string pointer - yet to be calculated')
        return None, None   # We have already written the value, so we don't want to write another

    # This function is called when a struct member has 'func:mode_array' in the comments. It records where the array of power mode pointers should be stored.
    def mode_array(self, member):
        if 'mode_array' in self.stored_addresses:
            raise Exception("'func:mode_array' has been specified twice")
        self.stored_addresses['mode_array'] = self.hex.write_addr
        for i in range(member['size'] // 4):
            self.hex.write_value(0, 'uint32_t', description='Mode data pointer - yet to be calculated')
        return None, None   # We have already written the value, so we don't want to write another

    # This function is called when a struct member has 'func:trig_table' in the comments.
    # It generates a trigonometric look-up table.
    def trig_table(self, member):
        name = member['name']
        scale = {'uint8_t': 256, 'uint16_t': 65536}[member['member_type']]
        steps = member['array_size'] - 1
        if name == 'sin_table':
            fn = lambda x: math.sin(x / steps * math.pi / 2) * scale
        elif name == 'asin_table':
            fn = lambda x: math.asin(x / steps) * scale / math.pi
        elif name == 'cosec_table':
            fn = lambda x: scale / math.sin(max(x, 1) / steps * math.pi / 2) / 64
        else:
            error("Unknown trigonometric table '%s'." % name)
        for x in range(steps + 1):
            value = round(fn(x))
            if value >= scale:
                value = scale - 1   # saturate
            text = 'NO_OUTPUT'
            if x == 4:
                text = '...'
            elif x < 4 or x > steps - 3:
                text = 'Table %s...[%d]' % (name, x)
            self.hex.write_value(value, member['member_type'], text)
        return None, None
        
    # Insert the given map data to the image and return the image address
    def insert_table(self, name_of_map, units, type, data, low_memory, member_data, constants):
        print('Data (%s)' % name_of_map)
        
        # Is there a flag present which prevents that map from loading?
        try:
            # Is there a flag present to prevent the table from being loaded (it must have the value 'Calculated')
            if constants[name_of_map+'_load_flag']['value'] == 'Calculated': 
                print("Map data not added. Values will be calculated.")
                # If so, return NULL and don't change the low memory marker
                return 0, low_memory
        except: # This may happen if there is no flag to prevent the map from being loaded.
            pass
        
        map_data = data['value']
        # If data is 1D make it 2D
        try:
            elements = len(map_data) * len(map_data[0])
        except:
            map_data = [map_data]
        elements = len(map_data) * len(map_data[0])
        width = len(map_data[0])
        height = len(map_data)
        
        # Determine the array element type
        type = type.replace('*', '')
        if type == 'int8_t' or type == 'uint8_t' :
            element_size = 1
        elif type == 'int16_t' or type == 'uint16_t' :
            element_size = 2
        elif type == 'int32_t' or type == 'uint32_t' :
            element_size = 4
        elif type == 'int64_t' or type == 'uint64_t' :
            element_size = 8
        elif type == 'float':
            element_size = 4
        elif type == 'double':
            element_size = 8
        else:
            element_size = 4
        
        # Is the map a [] array
        if 'array_size' in member_data:
            inline_array = True
            data_size = len(map_data) * len(map_data[0]) * element_size
            if data_size != member_data['size']:
                raise ScriptError("Array/Map %s seems to be the wrong memory size. Expected=%d, Actual=%d" % (name_of_map, member_data['size'], data_size))
        else:
            # Reserve memory
            inline_array = False
            old_data_ptr = self.hex.write_addr
            self.data_ptr = low_memory
            map_addr = self.get_memory(element_size * width * height, align=element_size)
            # Write the ptr to the data
            self.hex.set_write_addr(map_addr)
        
        # Write the data
        max_map_lines = 10
        map_line = 1
        for row in range(len(map_data)):
            for col in range(len(map_data[row])):
                map_line += 1
                value_str = map_data[row][col]
                try:
                    if value_str.find('`') != -1:
                        value_str = value_str[:value_str.find('`')]
                    if units != None:
                        if units.find('VALUE') == -1:
                            value = eval(units + '(' + value_str + ')')
                        else:
                            value = eval(units.replace('VALUE', value_str))
                    else:
                        value = eval(value_str)
                    if (type != 'float') and (type != 'double'):
                        value = int(value)
                except:
                    error("Could not evaluate %s as an integer." % value_str)
                text = 'NO_OUTPUT'
                if map_line == max_map_lines:
                    text = '...'
                elif map_line < max_map_lines:
                    text = 'Map %s[%d,%d]' % (name_of_map, row, col)
                self.hex.write_value(value, type, text)
                
        if inline_array:
            # An inline array does not have to return value and size, the data is already written
            return None, None
            
        # Restore the write ptr to the original value
        self.data_ptr = old_data_ptr
        self.hex.set_write_addr(old_data_ptr)
        return map_addr, map_addr + (element_size * width * height)
        
     
    # Use the struct 'struct_name' to add data to the hex image
    def add_data_struct(self, struct_name, struct, constants, prefix=''):
        # Calculate the size of the data structure and the memory address after the data structure.
        size = 0
        for member in struct:
            size += member['size']
        low_memory = self.data_ptr + size
        
        for member in struct:
            value = None
            units = None
            default = ''

            # Get the units - if they are defined
            try:
                units = constants[prefix + member['name']]['units']
            except:
                pass
                
            if 'func' in member['comment_data']:
                # Is the member a special item that has it's own Python function?
                try:
                    value, units = eval('self.' +  member['comment_data']['func'] + '(member)')
                except:
                    error("Could not use function %s in %s" % (member['comment_data']['func'], struct_name))
                    
            elif 'map_width' in member['comment_data']:
                # Is the member a width of the specified map? (1D or 2D)
                name_of_map = prefix + member['comment_data']['map_width']
                try:
                    value = '%d' % constants[name_of_map]['width']
                except:
                    if 'default' in member['comment_data']:
                        value = member['comment_data']['default']
                        default = '[DEFAULT] '
                        units = None
                    else:
                        error("Unknown map '%s'" % name_of_map)
                    
            elif 'map_height' in member['comment_data']:
                # Is the member a height of the specified map? (2D)
                name_of_map = prefix + member['comment_data']['map_height']
                try:
                    value = '%d' % constants[name_of_map]['height']
                except:
                    if 'default' in member['comment_data']:
                        value = member['comment_data']['default']
                        default = '[DEFAULT] '
                        units = None
                    else:
                        error("Unknown map '%s'" % name_of_map)
                    
            elif 'map' in member['comment_data']:
                # Is the member a map?
                name_of_map = prefix + member['comment_data']['map']
                try:
                    value, low_memory = self.insert_table(name_of_map, units, member['member_type'], constants[name_of_map], low_memory, member, constants)
                    if value != None: value = '%s' % value
                    units = None
                except:
                    if 'default' in member['comment_data']:
                        value = member['comment_data']['default']
                        default = '[DEFAULT] '
                        units = None
                    else:
                        error("Unknown map '%s'" % name_of_map) # Or possibly an exception in 'insert_table'
                    
            # Is the member actually a struct?
            elif member['member_type'] in json_data['structs']:
                # Do a bit of recursion to add the struct.
                self.add_data_struct(member['member_type'], json_data['structs'][member['member_type']], constants, prefix=member['name']+'.')
            
            elif not (prefix + member['name']) in constants:
                if 'default' in member['comment_data']:
                    value = member['comment_data']['default']
                    default = '[DEFAULT] '
                    units = None
                else:
                    error("Could not find '%s' in spreadsheet" % (prefix + member['name']))
                
            else:
                value = constants[prefix + member['name']]['value']
                
            # What if the member is an array?
            if value == None:
                values = []
            elif not 'array_size' in member:
                # This is a normal single value element. Make 'values' a single element array
                values = [ value ]
            else: # The member is a C array []
                # Was a 1D array of values found in the system constants? If there was, value would be an array
                if type(value) is list:
                    if member['array_size'] != len(value[0]):
                        error("Array size mis-match %s. System constants=%d elements, C array=%d elements" % (prefix + member['name'], member['array_size'], len(value[0])))
                    values = value[0]  # value would be a 2D array - we just want a 1D array
                else: # Probably using default values
                    values = []
                    for i in range(member['array_size']):
                        values.append(value)

            # We use a for loop just in case the member is an array
            for value in values:
                if value.find('`') != -1:
                    value = value[:value.find('`')]
                if units == None:
                    pass # No units defined, just use raw value
                elif units.find('VALUE') == -1:
                    # Simple units definitions e.g. EXCEL_PARSE:units=TIMES_1000
                    value = constants[prefix + member['name']]['units'] + '(' + value + ')'
                else:
                    # Complex units definition e.g.  EXCEL_PARSE:units=VALUE*22.3  or  EXCEL_PARSE:units=KRPM_TO_TPR(VALUE)
                    value = constants[prefix + member['name']]['units'].replace('VALUE', value)
                try:
                    value = eval(value)
                    if (member['member_type'] != 'float') and (member['member_type'] != 'double'):
                        value = int(value)
                except:
                    error("Could not evaluate %s as an integer." % value)
                if 'max' in member['comment_data']:
                    max = eval(member['comment_data']['max'])
                    if value > max:
                        error("Maximum value exceeded for %s. Maximum=%d, Value=%d" % (prefix + member['name'], max, value))
                if 'min' in member['comment_data']:
                    min = eval(member['comment_data']['min'])
                    if value < min:
                        error("Minimum value exceeded for %s. Minimum=%d, Value=%d" % (prefix + member['name'], min, value))
                self.hex.write_value(value, member['member_type'], description=default+prefix+member['name'])
                
        # Set the data ptr to after the data (+ maps)
        return low_memory
                
    # Reserve a section of memory. We reserve memory from the end of software upwards. But if we hit the memory reserved for the
    # general data, we skip and assign from the end of general data onwards.
    # By default, align on a word boundry
    def get_memory(self, size, align=4):
        start = self.hex.find_free_memory(size, align=align)
        self.hex.invalidate_memory(start, size)
        return start
        ## If the pointer is not aligned as we required it, increment until it is
        #while (self.data_ptr % align) != 0:
        #    self.data_ptr += 1
        ## Does the data overlap the general data area?
        #if ((self.data_ptr + size) > self.general_addr) and (self.data_ptr < self.min_eeprom_size):
        #    # Skip over general data
        #    self.data_ptr = self.min_eeprom_size
        #self.hex.set_write_addr(self.data_ptr)
        #return self.data_ptr
    

#
# This function is given the speadsheet and hex file. It will combine the two into a new image and return
# a flash image. The comment (if specified) is added to the release string for the image.
#
# The object returned is an HexFile class object (from hex_file.py) 
#    
def join_software_and_data(software_hex, spreadsheet, comment=None):
    global json_data
    
    print("Joining %s with %s" % (software_hex, spreadsheet))
    # Get data from spreadsheet
    general_data, mode_data = ReadSpreadsheet(spreadsheet)

    # Get JSON data from hex file
    json_data = None
    try:
        f = open(software_hex, 'r')
        for line in f:
            if len(line) > 0:
                if line[0] == '{':
                    json_data = json.loads(line)
    except:
        pass
    if json_data == None:
        error("Could not load JSON data from %s" % software_hex)
        
    # Get software image from hex file
    try:
        hex = hex_file.HexFile(software_hex)
    except:
        error("Could not load hex data from %s" % software_hex)
        
    # Calculate the size of the tFsh_systemConstants data structure
    struct = json_data['structs']['tFsh_systemConstants']
    general_size = 0
    for member in struct:
        general_size += member['size']
    
    # Add the 'general data' data structure
    image_data = ImageData(hex)
    image_data.general_addr = json_data['variables']['g_fsh_systemConstants']['addr']    # Start writing the general data just about the 64K boundary as it is ~ 16Kbytes long
    
    image_data.hex.set_write_addr(image_data.general_addr)
    image_data.add_data_struct('tFsh_systemConstants', json_data['structs']['tFsh_systemConstants'], general_data)
    image_data.hex.invalidate_memory(image_data.general_addr, general_size)
    
    # Add the version string
    #
    
    print("Add version string: ", end="")
    if not 'version_string_ptr' in image_data.stored_addresses:
        raise Exception('func:version_string was not specified in tFsh_systemConstants')
    version_str = ''
    if comment != None:
        version_str = comment + '\n'
    version_str += json_data['version_string']
    version_str += '\n' + general_data['sysvar_version']['value']
    version_str += ' (' + os.path.basename(spreadsheet) + ' ' + time.strftime('%Y/%m/%d %H:%M:%S', time.gmtime(os.path.getmtime(spreadsheet))) +') '
    if os.access(spreadsheet, os.W_OK):           # If the spreadsheet file is not read-only, it may have been modified from the official version.
        version_str += ' (May be modified)'
    
    # Ensure version string is not over 255 bytes
    version_str = version_str[:254]
    
    print("'%s'" % version_str.replace('\n', '<CR>'))
    version_str += '\0' # Add the required null byte
    # Write the version string pointer
    str_addr = image_data.get_memory(len(version_str))
    image_data.hex.write_value(str_addr, 'uint32_t', addr=image_data.stored_addresses['version_string_ptr'], description='Version string pointer')
    image_data.hex.set_write_addr(str_addr)
    # Write the version string data
    for c in version_str:
        image_data.hex.write_value(ord(c), 'uint8_t', description = 'Version string data')
    image_data.data_ptr = image_data.hex.write_addr
    # Remove the version string address
    del image_data.stored_addresses['version_string_ptr']

    # We have to ensure addresses without a value are set to 0xff
    last_addr = 0
    for i in image_data.hex.addresses():
        for j in range(last_addr, i):
            image_data.hex[j] = 0xff
        last_addr = i+1
        
    # Write the image size 
    image_size = 1+ image_data.hex.maxaddr() - bootloader_size
    print("Meta data size %.8x" % bootloader_size)    
    meta_data_size  = image_data.hex[bootloader_size + 28]
    meta_data_size += image_data.hex[bootloader_size + 29] * 256
    meta_data_size += image_data.hex[bootloader_size + 30] * 256 * 256
    meta_data_size += image_data.hex[bootloader_size + 31] * 256 * 256 * 256
    image_size -= meta_data_size
    
    # Round up to the nearest chunk size in this case 64. This is IMPORTANT as the Ebox bootloader version calculates CRC across chunk granularity so need to pad image to a chunk granularity
    while (image_size & 63) != 0:
        image_data.hex[image_data.hex.maxaddr()+1] = 0xff
        image_size += 1
    print("image_size(excluding bootloader) is =0x%08x, %d bytes" % (image_size,image_size))
    print("image_size(including bootloader and supporting app meta data) is =0x%08x %d bytes" % ((image_size+bootloader_size+meta_data_size),(image_size+bootloader_size+meta_data_size)))
    
    # The bootloader doesn't use this only the APP does when working out the CRC !!!
    image_data.hex[bootloader_size + 4] = (image_size >> 0) & 0xff
    image_data.hex[bootloader_size + 5] = (image_size >> 8) & 0xff
    image_data.hex[bootloader_size + 6] = (image_size >>16) & 0xff
    image_data.hex[bootloader_size + 7] = (image_size >>24) & 0xff
    
    # Calculate the CRC
    crc_addr  = bootloader_size + 8  # Location 8-11 in the meta data
    crc_start = crc_addr + 4
    crc_end   = image_data.hex.maxaddr() + 1
    
    b = bytearray()
    for i in range(crc_start, crc_end):
        b.append(image_data.hex[i])
    crc = binascii.crc32(b)
    print("image crc=0x%08x" % crc)
    image_data.hex[crc_addr + 0] = (crc >> 0) & 0xff
    image_data.hex[crc_addr + 1] = (crc >> 8) & 0xff
    image_data.hex[crc_addr + 2] = (crc >>16) & 0xff
    image_data.hex[crc_addr + 3] = (crc >>24) & 0xff

    return image_data.hex, json_data
    
