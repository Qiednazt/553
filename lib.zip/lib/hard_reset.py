#-------------------------------------------------------------------------------
# Name:        hard_reset.py
# Purpose:     Force a hard reset should a board become unresponsible.
#              The core code has been copied from the 505 motor control script.
#
# Author:      A. Gavel
#
# Created:     25/05/2018 
# Copyright:   (c) Dyson 2018
#-------------------------------------------------------------------------------

import sys                       # Standard Python library
import os                        # Standard Python library
import os.path
import subprocess
            
def reset_board():
    # Force a hard reset
    args = ("atmelice", "atsamc21e18a")   
    folder = os.environ['TOOLS_DIR'].replace('\\', '/') + '/atmel_flash_programmer/atprogram/atbackend'
    cmd = '"%s/atprogram" --tool %s --interface swd --device %s reset 2>&1' % ((folder,) + args)
    try:
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.PIPE)
        while True:
            line = proc.stdout.readline()
            print(line.strip().decode("utf-8"))
            if not line: break
        proc.wait()
    except:
        print("Error resetting device")
