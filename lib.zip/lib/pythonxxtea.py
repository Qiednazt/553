'''XXTEA encryption and decryption.


DESCRIPTION
============
The PythonXXTEA class is a pure Python implementation of XXTEA encryption and
decryption algorithms, based on the source code from Wikipedia:

    https://en.wikipedia.org/wiki/XXTEA
    
This is an improved version of the source code from Needham and Wheeler's
original implementation, described in the following reference:

    David J. Wheeler and Roger M. Needham (October 1998).
    "Correction to XTEA".
    Computer Laboratory, Cambridge University, England.

The original C-code algorithm relies on 32-bit unsigned integer arithmetic.
Care has been taken to emulate 32-bit unsigned arithmetic in Python code by
ANDing any results that may exceed the range 0 .. 4294967295 with the
bit-mask 0xFFFFFFFF.

This Python implementation is compatible with recent versions of both
Python 3 and Python 2.


LICENSING
=========
Copyright(c) Dyson Technology Ltd 2019. All Rights Reserved.

'''

__docformat__ = 'javadoc'


# Imports
import struct
from copy import copy

# random number generator for crypto applications
try:
    from secrets import randbelow               # Python 3.6+
except ImportError:
    from random import SystemRandom             # Python 2, Python 3.5-
    randbelow = SystemRandom().randrange


#############################################################################
# PythonXXTEAException class definition
#############################################################################

class PythonXXTEAException(Exception):
    '''XXTEA Exception subclass.'''
    pass


    
#############################################################################
# PythonXXTEA class definition
#############################################################################

class PythonXXTEA(object):
    '''XXTEA encryption and decryption.
    
    The PythonXXTEA class is a pure Python implementation of XXTEA encryption and
    decryption algorithms, based on the source code from Wikipedia:
    
        https://en.wikipedia.org/wiki/XXTEA
        
    This is an improved version of the source code from Needham and Wheeler's
    original implementation, described in the following reference:
    
        David J. Wheeler and Roger M. Needham (October 1998).
        "Correction to XTEA".
        Computer Laboratory, Cambridge University, England.
        
    The XXTEA block cypher by itself is only suitable for the secure encryption
    or decryption of one fixed-length group of bits called a block. A mode of
    operation describes how repeatedly to apply a cipher's single-block
    operation securely to transform amounts of data larger than a block.  
'''
    
    # class constants
    DELTA = 0x9E3779B9
    KEY_LEN = 16        # key length in bytes
    IV_LEN = 8          # initialization vector length in bytes
    WORD_LEN = 4        # encryption/decryption word length in bytes
    BLOCK_LEN = 8       # block cipher mode block size in bytes


    #####  PUBLIC METHODS  #####

    @classmethod
    def get_random_iv(cls):
        '''Generate a new random initialization vector (IV).
        
        @return     New IV as a bytearray of length cls.
        '''
        iv_list = []
        for i in range(cls.IV_LEN):
            iv_list.append(randbelow(256))
        return bytearray(iv_list)


    @classmethod
    def pad(cls, data_in, padding=0x00):
        '''Append padding bytes to the data, if necessary.

        Add padding bytes to the end of the data, if necessary to satisy the
        following requirements for XXTEA encoding:
        - The number of bytes must be an exact multiple of 4.
        - The number of data bytes must be at least 8.
          
        @param  data_in         bytearray data.
        @param  padding         The byte value to use as padding.
        
        @return (data, n)       Where: data = padded data.
                                       n    = number of bytes of padding added.
        '''
        data = copy(data_in)                # create a copy to avoid changing data_in
        n = (- len(data)) % cls.WORD_LEN    # exact multiple of 4 bytes
        if (len(data) + n) < 8:
            n += 4                          # minimum length of 8 bytes
        data += bytearray([padding]) * n
        return (data, n)


    def __init__(self, key, byteorder='<'):
        '''PythonXXTEA class initializer.

        @param  key         Encryption key: a Python bytearray of length 16 bytes.
        
        @param byteorder    Set byte-order, using one of the Python "struct"
                            package's byte-order formatting characters:
                                "<" : little-endian
                                ">" : big-endian
                                "@" : native endianness for the host system.                               
        '''
        self._iv = None
        self._mode = None
        
        # configure little-endian or big-endian byteorder
        if byteorder in ('@', '=', '<', '>', '!'):
            self._byteorder = byteorder
        else:
            raise PythonXXTEAException('Byte order must be one of: "@", "=", "<", ">", "!".')
            
        # convert key to a tuple containing 4 uint32_t values
        if len(key) != self.KEY_LEN:
            raise PythonXXTEAException('Key length must be 16 bytes.')
        self._key = struct.unpack(self._byteorder + 'IIII', key)        


    @property
    def iv(self):
        '''Initialization vector (IV).'''
        iv = self._iv
        if iv is not None:
            iv = bytearray(struct.pack(self._byteorder + 'Q', iv))  # uint64_t
        return iv


    @property
    def mode(self):
        '''Block cipher mode.
            "ECB" : Electronic Codebook
            "CTR" : Counter mode
        '''
        return self._mode


    def encrypt(self, data):
        '''XXTEA encrypt a single block of data.
        
        Input and output data are of type bytearray.  The data length must be
        an exact multiple of 4 bytes, with minimum length 8 bytes. The block
        size is 4 bytes  because of the XXTEA algorithm's reliance on 32-bit
        integer arithmetic.
        
        @param  data    bytearray data of length (n * 4) bytes, where n > 1.
        
        @return         Encrypted bytearray data of the same length as input.
        '''
        if len(data) % self.WORD_LEN != 0:
            raise PythonXXTEAException('Data length must be an exact multiple of {} bytes'.format(self.WORD_LEN))

        # number of blocks
        n = len(data) // self.WORD_LEN
        if n <= 1:
            raise PythonXXTEAException('Data length must be at least 8 bytes.')
            
        # convert input data to uint32_t values
        fmt = 'I' * n
        v = list(struct.unpack(self._byteorder + fmt, data))
        
        # encrypt
        rounds_init = 6 + (52 // n)
        sum = 0
        z = v[n - 1]
        for rounds in range(rounds_init, 0, -1):
            sum = (sum + self.DELTA) & 0xFFFFFFFF
            e = (sum >> 2) & 3
            for p in range(n - 1):
                y = v[p + 1]
                v[p] = (v[p] + self._mx(y, z, sum, p, e)) & 0xFFFFFFFF
                z = v[p]
            p += 1  # increment loop counter on exit, to emulate C for loop
            y = v[0]
            v[n - 1] = (v[n - 1] + self._mx(y, z, sum, p, e)) & 0xFFFFFFFF
            z = v[n - 1]
        # convert output data to bytearray values
        return bytearray(struct.pack(self._byteorder + fmt, *v))


    def decrypt(self, data):
        '''XXTEA decrypt a single block of data.
        
        Input and output data are of type bytearray.  The data length must be
        an exact multiple of 4 bytes, with minimum length 8 bytes. The block
        size is 4 bytes  because of the XXTEA algorithm's reliance on 32-bit
        integer arithmetic.
        
        @param  data    bytearray data of length (n * 4) bytes, where n > 1.
        
        @return         Decrypted bytearray data of the same length as input.
        '''
        if len(data) % self.WORD_LEN != 0:
            raise PythonXXTEAException('Data length must be an exact multiple of {} bytes'.format(self.WORD_LEN))

        # number of blocks
        n = len(data) // self.WORD_LEN
        if n <= 1:
            raise PythonXXTEAException('Data length must be at least 8 bytes.')
            
        # convert input data to uint32_t values
        fmt = 'I' * n
        v = list(struct.unpack(self._byteorder + fmt, data))
        
        # decrypt
        rounds_init = 6 + (52 // n)
        sum = (rounds_init * self.DELTA) & 0xFFFFFFFF
        y = v[0]
        for rounds in range(rounds_init, 0, -1):
            e = (sum >> 2) & 3
            for p in range(n - 1, 0, -1):
                z = v[p - 1]
                v[p] = (v[p] - self._mx(y, z, sum, p, e)) & 0xFFFFFFFF
                y = v[p]
            p -= 1  # decrement loop counter on exit, to emulate C for loop
            z = v[n - 1]
            v[0] = (v[0] - self._mx(y, z, sum, p, e)) & 0xFFFFFFFF
            y = v[0]
            sum = (sum - self.DELTA) & 0xFFFFFFFF
        # convert output data to bytearray values
        return bytearray(struct.pack(self._byteorder + fmt, *v))


    def block_init(self, mode='CTR', iv=None):
        '''Initialize block cipher mode.
        
        @param mode     Block cipher mode:
                            "ECB" : Electronic Codebook
                            "CTR" : Counter mode

        @param  iv      Initialization vector: a bytearray of length 8 bytes.
                        If iv is not supplied, a new random initialization
                        vector is generated when using block cipher mode "CTR".
        '''
        self._mode = mode

        # initialize block cipher mode
        self._mode = mode
        if mode == 'CTR':
            # Counter algorithm implemented for E003 Generic Slave Bootloader
            # generates ciphertext by encrypting a 64-bit vector:
            #    4 LSBytes of v = 4 LSBytes of IV + count
            #    4 MSBytes of v = 4 MSBytes of IV
            self._count = 0
            if iv is None:
                iv = self.get_random_iv();
            self._iv = struct.unpack(self._byteorder + 'Q', iv)[0]  # uint64_t
            self._v = self._iv
        elif mode == 'ECB':
            # In ECB mode the message is divided into blocks and each block is
            # encrypted separately.  No initialization required.
            pass            
        else:
            raise PythonXXTEAException('mode must be "ECB" or "CTR".')


    def block_encrypt(self, data):
        '''XXTEA encrypt one or more data groups in block cypher mode.
        
        All input data blocks, except for the last one, must have length equal
        to an exact multiple of 8 bytes. The last block may be of any length.
        
        In block cipher ECB mode, if the last block is less than 8 bytes long
        padding (0x00) will be added to the end of the input data to make its
        length an exact multiple of 8 bytes.
        
        block_init must be called to initialize block cypher mode before using
        this method to encrypt successive data blocks.
        
        @param  data    bytearray data.
        
        @return         Encrypted bytearray data of the same length as input.
        '''
        outbuf = bytearray()
        if self._mode == 'CTR':
            for i in range(0, len(data), self.BLOCK_LEN):
                buf = bytearray(data[ i : (i + self.BLOCK_LEN) ])            
                # generate ciphertext
                vbytes = bytearray(struct.pack(self._byteorder + 'Q', self._v))
                ciphertext = self.encrypt(vbytes)
                # encrypt input data by XORing with ciphertext
                for i in range(len(buf)):
                    buf[i] = buf[i] ^ ciphertext[i]
                self._increment_count()
                outbuf += buf                
        elif self._mode == 'ECB':
            outbuf = self.encrypt(self.pad(data)[0])
        return outbuf


    def block_decrypt(self, data):
        '''XXTEA decrypt one or more data groups in block cypher mode.
        
        All input data blocks, except for the last one, must have length equal
        to an exact multiple of 8 bytes. The last block may be of any length.
        
        In block cipher ECB mode, if the last block is less than 8 bytes long
        padding (0x00) will be added to the end of the input data to make its
        length an exact multiple of 8 bytes.
        
        block_init must be called to initialize block cypher mode before using
        this method to decrypt successive data blocks.
        
        @param  data    bytearray data.
        
        @return         Decrypted bytearray data of the same length as input.
        '''
        if self._mode == 'CTR':
            # CTR mode: encryption and decryption are symmetrical processes
            return self.block_encrypt(data)
            
        elif self._mode == 'ECB':
            return self.decrypt(self.pad(data)[0])



    #####  PRIVATE METHODS  #####
    
    def _mx(self, y, z, sum, p, e):
        '''Private helper function for XXTEA encryption and decryption.'''
        return (
            ((z >> 5 ^ ((y << 2) & 0xFFFFFFFF)) + (y >> 3 ^ ((z << 4) & 0xFFFFFFFF))) ^ 
            ((sum ^ y) + (self._key[(p & 3) ^ e] ^ z))
        ) & 0xFFFFFFFF


    def _increment_count(self):
        '''Increment block cipher CTR mode counter.

        The counter algorithm implemented for E003 Generic Slave Bootloader
        generates ciphertext by encrypting a 64-bit vector v, where:
           4 LSBytes of v = 4 LSBytes of IV + count
           4 MSBytes of v = 4 MSBytes of IV
           
        where "count" is the number of data blocks processed.
        
        '''
        self._count = (self._count + 1) & 0xFFFFFFFF    # 32-bit
        self._v = (self._iv & 0xFFFFFFFF00000000) | (((self._iv & 0x00000000FFFFFFFF) + self._count) & 0x00000000FFFFFFFF)  # 64-bit

            
if __name__ == '__main__':

    # If module is run as a script, demonstrate XXTEA encoding and decoding
    key = bytearray((0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF, 0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF))
    xxtea = PythonXXTEA(key)
    
    input = bytearray('The quick brown fox jumps over the lazy dog', 'ascii')   # 43 bytes
    (input, padding_len) = xxtea.pad(input)
    print('Padding length = {}'.format(padding_len))
    print('Input data = {}'.format(input))
    
    e = xxtea.encrypt(input)
    print('Encrypted data = {}'.format(e))
    
    d = xxtea.decrypt(e)
    print('Decrypted data = {}'.format(d))
