"""
Copywrite Dyson(C) 2020

API to update the filter mode
"""

from enum import Enum
from sc_protocol import SET_FILTER_FORCE_MODE, GET_FILTER_FORCE_MODE


class StatusModes(Enum):
    """
    Operating modes, must match tFlt_sensingAlgoStatus from arm_position.h
    """
    auto = 0
    clean = 1
    dirty = 2
    blocked = 3


def update_mode(device, mode):
    """
    Update the arm position mode, does not write to eeprom.

    Args:
        device: sc_protocol device to communicate through
        mode: str, int or OperatingModes mode to send

    Returns:
        None
    """
    if isinstance(mode, str):
        int_mode = StatusModes[mode].value
    elif isinstance(mode, StatusModes):
        int_mode = mode.value
    elif isinstance(mode, int) and (mode < len(StatusModes)):
        int_mode = mode
    else:
        raise ValueError("Invalid operating mode {}".format(mode))

    cmd = SET_FILTER_FORCE_MODE(int_mode)
    msg = device.command_messages()
    msg.add(cmd)
    device.send(msg)

def get_mode(device):
    """
    get current arm position mode

    Args:
        device: sc_protocol device to communicate with

    Returns:
        OperatingModes: current value of operating mode

    Raises:
        ValueError: got a bad response
    """
    cmd = GET_FILTER_FORCE_MODE()
    msg = device.command_messages()
    msg.add(cmd)
    device.send(msg)
    return StatusModes(cmd.filter_mode)
