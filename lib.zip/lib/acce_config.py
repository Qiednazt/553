#-------------------------------------------------------------------------------
# Name:        Accelerometer Register Read Write
# Purpose:     This module allows change accelerometer behavior save to eerpom
#
# Authors:     Kai Jie Teo
#
# Created:     07/07/2020
# Copyright:   (c) Dyson Technology Ltd. 2021
#-------------------------------------------------------------------------------

import gui                      # Dyson Simple User Interface library
import sc_protocol as protocol  # Dyson N553 SC comms interface

APP_TITLE = "Accelerometer configuration"
APP_HELP  = "This script allows the user to change accelerometer register value .\n"

# Full stickiness for Tk controls
STICKY_NSEW = gui.N + gui.S + gui.E + gui.W

from pathlib import Path
path = Path.cwd()
accel_cfg_filepath = path.resolve().parent / Path('support_scripts/accel_mcu_config/lid2de12.ini')
print(accel_cfg_filepath)

a = accel_cfg_filepath.exists()
if a ==  True:
    print("Using Old accelerometer (LISD2DE12)")
    # 0: Disable old accelerometer LISD2DE12 and enable the LIS2DW12
    # 1: Enable old accelerometer  LISD2DE12 and disable the LIS2DW12
    CFG_ACCELEROMETER_LIS2DE12_CHIP = 1
else:
    print("Using New accelerometer (LISD2DW12)")
    CFG_ACCELEROMETER_LIS2DE12_CHIP = 0

class this_app(gui.app):
    #
    # Define the controls
    #
    def __init__(self, *args, **kwargs):
        # Process arguments speficic to this application
        if 'device' in kwargs:
            self.device = kwargs['device']
            del kwargs['device']
            self.close_funcs.append(self.device.closing) # Give the application a function which will abort the connection
        else:
            gui.error("'device' is a required named parameter for this app.")

        if 'parent_data' in kwargs:
            self.parent_data = kwargs['parent_data']
            print("Parent data received")
            del kwargs['parent_data']

        # Initialise the base class
        gui.app.__init__(self, *args, **kwargs)

        # Read autostart value and behaviour flags from target

        self.INITIALISE_NUMBER = self.parent_data.ACCELEROMETER_INIT_SIZE
        self.SLEEP_SETTING_NUMBER = self.parent_data.ACCELEROMETER_SLEEP_SETTING_SIZE
        self.WAKE_UP_NORMAL_NUMBER = self.parent_data.ACCELEROMETER_WAKEUP_NORMAL_SIZE
        self.WAKE_UP_INCLINE_NUMBER = self.parent_data.ACCELEROMETER_WAKEUP_INCLINE_SIZE
        self.NUMBER_ENTRY_WIDTH = 3
        self.accelerometer_initWrite = []
        self.accelerometer_sleepWrite = []
        self.accelerometer_normalWrite = []
        self.accelerometer_inclineWrite = []
        self.accelerometer_dynamicThresholdWrite = 0.00

        self.add_text(text='State / Setting')
        self.add_text(text='Read')
        self.add_text(text='Write(in 0xff format)')
        self.newline()

        self.add_text(text='Initialise')
        self.newline()
        if CFG_ACCELEROMETER_LIS2DE12_CHIP == 1:
            self.initialise_reg = ['Ctrl_Reg1(20h)', 'Ctrl_Reg3(22h)', 'Ctrl_Reg5(24h)']
        else:
            self.initialise_reg = ['Ctrl1 (20h)', 'Ctrl2 (21h)', 'Ctrl3( 22h)', 'Ctrl4 (23h)', 'Ctrl5 (24h)', 'X_offs (3ch)', 'Y_offs (3dh)', 'Z_offs (3eh)', 'Ctrl7 (3fh)']
        for i in range(0,self.INITIALISE_NUMBER):
            self.accelerometer_initWrite.append(self.parent_data.accelerometer_init_config[i])
            self.add_text(self.initialise_reg[i])
            self.add_text("0x%02x" % self.parent_data.accelerometer_init_config[i])
            self.accelerometer_initWrite[i] = self.add_input(text="0x%02x" % self.parent_data.accelerometer_init_config[i], tooltip='Enter init setting')
            self.accelerometer_initWrite[i].config(width = self.NUMBER_ENTRY_WIDTH)
            self.newline()

        self.add_line(1500, span=10)
        self.newline()
        self.add_text(text='Enable Sleep Setting')
        self.newline()
        if CFG_ACCELEROMETER_LIS2DE12_CHIP == 1:
            self.sleep_reg = ['CTRL_Reg2(21h)', 'INT1_Ths(32h)', 'INT1_Dur(33h)','Act_ths(3eh)', 'Act_Dur(3fh)','Ctrl_Reg6(25h)']
        else:
            self.sleep_reg = ['Ctrl6 (25h)', 'Tap_ths_x (30h)', 'Wake_up_ths (34h)', 'Wake_up_dur (35h)', 'Ctrl7 (3fh)']
        for i in range(0,self.SLEEP_SETTING_NUMBER):
            self.accelerometer_sleepWrite.append(self.parent_data.accelerometer_sleep_config[i])
            self.add_text(self.sleep_reg[i])
            self.add_text("0x%02x" % self.parent_data.accelerometer_sleep_config[i])
            self.accelerometer_sleepWrite[i] = self.add_input(text="0x%02x" % self.parent_data.accelerometer_sleep_config[i], tooltip='Enter sleep setting')
            self.accelerometer_sleepWrite[i].config(width = self.NUMBER_ENTRY_WIDTH)
            self.newline()

        self.add_line(1500, span=10)
        self.newline()
        self.add_text(text='Wake Up Normal')
        self.newline()
        if CFG_ACCELEROMETER_LIS2DE12_CHIP == 1:
            self.wakeup_normal_reg = ['INT1_Ths(32h)', 'INT1_Dur(33h)', 'CTRL_Reg2(21h)', 'INT1_CFG(30h)' ]
        else:
            self.wakeup_normal_reg = ['Ctrl4 (23h)', 'Wake_up_ths (34h)', 'Ctrl7 (3fh)']
        for i in range(0,self.WAKE_UP_NORMAL_NUMBER):
            self.accelerometer_normalWrite.append(self.parent_data.accelerometer_wakeup_normal_config[i])
            self.add_text(self.wakeup_normal_reg[i])
            self.add_text("0x%02x" % self.parent_data.accelerometer_wakeup_normal_config[i])
            self.accelerometer_normalWrite[i] = self.add_input(text="0x%02x" % self.parent_data.accelerometer_wakeup_normal_config[i], tooltip='Enter wakeup normal setting')
            self.accelerometer_normalWrite[i].config(width = self.NUMBER_ENTRY_WIDTH)
            self.newline()

        self.add_line(1500, span=10)
        self.newline()
        self.add_text(text='Wake Up Incline')
        self.newline()
        if CFG_ACCELEROMETER_LIS2DE12_CHIP == 1:
             self.wakeup_incline_reg = ['INT1_Ths(32h)', 'INT1_Dur(33h)', 'CTRL_Reg2(21h)', 'INT1_CFG(30h)']
        else:        
             self.wakeup_incline_reg = ['Ctrl4 (23h)', 'Wake_up_ths (34h)', 'Ctrl7 (3fh)']
        for i in range(0,self.WAKE_UP_INCLINE_NUMBER):
            self.accelerometer_inclineWrite.append(self.parent_data.accelerometer_wakeup_incline_config[i])
            self.add_text(self.wakeup_incline_reg[i])
            self.add_text("0x%02x" % self.parent_data.accelerometer_wakeup_incline_config[i])
            self.accelerometer_inclineWrite[i] = self.add_input(text="0x%02x" % self.parent_data.accelerometer_wakeup_incline_config[i], tooltip='Enter wakeup normal setting')
            self.accelerometer_inclineWrite[i].config(width = self.NUMBER_ENTRY_WIDTH)
            self.newline()

        self.add_line(1500, span=10)
        self.newline()
        self.accelerometer_dynamicThresholdWrite = self.parent_data.accelerometer_dynamic_threshold
        self.add_text(text="INT1 Dynamic Threshold")
        self.add_text("%0.2f" % self.parent_data.accelerometer_dynamic_threshold)
        self.accelerometer_dynamicThresholdWrite = self.add_input(text="%0.2f" % self.parent_data.accelerometer_dynamic_threshold, tooltip='Enter dynamic threshold setting')
        self.accelerometer_dynamicThresholdWrite.config(width = self.NUMBER_ENTRY_WIDTH)
        self.newline()

        self.add_line(1500, span=10)
        self.newline()
        self.accelerometer_delay_sampling_time = self.parent_data.accelerometer_delay_sampling_time
        self.add_text(text="Delay time(ms) before start sampling:")
        self.add_text("%d" % self.parent_data.accelerometer_delay_sampling_time)
        self.accelerometer_delay_sampling_time = self.add_input(text="%d" % self.parent_data.accelerometer_delay_sampling_time, tooltip='Enter delay time in ms')
        self.accelerometer_delay_sampling_time.config(width = self.NUMBER_ENTRY_WIDTH)

        self.newline()
        self.accelerometer_sampling_count = self.parent_data.accelerometer_sampling_count
        self.add_text(text="Number of sampling count(10ms per count):")
        self.add_text("%d" % self.parent_data.accelerometer_sampling_count)
        self.accelerometer_sampling_count = self.add_input(text="%d" % self.parent_data.accelerometer_sampling_count, tooltip='Enter number of sampling count')
        self.accelerometer_sampling_count.config(width = self.NUMBER_ENTRY_WIDTH)
        self.newline()

        self.accelerometer_inactivity_duration = self.parent_data.accelerometer_inactivity_duration
        if CFG_ACCELEROMETER_LIS2DE12_CHIP == 1:
            self.add_text(text="SC internal inacivity duration (ms, RS_ACC_02_04):")
        else:
            self.add_text(text="SC internal inacivity duration (ms)")
        self.add_text("%d" % self.parent_data.accelerometer_inactivity_duration)
        self.accelerometer_inactivity_duration = self.add_input(text="%d" % self.parent_data.accelerometer_inactivity_duration, tooltip='Enter inactivity duration in ms')
        self.accelerometer_inactivity_duration.config(width = self.NUMBER_ENTRY_WIDTH)
        self.newline()

        self.accelerometer_raw_min_mg = self.parent_data.accelerometer_raw_min_mg
        if CFG_ACCELEROMETER_LIS2DE12_CHIP == 1:
            self.add_text(text="Autopause Raw Minimum Mg (RS_ACC_01_07):")
        else:        
            self.add_text(text="Autopause Raw Minimum Mg (RS_ACC_03_03):")
        self.add_text("%d" % self.parent_data.accelerometer_raw_min_mg)
        self.accelerometer_raw_min_mg = self.add_input(text="%d" % self.parent_data.accelerometer_raw_min_mg, tooltip='Enter the raw min Mg')
        self.accelerometer_raw_min_mg.config(width = self.NUMBER_ENTRY_WIDTH)
        self.newline()

        if CFG_ACCELEROMETER_LIS2DE12_CHIP == 0:
            self.accelerometer_wakeup_threshold = self.parent_data.accelerometer_wakeup_threshold
            self.add_text(text="Autopause Wake Up threshold in Mg (RS_ACC_04_03):")
            self.add_text("%d" % self.parent_data.accelerometer_wakeup_threshold)
            self.accelerometer_wakeup_threshold = self.add_input(text="%d" % self.parent_data.accelerometer_wakeup_threshold, tooltip='Enter the Wake up threshold')
            self.accelerometer_wakeup_threshold.config(width = self.NUMBER_ENTRY_WIDTH)
            self.newline()

        self.add_line(1500, span=10)
        self.newline()
        self.status = self.add_text(text='', span=5)
        self.newline()

        self.add_button("Apply to ram", self.apply_ram_button_pressed, tooltip="Apply config changes to RAM (temporary)", sticky=STICKY_NSEW)
        self.add_button("Apply to EE", self.apply_ee_button_pressed, tooltip="Apply config changes to RAM and save in EEPROM (permanent)", sticky=STICKY_NSEW)
        self.add_button("Restore Default", self.reset, tooltip="Reset to default value", sticky=STICKY_NSEW)
        self.add_button("Clear EEPROM Data", self.clear_eep, tooltip="Clear Accelerometer EEPROM Data", sticky=STICKY_NSEW)

    # Add a horizontal line
    def add_line(self, width=200, height=5, span=1, sticky=STICKY_NSEW, padx=2, pady=2):
        gui.Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = gui.Canvas(self, width=width, height=height)
        x.create_line(0, 2, width-1, 2)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        return x

    def apply_ee_button_pressed(self):
        self.apply_config_to_ram()
        self.parent_data.finalise_accelerometer_config_store_trigger = True
        self.status.change_text("Accelerometer config was finalised in EEPROM")

    def apply_ram_button_pressed(self):
        self.apply_config_to_ram()
        self.status.change_text("Accelerometer config was updated to RAM")

    def apply_config_to_ram(self):
        for i in range(0,self.INITIALISE_NUMBER):
            self.parent_data.accelerometer_init_config[i] = self.accelerometer_initWrite[i].value()

        for i in range(0,self.SLEEP_SETTING_NUMBER):
            self.parent_data.accelerometer_sleep_config[i] = self.accelerometer_sleepWrite[i].value()

        for i in range(0,self.WAKE_UP_NORMAL_NUMBER):
            self.parent_data.accelerometer_wakeup_normal_config[i] = self.accelerometer_normalWrite[i].value()

        for i in range(0,self.WAKE_UP_INCLINE_NUMBER):
            self.parent_data.accelerometer_wakeup_incline_config[i] = self.accelerometer_inclineWrite[i].value()

        self.parent_data.accelerometer_dynamic_threshold = self.accelerometer_dynamicThresholdWrite.value()

        self.parent_data.accelerometer_delay_sampling_time = self.accelerometer_delay_sampling_time.value()
        self.parent_data.accelerometer_sampling_count = self.accelerometer_sampling_count.value()
        self.parent_data.accelerometer_inactivity_duration = self.accelerometer_inactivity_duration.value()
        self.parent_data.accelerometer_raw_min_mg = self.accelerometer_raw_min_mg.value()
        if CFG_ACCELEROMETER_LIS2DE12_CHIP == 0:
            self.parent_data.accelerometer_wakeup_threshold = self.accelerometer_wakeup_threshold.value()
        self.parent_data.set_accelerometer_config_trigger=True

    def reset(self):
        if CFG_ACCELEROMETER_LIS2DE12_CHIP == 1:
            default_value = [   0x2f, 0x40, 0x08, 0x22, 0x7F, 0x7F,
                                0x60, 0x04, 0x08,
                                0x00, 0x05, 0x22, 0x94,
                                0x0D, 0x05, 0x29, 0x2a ]
        else:
            default_value = [   0x64, 0x84, 0x02, 0x20, 0xC0, 0x00, 0x00, 0x00, 0x21,
                                0xC4, 0x00, 0x42, 0x71, 0x21,
                                0x20, 0x00, 0x29,
                                0x20, 0x00, 0x29 ]
        pos = 0
        for i in range(0,self.INITIALISE_NUMBER):
            self.parent_data.accelerometer_init_config[i] = self.accelerometer_initWrite[i].set_value("0x%02x" % default_value[pos+i])

        pos += self.INITIALISE_NUMBER
        for i in range(0,self.SLEEP_SETTING_NUMBER):
            self.parent_data.accelerometer_sleep_config[i] = self.accelerometer_sleepWrite[i].set_value("0x%02x" % default_value[pos+i])

        pos += self.SLEEP_SETTING_NUMBER
        for i in range(0,self.WAKE_UP_NORMAL_NUMBER):
            self.parent_data.accelerometer_wakeup_normal_config[i] = self.accelerometer_normalWrite[i].set_value("0x%02x" % default_value[pos+i])

        pos += self.WAKE_UP_NORMAL_NUMBER
        for i in range(0,self.WAKE_UP_INCLINE_NUMBER):
            self.parent_data.accelerometer_wakeup_incline_config[i] = self.accelerometer_inclineWrite[i].set_value("0x%02x" % default_value[pos+i])

        if CFG_ACCELEROMETER_LIS2DE12_CHIP == 1:
            self.parent_data.accelerometer_dynamic_threshold = self.accelerometer_dynamicThresholdWrite.set_value("%0.2f" % 0.90)
            self.parent_data.accelerometer_delay_sampling_time = self.accelerometer_delay_sampling_time.set_value("%d" % 1000)
            self.parent_data.accelerometer_sampling_count = self.accelerometer_sampling_count.set_value("%d" % 5)
        else:
            self.parent_data.accelerometer_dynamic_threshold = self.accelerometer_dynamicThresholdWrite.set_value("%0.2f" % 1.05)
            self.parent_data.accelerometer_delay_sampling_time = self.accelerometer_delay_sampling_time.set_value("%d" % 100)
            self.parent_data.accelerometer_sampling_count = self.accelerometer_sampling_count.set_value("%d" % 10)

        self.parent_data.accelerometer_inactivity_duration = self.accelerometer_inactivity_duration.set_value("%d" % 3000)
        if CFG_ACCELEROMETER_LIS2DE12_CHIP == 1:
            self.parent_data.accelerometer_raw_min_mg = self.accelerometer_raw_min_mg.set_value("%d" % 800)
        else:
            self.parent_data.accelerometer_raw_min_mg = self.accelerometer_raw_min_mg.set_value("%d" % 300)
            self.parent_data.accelerometer_wakeup_threshold = self.accelerometer_wakeup_threshold.set_value("%d" % 1100)

    def clear_eep(self):
        self.parent_data.clear_accelerometer_eeprom_data_trigger=True

# Called by parent programs
def exec(parent_app, parent_data,device):
    app = this_app(parent=parent_app, parent_data=parent_data,device=device, title=APP_TITLE)
    return app

# Called by parent programs
def description():
    return APP_HELP

# This code starts the app if the file is executed rather than imported.
if __name__ == '__main__':
    # Get a connection to a device
    description()
    print("This is not a atandalone script")

