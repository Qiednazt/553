#-------------------------------------------------------------------------------
# Name:        Main
# Purpose:     This script allows the ADC system to be calibrated (on 553).
#
# Copyright:   (c) Dyson 2021
#-------------------------------------------------------------------------------

import sys                       # Standard Python library
import os                        # Standard Python library
import glob                      # Standard Python library
import time                      # Standard Python library
import tkinter                   # Standard GUI library file dialog box
import gui                       # Dyson Simple User Interface library
import sc_protocol               # Dyson 505 heater controller comms interface
import v9_protocol               # Dyson Ebox motor comms interface
import json                      # Standard Python library
import behaviour_conf            # Behaviour configuration script
import mode_config               # modify heat/flow setting of one mode
import arm_position
import amb_pressure_error
import eol_purging_flow_mode
import eol_purging_time_mode
import filter_mode
from tkinter import messagebox   # Standard GUI library message box
from tkinter import filedialog   # Standard GUI library file dialog box
import datetime
from enum import Enum

if not 'CAL_DATA_DEST' in os.environ:
    os.environ['CAL_DATA_DEST'] = os.environ['PROJECT_DIR']

APP_TITLE = "Manual Board Measurement Calibration GUI"
APP_HELP  = "This script allows the user to calibrate adc offset/slope.\n"

logfile_default_name = "553scProductTuneLog"
logfile_extension = ".csv"

todays_date = datetime.date.today().strftime("%d%b%Y")
logfile_name = logfile_default_name + "_" + todays_date + logfile_extension


# Full stickiness for Tk controls
STICKY_NSEW = gui.N + gui.S + gui.E + gui.W

class this_app(gui.app):
    # Shift factors for the calibration slope words
    # We choose a Q shift factor  to give maximum precision based on expected value range
    NUMBER_ENTRY_WIDTH = 10
    disable_motor_command = 0   # set 1 to disable motor command to test on SC only

    logging = False
    #
    # Define the controls
    #
    def __init__(self, *args, **kwargs):
        # Process arguments speficic to this application
        if 'device' in kwargs:
            self.device = kwargs['device']
            del kwargs['device']
            self.close_funcs.append(self.device.closing) # Give the application a function which will abort the connection
        else:
            gui.error("'device' is a required named parameter for this app.")

        if self.device != None:
            self.device.yeild = self.update     # Tell the protocol to call this function when it enters a long loop

        if 'v9_device' in kwargs:
            self.v9_device = kwargs['v9_device']
            del kwargs['v9_device']

        if 'parent_data' in kwargs:
            self.parent_data = kwargs['parent_data']
            del kwargs['parent_data']

        self.EEP_PCB_CALIBRATION_CHECKSUM_SEED = 100
        self.BUTTON_WIDTH = 12
        self.NUMBER_ENTRY_WIDTH = 12
        self.NUMBER_OUTPUT_WIDTH = 12
        self.EEP_START_MARKER_VALUE = 0x08EE07EE  # Constant written into Each EEPROM section

        self.software_hex = '../application/Objects/553sc.hex'
        self.calibration_valid = False
        self.write_calibration=False
        self.sync_vsens = 0  # By default don't syncronise the VSENSE measurement to the FET duty cycle
        self.read_calibration_from_file=False
        self.read_calibration_from_target=False
        self.refresh_tuning_parameters=False
        # EEPROM Calibration words. These names map to the names in the target EEPROM structure

        self.calibration_data = {}  # The Dictionary to store the calibration data

        self.bootstart_test_gate = 0
        self.offset_cal_adc_state = 0
        self.test_gate = None
        self.hal_reset = False
        self.offset_cal_correction_updated = False
        self.pcb_in_error_state = False
        self.restore_default_calibration = False


        # Initialise the base class
        gui.app.__init__(self, *args, **kwargs)

        print("\nAbout...")
        print("Release string:\n%s\n\n" % self.parent_data.release_string)
        print("Project = %d" % self.parent_data.sw_project)
        print("Component = %d" % self.parent_data.sw_component)
        print("Hardware serial number = %s" % self.parent_data.hw_serial_number)
        print("Software version = %d  0x%08x" % (self.parent_data.sw_version, self.parent_data.sw_version))
        print()


        self.draw_gui()
        self.update_all_calibration_edit_box()

        # Update the display
        self.update_controls()     # Update all currently defined controls
        self.current_ebox_flow_mode = self.parent_data.eboxFlowMode
        self.refresh_v9_tuning_parameters()

        self.after(300, self.periodic)

    def exit_fct(self):
        print("Clearing FCT flag and resetting")
        self.behaviour_flags = dict()
        self.behaviour_flags['fct_mode'] = 0
        self.parent_data.behaviour_flags = self.behaviour_flags
        self.parent_data.set_behavior_flags_trigger = True

        time.sleep(5)

    # Write the calibration to the target
    def write_cal(self):
        self.write_cal_ram()
        self.parent_data.finalise_sc_calibration_trigger=True
        self.parent_data.finalise_v9_calibration_trigger=True




    # Write the calibration to the target ram
    def write_cal_ram(self):
        self.parent_data.eol_air_exit_temp_a_offset  = self.eol_air_exit_temp_a_offset_entry.value()
        self.parent_data.eol_air_exit_temp_b_offset  = self.eol_air_exit_temp_b_offset_entry.value()
        self.parent_data.eol_air_exit_temp_a_slope   = self.eol_air_exit_temp_a_slope_entry.value()
        self.parent_data.eol_air_exit_temp_b_slope   = self.eol_air_exit_temp_b_slope_entry.value()
        self.parent_data.com_aet_flow_rate_4_l_s     = self.com_aet_flow_rate_4_l_s_entry.value()
        self.parent_data.com_aet_flow_rate_6_l_s     = self.com_aet_flow_rate_6_l_s_entry.value()
        self.parent_data.com_aet_flow_rate_9_l_s     = self.com_aet_flow_rate_9_l_s_entry.value()
        self.parent_data.com_aet_flow_rate_12_l_s    = self.com_aet_flow_rate_12_l_s_entry.value()

        self.parent_data.fct_triac_temp_offset        = self.fct_triac_temp_offset_entry.value()
        self.parent_data.fct_triac_temp_slope         = self.fct_triac_temp_slope_entry.value()
        self.parent_data.eol_triac_temp_trip_limit_mV = self.triac_temp_trip_limit_mV_entry.value()
        self.parent_data.eol_power_cap                = self.eol_power_cap_entry.value()
        self.parent_data.eol_rampup                   = self.eol_ramp_entry.value()
        self.parent_data.eol_ilimit                   = self.eol_ilim_entry.value()
        self.parent_data.eol_detach                   = self.eol_detach_entry.value()
        self.parent_data.eol_power_motor_tuning       = self.eol_power_motor_tuning_entry.value()
        self.parent_data.eol_power_r_heater_larm      = self.eol_power_r_heater_larm_entry.value()
        self.parent_data.eol_power_r_heater_rarm      = self.eol_power_r_heater_rarm_entry.value()

        self.parent_data.write_heater_calibration_trigger = True

    # Trigger zero crossing measurement
    def zcross_meas(self):
        msg = self.device.command_messages()
        msg.add(sc_protocol.FCT_ZCROSS_MEAS_CMD())
        self.device.send(msg, timeout=1)

        # Analyse results
        command_result    = msg.results[0].result

        if(command_result == 1):
            self.zc_status_text.change_text('Error - Target error or not in FCT mode')
            self.zc_duty_text.change_text('')
            self.zc_freq_text.change_text('')
        elif(command_result == 2):
            self.zc_status_text.change_text('Fail - No zero crossing signal was found')
            self.zc_duty_text.change_text('')
            self.zc_freq_text.change_text('')
        else:
            frequency = msg.results[0].frequency/256
            dutycycle = msg.results[0].dutycycle/40.96
            self.zc_status_text.change_text('Successful')
            self.zc_duty_text.change_text(dutycycle)
            self.zc_freq_text.change_text(frequency)

    # Trigger all TRIACs testing
    def triacs_test(self):
            self.zc_status_text.change_text('Done')
            self.zc_duty_text.change_text('')
            self.zc_freq_text.change_text('')


    def set_defaults(self):
        self.cal_air_exit_temp_mul_entry.set_value(1)
        self.cal_air_exit_temp_off_entry.set_value(0)
        self.cal_eol_air_exit_temp_off_entry.set_value(1)
        self.write_cal()

    def behaviour_flags_button_pressed(self):
        behaviour_conf.exec(gui.Toplevel(), self.parent_data, self.device)

    # Draw the GUI items
    # Add a horizontal line
    def add_line(self, width=200, height=5, span=1, sticky=STICKY_NSEW, padx=2, pady=2):
        gui.Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = gui.Canvas(self, width=width, height=height)
        x.create_line(0, 2, width-1, 2)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        return x

    def draw_gui(self):
        # Add the device serial number and release string
        #self.status_text = self.add_text(text='S/N='+self.hw_serial_number, span=999, tooltip=APP_HELP)
        #self.newline()
        #self.add_text(text='Release: '+self.release_string, span=10)
        #self.newline()
        #self.add_text(text='Software Build Id: %d' % self.sw_version, span=10)
        #self.newline()
        #self.newline()
        self.add_text(text='Status:')
        self.Status = self.add_text(text='',span=7)
        self.newline()

        self.add_text(text='Current UI mode:')
        self.current_ui_mode_text  = self.add_text(text='')
        self.add_text(text='Current CoolFix:')
        self.current_sensitive  = self.add_text(text='')

        self.add_text(text='Current heat mode:')
        self.current_heat_mode  = self.add_text(text='')

        self.add_text(text='Current heat temp:')
        self.current_heat_temp  = self.add_text(text='')
        self.newline()

        self.add_text(text='Current flow level:')
        self.current_flow_level_name  = self.add_text(text='')
        self.add_text(text='Current ebox flow mode:')
        self.current_ebox_flow_modeName  = self.add_text(text='')
        self.add_text(text='Current flow rate:')
        self.current_flow_rate  = self.add_text(text='')

        self.add_text(text='Idle mode active:')
        self.idle_mode_active  = self.add_text(text='')
        self.newline()

        # Note: AET offset/slope = tmas offset/slope - we do not cal the adc in isolation.
        self.add_text(text='EOL Air_Exit_Temp_A_slope:')
        self.eol_air_exit_temp_a_slope_entry = self.add_input(text=self.parent_data.eol_air_exit_temp_a_slope, tooltip='Enter AET (multiplier) slope(Q10).')
        self.eol_air_exit_temp_a_slope_entry.config(width = self.NUMBER_ENTRY_WIDTH)

        self.add_text(text='EOL Air_Exit_Temp_A_offset:')
        self.eol_air_exit_temp_a_offset_entry = self.add_input(text=self.parent_data.eol_air_exit_temp_a_offset, tooltip='Enter AET offset here(Q6).')
        self.eol_air_exit_temp_a_offset_entry.config(width = self.NUMBER_ENTRY_WIDTH)

        self.add_text(text='EOL Air_Exit_Temp_B_slope:')
        self.eol_air_exit_temp_b_slope_entry = self.add_input(text=self.parent_data.eol_air_exit_temp_b_slope, tooltip='Enter AET (multiplier) slope(Q10).')
        self.eol_air_exit_temp_b_slope_entry.config(width = self.NUMBER_ENTRY_WIDTH)

        self.add_text(text='EOL Air_Exit_Temp_B_offset:')
        self.eol_air_exit_temp_b_offset_entry = self.add_input(text=self.parent_data.eol_air_exit_temp_b_offset, tooltip='Enter AET offset here(Q6).')
        self.eol_air_exit_temp_b_offset_entry.config(width = self.NUMBER_ENTRY_WIDTH)
        self.newline()

        self.add_text(text='FCT Triac_Temp_slope:')
        self.fct_triac_temp_slope_entry = self.add_input(text=self.parent_data.fct_triac_temp_slope, tooltip='Enter ADC (multiplier) slope. (Unity gain slope = 1024.)')
        self.fct_triac_temp_slope_entry.config(width = self.NUMBER_ENTRY_WIDTH)

        self.add_text(text='FCT Triac_Temp_offset:')
        self.fct_triac_temp_offset_entry = self.add_input(text=self.parent_data.fct_triac_temp_offset, tooltip='Enter ADC offset here')
        self.fct_triac_temp_offset_entry.config(width = self.NUMBER_ENTRY_WIDTH)

        self.add_text(text='EOL Triac_Temp_Trip_Limit(mV):')
        self.triac_temp_trip_limit_mV_entry = self.add_input(text=self.parent_data.eol_triac_temp_trip_limit_mV, tooltip='Enter trip value for triac.')
        self.triac_temp_trip_limit_mV_entry.config(width = self.NUMBER_ENTRY_WIDTH)

        self.add_text(text='Accessory Detach(ticks):')
        self.eol_detach_entry = self.add_input(text=self.parent_data.eol_detach, tooltip='HC Accessory Timeout, 1 ticks = 20ms')
        self.eol_detach_entry.config(width = self.NUMBER_ENTRY_WIDTH)
        self.newline()

        self.add_text(text='HC Ramp:')
        self.eol_ramp_entry = self.add_input(text=self.parent_data.eol_rampup, tooltip='HC RampUp')
        self.eol_ramp_entry.config(width = self.NUMBER_ENTRY_WIDTH)

        self.add_text(text='Current flow offset:')
        self.current_flow_offset_entry = self.add_text(text=' ')
        self.current_flow_offset_entry.config(width = self.NUMBER_ENTRY_WIDTH)

        self.newline()
        self.add_line(1900, span=8)
        self.newline()

        self.add_text(text='HC Current Limit(mA):')
        self.eol_ilim_entry = self.add_input(text=self.parent_data.eol_ilimit, tooltip='HC Current Limit')
        self.eol_ilim_entry.config(width = self.NUMBER_ENTRY_WIDTH)

        self.add_text(text='EOL Power_Cap(W):')
        self.eol_power_cap_entry = self.add_input(text=self.parent_data.eol_power_cap, tooltip='Power Limit')
        self.eol_power_cap_entry.config(width = self.NUMBER_ENTRY_WIDTH)

        self.add_text(text='EOL Power_Motor TUNING(mW):')
        self.eol_power_motor_tuning_entry = self.add_input(text=self.parent_data.eol_power_motor_tuning, tooltip='Motor Power')
        self.eol_power_motor_tuning_entry.config(width = self.NUMBER_ENTRY_WIDTH)
        self.newline()

        self.add_text(text="R Heater Left(ohm)")
        self.eol_power_r_heater_larm_entry = self.add_input(text="%0.4f" % self.parent_data.eol_power_r_heater_larm, tooltip='R Heater Left')
        self.eol_power_r_heater_larm_entry.config(width = self.NUMBER_ENTRY_WIDTH)

        self.add_text(text="R Heater Right(ohm)")
        self.eol_power_r_heater_rarm_entry = self.add_input(text="%0.4f" % self.parent_data.eol_power_r_heater_rarm, tooltip='R Heater Right')
        self.eol_power_r_heater_rarm_entry.config(width = self.NUMBER_ENTRY_WIDTH)

        self.newline()
        self.add_line(1900, span=8)
        self.newline()

        self.add_text(text='Compensate AET when flow is idle:')
        self.com_aet_flow_rate_4_l_s_entry = self.add_input(text=self.parent_data.com_aet_flow_rate_4_l_s, tooltip='Compensate AET when flow is idle.')
        self.com_aet_flow_rate_4_l_s_entry.config(width = self.NUMBER_ENTRY_WIDTH)

        self.add_text(text='Compensate AET when flow rate is 6L/s:')
        self.com_aet_flow_rate_6_l_s_entry = self.add_input(text=self.parent_data.com_aet_flow_rate_6_l_s, tooltip='Compensate AET when flow rate is 6L/s.')
        self.com_aet_flow_rate_6_l_s_entry.config(width = self.NUMBER_ENTRY_WIDTH)

        self.add_text(text='Compensate AET when flow rate is 9.2L/s:')
        self.com_aet_flow_rate_9_l_s_entry = self.add_input(text=self.parent_data.com_aet_flow_rate_9_l_s, tooltip='Compensate AET when flow rate is 9.2L/s.')
        self.com_aet_flow_rate_9_l_s_entry.config(width = self.NUMBER_ENTRY_WIDTH)

        self.add_text(text='Compensate AET when flow rate is 11.9L/s:')
        self.com_aet_flow_rate_12_l_s_entry = self.add_input(text=self.parent_data.com_aet_flow_rate_12_l_s, tooltip='Compensate AET when flow rate is 11.9L/s.')
        self.com_aet_flow_rate_12_l_s_entry.config(width = self.NUMBER_ENTRY_WIDTH)

        self.newline()
        self.add_line(1900, span=8)
        self.newline()

        self.add_text(text="Arm position mode")
        arm_mode_combo = self.add_combo(text=[i.name for i in arm_position.OperatingModes],
                                        tooltip="set arm position mode, write cal to EE to make permament")
        arm_mode_combo.current(arm_position.get_mode(self.device).value)
        arm_mode_combo.func = lambda: arm_position.update_mode(self.device, arm_mode_combo.current())

        self.add_text(text="Filter mode")
        filter_mode_combo = self.add_combo(text=[i.name for i in filter_mode.StatusModes],
                                        tooltip="set filter status mode")
        filter_mode_combo.current(filter_mode.get_mode(self.device).value)
        filter_mode_combo.func = lambda: filter_mode.update_mode(self.device, filter_mode_combo.current())
        self.add_text(text='Filter Maintenance Status:')
        self.current_filter_maintenance_text  = self.add_text(text='')

        self.newline()

        self.add_text(text="Force ambient reading errors")
        amb_pressure_error_combo = self.add_combo(text=[i.name for i in amb_pressure_error.OperatingModes],
                                        tooltip="Ambient reading error")
        amb_pressure_error_combo.current(amb_pressure_error.get_mode(self.device))
        amb_pressure_error_combo.func = lambda: amb_pressure_error.update_mode(self.device, amb_pressure_error_combo.text[amb_pressure_error_combo.current()])

        self.add_text(text='Purging Time Delay:')
        eol_purging_time_mode_combo = self.add_combo(text=[i.name for i in eol_purging_time_mode.PurgingTimeModes],
                                        tooltip="select time mode for purging")
        eol_purging_time_mode_combo.current(eol_purging_time_mode.get_mode(self.device))
        eol_purging_time_mode_combo.func = lambda: eol_purging_time_mode.update_mode(self.device, eol_purging_time_mode_combo.text[eol_purging_time_mode_combo.current()])

        self.add_text(text='Purging Flow Mode:')
        eol_purging_flow_mode_combo = self.add_combo(text=[i.name for i in eol_purging_flow_mode.PurgingFlowModes],
                                        tooltip="select flow mode for purging")
        eol_purging_flow_mode_combo.current(eol_purging_flow_mode.get_mode(self.device))
        eol_purging_flow_mode_combo.func = lambda: eol_purging_flow_mode.update_mode(self.device, eol_purging_flow_mode_combo.text[eol_purging_flow_mode_combo.current()])

        self.newline()

        self.add_line(1900, span=8)
        self.newline()

        # Preriod related GUI items
        self.add_text(text='Duty cycle (%):')
        self.zc_duty_text = self.add_text(text='')
        self.zc_duty_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='Frequency (Hz):')
        self.zc_freq_text = self.add_text(text='')
        self.zc_freq_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='Zero crossing status:')
        self.zc_status_text = self.add_text(text='')
        self.zc_status_text.config(width = (self.NUMBER_OUTPUT_WIDTH))
        self.newline()

        self.add_text(text='Mems sensor pressure(mB):')
        self.pressure_text = self.add_text(text='')
        self.pressure_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='Mems sensor temperature (deg C):')
        self.mems_temp_text = self.add_text(text='')
        self.mems_temp_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.add_button(text='Copy to clipboard',  func=self.copy_button_pressed, tooltip="Save pressure snapshot to RAM")

        self.newline()

        self.add_line(1900, span=8)
        self.newline()
        self.add_button(text='motor power ebox \u25b2',  func=self.power_up_button_pressed, tooltip="Increase motor power by ebox")
        self.add_button(text='motor power ebox \u25bc',  func=self.power_down_button_pressed, tooltip="Decrease motor power by ebox")
        self.add_button(text='All flow offset',  func=self.all_flow_rate_button_pressed, tooltip="Change all flow offset")
        self.add_button(text='Update calibration',  func=self.update_all_calibration_edit_box, tooltip="Update all calibration data to edit box")
        self.add_button(text='start diagnostics', func=self.start_self_diagnostics)
        self.add_button(text='stop diagnostics', func=self.stop_self_diagnostics)
        self.newline()

        self.add_text(text='High Power Tune adjust (Ticks):')
        self.high_power_tune_adj_ticks = self.add_text(text='')
        self.high_power_tune_adj_ticks.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.add_text(text='High Power Tune adjust (us):')
        self.high_power_tune_adj_us = self.add_text(text='')
        self.high_power_tune_adj_us.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.add_text(text='High Power Tune power (W):')
        self.high_power_tune_power_W = self.add_text(text='')
        self.high_power_tune_power_W.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()

        self.add_text(text='Medium Power Tune adjust (Ticks):')
        self.medium_power_tune_adj_ticks = self.add_text(text='')
        self.medium_power_tune_adj_ticks.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.add_text(text='Medium Power Tune adjust (us):')
        self.medium_power_tune_adj_us = self.add_text(text='')
        self.medium_power_tune_adj_us.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.add_text(text='Medium Power Tune power (W):')
        self.medium_power_tune_power_W = self.add_text(text='')
        self.medium_power_tune_power_W.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()

        self.add_text(text='Low Power Tune adjust (Ticks):')
        self.low_power_tune_adj_ticks = self.add_text(text='')
        self.low_power_tune_adj_ticks.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.add_text(text='Low Power Tune adjust (us):')
        self.low_power_tune_adj_us = self.add_text(text='')
        self.low_power_tune_adj_us.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.add_text(text='Low Power Tune power (W):')
        self.low_power_tune_power_W = self.add_text(text='')
        self.low_power_tune_power_W.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.add_text(text='Motor speed (krpm):')
        self.motor_speed_text = self.add_text(text='')
        self.motor_speed_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()

        no_debug = 1#None
        self.power_tune_steps = 0
        if (not no_debug) and (self.parent_data.disable_motor_command == 0):
            print("Power tune step is %.3f \xb5s." % (self.parent_data.power_tune_step_size_ticks / v9_protocol.TICKS_PER_US))
        else:
            self.parent_data.power_tune_step_size_ticks = 24
            print("WARNING: Unable to read actual power tune step from software.")
            print("Assuming %.3f \xb5s." % (self.parent_data.power_tune_step_size_ticks / v9_protocol.TICKS_PER_US))

        self.newline()
        self.add_line(1900, span=8)
        self.newline()

        # Preriod related GUI items
        self.add_text(text='Air Exit Temp A1(Tmas, degC):')
        self.air_exit_temp_tmass_a1_text = self.add_text(text='')
        self.air_exit_temp_tmass_a1_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='AET Raw A1(degC):')
        self.aetraw_a1_text = self.add_text(text='')
        self.aetraw_a1_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='Triac Temp (mV):')
        self.triac_temp_mv_text = self.add_text(text='')
        self.triac_temp_mv_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()

        self.add_text(text='Air Exit Temp A2(Tmas, degC):')
        self.air_exit_temp_tmass_a2_text = self.add_text(text='')
        self.air_exit_temp_tmass_a2_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='AET Raw A2(degC):')
        self.aetraw_a2_text = self.add_text(text='')
        self.aetraw_a2_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='Power Ratio(0~3):')
        self.power_ratio_text = self.add_text(text='')
        self.power_ratio_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.newline()

        self.add_text(text='Air Exit Temp A3(Tmas, degC):')
        self.air_exit_temp_tmass_a3_text = self.add_text(text='')
        self.air_exit_temp_tmass_a3_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='AET Raw A3(degC):')
        self.aetraw_a3_text = self.add_text(text='')
        self.aetraw_a3_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.newline()

        self.add_text(text='Air Exit Temp A4(Tmas, degC):')
        self.air_exit_temp_tmass_a4_text = self.add_text(text='')
        self.air_exit_temp_tmass_a4_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='AET Raw A4(degC):')
        self.aetraw_a4_text = self.add_text(text='')
        self.aetraw_a4_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='Product Power (W):')
        self.product_power_text = self.add_text(text='')
        self.product_power_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()

        self.add_text(text='Air Exit Temp B1(Tmas, degC):')
        self.air_exit_temp_tmass_b1_text = self.add_text(text='')
        self.air_exit_temp_tmass_b1_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='AET Raw B1(degC):')
        self.aetraw_b1_text = self.add_text(text='')
        self.aetraw_b1_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='Product Current (A):')
        self.product_current_text = self.add_text(text='')
        self.product_current_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()

        self.add_text(text='Air Exit Temp B2(Tmas, degC):')
        self.air_exit_temp_tmass_b2_text = self.add_text(text='')
        self.air_exit_temp_tmass_b2_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='AET Raw B2(degC):')
        self.aetraw_b2_text = self.add_text(text='')
        self.aetraw_b2_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='AC Mains Voltage (V):')
        self.ac_mains_vol = self.add_text(text='')
        self.ac_mains_vol.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()

        self.add_text(text='Air Exit Temp B3(Tmas, degC):')
        self.air_exit_temp_tmass_b3_text = self.add_text(text='')
        self.air_exit_temp_tmass_b3_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='AET Raw B3(degC):')
        self.aetraw_b3_text = self.add_text(text='')
        self.aetraw_b3_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()

        self.add_text(text='Air Exit Temp B4(Tmas, degC):')
        self.air_exit_temp_tmass_b4_text = self.add_text(text='')
        self.air_exit_temp_tmass_b4_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='AET Raw B4(degC):')
        self.aetraw_b4_text = self.add_text(text='')
        self.aetraw_b4_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='R Heater Avg(Ohms):')
        self.heater_avg_res_text = self.add_text(text='')
        self.heater_avg_res_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()

        self.add_text(text='Avg A Air Exit Temp(Tmas, degC):')
        self.air_exit_temp_avg_a_text = self.add_text(text='')
        self.air_exit_temp_avg_a_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='Avg A AET Raw(degC):')
        self.aetraw_avg_a_text = self.add_text(text='')
        self.aetraw_avg_a_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()

        self.add_text(text='Avg B Air Exit Temp(Tmas, degC):')
        self.air_exit_temp_avg_b_text = self.add_text(text='')
        self.air_exit_temp_avg_b_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='Avg B AET Raw(degC):')
        self.aetraw_avg_b_text = self.add_text(text='')
        self.aetraw_avg_b_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()

        self.add_text(text='Delta A Air Exit Temp(Tmas, degC):')
        self.air_exit_temp_delta_a_text = self.add_text(text='')
        self.air_exit_temp_delta_a_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='Delta A AET Raw(degC):')
        self.aetraw_delta_a_text = self.add_text(text='')
        self.aetraw_delta_a_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()

        self.add_text(text='Delta B Air Exit Temp(Tmas, degC):')
        self.air_exit_temp_delta_b_text = self.add_text(text='')
        self.air_exit_temp_delta_b_text.config(width = self.NUMBER_OUTPUT_WIDTH)

        self.add_text(text='Delta B AET Raw(degC):')
        self.aetraw_delta_b_text = self.add_text(text='')
        self.aetraw_delta_b_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()


        # add control buttons
        if self.parent_data.country !=None:
            text = 'Set ' + self.country + ' defaults'
            self.add_button(text=text, span=2, func=self.set_defaults, tooltip="Write default values for the current software")
            self.newline()
        self.add_button(text='Write Cal to EE',   func=self.write_cal, tooltip="This button updates the cal data in target.")
        self.add_button(text='Write Cal to RAM',   func=self.write_cal_ram, tooltip="This button updates the cal data in target ram only.")
        self.add_button(text='Zcross meas', func=self.zcross_meas, tooltip="This button will measure zero crossing.")
        self.log_button = self.log_button = self.add_button(text="Start logging", func=self.logon,  tooltip="Start Logging.")
        self.add_button(text="Behaviour flags...", func=self.behaviour_flags_button_pressed, tooltip="Check and set behaviour flags")
        self.add_button(text="Exit FCT...", func=self.exit_fct, tooltip="reset FCT and restart")
        self.newline()

    #
    # This function is called periodically (about 10 times a seconds).
    # It will update inputs and set the DAC output value.
    #
    def periodic(self):

        if self.stopping:
            return

        self.current_flow_level_name.change_text(self.parent_data.flowLevelName)
        self.current_ebox_flow_modeName.change_text(self.parent_data.eboxFlowModeName)
        self.current_ebox_flow_mode = self.parent_data.eboxFlowMode
        self.current_heat_mode.change_text(self.parent_data.heatModeName)
        self.current_ui_mode_text.change_text(self.parent_data.ui_mode_name)
        self.current_sensitive.change_text(self.parent_data.sensitiveText)
        self.current_flow_rate.change_text(self.parent_data.targetFlowRate)
        self.current_heat_temp.change_text(self.parent_data.temp)
        self.current_filter_maintenance_text.change_text(self.parent_data.filter_mode_name)


        if self.parent_data.idle_activated == 0:
            self.idle_mode_active.change_text('No')
        else:
            self.idle_mode_active.change_text('Yes')

        self.pressure_text.change_text("%.3f" % self.parent_data.pressure_mB)
        self.mems_temp_text.change_text("%.3f" % self.parent_data.mems_temp_C)
        self.pressure_snapshot =  "%.3f\t" % self.parent_data.pressure_mB
        self.pressure_snapshot += "%.3f" % self.parent_data.mems_temp_C
        self.triac_temp_mv_text.change_text(self.parent_data.triac_temp_mV)
        self.power_ratio_text.change_text("%.3f" % self.parent_data.combinedPowerRatio)
        self.product_power_text.change_text("%.3f" % self.parent_data.productPower_W)
        self.product_current_text.change_text("%.3f" % self.parent_data.productCurrent_A)
        self.heater_avg_res_text.change_text("%.3f" %  ((self.parent_data.eol_power_r_heater_larm + self.parent_data.eol_power_r_heater_rarm)/2))
        self.ac_mains_vol.change_text("%.3f" % self.parent_data.acMainsVoltageRms_V)

        to_c = lambda k: k - 273 # convert kelvin to celsius

        self.air_exit_temp_tmass_a1_text.change_text(to_c(self.parent_data.air_exit_temp_k_a1))
        self.air_exit_temp_tmass_a2_text.change_text(to_c(self.parent_data.air_exit_temp_k_a2))
        self.air_exit_temp_tmass_a3_text.change_text(to_c(self.parent_data.air_exit_temp_k_a3))
        self.air_exit_temp_tmass_a4_text.change_text(to_c(self.parent_data.air_exit_temp_k_a4))
        self.air_exit_temp_tmass_b1_text.change_text(to_c(self.parent_data.air_exit_temp_k_b1))
        self.air_exit_temp_tmass_b2_text.change_text(to_c(self.parent_data.air_exit_temp_k_b2))
        self.air_exit_temp_tmass_b3_text.change_text(to_c(self.parent_data.air_exit_temp_k_b3))
        self.air_exit_temp_tmass_b4_text.change_text(to_c(self.parent_data.air_exit_temp_k_b4))

        self.aetraw_a1_text.change_text(to_c(self.parent_data.aetRaw_a1))
        self.aetraw_a2_text.change_text(to_c(self.parent_data.aetRaw_a2))
        self.aetraw_a3_text.change_text(to_c(self.parent_data.aetRaw_a3))
        self.aetraw_a4_text.change_text(to_c(self.parent_data.aetRaw_a4))
        self.aetraw_b1_text.change_text(to_c(self.parent_data.aetRaw_b1))
        self.aetraw_b2_text.change_text(to_c(self.parent_data.aetRaw_b2))
        self.aetraw_b3_text.change_text(to_c(self.parent_data.aetRaw_b3))
        self.aetraw_b4_text.change_text(to_c(self.parent_data.aetRaw_b4))

        self.aetraw_avg_a_text.change_text(to_c(self.parent_data.aetRaw_avg_a))
        self.aetraw_avg_b_text.change_text(to_c(self.parent_data.aetRaw_avg_b))
        self.aetraw_delta_a_text.change_text(self.parent_data.aetRaw_delta_a)
        self.aetraw_delta_b_text.change_text(self.parent_data.aetRaw_delta_b)
        self.air_exit_temp_avg_a_text.change_text(to_c(self.parent_data.air_exit_temp_k_avg_a))
        self.air_exit_temp_avg_b_text.change_text(to_c(self.parent_data.air_exit_temp_k_avg_b))
        self.air_exit_temp_delta_a_text.change_text(self.parent_data.air_exit_temp_k_delta_a)
        self.air_exit_temp_delta_b_text.change_text(self.parent_data.air_exit_temp_k_delta_b)
        self.motor_speed_text.change_text("%.3f" % self.parent_data.motor_speed_krpm)

        # Check the top level parent GUI has read our parameters and if so update the GUI
        if(self.refresh_tuning_parameters==True) and (self.parent_data.get_motor_tune_trim_values_trigger==False):
            self.refresh_v9_tuning_parameters()
            self.refresh_tuning_parameters=False

        # Permit not any measurements from pcb if in an error state

        # Write the calibration data to the Target and file

        # This must be at the end - to prevent multiple threads
        if (os.path.isfile('log.opt') and self.logging == True):
            self.log_data(logfile_name)


        self.after(300, self.periodic)

    def logon(self):
        if self.logging == False:

            self.logging = True
            self.log_button.config(text='Stop logging')

            logfile = open("log.opt", "a")
            log_entry = ""
            log_entry = ";Logging enabled"
            logfile.write(log_entry)
            logfile.close

            logfile = open(logfile_name, "a")  #Initialise logfile with labels
            log_entry = ""
            log_entry = log_entry + "Time HH:MM:SSSS"
            log_entry = log_entry + "," + "AetOff_a1"
            log_entry = log_entry + "," + "AetOff_b1"
            log_entry = log_entry + "," + "AetSlop_a1"
            log_entry = log_entry + "," + "AetSlop_b1"
            log_entry = log_entry + "," + "ComAETFlowIdle"
            log_entry = log_entry + "," + "ComAETFlow6L/s"
            log_entry = log_entry + "," + "ComAETFlow9.2L/s"
            log_entry = log_entry + "," + "ComAETFlow11.9L/s"
            log_entry = log_entry + "," + "TriacOff"
            log_entry = log_entry + "," + "TriacSlop"
            log_entry = log_entry + "," + "TriacTrip"
            log_entry = log_entry + "," + "MemsPress"
            log_entry = log_entry + "," + "MemsTemp"
            log_entry = log_entry + "," + "TriacTemp"
            log_entry = log_entry + "," + "AetTemp_a1 C"
            log_entry = log_entry + "," + "AetTemp_a2 C"
            log_entry = log_entry + "," + "AetTemp_a3 C"
            log_entry = log_entry + "," + "AetTemp_a4 C"
            log_entry = log_entry + "," + "AetTemp_b1 C"
            log_entry = log_entry + "," + "AetTemp_b2 C"
            log_entry = log_entry + "," + "AetTemp_b3 C"
            log_entry = log_entry + "," + "AetTemp_b4 C"
            log_entry = log_entry + "," + "AvgAAetTemp C"
            log_entry = log_entry + "," + "AvgBAetTemp C"
            log_entry = log_entry + "," + "DeltaAAetTemp C"
            log_entry = log_entry + "," + "DeltaBAetTemp C"
            log_entry = log_entry + "," + "AetTempRaw_a1 C"
            log_entry = log_entry + "," + "AetTempRaw_a2 C"
            log_entry = log_entry + "," + "AetTempRaw_a3 C"
            log_entry = log_entry + "," + "AetTempRaw_a4 C"
            log_entry = log_entry + "," + "AetTempRaw_b1 C"
            log_entry = log_entry + "," + "AetTempRaw_b2 C"
            log_entry = log_entry + "," + "AetTempRaw_b3 C"
            log_entry = log_entry + "," + "AetTempRaw_b4 C"
            log_entry = log_entry + "," + "AvgAAetTempRaw C"
            log_entry = log_entry + "," + "AvgBAetTempRaw C"
            log_entry = log_entry + "," + "DeltaAAetTempRaw C"
            log_entry = log_entry + "," + "DeltaBAetTempRaw C"
            log_entry = log_entry + "," + "combinedPowerRatio"
            log_entry = log_entry + "," + "productPower_W"
            log_entry = log_entry + "," + "productCurrent_A"
            log_entry = log_entry + "," + "rHeaterAvg_O"
            log_entry = log_entry + "," + "Vac"

            # Append  linefeed
            log_entry = log_entry + "\n"

            logfile.write(log_entry)
            logfile.close
        else:
            self.log_button.config(text='Start logging')
            self.logging = False

    def log_data(self, file_name):
        logfile = open(file_name, "a")

        print("Logged ",time.time())
        # Create a comma separated list from all the elements in the array - CR delimits entry.
        log_entry = ""
        # record is: time, aet_offset[6], aet_slope[6], triac_offset, triac_slope, triac_trip

        log_entry = log_entry + str(datetime.datetime.now().strftime("%H%M%S%f")[:-4])
        log_entry = log_entry + "," + str( "%.0f" % self.eol_air_exit_temp_a_offset_entry.value() )
        log_entry = log_entry + "," + str( "%.0f" % self.eol_air_exit_temp_b_offset_entry.value() )
        log_entry = log_entry + "," + str( "%.0f" % self.eol_air_exit_temp_a_slope_entry.value() )
        log_entry = log_entry + "," + str( "%.0f" % self.eol_air_exit_temp_b_slope_entry.value() )
        log_entry = log_entry + "," + str( "%.0f" % self.com_aet_flow_rate_4_l_s_entry.value() )
        log_entry = log_entry + "," + str( "%.0f" % self.com_aet_flow_rate_6_l_s_entry.value() )
        log_entry = log_entry + "," + str( "%.0f" % self.com_aet_flow_rate_9_l_s_entry.value() )
        log_entry = log_entry + "," + str( "%.0f" % self.com_aet_flow_rate_12_l_s_entry.value() )
        log_entry = log_entry + "," + str( "%.0f" % self.fct_triac_temp_offset_entry.value() )
        log_entry = log_entry + "," + str( "%.0f" % self.fct_triac_temp_slope_entry.value() )
        log_entry = log_entry + "," + str( "%.0f" % self.triac_temp_trip_limit_mV_entry.value() )

        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.pressure_mB )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.mems_temp_C )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.triac_temp_mV )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.air_exit_temp_k_a1 - 273) )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.air_exit_temp_k_a2 - 273) )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.air_exit_temp_k_a3 - 273) )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.air_exit_temp_k_a4 - 273) )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.air_exit_temp_k_b1 - 273) )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.air_exit_temp_k_b2 - 273) )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.air_exit_temp_k_b3 - 273) )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.air_exit_temp_k_b4 - 273) )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.air_exit_temp_k_avg_a - 273) )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.air_exit_temp_k_avg_b - 273) )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.air_exit_temp_k_delta_a )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.air_exit_temp_k_delta_b )

        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.aetRaw_a1 - 273) )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.aetRaw_a2 - 273) )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.aetRaw_a3 - 273) )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.aetRaw_a4 - 273) )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.aetRaw_b1 - 273) )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.aetRaw_b2 - 273) )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.aetRaw_b3 - 273) )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.aetRaw_b4 - 273) )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.aetRaw_avg_a - 273) )
        log_entry = log_entry + "," + str( "%.3f" % (self.parent_data.aetRaw_avg_b - 273) )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.aetRaw_delta_a )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.aetRaw_delta_b )

        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.combinedPowerRatio )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.productPower_W )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.productCurrent_A )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.rHeaterAvg_O )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.acMainsVoltageRms_V )

        # Append  linefeed
        log_entry = log_entry + "\n"

        logfile.write(log_entry)
        logfile.close

    def start_self_diagnostics(self):
        cmd = sc_protocol.SELF_DIAG_START_CMD()
        msg = self.device.command_messages()
        msg.add(cmd)
        self.device.send(msg)
        print("Action results:", ", ".join(map(str, cmd.results)))

    def stop_self_diagnostics(self):
        cmd = sc_protocol.SELF_DIAG_STOP_CMD()
        msg = self.device.command_messages()
        msg.add(cmd)
        self.device.send(msg)
        print("Test results:", ", ".join(map(str, cmd.results)))

    def set_flow_level(self):
        self.parent_data.set_current_flow_level_trigger = True
        self.update_all_calibration_edit_box()

    def power_up_button_pressed(self):
        self.v9_tune(1)

    def power_down_button_pressed(self):
        self.v9_tune(-1)

    def copy_button_pressed(self):
        command = 'echo | set /p nul=' + self.pressure_snapshot + '| clip'
        os.system(command)


    def update_all_calibration_edit_box(self):
        self.parent_data.get_heat_mode_config_trigger = True;
        self.current_flow_offset_entry.change_text(self.parent_data.offset)

    def all_flow_rate_button_pressed(self):
        self.parent_data.get_heat_mode_config_trigger = True;
        mode_config.exec(gui.Toplevel(), self.parent_data,self.device)


    def refresh_v9_tuning_parameters(self):
            self.high_power_tune_power_W.change_text( self.parent_data.high_power_tune_power_W)
            self.high_power_tune_adj_us.change_text( "%.3f" % self.parent_data.high_power_tune_trim_us)
            self.high_power_tune_adj_ticks.change_text(str(int(self.parent_data.high_power_tune_trim_us * v9_protocol.TICKS_PER_US)))

            self.medium_power_tune_power_W.change_text(self.parent_data.medium_power_tune_power_W)
            self.medium_power_tune_adj_us.change_text( "%.3f" % self.parent_data.medium_power_tune_trim_us)
            self.medium_power_tune_adj_ticks.change_text(str(int(self.parent_data.medium_power_tune_trim_us * v9_protocol.TICKS_PER_US)))

            self.low_power_tune_power_W.change_text(self.parent_data.low_power_tune_power_W)
            self.low_power_tune_adj_us.change_text( "%.3f" % self.parent_data.low_power_tune_trim_us)
            self.low_power_tune_adj_ticks.change_text(str(int(self.parent_data.low_power_tune_trim_us * v9_protocol.TICKS_PER_US)))

            if self.current_ebox_flow_mode == 2:
                self.power_tune_steps = int(self.parent_data.medium_power_tune_trim_us * v9_protocol.TICKS_PER_US / self.parent_data.power_tune_step_size_ticks)
            elif self.current_ebox_flow_mode == 1:
                self.power_tune_steps = int(self.parent_data.low_power_tune_trim_us * v9_protocol.TICKS_PER_US / self.parent_data.power_tune_step_size_ticks)
            else:
                self.power_tune_steps = int(self.parent_data.high_power_tune_trim_us * v9_protocol.TICKS_PER_US / self.parent_data.power_tune_step_size_ticks)


    def v9_tune(self, amount):
        if self.parent_data.disable_motor_command == 0:
            self.parent_data.v9_power_tune_steps += amount
            self.parent_data.set_v9_power_tune_steps_trigger=True
            self.parent_data.get_motor_tune_trim_values_trigger=True
            self.refresh_tuning_parameters=True







# Called by parent programs
def exec(parent_app, parent_data, device, v9_device):
    app = this_app(parent=parent_app, parent_data=parent_data, title=APP_TITLE, device=device, v9_device=v9_device)
    return app

# Called by parent programs
def description():
    return APP_HELP;

def reset_device():
    global device
    print("Resetting device")
    self.device.reset_device()
    time.sleep(0.1)

# This code starts the app if the file is executed rather than imported.
if __name__ == '__main__':
    # Get a connection to a device
    with sc_protocol.HC_Protocol(debug_level=0) as device:
        with v9_protocol.V9_Protocol(com_object=device) as v9_device:
            # Run the script
            app = exec(tkinter.Tk(),device, v9_device)
            app.mainloop()
            self.device.close()
            self.v9_device.close()

