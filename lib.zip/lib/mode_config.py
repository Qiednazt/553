#-------------------------------------------------------------------------------
# Name:        Mode-sensitive flow/heat configuration
# Purpose:     This module allows change flow/heat setting of one mode/sensitive combination
#
# Authors:     Pan Zhiyang
#
# Created:     03/09/2019
# Copyright:   (c) Dyson Technology Ltd. 2019
#-------------------------------------------------------------------------------

import gui                      # Dyson Simple User Interface library
import sc_protocol as protocol  # Dyson N553 SC comms interface

# Import eeprom flag definitions.
# This import is meant to depend on the project number as returned by target via DIPC.
import sc_eeprom as eeprom      # Dyson N553 EEPROM flag definitions

APP_TITLE = "Flow heat configuration in combination of UI mode and sensitive GUI"
APP_HELP  = "This script allows the user to change flow/heat setting .\n"

# Full stickiness for Tk controls
STICKY_NSEW = gui.N + gui.S + gui.E + gui.W

class this_app(gui.app):
    #
    # Define the controls
    #
    def __init__(self, *args, **kwargs):
        # Process arguments speficic to this application
        if 'device' in kwargs:
            self.device = kwargs['device']
            del kwargs['device']
            self.close_funcs.append(self.device.closing) # Give the application a function which will abort the connection
        else:
            gui.error("'device' is a required named parameter for this app.")
            
        if 'parent_data' in kwargs:            
            self.parent_data = kwargs['parent_data']
            print("Parent data received")
            del kwargs['parent_data']      

        # Initialise the base class
        gui.app.__init__(self, *args, **kwargs)

        # Read autostart value and behaviour flags from target

        self.NUMBER_ENTRY_WIDTH = 10
        self.NUMBER_OUTPUT_WIDTH = 12
        self.MODE_SENSITIVE_NO = 5
        self.UI_FLOW_OFFSET_NUMBER = 4
        
        self.add_text(text='EEPROM calib values:')
        self.newline()

        self.add_text(text='Mode/CoolFix')
        self.add_text(text='High heat')
        self.add_text(text='Medium heat')
        self.add_text(text='Low heat')
        self.add_text(text='High flow')
        self.add_text(text='Medium flow')
        self.newline()

        self.high_heat_temp_entry       = []
        self.medium_heat_temp_entry     = []
        self.low_heat_temp_entry        = []
        
        self.mode_sens_name = ['Inactive:', 'Wet CoolFix off:', 'Wet CoolFix on:', 'Dry CoolFix off:', 'Dry CoolFix on:']
       

        for i in range(0,self.MODE_SENSITIVE_NO):
            self.high_heat_temp_entry.append(self.parent_data.high_heat_temp[i])
            self.medium_heat_temp_entry.append(self.parent_data.medium_heat_temp[i])
            self.low_heat_temp_entry.append(self.parent_data.low_heat_temp[i])
            self.add_text(self.mode_sens_name[i])
            self.high_heat_temp_entry[i] = self.add_text(text=self.parent_data.high_heat_temp[i])
            self.high_heat_temp_entry[i].config(width = self.NUMBER_ENTRY_WIDTH)
            self.medium_heat_temp_entry[i] = self.add_text(text=self.parent_data.medium_heat_temp[i])
            self.medium_heat_temp_entry[i].config(width = self.NUMBER_ENTRY_WIDTH)
            self.low_heat_temp_entry[i] = self.add_text(text=self.parent_data.low_heat_temp[i])
            self.low_heat_temp_entry[i].config(width = self.NUMBER_ENTRY_WIDTH)
            self.add_text("%.1f L/s" % self.parent_data.mode_flow_rate2[i])
            self.add_text("%.1f L/s" % self.parent_data.mode_flow_rate1[i])
            self.newline()

        self.newline()
        self.add_line(1000, span=10)
        self.newline()

        self.add_text(text='Flow rate')
        self.add_text(text='Flow offset')
        self.newline()
        self.flow_rate_name = ['4.5 L/s:', '6 L/s:', '9.2 L/s:', '11.9 L/s:' ]
        self.flow_offset_entry       = []

        for i in range(0,self.UI_FLOW_OFFSET_NUMBER):
            self.flow_offset_entry.append(self.parent_data.flow_offset[i])
            self.add_text(self.flow_rate_name[i])
            self.flow_offset_entry[i] = self.add_text(text=self.parent_data.flow_offset[i])
            self.newline()

        self.add_line(1000, span=10)
        self.newline()
        self.add_line(1000, span=10)
        self.newline()
        
        # Now display the EUUS system constants and JPN system constants
        self.add_text(text='System Constants (ROM):')
        self.newline()

        self.add_text(text='Mode/CoolFix')
        self.add_text(text='High heat')
        self.add_text(text='Medium heat')
        self.add_text(text='Low heat')
        self.add_text(text='High flow')
        self.add_text(text='Medium flow')
        self.newline()

        self.variant_high_heat_temp_entry       = []
        self.variant_medium_heat_temp_entry     = []
        self.variant_low_heat_temp_entry        = []
        
        self.mode_sens_name = ['EUUS Inactive:', 'EUUS Wet CoolFix off:', 'EUUS Wet CoolFix on:', 'EUUS Dry CoolFix off:', 'EUUS Dry CoolFix on:', 'JPN Inactive:', 'JPN Wet CoolFix off:', 'JPN Wet CoolFix on:', 'JPN Dry CoolFix off:', 'JPN Dry CoolFix on:']

        for i in range(0,2*self.MODE_SENSITIVE_NO):
            self.variant_high_heat_temp_entry.append(self.parent_data.variant_high_heat_temp[i])
            self.variant_medium_heat_temp_entry.append(self.parent_data.variant_medium_heat_temp[i])
            self.variant_low_heat_temp_entry.append(self.parent_data.variant_low_heat_temp[i])
            self.add_text(self.mode_sens_name[i])
            self.variant_high_heat_temp_entry[i] = self.add_text(text=self.parent_data.variant_high_heat_temp[i])
            self.variant_high_heat_temp_entry[i].config(width = self.NUMBER_ENTRY_WIDTH)
            self.variant_medium_heat_temp_entry[i] = self.add_text(text=self.parent_data.variant_medium_heat_temp[i])
            self.variant_medium_heat_temp_entry[i].config(width = self.NUMBER_ENTRY_WIDTH)
            self.variant_low_heat_temp_entry[i] = self.add_text(text=self.parent_data.variant_low_heat_temp[i])
            self.variant_low_heat_temp_entry[i].config(width = self.NUMBER_ENTRY_WIDTH)
            self.add_text("%.1f L/s" % self.parent_data.variant_mode_flow_rate2[i])
            self.add_text("%.1f L/s" % self.parent_data.variant_mode_flow_rate1[i])
            self.newline()

        self.add_line(1000, span=10)
        self.newline()
        self.status = self.add_text(text='', span=5)
        self.newline()

        apply_to_ram_btn = self.add_button("Apply to ram", self.apply_ram_button_pressed, tooltip="Apply config changes to RAM (temporary)", sticky=STICKY_NSEW)
        apply_to_ram_btn["state"] = "disabled"
        apply_to_ee_btn = self.add_button("Apply to EE", self.apply_ee_button_pressed, tooltip="Apply config changes to RAM and save in EEPROM (permanent)", sticky=STICKY_NSEW)
        apply_to_ee_btn["state"] = "disabled"
        rst_btn = self.add_button("Reset to default", self.reset_value, sticky=STICKY_NSEW)
        rst_btn["state"] = "disabled"

    # Add a radio button element to the dialog
    def add_radio_button(self, text='', variable=None, value=None, func=None, span=1, tooltip=None, sticky=gui.W+gui.N, padx=2, pady=2, justify=gui.LEFT):
        assert variable
        gui.Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = gui.Radiobutton(self, text=text, variable=variable, value=value, command=func, justify=justify)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        if tooltip != None: gui.createToolTip(x, tooltip)
        return x

    # Add a horizontal line
    def add_line(self, width=200, height=5, span=1, sticky=STICKY_NSEW, padx=2, pady=2):
        gui.Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = gui.Canvas(self, width=width, height=height)
        x.create_line(0, 2, width-1, 2)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        return x

    def apply_ee_button_pressed(self):
        self.apply_config_to_ram()
        self.parent_data.finalise_sc_calibration_trigger = True
        self.status.change_text("Mode config was finalised in EEPROM")

    def apply_ram_button_pressed(self):
        self.apply_config_to_ram()
        self.status.change_text("Mode config was updated to RAM")
        
    def apply_config_to_ram(self):
        for i in range(0,self.MODE_SENSITIVE_NO):
            self.parent_data.high_heat_temp[i] = self.high_heat_temp_entry[i]["text"]
            self.parent_data.medium_heat_temp[i] = self.medium_heat_temp_entry[i]["text"]
            self.parent_data.low_heat_temp[i]=self.low_heat_temp_entry[i]["text"]

        for i in range(0,self.UI_FLOW_OFFSET_NUMBER):
            self.parent_data.flow_offset[i] = self.flow_offset_entry[i]["text"]
        
        self.parent_data.set_flow_mode_config_trigger=True
        self.parent_data.set_heat_mode_config_trigger=True        


    def reset_value(self):
        # Inactive mode
        self.high_heat_temp_entry[0].set_value(0)
        self.medium_heat_temp_entry[0].set_value(0)
        self.low_heat_temp_entry[0].set_value(0)

        # Roots mode sensitive off
        self.high_heat_temp_entry[1].set_value(140)
        self.medium_heat_temp_entry[1].set_value(110)
        self.low_heat_temp_entry[1].set_value(80)

        # Roots mode sensitive on
        self.high_heat_temp_entry[2].set_value(140)
        self.medium_heat_temp_entry[2].set_value(110)
        self.low_heat_temp_entry[2].set_value(60)

        # Wet to dry mode sensitive off
        self.high_heat_temp_entry[3].set_value(140)
        self.medium_heat_temp_entry[3].set_value(110)
        self.low_heat_temp_entry[3].set_value(80)

        # Wet to dry mode sensitive on
        self.high_heat_temp_entry[4].set_value(140)
        self.medium_heat_temp_entry[4].set_value(110)
        self.low_heat_temp_entry[4].set_value(60)

        # Straightening mode sensitive off
        self.high_heat_temp_entry[5].set_value(160)
        self.medium_heat_temp_entry[5].set_value(140)
        self.low_heat_temp_entry[5].set_value(120)

        # Straightening mode sensitive on
        self.high_heat_temp_entry[6].set_value(160)
        self.medium_heat_temp_entry[6].set_value(140)
        self.low_heat_temp_entry[6].set_value(100)

        # Finishing mode sensitive off
        self.high_heat_temp_entry[7].set_value(160)
        self.medium_heat_temp_entry[7].set_value(140)
        self.low_heat_temp_entry[7].set_value(120)

        # Finishing mode sensitive on
        self.high_heat_temp_entry[8].set_value(160)
        self.medium_heat_temp_entry[8].set_value(140)
        self.low_heat_temp_entry[8].set_value(100)
        
        # FLow offset default value
        self.flow_offset_entry[0].set_value(9)
        self.flow_offset_entry[1].set_value(20)
        self.flow_offset_entry[2].set_value(12)
        self.flow_offset_entry[3].set_value(9)

# Called by parent programs
def exec(parent_app, parent_data,device):
    app = this_app(parent=parent_app, parent_data=parent_data,device=device, title=APP_TITLE)
    return app

# Called by parent programs
def description():
    return APP_HELP

# This code starts the app if the file is executed rather than imported.
if __name__ == '__main__':
    # Get a connection to a device
    description()
    print("This is not a atandalone script")
    
