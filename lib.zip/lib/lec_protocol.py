#-------------------------------------------------------------------------------
# Name:        lec_protocol
#
# Purpose:     Provide a Dyson Low Level Connectivity (LEC) protocol.
#
# The LEC connection standards are defined in 
#    DOC-0090733 - LEC Framing protocol     - Version 01  01/09/2016
#    DOC-0090730 - LEC Datalink Protocol    - Version 01  01/09/2016
#    DOC-0090731 - LEC Network Protocol     - Version 01  01/09/2016
#    DOC-0090734 – LEC Protocol Stack       - Version 02  01/09/2016
#    DOC-0090732 – LEC Application Protocol - Version 01  01/09/2016
#    General:       http://confluence.dyson.global.corp/display/KAF/Low-End+Connectivity+-+Inter-Processor+Comms
#
# Example usage:
#      import lec_protocol
#      device = lec_protocol.LecProtocol()  # Ask the user for the com port
#      msg = device.command_messages()
#      msg.add(lec_protocol.ERROR_CODE_REQ())
#      device.send(msg)
#      print("Error Code = %d" % msg.results[0].result)
#
# Deviations from standard: (version 1 of the protocol)
#      1) The RESET_CMD does not work in it's current form.
#      2) APP_START_CMD/RES not implemented - will have to think how to implement this.
#      3) START_UPDATE_CMD/RES not implemented
#      4) NOTIFY_UPDATE_CMD/RES not implemented
#      5) UPDATE_CMD/RES not implemented
#      6) READY_TO_UPDATE_REQ/RES not implemented
#      7) CHUNK_READ_REQ/RES not implemented
#      8) SOFTWARE_SIZE_REQ/RES not implemented
#      9) HARDWARE_TIMESTAMP_REQ/RES not implemented
#     10) HARDWARE_VERSION_REQ/RES not implemented
#     11) TIME_CMD/RES/REQ not implmented
#     12) TIMESTAMP_CMD/RES/REQ not implmented
#     13) RESET_EVT/CHUNK_PROCESSED_EVT not implemented
#     14) SUBSCRIBE_CMD/RES not impelemented
#     15) UNSUBSCRIBE_CMD/RES not impelemented
#     16) EVENT handling not implemented
#     17) DATA_* messages not implemented
#     18) All *_LIMIT_MIN/MAX parameters not implemented
#     19) No battery pack parameters implemented
#              
#
# Author:      Mike Morgan
# Created:     10/08/2016
# Copyright:   (c) Dyson 2016
#-------------------------------------------------------------------------------

import copy              # Standard Python Library
import time              # Standard Python Library - Provides timing functions
import multiprocessing   # Standard Python Library - Provides Lock
import sys               # Standard Python Library - Provides access to some variables used or maintained by the interpreter
import dipc_connection    # Dyson LEC protocol transport library

# This class represents a message made up of several commands
class CommandMessages():
    def __init__(self, **kwargs):
        self.debug_level = kwargs.pop('debug_level', 0)  # By default the debug_level if off (0)
        self.error_str = None
        self.commands = []
        
    # Add the given command to the array of command bytes
    # params:
    #   cmd - LecCommand type object
    # returns:
    #   Nothing
    def add(self, cmd):
        # Do not do anythinf if there is an error
        if self.error_str != None:
            return
        # Add the command object to the array of commands
        self.commands.append(cmd)
        cmd.debug_level = self.debug_level
        # Was there an error creating the command
        if cmd.error_str != None:
            self.error_str = cmd.error_str
        
        
#-------------------------------------------------------------------------------
# This is an empty class used as the basis of all LEC protocol commands.
#-------------------------------------------------------------------------------
class LecCommand():
    def __init__(self, **kwargs):
        self.error_str = None
        self.byteorder = 'little'
        self.cmd_name = ''
        self.processing_time = kwargs.pop('timeout', 0)      # By default the command should take no time at all
        self.debug_level     = kwargs.pop('debug_level', 0)  # By default the debug_level if off (0)
        self.kwargs = kwargs
    
    # Return the command message bytes for this command
    def command_bytes(self):
        # The empty class returns no bytes
        return bytearray()

    def process_response(self, msg, index):
        # The empty class does not process anything
        return 0
    
    # Return a byte array representing the uint8 value given
    def uint8(self, value):
        return value.to_bytes(1, byteorder=self.byteorder, signed=False)
        
    # Return a byte array representing the int8 value given
    def int8(self, value):
        return value.to_bytes(1, byteorder=self.byteorder, signed=True)
        
    # Return a byte array representing the uint16 value given
    def uint16(self, value):
        return value.to_bytes(2, byteorder=self.byteorder, signed=False)
        
    # Return a byte array representing the int16 value given
    def int16(self, value):
        return value.to_bytes(2, byteorder=self.byteorder, signed=True)
        
    # Return a byte array representing the uint32 value given
    def uint32(self, value):
        return value.to_bytes(4, byteorder=self.byteorder, signed=False)
        
    # Return a byte array representing the uint32 value given
    def int32(self, value):
        return value.to_bytes(4, byteorder=self.byteorder, signed=True)
        
    # Return the uint8 number from the response messge at the specified index
    # msg is of type CommandMessages
    # index is an integer
    def get_uint8(self, msg, index):
        if index > len(msg) - 1:
            raise Exception("Message too short to get data.")
        return int.from_bytes(msg[index:index+1], byteorder=self.byteorder, signed=False)
        
    # Return the int8 number from the response messge at the specified index
    # msg is of type CommandMessages
    # index is an integer
    def get_int8(self, msg, index):
        if index > len(msg) - 1:
            raise Exception("Message too short to get data.")
        return int.from_bytes(msg[index:index+1], byteorder=self.byteorder, signed=True)
    
    # Return the uint16 number from the response messge at the specified index
    # msg_object is of type CommandMessages
    # index is an integer
    def get_uint16(self, msg, index):
        if index > len(msg) - 2:
            raise Exception("Message too short to get data.")
        return int.from_bytes(msg[index:index+2], byteorder=self.byteorder, signed=False)
        
    # Return the int16 number from the response messge at the specified index
    # msg is of type CommandMessages
    # index is an integer
    def get_int16(self, msg, index):
        if index > len(msg) - 2:
            raise Exception("Message too short to get data.")
        return int.from_bytes(msg[index:index+2], byteorder=self.byteorder, signed=True)
    
    # Return the uint32 number from the response messge at the specified index
    # msg_object is of type CommandMessages
    # index is an integer
    def get_uint32(self, msg, index):
        if index > len(msg) - 4:
            raise Exception("Message too short to get data.")
        return int.from_bytes(msg[index:index+4], byteorder=self.byteorder, signed=False)
        

    # Return the int32 number from the response messge at the specified index
    # msg_object is of type CommandMessages
    # index is an integer
    def get_int32(self, msg, index):
        if index > len(msg) - 4:
            raise Exception("Message too short to get data.")
        return int.from_bytes(msg[index:index+4], byteorder=self.byteorder, signed=True)
        

# Implements the SOFTWARE_ID_REQ/SOFTWARE_ID_RES command/response.
# Arguments  None
# Results    project = project number of software
#            component = project component number of software
# Command:   UINT16 SOFTWARE_ID_REQ (0x0300)
# Response:  UINT16 SOFTWARE_ID_RES (0x0301)
#            UINT32 PROJECT   - Project number of software
#            UINT32 COMPONENT - Project component number of software
# Note: Previous versions of the DIPC protocol specified 16 bits for PROJECT and COMPONENT.
class SOFTWARE_ID_REQ(LecCommand):
    SOFTWARE_ID_REQ = 0x0300
    SOFTWARE_ID_RES = 0x0301
    name = 'SOFTWARE_ID_REQ'
    
    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.project   = None   # Default attribute value before response is None
        self.component = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.SOFTWARE_ID_REQ))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.SOFTWARE_ID_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.SOFTWARE_ID_RES))
        self.project   = self.get_uint32(msg, index+2)
        self.component = self.get_uint32(msg, index+6)
        if self.debug_level > 20:
            print("Parsing %s: project=%d 0x%x component=%d 0x%x" % (self.name, self.project, self.project, self.component, self.component))
        index += 10
        return index

        
# Implements the SOFTWARE_VERSION_REQ/SOFTWARE_VERSION_RES command/response.
# Arguments  None
# Results    version - uint32 of software version
# Command:   UINT16 SOFTWARE_VERSION_REQ (0x0302)
# Response:  UINT16 SOFTWARE_VERSION_RES (0x0303)
#            UINT32 VERSION   - Version number of software
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.SOFTWARE_VERSION_REQ())
#     device.send(msg)
#     print("version=%d" % msg.results[0].version)
class SOFTWARE_VERSION_REQ(LecCommand):
    SOFTWARE_VERSION_REQ = 0x0302
    SOFTWARE_VERSION_RES = 0x0303
    name = 'SOFTWARE_VERSION_REQ'
    
    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.version   = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.SOFTWARE_VERSION_REQ))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.SOFTWARE_VERSION_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.SOFTWARE_VERSION_RES))
        self.version   = self.get_uint32(msg, index+2)
        if self.debug_level > 20:
            print("Parsing %s: version=%d (0x%08x)" % (self.name, self.version, self.version))
        index += 6
        return index

        
# Implements the SOFTWARE_TIMESTAMP_REQ/SOFTWARE_TIMESTAMP_RES command/response.
# Arguments  None
# Results    timestamp - number of seconds since 00:00 1/1/1970
# Results    timestamp_str - String representation of number of seconds since 00:00 1/1/1970
# Command:   UINT16 SOFTWARE_TIMESTAMP_REQ (0x0304)
# Response:  UINT16 SOFTWARE_TIMESTAMP_RES (0x0305)
#            UINT32 TIMESTAMP - Seconds since 1970/01/01 00:00
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.SOFTWARE_TIMESTAMP_REQ())
#     device.send(msg)
#     print("timestamp=%d" % msg.results[0].timestamp)
#     print("timestamp=%s" % msg.results[0].timestamp_str)
class SOFTWARE_TIMESTAMP_REQ(LecCommand):
    SOFTWARE_TIMESTAMP_REQ = 0x0304
    SOFTWARE_TIMESTAMP_RES = 0x0305
    name = 'SOFTWARE_TIMESTAMP_REQ'
    
    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.timestamp = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.SOFTWARE_TIMESTAMP_REQ))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.SOFTWARE_TIMESTAMP_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.SOFTWARE_TIMESTAMP_RES))
        self.timestamp = self.get_uint32(msg, index+2)
        self.timestamp_str = time.strftime('%Y/%m/%d-%H:%M:%S', time.gmtime(self.timestamp))
        if self.debug_level > 20:
            print("Parsing %s: timestamp=%d (%s)" % (self.name, self.timestamp, self.timestamp_str))
        index += 6
        return index

        
# Implements the SOFTWARE_RELSTR_REQ/SOFTWARE_RELSTR_RES command/response.
# Arguments  offset  - offset within the release string
#            max_len - maximum number of byte to send in the reply
# Results    str     - ASCII string reply
#            finished - True (all data returned) False (more release string to get)
# Command:   UINT16 SOFTWARE_RELSTR_REQ (0x0306)
#            UINT8  offset
#            UINT8  max reply length
# Response:  UINT16 SOFTWARE_RELSTR_RES (0x0307)
#            UINT8  reply length
#            [UINT8  data]...
class SOFTWARE_RELSTR_REQ(LecCommand):
    SOFTWARE_RELSTR_REQ = 0x0306
    SOFTWARE_RELSTR_RES = 0x0307
    name = 'SOFTWARE_RELSTR_REQ'
    
    def __init__(self, offset, max_len, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.offset = offset
        self.max_len = max_len
        self.data = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.SOFTWARE_RELSTR_REQ))
        msg.extend(self.uint8(self.offset))
        msg.extend(self.uint8(self.max_len))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.SOFTWARE_RELSTR_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.SOFTWARE_RELSTR_RES))
        length = self.get_uint8(msg, index+2)
        self.str = ''
        for i in range(length):
            self.str += chr(self.get_uint8(msg, index+3+i))
        self.finished = False
        if self.str.find(chr(0)) != -1:
            self.str = self.str[:self.str.find(chr(0))]
            self.finished = True
        if self.debug_level > 20:
            print("Parsing %s: str='%s'" % (self.name, self.str))
        index += 3 + length
        return index

        
# Implements the MEMORY_CONTENT_REQ/MEMORY_CONTENT_RES command/response.
# Arguments  addr = address to peek
# Results    value = Value at address
# Command:   UINT16 MEMORY_CONTENT_REQ (0x0902)
#            UINT32 Address to peek
# Response:  UINT16 MEMORY_CONTENT_RES (0x0903)
#            UINT32 peeked value
class MEMORY_CONTENT_REQ(LecCommand):
    MEMORY_CONTENT_REQ = 0x0902
    MEMORY_CONTENT_RES = 0x0903
    name = 'MEMORY_CONTENT_REQ'
    
    def __init__(self, addr, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.addr      = addr
        self.value     = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s, address 0x%08x" % (self.name, self.addr))
        msg.extend(self.uint16(self.MEMORY_CONTENT_REQ))
        msg.extend(self.uint32(self.addr))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.MEMORY_CONTENT_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.MEMORY_CONTENT_RES))
        self.value = self.get_uint32(msg, index+2)
        if self.debug_level > 20:
            print("Parsing %s: Addr 0x%08x = 0x%08x" % (self.name, self.addr, self.value))
        index += 6
        return index

        
# Implements the MEMORY_CONTENT_CMD/MEMORY_CONTENT_RES command/response.
# Arguments  addr = address to poke
#            value = value to poke
#            mask  = value mask (1 = change bit, 0 = do not change bit) default=0xffffffff
# Command:   UINT16 MEMORY_CONTENT_CMD (0x0904)
#            UINT32 Address to poke
#            UINT32 Value to poke
#            UINT32 Mask bits 1=change, 0=do not change
# Response:  UINT16 MEMORY_CONTENT_RES (0x0903)
#            UINT32 Value poked 
class MEMORY_CONTENT_CMD(LecCommand):
    MEMORY_CONTENT_CMD = 0x0904
    MEMORY_CONTENT_RES = 0x0903
    name = 'MEMORY_CONTENT_CMD'
    
    def __init__(self, addr, value, mask=0xffffffff, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.addr      = addr
        self.value     = value
        self.mask      = mask
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s, address 0x%08x" % (self.name, self.addr))
        msg.extend(self.uint16(self.MEMORY_CONTENT_CMD))
        msg.extend(self.uint32(self.addr))
        msg.extend(self.uint32(self.value & 0xffffffff))
        msg.extend(self.uint32(self.mask))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.MEMORY_CONTENT_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.MEMORY_CONTENT_RES))
        self.value   = self.get_uint32(msg, index+2)
        if self.debug_level > 20:
            print("Parsing %s: Addr 0x%08x = 0x%08x" % (self.name, self.addr, self.value))
        index += 6
        return index

        
# Implements the EXECUTE_FUNCTION_CMD/EXECUTE_FUNCTION_RES command/response.
# Arguments  addr = address of function to call
#            [] = array of uint32 parameters to pass to function
#            optional: name = Name of function (logging purposes)
# Results:   result - uint32 returned by function
#            
# Command:   UINT16 EXECUTE_FUNCTION_CMD (0x0906)
#            UINT32 Address of function
#            UINT8  Number of UINT32 parameters to pass
#            [UINT32 Optional parameter]
# Response:  UINT16 EXECUTE_FUNCTION_RES (0x0907)
#            UINT32 Value returned by function or random value if function returned void 
class EXECUTE_FUNCTION_CMD(LecCommand):
    EXECUTE_FUNCTION_CMD = 0x0906
    EXECUTE_FUNCTION_RES = 0x0907
    name = 'EXECUTE_FUNCTION_CMD'
    
    def __init__(self, addr, params = [], **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.fn_name   = kwargs.pop('name', '')
        self.addr      = addr
        self.params    = params[:4]
        self.result    = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s %s , address 0x%08x, params " % (self.name, self.fn_name, self.addr), end='')
            print(self.params)
        msg.extend(self.uint16(self.EXECUTE_FUNCTION_CMD))
        msg.extend(self.uint32(self.addr))
        msg.extend(self.uint8(len(self.params)))
        for param in self.params:
            msg.extend(self.uint32(param))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.EXECUTE_FUNCTION_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.EXECUTE_FUNCTION_RES))
        self.result = self.get_uint32(msg, index+2)
        if self.debug_level > 20:
            print("Parsing %s: %s @ 0x%08x Result %d 0x%08x" % (self.name, self.fn_name, self.addr, self.result, self.result))
        index += 6
        return index

# Implements the CONFIGURE_CMD/CONFIGURE_RES command/response.
# Arguments  config_id = ID of configuration item
#            config_data = byte array of configuration data
#            
# Command:   UINT16 CONFIGURE_CMD (0x0500)
#            UINT16 Configuration item ID
#            UINT16 Number of bytes of configuration data
#            [UINT8 Config data]
# Response:  UINT16 CONFIGURE__RES (0x0501)
#            UINT16 Configuration item ID
#            UINT16 Number of bytes of configuration data
#            [UINT8 Config data]
class CONFIGURE_CMD(LecCommand):
    CONFIGURE_CMD = 0x0500
    CONFIGURE_RES = 0x0501
    name = 'CONFIGURE_CMD'
    
    def __init__(self, config_id, config_data, name = '', **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str   = None
        self.config_id   = config_id
        self.config_data = config_data
        self.config_name = name
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s, config id 0x%04x %s, data " % (self.name, self.config_id, self.config_name), self.config_data, end='')
            print(self.config_data)
        msg.extend(self.uint16(self.CONFIGURE_CMD))
        msg.extend(self.uint16(self.config_id))
        if (self.config_data != None):
            msg.extend(self.uint16(len(self.config_data)))
            for byte in self.config_data:
                msg.extend(self.uint8(byte))
        else: 
            msg.extend(self.uint16(0))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.CONFIGURE_RES:
            raise Exception('Unexpected response 0x%04x %s at %d, expected 0x%04x' % (cmd_id, self.config_name, index, self.CONFIGURE_RES))
        if (self.config_data != None):
            index += 6 + len(self.config_data)
        else: 
            index += 6
        return index

# Implements the CONFIGURE_REQ/CONFIGURE_RES command/response.
# Arguments  config_id = ID of configuration item
# Results    config_data - byte array of config data           
#
# Command:   UINT16 CONFIGURE_REQ (0x0502)
#            UINT16 Configuration item ID
# Response:  UINT16 CONFIGURE_RES (0x0501)
#            UINT16 Configuration item ID
#            UINT16 Number of bytes of configuration data
#            [UINT8 Config data]
class CONFIGURE_REQ(LecCommand):
    CONFIGURE_REQ = 0x0502
    CONFIGURE_RES = 0x0501
    name = 'CONFIGURE_REQ'
    
    def __init__(self, config_id, data = [], name = '', **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str   = None
        self.config_id   = config_id
        self.config_name = name
        self.config_data = None # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s, config id 0x%04x %s" % (self.name, self.config_id, self.config_name))
        msg.extend(self.uint16(self.CONFIGURE_REQ))
        msg.extend(self.uint16(self.config_id))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.CONFIGURE_RES:
            raise Exception('Unexpected response 0x%04x %s at %d, expected 0x%04x' % (cmd_id, self.config_name, index, self.CONFIGURE_RES))
        config_id = self.get_uint16(msg, index + 2)
        length    = self.get_uint16(msg, index + 4)
        self.config_data = bytearray()
        for i in range(length):
            self.config_data.append(self.get_uint8(msg, index + 6 + i))
        index += 6 + length
        return index


# Implements the CALIBRATE_CMD/CALIBRATE_RES command/response.
# Arguments  cal_id = ID of calibration item
#            cal_data = byte array of calibration data
#            
# Command:   UINT16 CALIBRATE_CMD (0x0504)
#            UINT16 Calibration item ID
#            UINT16 Number of bytes of calibration data
#            [UINT8 calibration data]
# Response:  UINT16 CALIBRATE_RES (0x0505)
#            UINT16 Calibration item ID
#            UINT16 Number of bytes of calibration data
#            [UINT8 calibration data]
class CALIBRATE_CMD(LecCommand):
    CALIBRATE_CMD = 0x0504
    CALIBRATE_RES = 0x0505
    name = 'CALIBRATE_CMD'
    
    def __init__(self, cal_id, cal_data, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str   = None
        self.cal_id   = cal_id
        self.cal_data = cal_data
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s, calibration id 0x%04x, data " % (self.name, self.cal_id), end='')
            print(self.cal_data)
        msg.extend(self.uint16(self.CALIBRATE_CMD))
        msg.extend(self.uint16(self.cal_id))
        msg.extend(self.uint16(len(self.cal_data)))
        for byte in self.cal_data:
            msg.extend(self.uint8(byte))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.CALIBRATE_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.CALIBRATE_RES))
        index += 6 + len(self.cal_data)
        return index

# Implements the CALIBRATE_REQ/CALIBRATE_RES command/response.
# Arguments  cal_id = ID of calibration item
# Results    cal_data - byte array of calibration data           
#
# Command:   UINT16 CALIBRATE_REQ (0x0506)
#            UINT16 Calibration item ID
# Response:  UINT16 CALIBRATE_RES (0x0505)
#            UINT16 Calibration item ID
#            UINT16 Number of bytes of calibration data
#            [UINT8 Calibration data]
class CALIBRATE_REQ(LecCommand):
    CALIBRATE_REQ = 0x0506
    CALIBRATE_RES = 0x0505
    name = 'CALIBRATE_REQ'
    
    def __init__(self, cal_id, data = [], **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str   = None
        self.cal_id   = cal_id
        self.cal_data = None # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s, calibration id 0x%04x" % (self.name, self.cal_id))
        msg.extend(self.uint16(self.CALIBRATE_REQ))
        msg.extend(self.uint16(self.cal_id))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.CALIBRATE_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.CALIBRATE_RES))
        cal_id = self.get_uint16(msg, index + 2)
        length = self.get_uint16(msg, index + 4)
        self.cal_data = bytearray()
        for i in range(length):
            self.cal_data.append(self.get_uint8(msg, index + 6 + i))
        index += 6 + length
        return index
        
# Implements the RESET_CMD/RESET_EVT command/response.
#
# Note: This command should not be sent with other commands in a message.
# Note: This command will invoke the bootloader.
#
# Arguments  None
# Command:   UINT16 RESET_CMD (0x0100)
# Response:  UINT16 RESET_EVT (0x2000)
#            UINT32 Value poked 
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.RESET_CMD())
#     device.send(msg)
class RESET_CMD(LecCommand):
    RESET_CMD = 0x0100
    RESET_EVT = 0x2000
    name = 'RESET_CMD'
    
    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.RESET_CMD))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.RESET_EVT:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.RESET_EVT))
        if self.debug_level > 20:
            print("Reset event")
        index += 2
        return index

        
# Implements the READY_TO_UPDATE_REQ/READY_TO_UPDATE_RES command/response.
# Arguments  None
# Command:   UINT16 READY_TO_UPDATE_REQ (0x0202)
# Response:  UINT16 READY_TO_UPDATE_RES (0x0203)
#            UINT8  0x00 = Ready to update, 0x01 = Not ready to update
class READY_TO_UPDATE_REQ(LecCommand):
    READY_TO_UPDATE_REQ = 0x0202
    READY_TO_UPDATE_RES = 0x0203
    name = 'READY_TO_UPDATE_REQ'
    
    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.state = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.READY_TO_UPDATE_REQ))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.READY_TO_UPDATE_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.READY_TO_UPDATE_RES))
        self.state = self.get_uint8(msg, index+2)
        if self.debug_level > 20:
            print("Parsing %s: state=%d  0=Ready, 1=Not ready" % (self.name, self.state))
        index += 3
        return index

        
# Implements the HARDWARE_SERIAL_REQ/HARDWARE_SERIAL_RES command/response.
# Arguments  None
# Results    serial_str  - Hex representation of the serial number
# Command:   UINT16      HARDWARE_SERIAL_REQ (0x0404)
# Response:  UINT16      HARDWARE_SERIAL_RES (0x0405)
#            UINT8       data length
#            [UINT8]...  data length
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.HARDWARE_SERIAL_REQ())
#     device.send(msg)
#     print("Serial = '%s'" % msg.results[0].serial_str)
class HARDWARE_SERIAL_REQ(LecCommand):
    HARDWARE_SERIAL_REQ = 0x0404
    HARDWARE_SERIAL_RES = 0x0405
    name = 'HARDWARE_SERIAL_REQ'
    
    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.serial_str = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.HARDWARE_SERIAL_REQ))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.HARDWARE_SERIAL_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.HARDWARE_SERIAL_RES))
        length = self.get_uint8(msg, index+2)
        self.serial_str = ''
        for i in range(length):
            self.serial_str += '%02x' % self.get_uint8(msg, index+3+i)
        if self.debug_level > 20:
            print("Parsing %s: '%s'" % (self.name, self.serial_str))
        index += 3 + length
        return index

        
# Implements the CALIBRATE_LOCK_CMD/CALIBRATE_LOCK_RES command/response.
# Arguments  None
# Results    calbration_locked  - Boolean True if calibration is locked
# Command:   UINT16      CALIBRATE_LOCK_CMD (0x050A)
# Response:  UINT16      CALIBRATE_LOCK_RES (0x050B)
#            UINT8       result (0x00 - calibration locked, 0xff - calibration unlocked)
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.CALIBRATE_LOCK_CMD())
#     device.send(msg)
#     print("Calibration locked = '%s'" % msg.results[0].calbration_locked)  # calbration_locked is a boolean
class CALIBRATE_LOCK_CMD(LecCommand):
    CALIBRATE_LOCK_CMD = 0x050A
    CALIBRATE_LOCK_RES = 0x050B
    name = 'CALIBRATE_LOCK_CMD'
    
    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.calbration_locked = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.CALIBRATE_LOCK_CMD))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.CALIBRATE_LOCK_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.CALIBRATE_LOCK_CMD))
        self.calbration_locked = (self.get_uint8(msg, index+2) == 0x00)
        index += 3
        return index

        
# Implements the CALIBRATE_LOCK_REQ/CALIBRATE_LOCK_RES command/response.
# Arguments  None
# Results    calbration_locked  - Boolean True if calibration is locked
# Command:   UINT16      CALIBRATE_LOCK_REQ (0x050C)
# Response:  UINT16      CALIBRATE_LOCK_RES (0x050B)
#            UINT8       result (0x00 - calibration locked, 0xff - calibration unlocked)
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.CALIBRATE_LOCK_REQ())
#     device.send(msg)
#     print("Calibration locked = '%s'" % msg.results[0].calbration_locked)  # calbration_locked is a boolean
class CALIBRATE_LOCK_REQ(LecCommand):
    CALIBRATE_LOCK_REQ = 0x050C
    CALIBRATE_LOCK_RES = 0x050B
    name = 'CALIBRATE_LOCK_REQ'
    
    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.calbration_locked = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.CALIBRATE_LOCK_REQ))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.CALIBRATE_LOCK_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.CALIBRATE_LOCK_REQ))
        self.calbration_locked = (self.get_uint8(msg, index+2) == 0x00)
        index += 3
        return index

        
# Implements the CALIBRATE_WRITE_CMD/CALIBRATE_WRITE_RES command/response.
# Arguments  None
# Results    result      0x00 - Data writte OK, 0xfe - failed to write data, 0xff - calibration is locked
# Command:   UINT16      CALIBRATE_WRITE_CMD (0x0508)
# Response:  UINT16      CALIBRATE_WRITE_RES (0x0509)
#            UINT8       result
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.CALIBRATE_WRITE_CMD())
#     device.send(msg)
#     print("result = %d" % msg.results[0].result)
class CALIBRATE_WRITE_CMD(LecCommand):
    CALIBRATE_WRITE_CMD = 0x0508
    CALIBRATE_WRITE_RES = 0x0509
    name = 'CALIBRATE_WRITE_CMD'
    
    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.serial_str = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.CALIBRATE_WRITE_CMD))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.CALIBRATE_WRITE_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.CALIBRATE_WRITE_RES))
        self.result = self.get_uint8(msg, index+2)
        if self.debug_level > 20:
            print("Parsing %s: %d" % (self.name, self.result))
        index += 3
        return index

        
# Implements the ERROR_CODE_REQ/ERROR_CODE_RES command/response.
# Arguments  None
# Results    result      0x0000 - No error, 0x1000 - Generic error - clearable, 0x2000 - Generic error - non-clearable
# Command:   UINT16      ERROR_CODE_REQ (0x0800)
# Response:  UINT16      ERROR_CODE_RES (0x0801)
#            UINT8       0x00=Not clearable, 0xff=Clearable
#            UINT16      0x0000=No Error, Other=Error code
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.ERROR_CODE_REQ())
#     device.send(msg)
#     print("result = %d" % msg.results[0].result)
#     print("clearable = %r" % msg.results[0].clearable)  # 'clearable' is a boolean
class ERROR_CODE_REQ(LecCommand):
    ERROR_CODE_REQ = 0x0800
    ERROR_CODE_RES = 0x0801
    name = 'ERROR_CODE_REQ'
    
    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.serial_str = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.ERROR_CODE_REQ))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.ERROR_CODE_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.ERROR_CODE_RES))
        self.clearable = self.get_uint8(msg, index+2) == 0xff
        self.result = self.get_uint16(msg, index+3)
        if self.debug_level > 20:
            print("Parsing %s: %d" % (self.name, self.result))
        index += 5
        return index

        
# Implements the CLEAR_ERROR_CMD/ERROR_CODE_RES command/response.
# Arguments  None
# Results    result      0x0000 - No error, 0x1000 - Generic error - clearable, 0x2000 - Generic error - non-clearable
# Command:   UINT16      CLEAR_ERROR_CMD (0x0802)
# Response:  UINT16      ERROR_CODE_RES (0x0801)
#            UINT8       result
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.CLEAR_ERROR_CMD())
#     device.send(msg)
#     print("result = %d" % msg.results[0].result)
class CLEAR_ERROR_CMD(LecCommand):
    CLEAR_ERROR_CMD = 0x0802
    ERROR_CODE_RES = 0x0801
    name = 'CLEAR_ERROR_CMD'
    
    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.serial_str = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.CLEAR_ERROR_CMD))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.ERROR_CODE_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.ERROR_CODE_RES))
        self.result = self.get_uint16(msg, index+2)
        if self.debug_level > 20:
            print("Parsing %s: %d" % (self.name, self.result))
        index += 4
        return index

        
# Implements the EXTENDED_ERROR_REQ/EXTENDED_ERROR_RES command/response.
# Arguments  None
# Results    data        Byte array of extended error data
# Command:   UINT16      EXTENDED_ERROR_REQ (0x0908)
# Response:  UINT16      EXTENDED_ERROR_RES (0x0909)
#            UINT16      length
#            [UINT8]...  data
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.EXTENDED_ERROR_REQ())
#     device.send(msg)
#     print("data = ", msg.results[0].data)
class EXTENDED_ERROR_REQ(LecCommand):
    EXTENDED_ERROR_REQ = 0x0804
    EXTENDED_ERROR_RES = 0x0805
    name = 'EXTENDED_ERROR_REQ'
    
    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.serial_str = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.EXTENDED_ERROR_REQ))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.EXTENDED_ERROR_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.EXTENDED_ERROR_RES))
        length = self.get_uint16(msg, index+2)
        self.data = bytearray()
        for i in range(length):
            self.data.append(self.get_uint8(msg, index+4+i))
        if self.debug_level > 20:
            print("Parsing %s: " % self.name, self.data)
        index += 4 + length
        return index

        
# Implements the PARAMETER_CMD/PARAMETER_RES command/response.
# Arguments  param_id    Parameter ID of the data to send
#            data        Data to send
# Results    data        Data returned by the device
# Command:   UINT16      PARAMETER_CMD (0x1000)
#            UINT16      parameter id
#            UINT16      parameter data size
#            [UINT8]...  parameter data
# Response:  UINT16      PARAMETER_RES (0x1001)
#            UINT16      parameter id
#            UINT16      parameter data size
#            [UINT8]...  parameter data
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.PARAMETER_CMD(param_id, data))
#     device.send(msg)
#     print("data = ", msg.results[0].data)
class PARAMETER_CMD(LecCommand):
    PARAMETER_CMD = 0x1000
    PARAMETER_RES = 0x1001
    name = 'PARAMETER_CMD'
    
    def __init__(self, param_id, data, name='', **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.param_id = param_id
        self.param_name = name
        self.data = data
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s 0x%04x %s " % (self.name, self.param_id, self.param_name), self.data)
        msg.extend(self.uint16(self.PARAMETER_CMD))
        msg.extend(self.uint16(self.param_id))
        msg.extend(self.uint16(len(self.data)))
        msg.extend(self.data)
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.param_id = self.get_uint16(msg, index+2)
        length = self.get_uint16(msg, index+4)
        self.data = bytearray()
        for i in range(length):
            self.data.append(self.get_uint8(msg, index+6+i))
        if self.debug_level > 20:
            print("Parsing %s  0x%04x: " % (self.name, self.param_id), self.data)
        index += 6 + length
        return index

        
# Implements the PARAMETER_REQ/PARAMETER_RES command/response.
# Arguments  param_id    Parameter ID of the data to send
# Results    data        Data returned by the device
# Command:   UINT16      PARAMETER_REQ (0x1002)
#            UINT16      parameter id
# Response:  UINT16      PARAMETER_RES (0x1001)
#            UINT16      parameter id
#            UINT16      parameter data size
#            [UINT8]...  parameter data
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.PARAMETER_REQ(param_id))
#     device.send(msg)
#     print("data = ", msg.results[0].data)
class PARAMETER_REQ(LecCommand):
    PARAMETER_REQ = 0x1002
    PARAMETER_RES = 0x1001
    name = 'PARAMETER_REQ'
    
    def __init__(self, param_id, name='', **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.param_id = param_id
        self.param_name = name
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s 0x%04x %s " % (self.name, self.param_id, self.param_name))
        msg.extend(self.uint16(self.PARAMETER_REQ))
        msg.extend(self.uint16(self.param_id))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.param_id = self.get_uint16(msg, index+2)
        length = self.get_uint16(msg, index+4)
        self.data = bytearray()
        for i in range(length):
            self.data.append(self.get_uint8(msg, index+6+i))
        if self.debug_level > 20:
            print("Parsing %s  0x%04x: " % (self.name, self.param_id), self.data)
        index += 6 + length
        return index

        
# Gets the GET_DRIVE_MODE_PARAMETER parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.GET_DRIVE_MODE_PARAMETER())
#     device.send(msg)
#     print("Result = %d (-1=backwards, 0=stopped, 1=forwards)" % msg.results[0].state)
#     print("Result = %s ('backwards', 'stopped', 'forwards')"  % msg.results[0].state_name)
class GET_DRIVE_MODE_PARAMETER(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, 0x1100, name = 'DRIVE_MODE', **kwargs)
        self.state = None  # Value is not available until a response is parsed
        self.state_name = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.state = int.from_bytes(self.data, byteorder='little', signed=True)
        if self.state ==  0:  self.state_name = 'stopped'
        if self.state ==  1:  self.state_name = 'forwards'
        if self.state == -1:  self.state_name = 'backwards'
        return index

        
# Gets the GET_POWER_PARAMETER parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.GET_POWER_PARAMETER())
#     device.send(msg)
#     print("Result = %f Watts" % msg.results[0].power_W)
class GET_POWER_PARAMETER(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, 0x0100, name = 'POWER', **kwargs)
        self.power_W = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.power_W = int.from_bytes(self.data, byteorder='little', signed=True) / 1000
        return index
        
        
# Gets the GET_VOLTAGE_PARAMETER parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.GET_VOLTAGE_PARAMETER())
#     device.send(msg)
#     print("Result = %f Volts" % msg.results[0].voltage_V)
class GET_VOLTAGE_PARAMETER(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, 0x0102, name = 'VOLTAGE', **kwargs)
        self.voltage_V = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.voltage_V = int.from_bytes(self.data, byteorder='little', signed=True) / 1000
        return index

        
# Gets the GET_CURRENT_PARAMETER parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.GET_CURRENT_PARAMETER())
#     device.send(msg)
#     print("Result = %f Volts" % msg.results[0].current_A)
class GET_CURRENT_PARAMETER(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, 0x0104, name = 'CURRENT', **kwargs)
        self.current_A = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.current_A = int.from_bytes(self.data, byteorder='little', signed=True) / 1000
        return index

        
# Gets the GET_SPEED_PARAMETER parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.GET_SPEED_PARAMETER())
#     device.send(msg)
#     print("Result = %f uS/rev" % msg.results[0].speed_us_per_rev)
#     print("Result = %f krpm"   % msg.results[0].speed_krpm)
class GET_SPEED_PARAMETER(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, 0x0106, name = 'SPEED', **kwargs)
        self.speed_us_per_rev = None  # Value is not available until a response is parsed
        self.speed_krpm = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.speed_us_per_rev = int.from_bytes(self.data, byteorder='little', signed=True)
        if self.speed_us_per_rev > 0:
            self.speed_krpm = (((1.0 / (self.speed_us_per_rev / 1000000.0)) * 60.0) / 1000.0)
        else:
            self.speed_krpm = 0.0
        return index
        
        
# Gets the GET_TEMPERATURE_PARAMETER parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.GET_TEMPERATURE_PARAMETER())
#     device.send(msg)
#     print("Result = %f degC" % msg.results[0].temperature_degC)
class GET_TEMPERATURE_PARAMETER(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, 0x0108, name = 'TEMPERATURE', **kwargs)
        self.temperature_degC = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.temperature_degC = int.from_bytes(self.data, byteorder='little', signed=True) / 1000.0
        return index


# Sets the SET_DRIVE_MODE_PARAMETER parameter.
# Note: The value returned may not be the value set. Some parameters can not be set on some devices.
# states:
#    0  or 'stopped'
#    1  or 'forwards'
#   -1  or 'backwards'
# Usage:
#     msg = device.command_messages()
#     state = 1            # Either pass in a string or int
#     state = 'forwards'   # Either pass in a string or int
#     msg.add(lec_protocol.SET_DRIVE_MODE_PARAMETER(state))
#     device.send(msg)
#     print("Actual state = %s" % msg.results[0].state_name)
#     print("Actual state = %d" % msg.results[0].state)
class SET_DRIVE_MODE_PARAMETER(PARAMETER_CMD):
    def __init__(self, state, **kwargs):
        if isinstance(state, str):
            if   state == 'forwards':   state = 1
            elif state == 'backwards':  state = -1
            else:                       state = 0
        self.state = state
        PARAMETER_CMD.__init__(self, 0x1100, state.to_bytes(1, byteorder='little', signed=True), name = 'DRIVE_MODE', **kwargs)
        self.value = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.state = int.from_bytes(self.data, byteorder='little', signed=True)
        if self.state ==  0:  self.state_name = 'stopped'
        if self.state ==  1:  self.state_name = 'forwards'
        if self.state == -1:  self.state_name = 'backwards'
        return index

        
# Sets the POWER_PARAMETER parameter.
# Note: The value returned may not be the value set. Some parameters can not be set on some devices.
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.SET_POWER_PARAMETER(power_W=525))
#     device.send(msg)
#     print("Result = %f Watts" % msg.results[0].power_W)
class SET_POWER_PARAMETER(PARAMETER_CMD):
    def __init__(self, power_W, **kwargs):
        self.power_W = power_W
        PARAMETER_CMD.__init__(self, 0x0100, int(power_W * 1000).to_bytes(4, byteorder='little', signed=True), name = 'POWER', **kwargs)
    def process_response(self, msg, index):
        index = PARAMETER_CMD.process_response(self, msg, index)
        self.power_W = int.from_bytes(self.data, byteorder='little', signed=True) / 1000
        return index
        
        
# Sets the VOLTAGE_PARAMETER parameter.
# Note: The value returned may not be the value set. Some parameters can not be set on some devices.
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.SET_VOLTAGE_PARAMETER(voltage_V=25.0))
#     device.send(msg)
#     print("Result = %f Volts" % msg.results[0].voltage_V)
class SET_VOLTAGE_PARAMETER(PARAMETER_CMD):
    def __init__(self, voltage_V, **kwargs):
        self.voltage_V = voltage_V
        PARAMETER_CMD.__init__(self, 0x0102, int(voltage_V * 1000).to_bytes(4, byteorder='little', signed=True), name = 'VOLTAGE', **kwargs)
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.voltage_V = int.from_bytes(self.data, byteorder='little', signed=True) / 1000
        return index

        
# Sets the CURRENT_PARAMETER (electrical current) parameter.
# Note: The value returned may not be the value set. Some parameters can not be set on some devices.
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.SET_CURRENT_PARAMETER(current_A=60.0))
#     device.send(msg)
#     print("Result = %f A" % msg.results[0].current_A)
class SET_CURRENT_PARAMETER(PARAMETER_CMD):
    def __init__(self, current_A, **kwargs):
        self.current_A = current_A
        PARAMETER_CMD.__init__(self, 0x0104, int(current_A * 1000).to_bytes(4, byteorder='little', signed=True), name = 'CURRENT', **kwargs)
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.current_A = int.from_bytes(self.data, byteorder='little', signed=True) / 1000.0
        return index

        
# Sets the SPEED_PARAMETER parameter.
# Note: The value returned may not be the value set. Some parameters can not be set on some devices.
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.SET_SPEED_PARAMETER(speed_krpm=60.0))
#   or
#     msg.add(lec_protocol.SET_SPEED_PARAMETER(speed_us_per_rev=60.0))
#     device.send(msg)
#     print("Result = %f uS/rev" % msg.results[0].speed_uS_per_rev)
#     print("Result = %f krpm"   % msg.results[0].speed_krpm)
class SET_SPEED_PARAMETER(PARAMETER_CMD):
    def __init__(self, speed_uS_per_rev=None, speed_krpm=None, **kwargs):
        if speed_uS_per_rev == None:
            speed_uS_per_rev = (1.0 / ((speed_krpm * 1000.0) / 60.0)) * 1000000.0
        self.speed_uS_per_rev = speed_uS_per_rev
        PARAMETER_CMD.__init__(self, 0x0106, int(self.speed_uS_per_rev).to_bytes(4, byteorder='little', signed=True), name = 'SPEED', **kwargs)
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.speed_us_per_rev = int.from_bytes(self.data, byteorder='little', signed=True)
        self.speed_krpm = (((1.0 / (self.speed_us_per_rev / 1000000.0)) * 60.0) / 1000.0)
        return index
        
        
# Sets the TEMPERATURE_PARAMETER parameter.
# Note: The value returned may not be the value set. Some parameters can not be set on some devices.
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.SET_TEMPERATURE_PARAMETER(self.temperature_degC = 28.7))
#     device.send(msg)
#     print("Result = %f degC" % msg.results[0].temperature_degC)
class SET_TEMPERATURE_PARAMETER(PARAMETER_CMD):
    def __init__(self, temperature_degC, **kwargs):
        self.temperature_degC = temperature_degC
        PARAMETER_CMD.__init__(self, 0x0108, int(temperature_degC * 1000).to_bytes(4, byteorder='little', signed=True), name = 'TEMPERATURE', **kwargs)
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.temperature_degC = int.from_bytes(self.data, byteorder='little', signed=True) / 1000.0
        return index

        
# Implements the HEARTBEAT_CMD/HEARTBEAT_RES command/response.
# Arguments  none
# Command:   UINT16     Command ID  - HEARTBEAT_CMD (0x0610)
#            UINT16     duration (ms)
# Response:  UINT16     Command ID  - HEARTBEAT_RES (0x0611)
#            UINT16     duration (ms)
# Usage:
#     msg = device.command_messages()
#     msg.add(v10_vac_protocol.HEARTBEAT_CMD(1234))   # Kick the heartbeat timeout and set to 1234 ms
#     device.send(msg)
class HEARTBEAT_CMD(LecCommand):
    HEARTBEAT_CMD = 0x0610
    HEARTBEAT_RES = 0x0611
    name = 'HEARTBEAT_CMD'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, duration_ms, **kwargs)
        self.duration_ms = duration_ms
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.HEARTBEAT_CMD))
        msg.extend(self.uint16(self.duration_ms))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.HEARTBEAT_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.HEARTBEAT_RES))

        if self.debug_level > 20:
            print("Parsing %s" % (self.name))
        index += 4  # Yes - we are ignoring the duration response.
        return index


# Implements the UNSUPPORTED_CMD/UNSUPPORTED_RES command/response.
# Arguments  None
# This command is here to simulate an un-supported command and test handling of the command.
# Command:   UINT16 UNSUPPORTED_REQ (0xfefe)
# Response:  UINT16 UNSUPPORTED_RES (0x0001)
#            UINT8  0x00 = Ready to update, 0x01 = Not ready to update
class UNSUPPORTED_CMD(LecCommand):
    UNSUPPORTED_CMD = 0x0000  # This command ID is not supported by any device
    UNSUPPORTED_RES = 0x0001
    name = 'UNSUPPORTED_CMD'
    
    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.UNSUPPORTED_CMD))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.UNSUPPORTED_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.UNSUPPORTED_RES))
        if self.debug_level > 20:
            print("Parsing %s:" % (self.name))
        index += 9999  # Prevent parsing of further commands
        return index

        
        
        
        
#-------------------------------------------------------------------------------
# This class implements Protocol layer of the Dyson Low Level 
# Connectivity (LEC) protocol.
#
#-------------------------------------------------------------------------------
class LecProtocol():

    RESET_EVT_ID           = 0x2000
    CHUNK_PROCESSED_EVT_ID = 0x2100
    FAULT_EVT_ID           = 0x3000
    BATCH_TRANSFER_EVT_ID  = 0x3103
    DIAGNOSTIC_EVT_ID      = 0x3104
    SLEEP_EVT_ID           = 0x3200
    WAKE_EVT_ID            = 0x3201
    DATA_AVAILABLE_EVT_ID  = 0x3300
    DATA_EVT_ID            = 0x3301
    PARAMETER_EVT_ID       = 0x3400

    def __init__(self, **kwargs):
        self.debug_level = 0
        if 'debug_level' in kwargs:
            self.debug_level = kwargs['debug_level']
        self.connection = dipc_connection.DipcConnection(**kwargs)
        self.byteorder = self.connection.byteorder
        self.quit = False
        self.yeild = None
        self.batch_number = 0
        self.send_mutex = multiprocessing.Lock()
        self.last_response_time = time.time() - 1000000
    
    def __enter__(self):
        return self
    
    # Tidy up after exit or exception.
    def __exit__(self, type, value, traceback):
        self.close()

    def close(self):
        self.connection.close()

    # Called by window objects to inform the protocol that the window has been closed.
    def closing(self):
        # Have commented out the line below. It was causing problems with the GUI spawning windows.
        #   When one of the windows is closed, it set the flag to True - but the original window was still using
        #   the device and an error was generated - occasionally.
        #self.quit = True
        pass
    
    def command_messages(self):
        return CommandMessages(debug_level=self.debug_level)
    
    # Process the given event message. 
    def process_event(self, response):
        pass # Not implemented yet
        
    # Send a command and wait for a response.
    # The response is an array of LecCommand objects. Each has specific attribute value depending on the command.
    #  command_messages is a list of CommandMessages. A command data frame is created from the list.
    #  timeout - If there is no response in the time given (seconds), re-send command (if retries > 0)
    #            Default is 0.1 seconds + any additional time added by any of the commands
    #  retries - Number of times to re-send original command before throwing an exception. If < 0, the function does not even wait for a reply.
    def send(self, command_messages, timeout=None, retries=9):
        # Send the message
        command_messages.results = []
        name = ''
        if self.debug_level > 20:
           print("LecProtocol: Building message")
        message_bytes = bytearray()
        message_bytes.append(0) # Append a dummy batch number
        command_timeout = 0.5 # By default, wait 0.5 seconds for a response (longer than 248F as need to allow for master slave switch on single wire)
        for cmd in command_messages.commands:
            cmd.debug_level = self.debug_level
            cmd.byteorder = self.byteorder
            cmd.protocol = self
            message_bytes.extend(cmd.command_bytes())
            command_timeout += cmd.processing_time
        if timeout == None:
            timeout = command_timeout
        # Ensure no other process is sending
        if self.debug_level >= 30: print("send_mutex_acquire start")
        if self.send_mutex.acquire(timeout=1) == False:
            if self.debug_level >= 30: print("send_mutex_acquire timeout")
            return
        if self.debug_level >= 30: print("send_mutex_acquired")
        # Put the batch number in the first byte - This has to be done after the mutex in case another process changed the batch number.
        self.batch_number += 1
        if self.batch_number > 255:
            self.batch_number = 1
        message_bytes[0] = self.batch_number
        try:
            self.connection.send_packet(message_bytes)
            # If there is not expected to be a reply, quit now
            if retries < 0:
               return
            response = None
            retry = 0
            while response == None:
                response = self.connection.wait_for_packet(timeout=timeout)
                # Check the response
                if response == None:
                    pass
                elif response.control_byte != dipc_connection.DipcConnection.UNNUMBERED_UI:
                    response = None # Ignore because the frame type is not a response to the command
                elif len(response.data) < 1:
                    response = None # Ignore because the message is too small for a response message
                elif response.data[0] == 0:  # An event message
                    response = self.process_event(response)
                elif response.data[0] != self.batch_number:
                    response = None # Ignore because the batch number is incorrect
                if response == None:
                    if self.quit:
                        raise KeyboardInterrupt()
                    if retry == retries:
                        sys.tracebacklimit = 0  # Ignore the callstacks in the message window. This line can be deleted when doing development and debugging.
                        raise Exception('No response from device\nDevice might have entered low power mode\nPlease reset the device and restart TCG')
                    retry += 1
                    if self.debug_level > 0:
                        print("LecProtocol: Resending command due to timeout")
                    self.connection.send_packet(message_bytes)
            self.last_response_time = time.time()
            index = 1  # Skip the batch number byte
            
            for cmd in command_messages.commands:
                cmd.byteorder = self.byteorder
                index = cmd.process_response(response.data, index)
                command_messages.results.append(cmd)
        finally:
            if self.debug_level >= 30: print("send_mutex_release")
            self.send_mutex.release()
            if self.debug_level >= 30: print("send_mutex_released")
            
