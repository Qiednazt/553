#-------------------------------------------------------------------------------
# Name:        gui
# Purpose:     Provides a simplified User Interface for Dyson scripts
#
# Author:      Mike Morgan
#
# Created:     10/08/2016
# Copyright:   (c) Dyson 2016
#-------------------------------------------------------------------------------

import sys
import os
import time
import msvcrt                                     # Module for reading keyboard on Windows
import io                                         # Used for io.StringIO
import imp                                        # Used for executing other scripts
import threading                                  # Used for lock object
from tkinter                  import *            # GUI library
from tkinter                  import messagebox   # GUI library
from tkinter.scrolledtext     import ScrolledText # GUI library

# Remember the print function ptr
original_print_fn = print

# These are special keys which may be returned by wait_key() or get_key()
# This is not a complete key list. The full list of keyboard codes may be found at http://www.lagmonster.org/docs/DOS7/v-ansi-keys.html
# or use the function gui.display_key()
previous_keys    = ''
RETURN           = '\x0d'
ESCAPE           = '\x1b'
BACKSPACE        = '\x08'
UP_ARROW         = '\xe0\x48'  # decimal 224;72
DOWN_ARROW       = '\xe0\x50'
LEFT_ARROW       = '\xe0\x4b'
RIGHT_ARROW      = '\xe0\x4d'
CTRL_UP_ARROW    = '\xe0\x8d'
CTRL_DOWN_ARROW  = '\xe0\x91'
CTRL_LEFT_ARROW  = '\xe0\x73'
CTRL_RIGHT_ARROW = '\xe0\x74'
F1               = '\x00\x3b'
F2               = '\x00\x3c'
F3               = '\x00\x3d'

# This function is intended for use in console applications.
# The function will wait until a key is pressed and return the key code. The value returned
# is a string and may consist of two characters if the key was a special key e.g. F1 or cursor keys.
def wait_key():
    global previous_keys
    key = ''
    while len(key) == 0:
        key_b = msvcrt.getch()
        for k in key_b:
            previous_keys += chr(k)
        if ord(previous_keys[0]) == 0xe0 and len(previous_keys) > 1:
            key = previous_keys[0:2]
            previous_keys = previous_keys[2:]
        elif ord(previous_keys[0]) == 0x00 and len(previous_keys) > 1:
            key = previous_keys[0:2]
            previous_keys = previous_keys[2:]
        elif previous_keys[0] in "\x00\xe0":
            # A special key has been pressed, but we don't yet have the second character.
            pass
        else: # A normal single character key
            key = previous_keys[0]
            previous_keys = previous_keys[1:]
    return key


# This function is intended for use in console applications.
# The function will return the key pressed or or an empty string is no key is pressed. The value returned
# is a string and may consist of two characters if the key was a special key e.g. F1 or cursor keys.
def get_key():
    if msvcrt.kbhit():
        return wait_key()
    return ''


# This function is intended for use in console applications.
# The function is used for updating the key list above. Run the function, press a key and it
# will display the key value in a way that can be added to the key list above.
def display_key():
    print("\nPress a key and the key sequence will be displayed. This can be added to\n%s\n" % __file__)
    key = wait_key()
    print("KEY_NAME = '", end='')
    for c in key:
        if len(key) == 1 and (ord(c) >= 32 and ord(c) < 127):
            print(c, end='')
        else:
            print("\\x%02x" % ord(c), end='')
    print("'")


#
# This class is a helper class that allows print to be redirected to a function
#
class writer:
    def __init__(self, func=None, writer=None):
        self.writer = writer
        self.func = func
        self.lock = threading.Lock()

    def write(self, text):
        self.lock.acquire()
        if self.writer != None: self.writer.write(text)
        if self.func != None:
            self.func(text)
        self.lock.release()

    def flush(self):
        pass

    def close(self):
        self.writer = None
        self.func = None

#
# This allows the default exception handling to be over-ridden so that it appears in a message box.
# This is important because there may not be a console window to display the message.
#
exception_handler_swapped = False

def exception_handler(exctype, value, tb):
    old_stderr = sys.stderr
    sys.stderr = mystderr = io.StringIO()
    sys.__excepthook__(exctype, value, tb)
    sys.stderr = old_stderr
    messagebox.showerror('Error', mystderr.getvalue())
    print(mystderr.getvalue(), file=sys.stderr)
    sys.exit(1)

def tk_exception_handler(self, exctype, value, tb):
    exception_handler(exctype, value, tb)

# This function will swap the exception handlers for 'exception_handler()'
def swap_exception_handler():
    global exception_handler_swapped
    if not exception_handler_swapped:
        exception_handler_swapped = True
        sys.excepthook = exception_handler
        Tk.report_callback_exception = tk_exception_handler


####
# New widget classes
####

# This class creates a replacement class for standard tkinter class 'Label'.
# It adds the 'change_text' method which changes the label text immediately.
# It adds the 'tooltip' initialiser which adds a tooltip to the widget.
class Text(Label):
    def __init__(self, *args, **kwargs):
        if 'tooltip' in kwargs:
            createToolTip(self, kwargs['tooltip'])
            del kwargs['tooltip']
        Label.__init__(self, *args, **kwargs)

    def change_text(self, new_text):
        self['text'] = new_text
        self._nametowidget(self.winfo_parent()).update() # Call the update method of the parent to change the text right away


# This class creates a replacement class for standard tkinter class 'CheckButton'.
# text - text of check button
# tooltip - tooltip text
# func - function to call if state changes
#
class TickBox(Checkbutton):
    def __init__(self, *args, **kwargs):
        if 'tooltip' in kwargs:
            createToolTip(self, kwargs['tooltip'])
            del kwargs['tooltip']
        self.func = None
        if 'func' in kwargs:
            self.func = kwargs['func']
            del kwargs['func']
        self.var = IntVar(args[0])
        if 'value' in kwargs:
            self.var = kwargs['value']
            del kwargs['value']
        Checkbutton.__init__(self, *args, variable=self.var, command=self.func, **kwargs)

    # 0 (box not ticked), 1 (box ticked)
    def value(self):
        return self.var.get()

    # 0 (box not ticked), !=1 (box ticked)
    def set_value(self, new_value):
        if new_value==0:
            self.var.set(0)
        else:
            self.var.set(1)


# This class creates a replacement class for standard tkinter class 'Combobox'.
# text - array of strings
# tooltip - tooltip text
# func - function to call if state changes
#
from tkinter import ttk
class Combo(ttk.Combobox):
    def __init__(self, *args, **kwargs):
        if 'tooltip' in kwargs:
            createToolTip(self, kwargs['tooltip'])
            del kwargs['tooltip']
        if 'text' in kwargs:
            self.text = kwargs['text']
            del kwargs['text']
        self.func = None
        if 'func' in kwargs:
            self.func = kwargs['func']
            del kwargs['func']
        if 'value' in kwargs:
            self.var = kwargs['value']
            del kwargs['value']
        ttk.Combobox.__init__(self, *args, state='readonly', **kwargs)
        self['values'] = self.text
        self.bind("<<ComboboxSelected>>", self.changed)
    def changed(self, event):
        self.func()

    # Return the selected text
    def value(self):
        return self.get()

    # Return the index of the selected text
    def index_value(self):
        t = self.get()
        for i in range(len(self.text)):
            if self.text[i] == self.get():
                return i
        return -1

    # Set the text of the control.
    def set_value(self, new_value):
        self.set(new_value)


# This class creates a replacement class for standard tkinter class 'Entry'.
# It adds the 'text' initialiser to allow the initial text of the field to be set.
# It adds the 'value' method to get the number representation of the field (integer or float).
class NumberField(Entry):
    def __init__(self, *args, **kwargs):
        t = '0'
        self.format = None
        if 'format' in kwargs:
            self.format = kwargs['format']
            del kwargs['format']
        if 'text' in kwargs:
            t = kwargs['text']
            del kwargs['text']
        if 'tooltip' in kwargs:
            createToolTip(self, kwargs['tooltip'])
            del kwargs['tooltip']
        Entry.__init__(self, *args, **kwargs)
        self.insert(0, t)

    # Return the integer or float value. If value is invalid, return 0 (and set text to zero).
    def value(self):
        x = 0
        try:
           x = eval(self.get())
        except:
           pass
        return x

    # Set the text of the control.
    def set_value(self, new_value_str):
        self.delete(0, END)
        if self.format != None:
            new_value_str = self.format % new_value_str
        self.insert(0, new_value_str)


# This class creates a replacement class for standard tkinter class 'Entry'.
# It adds the 'text' initialiser to allow the initial text of the field to be set.
# It adds the 'value' method to get the current text.
class TextField(Entry):
    def __init__(self, *args, **kwargs):
        t = '0'
        if 'tooltip' in kwargs:
            createToolTip(self, kwargs['tooltip'])
            del kwargs['tooltip']
        if 'text' in kwargs:
            t = kwargs['text']
            del kwargs['text']
        Entry.__init__(self, *args, **kwargs)
        self.insert(0, t)

    # Return the integer or float value. If value is invalid, return 0 (and set text to zero).
    def value(self):
        return self.get()

    # Return the integer or float value. If value is invalid, return 0 (and set text to zero).
    def change_text(self, new_text_str):
        self.delete(0, END)
        self.insert(0, new_text_str)
        self._nametowidget(self.winfo_parent()).update() # Call the update method of the parent to change the text right away


# This class creates a replacement class for standard tkinter class 'ScrolledText'.
# It adds a multi-line text window which may be printed to.
class TextWindow(ScrolledText):
    def __init__(self, *args, **kwargs):
        self.newline = False
        tooltip = None
        if 'tooltip' in kwargs:
            tooltip = kwargs['tooltip']
            del kwargs['tooltip']

        ScrolledText.__init__(self, *args, **kwargs)

        # Disable text entry to window
        self.bind("<Key>", lambda e: "break")
        # Add a tooltip if specified
        if 'tooltip' != None:
            createToolTip(self, tooltip)

    # Send text to the text window.
    def write(self, text):
        # self.newline ensures that the bottom line of a text control is not always blank by not
        # printing the final '\n' of a string until another line is printed.
        if self.newline == True:
            text = '\n' + text
            self.newline = False
        if len(text) > 0 and text[-1] == '\n':
            text = text[:-1]
            self.newline = True
        self.insert(END, text)
        self.see('end')
        self.update()

    # Clear the text window.
    def clear(self):
        self.delete('1.0', END)

    # Send the arguments to the print window. Same format as print()
    def print(*args, end='\n'):
        self.write(' '.join(map(str, args)) + end)

    # Send the arguments to the print window. Same format as print()
    def value(self):
        return self.get('1.0', END)


# The tooltip class is used by many custom widgets to allow the 'tooltip' initialiser option.
class ToolTip(object):
    def __init__(self, widget):
        self.widget = widget
        self.tipwindow = None
        self.id = None
        self.x = self.y = 0

    def starttip(self, text):
        self.text = text
        self.active = True
        self.widget._nametowidget(self.widget.winfo_parent()).after(1000, self.showtip) # 1000ms after entering the widget, shot the tool tip.

    def showtip(self):
        if not self.active:
            return
        # Display text in tooltip window
        if self.tipwindow or not self.text:
            return
        x, y, cx, cy = self.widget.bbox("insert")
        x = x + self.widget.winfo_rootx() + 27
        y = y + cy + self.widget.winfo_rooty() +27
        self.tipwindow = tw = Toplevel(self.widget)
        tw.wm_overrideredirect(1)
        tw.wm_geometry("+%d+%d" % (x, y))
        try:
            # For Mac OS
            tw.tk.call("::tk::unsupported::MacWindowStyle",
                       "style", tw._w,
                       "help", "noActivates")
        except TclError:
            pass
        label = Label(tw, text=self.text, justify=LEFT,
                      background="#ffffe0", relief=SOLID, borderwidth=1,
                      font=("tahoma", "8", "normal"))
        label.pack(ipadx=1)

    def hidetip(self):
        self.active = False
        tw = self.tipwindow
        self.tipwindow = None
        if tw:
            tw.destroy()


# This function allows a tooltip to be assigned to a widget.
# Params
#     widget - widget to attach the tool tip to.
#     text   - tool tip text
# Returns
#     None
# Usage
#        self.my_widget = NumberField(self, text='My Number Field')
#        createToolTip(self.my_widget, 'This text will appear as a tooltip if the\npointer hangs over the entry field')
def createToolTip(widget, text):
    toolTip = ToolTip(widget)
    def enter(event):
        toolTip.starttip(text)
    def leave(event):
        toolTip.hidetip()
    widget.bind('<Enter>', enter)
    widget.bind('<Leave>', leave)


####
# GUI Application class
#
# This class should be sub-classed to create your application.
# Usage:
#    class my_app(gui.app):
#        def __init__(self, *args, **kwargs):
#            gui.app.__init__(self, *args, **kwargs)                                  # Call the base class initialiser
#            self.my_text_ctrl = self.add_text(text='This is my application class!')  # Add my own control.
####

class app(Frame):
    close_funcs = []  # Functions to be called when the app is closing

    # Class initialisation function.
    #   Handle named parameters 'title', 'parent', 'debugLevel'
    #   Set up the class for adding widgets using the 'add_' functions.
    def __init__(self, *args, **kwargs):
        self.child_apps = []   # Use to keep track of applications opened using 'exec_child_application' or 'exec_child_script'
        self.stopping = False
        title = 'Application'
        if 'title' in kwargs:
            title = kwargs['title']
            del kwargs['title']

        self.parent = None
        if 'parent' in kwargs:
            self.parent = kwargs['parent']
            del kwargs['parent']

        self.debugLevel = 0
        if 'debugLevel' in kwargs:
            self.debugLevel = kwargs['debugLevel']
            del kwargs['debugLevel']

        # Use a dialog based exception handler because the console window may not be available
        if self.debugLevel == 0:
            swap_exception_handler()

        self.modules = dict()
        self.stdout = None

        # These are used to keep track of where to add the next dialog control
        self.dialog_row = 0
        self.dialog_col = 0

        Grid.rowconfigure(self.parent, 0, weight = 1)
        Grid.columnconfigure(self.parent, 0, weight = 1)
        Frame.__init__(self, self.parent, *args, **kwargs)
        self.grid(row = 0, column = 0, sticky=N+S+E+W)

        # Set the title
        self._nametowidget(self.winfo_parent()).title(title)

        if self.parent != None:
            self.parent.protocol("WM_DELETE_WINDOW", self.on_closing)

    def mainloop(self):
        try:
            Frame.mainloop(self)
        except KeyboardInterrupt:  # TODO - this does not work!!!!!!!! Exception NOT caught.
            pass

    def on_closing(self):
        self.stopping = True
        self.after(100, self.parent.destroy)

    # Function called when app is closing. Cleans up child objects.
    def destroy(self):
        # Tell associated objects that the window is closing
        for func in self.close_funcs:
            func()
        # If stdout was re-directed - restore original value
        if self.stdout != None:
            sys.stdout.close()
            #sys.stdout = self.stdout  NOTE If the window is constantly printed, an exception is caused when the window closes
        # Destroy child applications
        for child in self.child_apps:
            try:
                child.parent.destroy()
            except:
                pass
        try:
            Frame.destroy(self)
        except:
            pass


    # This function updates the controls on the display. It should be used in long loops to keep the display active.
    def update_controls(self):
        self.update_idletasks()
        self.update()

    # Function used when add widgets to an app. It moved the row that widgets are added on down a line and moved to the first column.
    def newline(self):
        self.dialog_row = self.dialog_row + 1
        self.dialog_col = 0

    # Add a text element to the dialog
    def add_text(self, text='', span=1, tooltip=None, sticky=W+N+S, padx=2, pady=2, justify=LEFT):
        Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = Text(self, text=text, justify=justify)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        if tooltip != None: createToolTip(x, tooltip)
        return x

    # Add a tick box element to the dialog
    def add_tick_box(self, text='', func=None, span=1, tooltip=None, sticky=W+N, padx=2, pady=2, justify=LEFT):
        Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = TickBox(self, text=text, func=func, justify=justify)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        return x

    # Add a number entry element to the dialog. Note: float is allowed.
    def add_input(self, text='', func=None, span=1, tooltip=None, sticky=E+W, padx=2, pady=2, width=None, format=None):
        if func == None:
            x = NumberField(self, text=text, width=width, format=format)
        else:
            x = NumberField(self, validate='focusout', validatecommand=func, text=text, width=width, format=format)
        Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        if tooltip != None: createToolTip(x, tooltip)
        return x

    # Add a text entry element to the dialog.
    def add_text_input(self, text='', func=None, span=1, tooltip=None, sticky=E+W, padx=2, pady=2, width=None):
        if func ==None:
            x = TextField(self, text=text, width=width)
        else:
            x = TextField(self, validate='focusout', validatecommand=func, text=text, width=width)
        Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        if tooltip != None: createToolTip(x, tooltip)
        return x

    # Add a number entry element to the dialog. Note: float is allowed.
    def add_multiline_text_input(self, text='', lines=1, span=1, tooltip=None, sticky=E+W, padx=2, pady=2):
        x = ScrolledText(self, height=lines)
        Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        if tooltip != None: createToolTip(x, tooltip)
        return x

    # Add a button element to the dialog
    def add_button(self, text='', func=None, span=1, tooltip=None, sticky=W+N, padx=2, pady=2, **kwargs):
        Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = Button(self, text=text, command=func, **kwargs)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        if tooltip != None: createToolTip(x, tooltip)
        return x

    def do_nothing():
        pass

    # Add a combo frop down element to the dialog
    def add_combo(self, text='', func=do_nothing, span=1, tooltip=None, sticky=W+N+E, padx=2, pady=2):
        Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = Combo(self, text=text, func=func)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        if tooltip != None: createToolTip(x, tooltip)
        return x

    # A multiline text control which can accept text from print
    def add_print_window(self, *args, **kwargs):
        if not 'padx'   in kwargs: kwargs['padx'] = 2
        if not 'pad2'   in kwargs: kwargs['padx'] = 2
        tooltip = None
        if 'tooltip'   in kwargs:
            tooltip = kwargs['tooltip']
            del kwargs['tooltip']
        sticky = N+S+E+W
        if 'sticky'   in kwargs:
            sticky = kwargs['sticky']
        span = 1
        if 'span'   in kwargs:
            span = kwargs['span']
            del kwargs['span']
        Grid.rowconfigure(self, self.dialog_row, weight = 1)
        Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = TextWindow(self, *args, **kwargs)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky)
        self.dialog_col = self.dialog_col + span
        if tooltip != None: createToolTip(x, tooltip)
        return x

    # Redirect stdout to a text window. Duplidate to existing stdout if std_duplicated is True.
    def redirect_print(self, ctrl, std_duplicated=False):
        if self.stdout == None:
            self.stdout = sys.stdout
        if std_duplicated:
            sys.stdout = writer(ctrl.write, sys.stdout)
        else:
            sys.stdout = writer(ctrl.write, None)

    # Load a module if it has not already been loaded
    def load_module(self, file):
        # Is this a new module?
        if not file in self.modules:
            # Make a copy of the file without the first line. The imp module does not like non-python lines.
            new_file = os.environ['TEMP'].replace('\\', '/') + '/' + os.path.basename(file)
            file_in = open(file, 'r')
            file_out = open(new_file, 'w')
            line_no = 0
            for line in file_in:
                line_no += 1
                if line_no > 1:
                    file_out.write(line)
            file_in.close()
            file_out.close()

            # Load the module
            imp.acquire_lock()
            module = imp.load_source(new_file, new_file)
            imp.release_lock()
            self.modules[file] = module


    # Execute the given .wsf script.
    def exec_child_script(self, cmd, param = None):
        self.exec_child_application(cmd, script=True, param = param)

    # Execute the given .cmd script.
    def exec_child_application(self, cmd, script=False, param = None):
        self.load_module(cmd)
        # Execute the module
        try:
            window_app = None
            if not script:
                window_app = Tk()
            if param == None:
                app = self.modules[cmd].exec(window_app, self.device)
            else:
                app = self.modules[cmd].exec(window_app, self.device, param=param)
            if not script:
                # Remember this child app so we can close it later
                self.child_apps.append(app)
        except Exception as e:
            print("Exception:", e)


    # Get APP_DESCRIPTION from the given script. Useful for adding to the tooltip of buttons.
    def child_application_description(self, cmd):
        self.load_module(cmd)
        # Get the description
        description = cmd
        try:
            description = self.modules[cmd].APP_DESCRIPTION
        except:
            pass

        return description

# Execute the given script.
def get_child_script(file, script=False, param = None):
    new_file = os.environ['TEMP'].replace('\\', '/') + '/' + os.path.basename(file)
    file_in = open(file, 'r')
    file_out = open(new_file, 'w')
    line_no = 0
    for line in file_in:
        line_no += 1
        if line_no > 1:
            file_out.write(line)
    file_in.close()
    file_out.close()

    # Load the module
    imp.acquire_lock()
    module = imp.load_source(new_file, new_file)
    imp.release_lock()
    return module


