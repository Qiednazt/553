#-------------------------------------------------------------------------------
# Name:        hex_file library
# Purpose:     Provide an easy to manipulate hex file
#
# Author:      Mike Morgan
#
# Created:     9/4/2016
# Copyright:   (c) Dyson 2016
#-------------------------------------------------------------------------------

import sys
import os
import time
import subprocess
import struct
from project_intelhex import *

def safe_int(value):
    try:
        return "%d" % int(value)
    except:
        return 'NaN'

#-------------------------------------------------------------------------------
# The HexFile class handles adds to the IntelHex library object.
#-------------------------------------------------------------------------------
class HexFile(IntelHex):
    descriptions = dict()

    def __init__(self, hex_file=None):
        self.empty_block = bytearray()
        for i in range(32 * 1024):
            self.empty_block.append(0)
        if hex_file == None:
            IntelHex.__init__(self)
            self.memory_all_used_below = 0
            self.used_memory = bytearray()
        else:
            IntelHex.__init__(self, hex_file)
            self.memory_all_used_below = self.maxaddr()+1
            self.used_memory = bytearray()
            self.invalidate_memory(0, self.memory_all_used_below)

    def invalidate_memory(self, addr, size):
        while len(self.used_memory) < (addr + size):
            self.used_memory += self.empty_block
        for i in range(size):
            self.used_memory[addr + i] = 1
        
    def find_free_memory(self, size, align = 1):
        # Find first free memory
        while self.used_memory[self.memory_all_used_below] != 0:
            self.memory_all_used_below += 1
            if self.memory_all_used_below >= len(self.used_memory):
                self.used_memory += self.empty_block
        
        i = self.memory_all_used_below
        while True:
            # Extend the memory if we are close to the end
            if i + size > len(self.used_memory):
                self.used_memory += self.empty_block
            # Check memory
            i = (i + (align-1)) & ~(align-1)  # Move i up to next alignment
            start = i
            while (i < (start + size)) and (self.used_memory[i] == 0):
                i += 1
            # Was the memory all unused?
            if i == (start + size):
                return start
            else:
                # Move i passed used memory
                while self.used_memory[i] != 0:
                    i += 1
                    if i >= len(self.used_memory):
                        self.used_memory += self.empty_block
                
                
    
    def set_write_addr(self, addr = None):
        if addr == None:
            self.write_addr = self.maxaddr() + 1
        else:
            self.write_addr = addr
    
    # Wtite a value. If description == 'NO_OUTPUT', don't print description line
    def write_value(self, value, type, description='', addr=None):
        a = self.write_addr
        if addr != None:
            a = addr
        if 'string' in description and type == 'uint8_t':
            s ='?'
            if value >= 32 and value < 127:
                s = chr(value)
            if description != 'NO_OUTPUT':
                print("0x%04x: %-9s %10d (0x%08x)  %s (%s)" % (a, type, value, value & 0xffffffff, description, s))
        elif type == 'float':
            if description != 'NO_OUTPUT':
                print("0x%04x: %-9s %23.6f  %s" % (a, type, value, description))
        elif type == 'double':
            if description != 'NO_OUTPUT':
                print("0x%04x: %-9s %23.12Ef  %s" % (a, type, value, description))
        elif type == 'int64_t' or type == 'uint64_t':
            if description != 'NO_OUTPUT':
                print("0x%04x: %-20s %10d (0x%016x)  %s" % (a, type, value, value & 0xffffffffffffffff, description))
        else:
            if description != 'NO_OUTPUT':
                print("0x%04x: %-9s %10d (0x%08x)  %s" % (a, type, value, value & 0xffffffff, description))
        if type == 'uint8_t':
            self.write_uint8(value, addr, description)
        elif type == 'int8_t':
            self.write_int8(value, addr, description)
        elif type == 'uint16_t':
            self.write_uint16(value, addr, description)
        elif type == 'int16_t':
            self.write_int16(value, addr, description)
        elif type == 'uint32_t':
            self.write_uint32(value, addr, description)
        elif type == 'int32_t':
            self.write_int32(value, addr, description)
        elif type == 'uint64_t':
            self.write_uint64(value, addr, description)
        elif type == 'int64_t':
            self.write_int64(value, addr, description)
        elif type == 'float':
            self.write_float(value, addr, description)
        elif type == 'double':
            self.write_double(value, addr, description)
        elif type[-1] == '*':
            self.write_uint32(value, addr, description)
        else:
            raise Exception('Unknown type %s' % type)
    
    def write_uint8(self, value, addr=None, description=None):
        if value < 0 or value > 0xff:
            raise Exception("Can not add uint_8 with a value %s for %s" % (safe_int(value), description))
        if addr == None:
            addr = self.write_addr
            inc = 1
        else:
            inc = 0
        self.invalidate_memory(addr, 1)
        self[addr] = value
        self.write_addr += inc
        
    def write_int8(self, value, addr=None, description=None):
        if value < -0x80 or value > 0x7f:
            raise Exception("Can not add int_8 with a value %s for %s" % (safe_int(value), description))
        if addr == None:
            addr = self.write_addr
            inc = 1
        else:
            inc = 0
        self.invalidate_memory(addr, 1)
        self[addr] = value & 0xff
        self.write_addr += inc
        
    def write_uint16(self, value, addr=None, description=None):
        if value < 0 or value > 0xffff:
            raise Exception("Can not add uint_16 with a value %s for %s" % (safe_int(value), description))
        if addr == None:
            addr = self.write_addr
            inc = 2
        else:
            inc = 0
        self.invalidate_memory(addr, 2)
        self[addr+0] = value & 0xff
        self[addr+1] = (value >> 8) & 0xff;
        self.write_addr += inc
        
    def write_int16(self, value, addr=None, description=None):
        if value < -0x8000 or value > 0x7fff:
            raise Exception("Can not add int_16 with a value %s for %s" % (safe_int(value), description))
        if addr == None:
            addr = self.write_addr
            inc = 2
        else:
            inc = 0
        self.invalidate_memory(addr, 2)
        self[addr+0] = value & 0xff
        self[addr+1] = (value >> 8) & 0xff;
        self.write_addr += inc
        
    def write_uint32(self, value, addr=None, description=None):
        if value < 0 or value > 0xffffffff:
            raise Exception("Can not add uint_32 with a value %s for %s" % (safe_int(value), description))
        if addr == None:
            addr = self.write_addr
            inc = 4
        else:
            inc = 0
        self.invalidate_memory(addr, 4)
        self[addr+0] = value & 0xff
        self[addr+1] = (value >> 8) & 0xff;
        self[addr+2] = (value >>16) & 0xff;
        self[addr+3] = (value >>24) & 0xff;
        self.write_addr += inc
        
    def write_uint64(self, value, addr=None, description=None):
        if value < 0 or value > 0xffffffffffffffff:
            raise Exception("Can not add uint_64 with a value %s for %s" % (safe_int(value), description))
        if addr == None:
            addr = self.write_addr
            inc = 8
        else:
            inc = 0
        self.invalidate_memory(addr, 8)
        self[addr+0] = value & 0xff
        self[addr+1] = (value >> 8) & 0xff;
        self[addr+2] = (value >>16) & 0xff;
        self[addr+3] = (value >>24) & 0xff;
        self[addr+4] = (value >>32) & 0xff;
        self[addr+5] = (value >>40) & 0xff;
        self[addr+6] = (value >>48) & 0xff;
        self[addr+7] = (value >>56) & 0xff;
        self.write_addr += inc
        
    def write_int32(self, value, addr=None, description=None):
        if value < -0x80000000 or value > 0x7fffffff:
            raise Exception("Can not add int_32 with a value %s for %s" % (safe_int(value), description))
        if addr == None:
            addr = self.write_addr
            inc = 4
        else:
            inc = 0
        self.invalidate_memory(addr, 4)
        self[addr+0] = value & 0xff
        self[addr+1] = (value >> 8) & 0xff;
        self[addr+2] = (value >>16) & 0xff;
        self[addr+3] = (value >>24) & 0xff;
        self.write_addr += inc
        
    def write_int64(self, value, addr=None, description=None):
        if value < -0x8000000000000000 or value > 0x7fffffffffffffff:
            raise Exception("Can not add int_64 with a value %s for %s" % (safe_int(value), description))
        if addr == None:
            addr = self.write_addr
            inc = 8
        else:
            inc = 0
        self.invalidate_memory(addr, 8)
        self[addr+0] = value & 0xff
        self[addr+1] = (value >> 8) & 0xff;
        self[addr+2] = (value >>16) & 0xff;
        self[addr+3] = (value >>24) & 0xff;
        self[addr+4] = (value >>32) & 0xff;
        self[addr+5] = (value >>40) & 0xff;
        self[addr+6] = (value >>48) & 0xff;
        self[addr+7] = (value >>56) & 0xff;
        self.write_addr += inc
        
    def write_float(self, value, addr=None, description=None):
        if value > 1E38 or value < -1E38:
            raise Exception("Can not add float with a value %f for %s" % (value, description))
        if addr == None:
            addr = self.write_addr
            inc = 4
        else:
            inc = 0
        self.invalidate_memory(addr, 4)
        bytes = struct.pack('f', value)
        self[addr+0] = bytes[0]
        self[addr+1] = bytes[1];
        self[addr+2] = bytes[2];
        self[addr+3] = bytes[3];
        self.write_addr += inc
        
    def write_double(self, value, addr=None, description=None):
        if addr == None:
            addr = self.write_addr
            inc = 8
        else:
            inc = 0
        self.invalidate_memory(addr, 8)
        bytes = struct.pack('d', value)
        self[addr+0] = bytes[0]
        self[addr+1] = bytes[1];
        self[addr+2] = bytes[2];
        self[addr+3] = bytes[3];
        self[addr+4] = bytes[4];
        self[addr+5] = bytes[5];
        self[addr+6] = bytes[6];
        self[addr+7] = bytes[7];
        self.write_addr += inc
        
    
    
