#
# This module pretends to be the intelhex library
# If the library is not available, it is installed from the 'python_install' folder.
# The environment 'python_install' points to a folder which contains the zip file for this library.
#
# Usage:
#   import project_intelhex as intelhex
#

import zipfile
import os
import shutil

# Import the module

try:
    from intelhex import *
    installed = True
except:
    installed = False
    
# Did it import?
if not installed:
    # The module did not load, we will have to install it
    name = 'intelhex-2.1'
    
    # Display install message window
    import tkinter
    top = tkinter.Tk()
    top.title("Installing")
    msg = tkinter.Message(top, text="\nInstalling library " + name + "\n")
    msg.pack()
    top.update()

    filename = os.environ['NETWORK_TOOLS_DIR'] + '/Python/' + name + '.zip'

    # Remove pre-existing install files
    shutil.rmtree(os.environ['TEMP'] + '/' + name, ignore_errors=True)
    
    errstr = None
    try:
        errstr = 'Installing ' + name + ': Could not open ' + filename
        zip = zipfile.ZipFile(filename)
        errstr = 'Installing ' + name + ': Could not open unzip ' + filename + '  to  ' + os.environ['TEMP']
        zip.extractall(os.environ['TEMP'])
        os.system('cd /d "' + os.environ['TEMP'] + '\\' + name + '" & "' + os.environ['PYTHON_EXEC_DIR'] + '\\python.exe" setup.py install')
        errstr = 'Installing ' + name + ': Failed to install'
        from intelhex import *
        errstr = None
        print("\n\nFinished installing library " + name + "\n\n")
    except:
        pass
        
    if errstr != None:
        raise Exception(errstr)
        
    # Clean up
    shutil.rmtree(os.environ['TEMP'] + '/' + name, ignore_errors=True)
    
    # Close the info window
    try:
        top.destroy()
    except:
        pass

