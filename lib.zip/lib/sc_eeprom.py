#-------------------------------------------------------------------------------
# Name:        hc_eeprom.py
# Purpose:     This module defines EEPROM flags for N505 HC.
#
# Author:      Nikita Shmidt
#
# Created:     15/03/2018
# Copyright:   (c) Dyson Technology Ltd. 2018
#-------------------------------------------------------------------------------

class BehaviourFlag(list):
    def __init__(self, **kwargs):
        self.append(kwargs["off"])
        self.append(kwargs["on"])
        del kwargs["off"]
        del kwargs["on"]
        self.__dict__.update(kwargs)

behaviour_flags = (
        BehaviourFlag(
            bit_position = 0,
            name = "EEP_BEHAVIOUR_ENABLE_FCT_MODE_BIT_MASK",
            text = "Enable FCT mode",
            off = "The motor starts in the application (normal) mode",
            on = "The motor starts in the FCT mode"
        ),
        BehaviourFlag(
            bit_position = 1,
            name = "EEP_BEHAVIOUR_DISABLE_SILENT_RESET_BIT_MASK",
            text = "Disable silent reset on certain errors",
            off = "On some errors the application will silently reset itself",
            on = "Any error will cause emergency shutdown and entry into the error state"
        ),
        BehaviourFlag(
            bit_position = 2,
            name = "EEP_BEHAVIOUR_CAL_WRITE_DISABLE_BIT_MASK",
            text = "Disable calibration write",
            off = "Calibration write is enabled",
            on = "Calibration write is disabled"
        ),
        BehaviourFlag(
            bit_position = 3,
            name = "EEP_BEHAVIOUR_DISABLE_EBOX_HC_HEARTBEAT_BIT_MASK",
            text = "Disable ebox hc heartbeat",
            off = "Ebox hc heartbeat is enabled",
            on = "Ebox hc heartbeat is disabled"
        ),
)
