#-------------------------------------------------------------------------------
# Name:        dip_connection
# 
# Purpose:     Provide a Dyson Inter Process Communication (DIPC) connection to a device.
#
# The LEC connection standards are defined in 
#    DOC-0090733 - DIPC Framing protocol     - Version 02  01/03/2017
#    DOC-0090730 - DIPC Datalink Protocol    - Version 02  01/03/2017
#    DOC-0090731 - DIPC Network Protocol     - Version 02  01/03/2017
#    DOC-0090734 – DIPC Protocol Stack       - Version 02  01/03/2017
#    DOC-0090732 – DIPC Application Protocol - Version 02  01/03/2017
#    N248 Specific: http://confluence.dyson.global.corp/display/N248/N248+Protocol
#    General:       http://confluence.dyson.global.corp/display/KAF/Low-End+Connectivity+-+Inter-Processor+Comms
#
# This module implements the 'minimal usage' model as defined by DOC-0090734. The module implements the 'master' 
# part of the DIPC communication described as 'Simple Network'
#    
# Suggested usage:
#    This library would not normally be used by applications. It would normally be included in a DIPC protocol
#    library.
#
# Notes:
#    1) Every frame has dedicated delimiter bytes (0x12) even if they are sent immediately after a previous frame E.g.
#            0x12 data 0x12 0x12 data 0x12
#       According to the spec, the middle 0x12 0x12 bytes can be reduced to a single 0x12 byte. This library does not do this
#       on sending, but it will accept data in this form.
#    2) The protocol version byte is 0x00
#    3) The Physical address is not implemented
#    4) The control field normally only handles UI messages. SNRM messages are sent when trying to 
#       gain an initial connection (as a primary). Any response is considered a connection.
#
# Author:      Mike Morgan
# Created:     10/08/2016
# Copyright:   (c) Dyson 2016
#-------------------------------------------------------------------------------

import copy                       # Standard Python Library
import time                       # Provides timing functions
import dipc_framing

#-------------------------------------------------------------------------------
# This class implements Datalink/Network layers of the Dyson Low Level 
# Connectivity (LEC) protocol.
#
# This protocol is defined in (IN CONFLUENCE AT THE MOMENT http://confluence.dyson.global.corp/display/KAF/Datalink+and+Network+Layers - last dated 4 Aug 16)
# Currently, the protocol is partially implemented. Thse are:
#      
#
#-------------------------------------------------------------------------------


class DipcConnection():
    # CODE values     UI     B5     B4     B2     B1     B0     
    UNNUMBERED_UI   = 0xc0 + (0<<5)+(0<<4)+(0<<2)+(0<<1)+(0<<0)  # 0 0 0 0 0 Unnumbered Information
    UNNUMBERED_DM   = 0xc0 + (1<<5)+(1<<4)+(0<<2)+(0<<1)+(0<<0)  # 1 1 0 0 0 Danger Mouse - Secondary node says 'I need initialising'
    UNNUMBERED_DISC = 0xc0 + (0<<5)+(0<<4)+(0<<2)+(1<<1)+(0<<0)  # 0 0 0 1 0 Disconnect secondary
    UNNUMBERED_UA   = 0xc0 + (0<<5)+(0<<4)+(1<<2)+(1<<1)+(0<<0)  # 0 0 1 1 0 Unnumbered Acknowledge
    UNNUMBERED_SNRM = 0xc0 + (0<<5)+(0<<4)+(0<<2)+(0<<1)+(1<<0)  # 0 0 0 0 1 Set Normal Response Mode
    UNNUMBERED_FRMR = 0xc0 + (1<<5)+(0<<4)+(0<<2)+(0<<1)+(1<<0)  # 1 0 0 0 1 Invalid Frame Received
    UNNUMBERED_XID =  0xc0 + (1<<5)+(1<<4)+(1<<2)+(0<<1)+(1<<0)  # 1 1 1 0 1 Exchange node identification

    SW_ID_REQ = 0x0300 # SOFTWARE_ID_REQ - used for connection test 
    SW_ID_RES = 0x0301 # SOFTWARE_ID_RES - used for connection test     
 
    #
    # Params:
    #   com_port (default None)
    #     The port string is the serial port to use for the connection. It can be of the form 'com1:' but it should be
    #     of the form '\\.\COMx' to avoid issues with ports of high number e.g. COM22. If the value is None, the
    #     class will use a tkinter dialog (defined in the 'port_selection' module) to allow the user to select a com port. 
    #     If this method is used, the class has the persistent 'user_data' dictionary defined which is saved to file when 
    #     the class object closes.
    #     'ask' will display a list of available com ports.
    #   name (default 'DIPC connection')
    #     A description of the connection. For PCs connection to several devices, this helps keep track of which device is which.
    #     e.g. name='V10 connection'
    #   debugLevel (default 0)
    #     0-9   No debug
    #     10 >= High level debug
    #     20 >= Packet data
    #     30 >= Low level
    #     40 >= Very Low level
    #   baud (default 19200)
    #     Baud rate e.g. 19200. Format is 8 data bits, 1 start bit, no parity
    #   byteorder (default 'little')
    #     If 'little', numbers are sent in little endian order, otherwise, 'big' endian order
    #   protocol_byte
    #     Value to use for the protocol byte.  This is defined by the protocol layer. If not specified, the protocol byte is ommitted.
    #   source_addr
    #     Value to use for the source_addr byte(s).  This is defined by the protocol layer. If not specified, the source/destination bytes are ommitted.
    #   source_addr_size
    #     Number of bytes to use for the source/destination bytes (if used). Default is 1. May be 2.
    #
    def __init__(self, **kwargs):
        self.protocol_byte    = kwargs.get('protocol_byte', None)
        self.source_addr      = kwargs.get('source_addr', None)
        self.destination_addr = kwargs.get('destination_addr', None)  
        self.source_addr_size = kwargs.pop('source_addr_size', 1)  # May be 1 or 2
        self.debugLevel       = kwargs.get('debug_level', 0)
        self.baud             = kwargs.get('baud', 115200)
        self.name             = kwargs.pop('name', 'DIPC connection')
        self.com_port         = kwargs.pop('com_port', None)  # By default, the user will select the com port
        self.byteorder        = kwargs.pop('byteorder', 'little')
        self.last_event_time = 0
        self.event_function = None
        self.ser = None
        
        if 'com_object' in kwargs:
            self.ser = kwargs['com_object'].connection.ser
            self.user_data = None
            return
        
        # If we still do not have a com port, ask the user
        self.user_data = None
        if self.com_port == None:
            import port_selection   # This is imported here so that tkinter is not required if the com port is specified. 
            # Ask the user to select a com port
            self.user_data = port_selection.get_com_port(name=self.name, test_func=self.connection_test, kwargs=kwargs)
            self.com_port = self.user_data['com_port']
            
        if self.com_port == 'ask':
            import port_selection
            self.com_port = None
            while self.com_port == None:
                popup = port_selection.ComSelect(self.name)
                popup.mainloop()            
                if popup.selected_port == None:
                    raise SystemExit(None)   # Quit if the use did not select a com port
                self.com_port = popup.selected_port
                try:
                    with dipc_framing.DipcFraming(self.com_port, **kwargs) as c:
                        pass
                except:
                    port_selection.could_not_open(self.com_port)
                    self.com_port = None
            
        # Open the com port
        try:
            self.ser = dipc_framing.DipcFraming(self.com_port, **kwargs)
            if self.debugLevel >= 30:
                print("%s.__init__(): %s opened" % (self.name, self.com_port))
        except:
            self.ser = None
            print('%s.__init__(): ERROR: Could not open %s' % (self.name, self.com_port))
            raise SystemExit(None)
        
    def __enter__(self):
        return self

    # Tidy up after exit or exception.
    def __exit__(self, type, value, traceback):
        self.close()
            
    #
    # This function is used to close a connection. It will save connection data and close the com port.
    #
    def close(self):
        # Try to close the serial port
        try:
            if self.ser != None:
                self.ser.close()
            if self.debugLevel >= 30:
                print("%s.close()" % self.name)
        except:
            pass
        self.ser = None

        # If the 'port_selection' module was used to open the serial port, save any user data in the 'port_selection' config file.
        # This allows the chosen com port to be automatically selected next time. Additionally, other user data is stored.
        if self.user_data != None:
            import port_selection   # This is imported here so that tkinter is not required if the com port is specified. 
            port_selection.save_user_data(self.user_data)
            
        
    # Internal function to process an incoming frame into seperate parts.
    # The incomming frame is assumed to have no length bytes and no CRC32 bytes.
    #  'data'              Payload of the protocol packet
    #  'protocol_byte'     The protocol byte of the packet - or None if this connection does not have a protocol byte defined
    #  'control_byte'      The control byte of the packet
    #  'source_addr'       Source address of packet - or None if this connection has no source address defined, 0xff if any addr is accepted
    #  'destination_addr'  Destination address of packet - or None if this connection has no source address defined
    def process_frame(self, frame):
        class Object(object): pass
        result = Object()
        index = 0
        try:
            # Process the protocol byte
            if self.protocol_byte != None:
                result.protocol_byte = frame[index]
                index += 1
            else:
                result.protocol_byte = None
            
            # Process the control byte
            result.control_byte = frame[index]
            index += 1

            # Process the source/destination byte(s)
            if self.source_addr != None:
                result.destination_addr = int.from_bytes(frame[index:index + self.source_addr_size], byteorder=self.byteorder, signed=False)
                index += self.source_addr_size
                result.source_addr      = int.from_bytes(frame[index:index + self.source_addr_size], byteorder=self.byteorder, signed=False)
                index += self.source_addr_size
            else:
                result.source_addr      = None
                result.destination_addr = None

            result.data = frame[index:]

        except:
            if self.debugLevel >= 10:
                print("%s.get_packet()  Exception when parsing packet." % self.name)
            result = None

        return result
        

    #
    # This function tests the specified com port to see if it has a valid connection to a device. It is used by the port_selection.get_com_port
    # function when it is looking for a connection. The function returns True if a device is spotted and False if not.
    #
    def connection_test(self, com_port, **kwargs):
        packet = None
        with DipcConnection(com_port = com_port, **kwargs) as device:
            # Send a command, expect a reply
            SW_ID_payload = [1, self.SW_ID_REQ & 0xff, (self.SW_ID_REQ >> 8) & 0xff]
            device.sendFrame(SW_ID_payload, code = self.UNNUMBERED_UI)
            packet = device.getFrame(timeout = 0.1)
            # Close the connection
            device.close()
        return packet != None
        
    
    #
    # This function constructs a frame based on a frame description and
    # sends it on the serial port.
    #
    # Params
    #   payload
    #     Byte array of the payload
    #   code
    #     Control code value as defined by the protocol specification
    #   pf
    #     Poll/Forget flag - as defined by the protocol spec
    #   destination_addr
    #     Destination address value to use. If None, then use self.destination
    #
    def sendFrame(self, payload, code = UNNUMBERED_UI, pf = 0, source_addr = None, destination_addr = None):
        if destination_addr == None: destination_addr = self.destination_addr
        if source_addr      == None: source_addr      = self.source_addr
        frame = bytearray()
        # Add the protocol byte if it is defined
        if self.protocol_byte != None:
            frame.append(self.protocol_byte)
        # Add the control byte
        frame.append(code | pf)
        # Add destination/source bytes
        if source_addr != None and destination_addr != None:
            frame.extend(destination_addr.to_bytes(self.source_addr_size, byteorder=self.byteorder, signed=False))
            frame.extend(     source_addr.to_bytes(self.source_addr_size, byteorder=self.byteorder, signed=False))
        # Pre-pend control bytes to payload
        frame.extend(payload)
        # Send to the serial port
        self.ser.sendFrame(bytes(frame))

    def send_packet(self, payload, code = UNNUMBERED_UI, pf = 0, source_addr = None, destination_addr = None):
        self.sendFrame(payload, code=code, pf=pf, source_addr=source_addr, destination_addr=destination_addr)

    # Wait for a packet. Timeout is in seconds. It may be a fraction.
    # Returns payload of packet.
    #  'data'              Payload of the protocol packet
    #  'protocol_byte'     The protocol byte of the packet - or None if this connection does not have a protocol byte defined
    #  'control_byte'      The control byte of the packet
    #  'source_addr'       Source address of packet - or None if this connection has no source address defined
    #  'destination_addr'  Destination address of packet - or None if this connection has no source address defined
    # Params
    #    timeout          - How long to wait
    #    destination_addr - Only accept packets with the correct destination addr. None=use object source_addr, 0xff=Ignore destination byte
    #    source_addr      - Only accept packets with the correct source addr. None=use object destination_addr, 0xff=Ignore source byte
    def getFrame(self, timeout=1.0, destination_addr=None, source_addr=None):
        if destination_addr == None: destination_addr = self.destination_addr
        if source_addr      == None: source_addr      = self.source_addr
        start = time.time()
        if self.debugLevel >= 30:
            print("%s.getFrame(timeout=%0.3f)" % (self.name, timeout * 1.0))
        frame = self.ser.getFrame(timeout=timeout)
        if self.debugLevel >= 30:
            if frame == None:
                print("%s.getFrame() - timeout" % self.name)
                return None
            else:
                print("%s.getFrame() - " % self.name, frame)
        # We have a valid packet. We must now parse it.
        result = self.process_frame(frame)

        # Do we have a message
        if result != None and len(result.data) > 0:
            # Is the message intended for someone else
            bad_addr = False          
            if source_addr      != None and source_addr      != 0xff and source_addr      != result.destination_addr:                                bad_addr=True          
            if destination_addr != None and destination_addr != 0xff and destination_addr != result.source_addr and result.destination_addr != 0xff: bad_addr=True           
            if self.event_function != None and result.destination_addr == 0x03 and result.source_addr == 0x02: # possible event from SC to UI
                try:
                    self.event_function(result.data[1:])
                except Exception as e:
                    pass
            if bad_addr:
                # Get another message
                result = self.getFrame(timeout = timeout - (time.time() - start), destination_addr=destination_addr, source_addr=source_addr)
            # Is it an event message?
            if result != None and len(result.data) > 0:
                if result.data[0] == 0x00:
                    if self.event_function != None:
                        try:
                            self.event_function(result.data[1:])
                        except Exception as e:
                            pass
                        # Get another message
                        result = self.getFrame(timeout = timeout - (time.time() - start), destination_addr=destination_addr, source_addr=source_addr)
        return result
    
    def wait_for_packet(self, timeout=1):
        return self.getFrame(timeout=timeout,destination_addr=self.destination_addr, source_addr=self.source_addr)
