"""

This script displays the current status of the device. It is implemented as the 'Status' button by _MotorControl.js.

The status is displayed in human readable form.

"""
# End Support Script Details


import sys                  # Standard Python library
import datetime             # date and time
import gui                  # Dyson Simplified Graphical User Interface library
import sc_protocol          # Dyson 505 Heater comms interface
import time
import re
import os.path

APP_TITLE = "Get Heater Status"
APP_HELP  = "Displays the current status of the heater."

# This function allows other scripts to start this script. Other scripts expect to see an exec function in this module.
# The script may be called using the gui.exec() function.
def exec(parent_app, device):
    # Display title
    print(APP_TITLE)
    print(APP_HELP)
    print()

    # load the system flags
    data_parsed = _load_file_in_dict()

    # Get data
    msg = device.command_messages()
    msg.add(sc_protocol.GET_HEATER_STATUS())
    device.send(msg)

    print("User heat level        = %s" % msg.results[0].heat)
    print("User eboxFlowMode level= %s" % msg.results[0].eboxFlowMode)
    print("Accessory attached     = %xh" % msg.results[0].type)
    print("Target temperature (c) = %s" % msg.results[0].temp)
    print("Motor offset (us)      = %s" % msg.results[0].offset)
    print("FlowModeName           = %s" % msg.results[0].eboxFlowModeName)
    print("uiState                = %s" % msg.results[0].state)
    error = msg.results[0].error
    print("Current error          = %x" % error)

    # Check if any of them are active
    print("List of active errors -")
    for key in data_parsed:
        value_int = int(data_parsed[key], 16)
        if(((1 << value_int) & error) != 0 ):
            print("Active - {} : {}".format(data_parsed[key], key))

    # Check inactive error
    print("List of Inactive errors -")
    for key in data_parsed:
        value_int = int(data_parsed[key], 16)
        if(((1 << value_int) & error) == 0 ):
            print("Inactive - {} : {}".format(data_parsed[key], key))


def _load_file_in_dict():
    """
    Stores the sys_flags info in the dict
    :param file to parse:

    """
    SYS_FLAG_HEADER = "../source/system/sys_flags.h"
    SYS_FLAG_TXT = "SYS_FLAGS.txt"

    if os.path.isfile(SYS_FLAG_HEADER):
        file = SYS_FLAG_HEADER
        print ("Using sys_flag.h header file.")
    elif os.path.isfile(SYS_FLAG_TXT):
        file = SYS_FLAG_TXT
        print ("Using SYS_FLAGS.txt text file.")
    else:
        print("Could not find list of sys_flags errors header or txt file.")
        raise FileNotFoundError

    # search for #define SYS_FLAGS_* and value assosiated with it
    regex_search_for = (r"^^\s*#define\s*(?P<id>[A-Z0-9_]*)\s+\(\s*(?P<value>[0-9xa-fA-F]*)")
    data_parsed = dict()

    with open(file, "r+") as c_header:
        line = c_header.readline()
        while line:
            match = re.search(regex_search_for, line)
            if match and match.group('id').endswith("_POS"):
                data_parsed[match.group('id')] = match.group('value')
            line = c_header.readline()

    return data_parsed

# Called by parent programs
def description():
    return APP_HELP;
