"""
Copywrite Dyson(C) 2020

API to update the arm position mode
"""

from enum import Enum
from sc_protocol import SET_ARM_POSITION_MODE, GET_ARM_POSITION_MODE


class OperatingModes(Enum):
    """
    Operating modes, must match tArm_operatingMode from arm_position.h
    """
    auto = 0
    open = 1
    closed = 2


def update_mode(device, mode):
    """
    Update the arm position mode, does not write to eeprom.

    Args:
        device: sc_protocol device to communicate through
        mode: str, int or OperatingModes mode to send

    Returns:
        None
    """
    if isinstance(mode, str):
        int_mode = OperatingModes[mode].value
    elif isinstance(mode, OperatingModes):
        int_mode = mode.value
    elif isinstance(mode, int) and (mode < len(OperatingModes)):
        int_mode = mode
    else:
        raise ValueError("Invalid operating mode {}".format(mode))

    cmd = SET_ARM_POSITION_MODE(int_mode)
    msg = device.command_messages()
    msg.add(cmd)
    device.send(msg)

def get_mode(device):
    """
    get current arm position mode

    Args:
        device: sc_protocol device to communicate with

    Returns:
        OperatingModes: current value of operating mode

    Raises:
        ValueError: got a bad response
    """
    cmd = GET_ARM_POSITION_MODE()
    msg = device.command_messages()
    msg.add(cmd)
    device.send(msg)
    return OperatingModes(cmd.arm_position_mode)
