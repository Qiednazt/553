#-------------------------------------------------------------------------------
# Name:        port_selection
# Purpose:     Provide two frame classes to aid the user selection a com port.
#
# Author:      Mike Morgan
#
# Created:     10/08/2016
# Copyright:   (c) Dyson 2016
#-------------------------------------------------------------------------------

import os
import json
import dipc_framing
from tkinter import *            # GUI library for connection dialog
from tkinter import messagebox   # GUI library for connection dialog


# This function will allow the user to select a com port from a list of available com ports.
# Params:
#     name
#         The name is displayed on dialog boxes and also used to specify the user settings data file.
#     test_func
#         This parameter is a function which is called to ensure the device is present on the selected
#         serial port. It is supplied with a serial object and must return True if a device is connected.
#         If the value is None, the function will not ensure the device is present.
#
def get_com_port(name='LEC Communications', test_func=None, **kwargs):
    settings_filename = kwargs.get('settings_filename', None)
    # Ensure settings_filename is a valid filename.
    if settings_filename == None:
        filename = name
        # Ensure filename has only value characters.
        for char in '\\/:*?"><|':
            filename = filename.replace(char, '_')
        settings_filename = os.environ['TEMP'] + '/' + filename + '.ini' # E.g. C:\Users\mikemorgan\AppData\Local\Temp\Dyson V10 Serial Comms.ini
    
    # Get the JSON user data from the file
    user_data = {}
    try:
        f = open(settings_filename, 'r')
        user_data = json.loads(f.readline().replace('\r', '').replace('\n', ''))
        user_data['settings_filename'] = settings_filename
        f.close()
    except:
        user_data = {}
    if not 'com_port' in user_data:
        user_data['settings_filename'] = settings_filename
        user_data['com_port'] = None
        
    while True:
        # If no default com port has been defined, ask the user to select one
        if user_data['com_port'] == None:
            popup = ComSelect(name)
            popup.mainloop()
            if popup.selected_port == None:
                raise SystemExit(None)   # Quit if the use did not select a com port
            user_data['com_port'] = popup.selected_port
            
        # First test - can the com port be opened
        port = None
        try:
            port = dipc_framing.DipcFraming(user_data['com_port'])
        except:
            messagebox.showinfo('Error','Could not open ' + user_data['com_port'])
            user_data['com_port'] = None
        if port != None:
            port.close()
        
        # If a test function has been defined, wait for confirmation that the connection is OK
        if user_data['com_port'] != None and test_func != None:
            waiting = DeviceConnect(name, user_data['com_port'], test_func, **kwargs)
            waiting.mainloop()
            # If the user wanted to cancel, quit the app
            if waiting.result == DeviceConnect.USER_CANCEL:
                raise SystemExit(None)
            elif waiting.result == DeviceConnect.CHANGE_PORT:
                user_data['com_port'] = None
        
        # If the com port is defined at this stage, we have chosen a com port - so quit
        if user_data['com_port'] != None:
            # If there was not test function, do not save the com port. We will always need to select the com port if there is no test function.
            if test_func == None:
                user_data['com_port'] = None
            # Allow save_user_data() to know where to save the file
            save_user_data(user_data)
            return user_data
        
# Save data to a file so that it is read when we next connect.
def save_user_data(user_data):
    try:
        f = open(user_data['settings_filename'], 'w')
        f.write(json.dumps(user_data, separators=(',', ':'))+'\n')
        f.close()
    except:
        pass
            
def could_not_open(port):
    messagebox.showinfo('Error','Could not open ' + port)
            

        
#-------------------------------------------------------------------------------
# This class allows the user to select a ComPort from a list. Only com ports
# that can be opened are listed.
# Usage:
#    myapp = ComSelect()
#    myapp.mainloop()
#    print(myapp.selected_port)
# or
#    myapp = ComSelect(default_port='\\\\.\\COM1')
#    myapp.mainloop()
#    print(myapp.selected_port)
#
# If no com port is selected, 'selected_port' will be None, otherwise a string
# is returned with the name of the selected com port.
# Note, On Windows, COM port names are of the form \\.\COMx to avoid issues with
# ports of high number e.g. COM22.
#-------------------------------------------------------------------------------
class ComSelect(Frame):
    selected_port = None
    def __init__(self, name, master=None, default_port=None):
        Frame.__init__(self, master)
        self.pack()
        self.master.title("Select port")
        self.v = StringVar()
        Label(master, text='Please select a COM port for ' + name).pack()
        ports = self.serial_ports()
        for port in ports:
            b = Radiobutton(master, text=port, variable=self.v, value=port)
            b.pack()
            if port == default_port:
                b.select()
                default_port = 'DONE'
        # If none of the comports is the default port, do an invisible radio button to allow all visible buttons to be de-selected
        if default_port != 'DONE':
            Radiobutton(master, text='x', variable=self.v, value='INVALID').select()
        # Add the OK and Cencel buttons
        Button(master, text="OK", command=self.callbackOK).pack(side=LEFT, padx=10, pady=10)
        Button(master, text="Cancel", command=self.callbackCancel).pack(side=RIGHT, padx=10, pady=10)

    def callbackOK(self):
        # Quit the dialog if we have a value com port selected.
        if self.v.get() != 'INVALID':
            self.selected_port = self.v.get()
            self.master.destroy()

    def callbackCancel(self):
        # The self.selected_port value is None by default and is only set by callbackOK
        # So we can just destroy
        self.master.destroy()

    # Thanks to Twitter @rodcloutier - Return a list of all serial ports
    def serial_ports(self):
        """Lists serial ports
            :raises EnvironmentError:
            On unsupported or unknown platforms
            :returns:
            A list of available serial ports
        """
        if sys.platform.startswith('win'):
            import winreg
            import itertools
            path = 'HARDWARE\\DEVICEMAP\\SERIALCOMM'
            try:
                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path)
            except WindowsError:
                raise IterationError
            ports = []
            for i in itertools.count():
                try:
                    name, port, available = winreg.EnumValue(key, i)
                    if available != 0:
                        ports.append(port)
                except EnvironmentError:
                    break
            return ports
        elif sys.platform.startswith('linux') or sys.platform.startswith('cygwin'):
            # this is to exclude your current terminal "/dev/tty"
            ports = glob.glob('/dev/tty[A-Za-z]*')
        elif sys.platform.startswith('darwin'):
            ports = glob.glob('/dev/tty.*')
        else:
            raise EnvironmentError('Unsupported platform')
        result = []
        for port in ports:
            print(port)
            try:
                s = serial.Serial(port)
                s.close()
                result.append(port)
            except (OSError, serial.SerialException):
                pass
        return result


#-------------------------------------------------------------------------------
# This class pops up a message box that says 'Connecting to device on comX' and
# has two buttons 'Cancel' and 'Change port'. The serial_port_object parameter
# must be an open serial port.
# The class will periodically send a message to the device. The class quits
# when a valid reply is recieved or the user quits.  The self.result variable
# may be
#    DeviceConnect.CONNECTED
#    DeviceConnect.USER_CANCEL
#    DeviceConnect.CHANGE_PORT
#
# Usage:
#    myapp = DeviceConnect(data_link_object)
#    myapp.mainloop()
#    print(myapp.result) # Either DeviceConnect.CONNECTED,
#                        #     or DeviceConnect.USER_CANCEL
#                        #     or DeviceConnect.CHANGE_PORT
#-------------------------------------------------------------------------------
class DeviceConnect(Frame):
    CONNECTED   = 1
    USER_CANCEL = 2
    CHANGE_PORT = 3
    result = USER_CANCEL
    def __init__(self, name, com_port, test_func, master=None, **kwargs):
        self.com_port = com_port
        self.test_func = test_func
        self.kwargs = kwargs
        Frame.__init__(self, master)
        self.pack()
        self.master.title("Waiting...")
        Label(master, text='Connecting to device %s on %s' % (name, com_port)).pack()
        Button(master, text="Cancel", command=self.callbackCancel).pack(side=LEFT, padx=10, pady=10)
        Button(master, text="Change Port", command=self.callbackChangePort).pack(side=RIGHT, padx=10, pady=10)
        # Start sending messages to the device
        self.master.after(0, self.callbackSendMsg)

    def callbackChangePort(self):
        # The user has decided to try a different com port
        self.result = self.CHANGE_PORT
        self.master.destroy()

    def callbackCancel(self):
        # The user has decided to give up competely
        self.result = self.USER_CANCEL
        self.master.destroy()

    def callbackSendMsg(self):
        # Check if there was a response to a ping. If so, terminate this class,
        # otherwise, send another ping
        if self.test_func(self.com_port, **self.kwargs['kwargs']) == False:
            self.master.after(200, self.callbackSendMsg)
        else:
            self.result = self.CONNECTED
            self.master.destroy()
                
  
        