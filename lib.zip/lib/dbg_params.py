#-------------------------------------------------------------------------------
# Name:        Debug Parameter Read
# Purpose:     This module allows to read debug parameters
#
# Authors:     Lulim
#
# Created:     23/09/2020
# Copyright:   (c) Dyson Technology Ltd. 2020
#-------------------------------------------------------------------------------

import gui                      # Dyson Simple User Interface library
import sc_protocol              # Dyson N553 SC comms interface
import struct
import array
import tkinter

APP_TITLE = "Debug params"
APP_HELP  = "This script allows the user to read debug params\n"

# Full stickiness for Tk controls
STICKY_NSEW = gui.N + gui.S + gui.E + gui.W
DEBUG_VAR_FILENAME = "debugvar.txt"

class this_app(gui.app):
    #
    # Define the controls
    #
    def __init__(self, *args, **kwargs):
        # Process arguments speficic to this application
        if 'device' in kwargs:
            self.device = kwargs['device']
            del kwargs['device']
            self.close_funcs.append(self.device.closing) # Give the application a function which will abort the connection
        else:
            gui.error("'device' is a required named parameter for this app.")

        if 'parent_data' in kwargs:
            self.parent_data = kwargs['parent_data']
            print("Parent data received")
            del kwargs['parent_data']
        else:
            self.parent_data = None
            
        # Open the file
        debugvar_file = open(DEBUG_VAR_FILENAME, "r")
        self.debugvars_list = debugvar_file.readlines()
        
        # Initialise the base class
        gui.app.__init__(self, *args, **kwargs)
        self.address_val = [''] * len(self.debugvars_list)
        i = 0
        # Placing the texts
        for debugvar in self.debugvars_list:
            self.var_addr, self.var_size = self.device.get_variable_addr(debugvar.strip())
            self.add_text(debugvar.split())
            self.address_val[i] = self.add_text_input(text='')
            self.address_val[i].config(width = ( self.var_size + 2 ))
            self.newline()
            i = i + 1
        self.after(200, self.periodic)                     # After X milliseconds, execute self.periodic()

    def periodic(self):
        i = 0
        for debugvar in self.debugvars_list:
            self.var_addr, self.var_size = self.device.get_variable_addr(debugvar.strip())
            self.remaining_size = self.var_size
            self.value_str = ""
            while self.remaining_size > 0:
                self.readVar = self.device.peek_addr(self.var_addr + self.var_size - self.remaining_size)
                if self.remaining_size < 4:
                    if self.remaining_size == 1: self.readVar &= 0xff
                    if self.remaining_size == 2: self.readVar &= 0xffff
                    if self.remaining_size == 3: self.readVar &= 0xffffff
                    self.remaining_size = 0
                else:
                    self.remaining_size = self.remaining_size - 4
                self.value_str = ( "%.8x " % self.readVar ) + self.value_str

            # Update the read variable value
            self.address_val[i].change_text( "0x" + self.value_str )
            i = i + 1
        self.after(1000, self.periodic)  # Call this function again. 1000 ms to make time to Ctrl + C the value if needed. 

# Called by parent programs
def exec(parent_app, parent_data,device):
    app = this_app(parent=parent_app, parent_data=parent_data,device=device, title=APP_TITLE)
    return app

# Called by parent programs
def description():
    return APP_HELP

# Called by dbg_params.cmd
def exec_cmd():
    # Get a connection to a device
    description()
    print(APP_TITLE)
    print(APP_HELP)
    print()
    # Get a connection to a device
    with sc_protocol.HC_Protocol(debug_level=0) as device:
        # Run the script
        app = exec(tkinter.Tk(),None,device)
        app.mainloop()
        device.close()

# This code starts the app if the file is executed rather than imported.
if __name__ == '__main__':
    # Get a connection to a device
    description()
    print("This is not a stand alone script")
