#-------------------------------------------------------------------------------
# Name:        UI emulator
# Purpose:     This module will emulate UI button
#
# Authors:     Pan Zhiyang
#
# Created:     13/09/2019
# Copyright:   (c) Dyson Technology Ltd. 2019
#-------------------------------------------------------------------------------

import time                     # Standard Python library
import os                       # Standard Python library
import gui                      # Dyson Simple User Interface library
import sc_protocol as protocol  # Dyson N553 SC comms interface
import binascii

APP_TITLE = "N553 UI emulation GUI"
APP_HELP  = "This script will emulate UI button .\n"

# Full stickiness for Tk controls
STICKY_NSEW = gui.N + gui.S + gui.E + gui.W

class this_app(gui.app):
    #
    # Define the controls
    #
    def __init__(self, *args, **kwargs):
        # Process arguments speficic to this application
        if 'device' in kwargs:
            self.device = kwargs['device']
            del kwargs['device']
            self.close_funcs.append(self.device.closing) # Give the application a function which will abort the connection
        else:
            gui.error("'device' is a required named parameter for this app.")

        if 'parent_data' in kwargs:
            self.parent_data = kwargs['parent_data']
            del kwargs['parent_data']

        # Initialise the base class
        gui.app.__init__(self, *args, **kwargs)

        # Read autostart value and behaviour flags from target

        self.NUMBER_ENTRY_WIDTH = 10
        self.NUMBER_OUTPUT_WIDTH = 12
        self.MODE_SENSITIVE_NO = 9
        self.dataToSent_len = 20
        self.dataToSent = bytearray(self.dataToSent_len)
        self.dataToSent[self.dataToSent_len-4] = 0x4E  # 'N553'
        self.dataToSent[self.dataToSent_len-3] = 0x35
        self.dataToSent[self.dataToSent_len-2] = 0x35
        self.dataToSent[self.dataToSent_len-1] = 0x33

        self.add_button(text='Power',  func=self.power_button_pressed, tooltip="Power button")
        self.add_button(text='Mode',  func=self.mode_button_pressed, tooltip="Mode button")
        self.add_button(text='CoolFix',  func=self.sensitive_button_pressed, tooltip="CoolFix button")
        self.newline()
        self.add_button(text='Flow',  func=self.flow_button_pressed, tooltip="Flow button")
        self.add_button(text='Heat',  func=self.heat_button_pressed, tooltip="Heat button")
        self.newline()
        self.add_button(text='Pause on',  func=self.Pause_on_button_pressed, tooltip="Pause on button")
        self.add_button(text='Pause off',  func=self.Pause_off_button_pressed, tooltip="Pause off button")
        self.newline()
        self.add_text(text='Pause on delay time (ms):')
        self.pause_delay_time = self.add_input(text='2000', tooltip='Enter pause on delay time')
        self.newline()
        self.add_text(text='Current UI mode:')
        self.current_ui_mode_text  = self.add_text(text='')
        self.add_text(text='Current CoolFix:')
        self.current_sensitive  = self.add_text(text='')
        self.newline()
        self.add_text(text='Current heat mode:')
        self.current_heat_mode  = self.add_text(text='')
        self.add_text(text='Current heat temp:')
        self.current_heat_temp  = self.add_text(text='')
        self.newline()
        self.add_text(text='Current flow level:')
        self.current_flow_level  = self.add_text(text='')
        self.add_text(text='Current ebox flow mode:')
        self.current_ebox_flow_mode  = self.add_text(text='')
        self.newline()
        self.add_text(text='Current flow rate:')
        self.current_flow_rate  = self.add_text(text='')
        self.add_text(text='Current flow offset:')
        self.current_flow_offset  = self.add_text(text='')
        self.newline()
        self.add_text(text='Idle mode active:')
        self.idle_mode_active  = self.add_text(text='')
        self.newline()
        self.add_text(text='Pause mode active:')
        self.pause_mode_active  = self.add_text(text='')
        self.newline()
        self.add_text(text='Current arm clamp state:')
        self.current_clamp_state  = self.add_text(text='')
        self.newline()
        self.add_text(text='Current lock state:')
        self.current_lock_state  = self.add_text(text='')
        self.newline()
        self.update_controls()
        self.after(200, self.periodic)                     # After X milliseconds, execute self.periodic()
        if self.device != None:
            self.device.yeild = self.update                 # Tell the protocol to call this function when it enters a long loop

    # This function is called periodically. If there has not been any communication with the device for over a second,
    # it sends a 'get error status' command.  This sets the status text to either 'OK', 'Error' or 'Disconnected'
    def periodic(self):

        self.current_flow_level.change_text(self.parent_data.flowLevelName)
        # current_flow_level = msg.results[0].flowMode
        self.current_heat_mode.change_text(self.parent_data.heatModeName)
        # current_heat_level = msg.results[1].heatMode
        self.current_ui_mode_text.change_text(self.parent_data.ui_mode_name)
        self.current_sensitive.change_text(self.parent_data.sensitiveText)
        current_sensitive_status = self.parent_data.sensitive_state
        self.current_flow_rate.change_text(self.parent_data.targetFlowRate)
        self.current_ebox_flow_mode.change_text(self.parent_data.eboxFlowModeName)
        self.current_flow_offset.change_text(self.parent_data.offset)
        self.current_heat_temp.change_text(self.parent_data.temp)
        self.idle_activated = self.parent_data.idle_activated
        if self.parent_data.idle_activated == 0:
            self.idle_mode_active.change_text('No')
        else:
            self.idle_mode_active.change_text('Yes')

        if self.parent_data.pause_activated == 0:
            self.pause_mode_active.change_text('No')
        else:
            self.pause_mode_active.change_text('Yes')

        error_code = self.parent_data.error
        self.dataToSent[0] = int(self.parent_data.ui_mode)
        self.dataToSent[1] = self.parent_data.h_temp
        self.dataToSent[2] = self.parent_data.m_temp
        self.dataToSent[3] = self.parent_data.l_temp
        self.dataToSent[4] = int(self.parent_data.flow_rate2 * 10)
        self.dataToSent[5] = int(self.parent_data.flow_rate1 * 10)
        self.dataToSent[6] = self.parent_data.flowLevel
        self.dataToSent[7] = self.parent_data.heatMode
        self.dataToSent[8] = self.parent_data.sensitive_state
        self.dataToSent[9] = self.parent_data.idle_activated
        self.dataToSent[10] = self.parent_data.pause_activated
        self.dataToSent[11] = int(self.parent_data.targetFlowRate * 10)
        for i in range(0, 4):
            self.dataToSent[12+i] = (error_code & 0xFF)
            error_code >>= 8
        command = 'echo | set /p nul=' + str(binascii.hexlify(self.dataToSent), 'ascii') + '| clip'
        os.system(command)

        self.after(200, self.periodic)  # Call this function again

    # Add a horizontal line
    def add_line(self, width=200, height=5, span=1, sticky=STICKY_NSEW, padx=2, pady=2):
        gui.Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = gui.Canvas(self, width=width, height=height)
        x.create_line(0, 2, width-1, 2)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        return x

    def power_button_pressed(self):
        self.parent_data.power_button_pressed_trigger=True

    def mode_button_pressed(self):
        self.parent_data.mode_button_pressed_trigger=True
        self.parent_data.mode_button_released_trigger=True

    def sensitive_button_pressed(self):
        self.parent_data.sensitive_button_pressed_trigger=True

    def flow_button_pressed(self):
        self.parent_data.flow_button_pressed_trigger=True

    def heat_button_pressed(self):
        self.parent_data.heat_button_pressed_trigger=True

    def Pause_on_button_pressed(self):
        self.after(self.pause_delay_time.value(), self.active_pause_mode)
        time.sleep(0.1)

    def Pause_off_button_pressed(self):
        self.parent_data.Pause_off_trigger=True

    def active_pause_mode(self):
        self.parent_data.Pause_on_trigger =True

# Called by parent programs
def exec(parent_app, parent_data, device):
    app = this_app(parent=parent_app, parent_data=parent_data, device=device, title=APP_TITLE)
    return app

# Called by parent programs
def description():
    return APP_HELP

# This code starts the app if the file is executed rather than imported.
if __name__ == '__main__':
    # Get a connection to a device
    with sc_protocol.SC_Protocol(debug_level=0) as hc_device:
        # Run the script
        app = exec(None, hc_device)
        hc_device.close()
