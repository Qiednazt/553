"""
Copywrite Dyson(C) 2021

API to force amb temp error.
Note -  Currently this only forces the product to go in over_temp
        This is a drop down list, which can have either state. Changing from over temp to auto will not
"""

from enum import Enum
from sc_protocol import SET_AMB_READING_ERROR_MODE, GET_AMB_READING_ERROR_MODE


class OperatingModes(Enum):
    """
    Operating modes, must match ambient pressure flag position from sys_flags.h
    """
    auto = 0x00
    raise_over_pressure = 0x0A
    raise_under_pressure = 0x0B


def update_mode(device, mode):
    """
    Update the amb pressure error, does not write to eeprom.

    Args:
        device: sc_protocol device to communicate through
        mode: str, int or OperatingModes mode to send

    Returns:
        None
    """
    print(mode)
    if isinstance(mode, str):
        int_mode = OperatingModes[mode].value
    elif isinstance(mode, OperatingModes):
        int_mode = mode.value
    elif isinstance(mode, int) and (mode < len(OperatingModes)):
        int_mode = mode
    else:
        raise ValueError("Invalid operating mode {}".format(mode))

    cmd = SET_AMB_READING_ERROR_MODE(int_mode)
    msg = device.command_messages()
    msg.add(cmd)
    device.send(msg)

def get_mode(device):
    """
    get current amb pressure error flag

    Args:
        device: sc_protocol device to communicate with

    Returns:
        OperatingModes: index of the array of enum elements.
        This index is first stored by the Combo class of the Gui.

    Raises:
        ValueError: got a bad response
    """
    cmd = GET_AMB_READING_ERROR_MODE()
    msg = device.command_messages()
    msg.add(cmd)
    device.send(msg)
    mode = 0
    for data in OperatingModes:
        if cmd.pressure_error == data.value:
            break
        mode += 1

    return mode
