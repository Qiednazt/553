#-------------------------------------------------------------------------------
# Name:        DIPC Protocol for N553 System Controller
# Purpose:     This module provides DIPC commands for the N553 System Controller
# Copyright:   (c) Dyson Technology Ltd. 2021
#-------------------------------------------------------------------------------

import os
import json
import dipc_connection
import struct
import array
from enum import Enum
from lec_protocol import *

# Note: FSH_EEPROM_TOP aka flashtop is now read from the json data.
# It must match the macro 'FSH_EEPROM_TOP' in fsh_flash_data.h
TICKS_PER_US = 48

BITS_8 = 8
BITS_12 = 12
BYTE_2 = 2
BYTE_4 = 4

# Calibration stored in NVM
CALIB_ID_EOL_CAL_TIMESTAMP              = 0x000A
CALIB_ID_EOL_CAL_RIG_ID                 = 0x000B
CALIB_ID_EOL_LAMP_UI_CAL                = 0x0010
CALIB_ID_FCT_CAL_RIG_ID                 = 0x0019
CALIB_ID_FCT_CAL_TIMESTAMP              = 0x001A
CALIB_ID_FCT_PCB_INFO                   = 0x001B
CALIB_ID_FCT_SECURITY_BIT               = 0x001D
CALIB_ID_FCT_TRIAC_TEMP_OFFSET          = 0x0021
CALIB_ID_FCT_TRIAC_TEMP_SLOPE           = 0x0022
CALIB_ID_EOL_TRIAC_TEMP_TRIP_LIMIT_MV   = 0x0024
CALIB_ID_EOL_CURRENT_LIMIT_MA           = 0x0025
CALIB_ID_EOL_CURRENT_RAMP_SLOPE         = 0x0026
CALIB_ID_EOL_POWER_CAP                  = 0x0029
CALIB_ID_EOL_POWER_MOTOR_TUNING         = 0x0030
CALIB_ID_EOL_POWER_R_HEATER_LARM        = 0x0031
CALIB_ID_EOL_POWER_R_HEATER_RARM        = 0x0032
CALIB_ID_EOL_FLOW_OFFSET_CAL_ID_BASE    = 0x0056
CALIB_ID_EOL_AIR_EXIT_TEMP_OFFSET_BASE  = 0x005B
CALIB_ID_COM_AET_FLOW_RATE_4_L_S_BASE   = 0x005D
CALIB_ID_COM_AET_FLOW_RATE_6_L_S_BASE   = 0x005E
CALIB_ID_COM_AET_FLOW_RATE_9_L_S_BASE   = 0x005F
CALIB_ID_COM_AET_FLOW_RATE_12_L_S_BASE  = 0x0060
CALIB_ID_EOL_AIR_EXIT_TEMP_SLOPE_BASE   = 0x0063
CALIB_ID_IDLE_ARM_THRESHOLDS            = 0x0070

# Configuration stored in NVM
CONFIG_ID_EOL_BEHAVIOUR_FLAGS           = 0x0002
CONFIG_ID_EOL_ACC_DETACH_TIMEOUT        = 0x0003
CONFIG_ID_USAGE_DATA_BASE               = 0x2000
CONFIG_ID_CALIBRATION_DATA_BASE         = 0x3000
CONFIG_ID_ERROR_DATA_BASE               = 0x4000
CONFIG_ID_EEPROM_DATA_BASE              = 0x5000
CONFIG_ID_SESSION_EEPROM_BASE           = 0x6000
CONFIG_ID_SESSION_LIVE_BASE             = 0x6F00
CONFIG_ID_XXTEA_KEY                     = 0x9102

# DIPC Buttons
BUTTON_PRESS_EVT                        = 0x8200

DIPCTX_POWER_BUTTON_PRESS     = 0x01
DIPCTX_MODE_BUTTON_PRESS      = 0x02
DIPCTX_SENS_BUTTON_PRESS      = 0x04
DIPCTX_FLOW_BUTTON_PRESS      = 0x08
DIPCTX_HEAT_BUTTON_PRESS      = 0x10

# DIPC Button modifiers
DIPCTX_BUTTON_PRESS     = 0x0
DIPCTX_BUTTON_RELEASE   = 0x1

# DIPC Button duration
DIPCTX_BUTTON_SHORT_PRESS_MS          = 0x0028  # 40ms
DIPCTX_BUTTON_MEDIUM_PRESS_MS         = 0x01F4  # 500ms
DIPCTX_BUTTON_LONG_PRESS_MS           = 0x1388  # 5000ms

# Measurements and indication parameters used in FCT/EOL and normal product operation
PARAM_ID_SC_ERROR                       = 0x8000
PARAM_ID_CLAMP_STATE                    = 0x8001
PARAM_ID_LOCK_STATE                     = 0x8002
PARAM_ID_PAUSE_STATE                    = 0x8003
PARAM_ID_HEAT_MODE                      = 0x8004
PARAM_ID_FLOW_MODE                      = 0x8005
PARAM_ID_SENSITIVE                      = 0x8006
PARAM_ID_PRESSURE                       = 0x8007
PARAM_ID_TRIAC_TEMP_MV                  = 0x8008
PARAM_ID_DEBUG_HEATER_POWER_DATA        = 0x800A
PARAM_ID_EOL_HEATER_POWER_DATA          = 0x800B
PARAM_ID_ACCELERATION_PARAM_ID          = 0x800C
PARAM_ID_MAGNETOMETER_PARAM_ID          = 0x800D                # added at KXQ-134
PARAM_ID_ACCELERATION_INT_STATE_PARAM_ID= 0X800E
PARAM_ID_FILTER_MAINTENANCE             = 0x8011
PARAM_ID_HEATER_ID_LEFT                 = 0x8020
PARAM_ID_HEATER_ID_RIGHT                = 0x8021
PARAM_ID_SC_PCBA_REVISION               = 0x8022
PARAM_ID_EBOX_PCBA_REVISION             = 0x8023
PARAM_ID_RELAY_PCBA_REVISION            = 0x8024
PARAM_ID_TEMPERATURE_PARAM_ID           = 0x0108
PARAM_ID_AIR_EXIT_TEMP_RAW_K_BASE       = 0x8050
PARAM_ID_AIR_EXIT_TEMP_K_BASE           = 0x8058
PARAM_ID_AVG_A_AIR_EXIT_TEMP_RAW_K_BASE = 0x8060
PARAM_ID_AVG_B_AIR_EXIT_TEMP_RAW_K_BASE = 0x8061
PARAM_ID_AVG_A_AIR_EXIT_TEMP_K_BASE     = 0x8062
PARAM_ID_AVG_B_AIR_EXIT_TEMP_K_BASE     = 0x8063
PARAM_ID_DEL_A_AIR_EXIT_TEMP_RAW_K_BASE = 0x8064
PARAM_ID_DEL_B_AIR_EXIT_TEMP_RAW_K_BASE = 0x8065
PARAM_ID_DEL_A_AIR_EXIT_TEMP_K_BASE     = 0x8066
PARAM_ID_DEL_B_AIR_EXIT_TEMP_K_BASE     = 0x8067
PARAM_ID_DISABLE_FILTER_CHECK           = 0x8068
PARAM_ID_ARM_POSITION_MODE              = 0x8069
PARAM_ID_EOL_FILTER_SENSOR_DATA         = 0x8070
PARAM_ID_EOL_ARM_POSITION_SENSOR_DATA   = 0x8078
PARAM_ID_FILTER_MODE                    = 0x8081
PARAM_ID_AIR_EXIT_TEMP_ALL_K_RAW        = 0x8082
PARAM_ID_ABM_READING_ERROR              = 0x8094
PARAM_ID_EOL_PURGING_TIME_DELAY         = 0x8210
PARAM_ID_EOL_PURGING_FLOW_MODE          = 0x8211
PARAM_ID_EOL_HEATER_CONTROL_METHOD      = 0x8212


class HC_Protocol(LecProtocol):

    # Cut and Paste from tAppSystemState in app.h. This is done rather than analysing the header file to allow the enums to
    # be used without an accompanying hex file.
    SYSTEM_STATES = """
        APP_RESET_SYSTEM_STATE  = 0,         //!<  0-Starting. The software has just reset. Comms not set up yet.
        APP_BOOTED_SYSTEM_STATE,             //!<  1-Starting. Default comms has been initialised.
        APP_CONFIG_SYSTEM_STATE,             //!<  2-Starting. App config data in flash has been verified.
        APP_EEPROM_SYSTEM_STATE,             //!<  3-Starting. EEPROM data hase been loaded.
        APP_HAL_INIT_SYSTEM_STATE,           //!<  4-Starting. Initialising HAL.
        APP_INIT_PROTECTIONS_SYSTEM_STATE,   //!<  5-Starting. Checking initial protections.
        APP_IDLE_SYSTEM_STATE,               //!<  6-Idling. The device is waiting to be told to start.
        APP_STATIONARY_START_SYSTEM_STATE,   //!<  7-Stationary Start. The device is attempting to start the motor.
        APP_SYNC_COMMUTATION_SYSTEM_STATE,   //!<  8-Synchronous commutation state.
        APP_RESYNC_SYSTEM_STATE,             //!<  9-Resynchronisation state
        APP_ADV_ACCEL_STG1_SYSTEM_STATE,     //!< 10-Advance accelerator Stage 1 state
        APP_ADV_ACCEL_STG2_SYSTEM_STATE,     //!< 11-Advance accelerator Stage 2 state
        APP_STEADY_STATE_SYSTEM_STATE,       //!< 12-Steady state
        APP_SHUTDOWN_SYSTEM_STATE,           //!< 13-The motor is waiting for the voltage to rise before re-starting
        APP_RESET_TRIGGER_STATE,             //!< 14-The motor is idle waiting for a trigger release
        APP_WAIT_VOLTAGE_RECOVERY_STATE,     //!< 15- Motor is idle waiting for voltage recovery
        APP_TERMINATE_SYSTEM_STATE           //!<  X-Terminating. This should be the last state.
    """


    def __init__(self, **kwargs):
        kwargs['protocol_byte']    = kwargs.pop('protocol_byte', 0x00)    # 0 = (Data link version=2, Network version=2, Application version=2)
        kwargs['baud']             = kwargs.pop('baud', 115200)           # By default, the V10 protocol is 115200, 8 data bits, 1 stop bit, no parity
        kwargs['source_addr']      = kwargs.pop('source_addr', 0xf0)      # Lets choose a high source number for this library
        kwargs['destination_addr'] = kwargs.pop('destination_addr', 0x02) # Talk to the HC (node 2)
        LecProtocol.__init__(self, **kwargs)
        self.previous_function_addr = dict()
        self.previous_variable_addr = dict()
        self.enums = dict()
        self.process_enum(self.SYSTEM_STATES, 'SYSTEM_STATES')
        self.power_mode_data = None
        self.post_process_data = None
        self.terminated = False
        self.hex_file_name = kwargs.get('hex_file', '/system_scripts/553sc.hex')

    def terminate(self):
        self.terminated = True
        self.connection.close()

    # This function is used when the device disconnects and a possibly new bit of code re-connects.
    # Existing gathered information needs to be forgotten
    def forget(self):
        self.previous_function_addr = dict()
        self.previous_variable_addr = dict()
        self.power_mode_data = None
        self.post_process_data = None

    # Take the enum string and parse. Add to self.enums for use by enum_name_to_value and enum_value_to_name.
    def process_enum(self, str, enum_name):
        enum_index = 0
        self.enums[enum_name] = dict()
        self.enums['array:' + enum_name] = []
        for line in str.split('\n'):
            parts = line.replace('/', ' ').replace(',', ' ').replace('=', ' ').split()
            if len(parts) > 0:
                name = parts[0]
                self.enums[enum_name][name] = enum_index
                self.enums['array:' + enum_name].append(name)
                enum_index += 1

    # Given an enum name ('SYSTEM_STATES') and enum entry name, return the value of the enum entry. E.g.
    #   i = device.enum_name_to_value('SYSTEM_STATES', 'APP_INVALID_CONFIG_ERROR_ID')
    def enum_name_to_value(self, enum_name, value_name):
        if not enum_name in self.enums:
            raise Exception('Unknown enum %s' % enum_name)
        if not value_name in self.enums[enum_name]:
            raise Exception('Unknown enum value %s in enum %s' % (value_name, enum_name))
        return self.enums[enum_name][value_name]

    # Given an enum name ('SYSTEM_STATES'), return the name of the enum entry or UNKNOWN if the value is incorrect. E.g.
    #   s = device.enum_value_to_name('SYSTEM_STATES', 7)
    def enum_value_to_name(self, enum_name, value):
        if not enum_name in self.enums:
            raise Exception('Unknown enum %s' % enum_name)
        if value >= len(self.enums['array:'+enum_name]):
            return 'UNKNOWN_ENUM'
        return self.enums['array:'+enum_name][value]

    def close(self):
        self.connection.close()

    # Reset the device without invoking the bootloader
    def reset_device(self):
        msg = self.command_messages()
        msg.add(DEV_RESET_CMD())
        self.send(msg, retries = -1)

    # Return True if there is access to debug commands (peek/poke)
    def debug_available(self):
        try:
            self.get_post_process_data()
        except:
            return False
        return True

    #
    # Load data about the build from the JSON data appended to the hex file. This is usually only done if
    # the calling code requires such information.
    #
    def get_post_process_data(self,inhibitTimestampCheck=False):
        err = None
        if self.post_process_data == None:
            try:
                if(inhibitTimestampCheck==False):
                    # Get the build timestamp of the software
                    msg = self.command_messages()
                    msg.add(SOFTWARE_TIMESTAMP_REQ())   # Set the variable to a known value
                    self.send(msg, retries=3)
                    self.build_timestamp = msg.results[0].timestamp
                # Get the JSON data
                try:
                    f = open(os.environ['PROJECT_DIR'] + '/support_scripts/json.dat', 'r')
                    self.post_process_data = json.load(f)
                    f.close()
                except:
                    pass
                try:
                    filename = os.environ['PROJECT_DIR'] + '/' + self.hex_file_name
                    file = open(filename, 'r')
                    line = file.readline()
                    while line[0] == ':':
                        line = file.readline()
                    self.post_process_data = json.loads(line)
                    file.close()
                except:
                    pass

                # When using json data for reflash info we can ignore the timestamp as this data very rarely changes and
                # will be picked up by other changes such as TARGET version changes
                if(inhibitTimestampCheck==False):
                    # Is the timestamp of the data file different from the device timestamp
                    if self.post_process_data['build_timestamp'] != self.build_timestamp:
                        # Having different timestamps make it very likely that the addresses will be incompatible.
                        err = "ERROR: The application data file %s has a different timestamp to the device." % filename
                # Add the structure data from an array to a dict for use by get_member_offset_size()
                structs_data = dict()
                for struct_name in self.post_process_data['structs']:
                    structs_data['key:'+struct_name] = dict()
                    for member in self.post_process_data['structs'][struct_name]:
                        structs_data['key:'+struct_name][member['name']] = member
                for key, value in structs_data.items():
                    self.post_process_data['structs'][key] = value

            except:
                err = "ERROR: Could not read or process application data file"
        if err != None:
            self.post_process_data = None
            raise BaseException(err)


    # Given a function name, this function will return the function address.
    def get_function_addr(self, name):
        # If we know this name already, just return the address
        if name in self.previous_function_addr:
            return self.previous_function_addr[name]
        # Have we loaded the post process data?
        self.get_post_process_data()
        # Is the function in the list of functions composed at compile time?
        if not name in self.post_process_data['functions']:
            err = "Could not find function '%s' in application data file." % name
            print(err)
            raise NameError(err)
        addr = self.post_process_data['functions'][name]['addr']
        self.previous_function_addr[name] = addr  # Next time we ask for this function, we will get it from previous_function_addr
        return addr


    # Given a variable name, this function will return the variable address and size.
    # E.g.
    #    addr,size = get_variable_addr('m_error_code'):
    #    addr,size = get_variable_addr('g_fsh_systemConstants.uart_baud', struct='tFshApplicationData'):
    #    addr,size = get_variable_addr('?.uart_baud', struct='tFshApplicationData', addr=0x20000432):
    def get_variable_addr(self, name, struct=None, addr=None):
        if struct==None:
            struct = ''
        # If we know this name already, just return the address
        if addr == None and name+':'+struct in self.previous_variable_addr:
            return self.previous_variable_addr[name+':'+struct]
        # Is the variable in a structure and the structure not specified?
        if '.' in name and struct == '':
            err = "get_variable_addr('%s', struct=None): Structure variables must have the structure name specified." % name
            print(err)
            raise NameError(err)
        # Have we loaded the post process data?
        self.get_post_process_data()
        # If the variable is a structure variable, get the offset
        struct_offset = 0
        struct_size = 0
        if '.' in name:
            i = name.find('.')
            # Is the reference a multiple structure reference
            # E.g.    addr,size = get_variable_addr('g_fsh_systemConstants.filter_wash.pressure_coef', struct='tFshApplicationData.tFilterWashConstants'):
            if name.find('.', i+1) != -1:
                k = name.find('.', i+1)
                j = struct.find('.')
                first_struct  = struct[:j]      # tFshApplicationData
                other_structs = struct[j+1:]    # tFilterWashConstants
                first_name    = name[:i]        # g_fsh_systemConstants
                second_name   = name[i+1:k]     # filter_wash
                other_names   = name[k+1:]      # pressure_coef
                addr2, size2 = self.get_variable_addr(first_name+'.'+second_name, first_struct, addr=addr)
                struct_offset, struct_size = self.get_member_offset_size(first_struct, second_name)
                result, size = self.get_variable_addr('?.' + other_names, other_structs, addr=addr2)
                return result, size
            else:
                # A simple struct request
                # E.g.    addr,size = get_variable_addr('g_fsh_systemConstants.filter_wash', struct='tFshApplicationData'):
                struct_offset, struct_size = self.get_member_offset_size(struct, name[i+1:])
                name = name[:i]  # Remove the structure member name leaving just the data structure variable name
        # Is the function in the list of functions composed at compile time?
        if name == '?':
            if addr == None:
                err = "Structure address '%s' not specified." % name
                print(err)
                raise NameError(err)
        elif not name in self.post_process_data['variables']:
            err = "Could not find variable '%s' in application data file." % name
            print(err)
            raise NameError(err)
        else:
            addr = self.post_process_data['variables'][name]['addr']
            size = self.post_process_data['variables'][name]['size']
        if struct_size != 0:
            addr += struct_offset
            size = struct_size
        self.previous_variable_addr[name+':'+struct] = (addr, size)  # Next time we ask for this variable, we will get it from previous_variable_addr
        return addr, size

    # Get the release string. This may take several messages depending on the length of the release string
    def get_release_str(self):
        offset = 0
        length = 64
        finished = False
        str = ''
        while not finished:
            msg = self.command_messages()
            msg.add(SOFTWARE_RELSTR_REQ(offset, max_len=length))
            self.send(msg, retries=3)
            offset += length
            str += msg.results[0].str
            finished = msg.results[0].finished
        return str


    #
    # GetMemberOffset
    #   Given a structure name and member name, return the offset and size of the member.
    #
    def get_member_offset_size(self, struct_name, member_name):
        self.get_post_process_data()
        try:
            x = self.post_process_data['structs']['key:'+struct_name]
        except:
            print('505HcDataLink.get_member_offset_size: ERROR: struct %s not found' % struct_name)
            return None
        try:
            x = x[member_name]
        except:
            print('505HcDataLink.get_member_offset_size: ERROR: member %s of struct %s not found' % (member_name, struct_name))
            return None
        return x['offset'],x['size']

    #
    # This function performs a peek command (of an address).
    # This function is inefficient because it sends only one command in a message. It should be used
    # as a convienience where run-time is not important.
    #
    # Usage:
    #     value = device.peek_addr(addr)
    #
    def peek_addr(self, addr):
        msg = self.command_messages()
        msg.add(MEMORY_CONTENT_REQ(addr))
        self.send(msg)
        return msg.results[0].value

    #
    # This function performs a peek command (of a variable).
    # This function is inefficient because it sends only one command in a message. It should be used
    # as a convienience where run-time is not important.
    #
    # Usage:
    #     value = device.peek_var('appStatus')
    #     value = device.peek_var('device_speed', signed=True)
    #     value = device.peek_var('g_fsh_systemConstants.uart_baud', struct='tFshApplicationData')
    #     value = device.peek_var('?.uart_baud', struct='tFshApplicationData', addr=0x20000432)
    #
    def peek_var(self, name, struct=None, addr=None, signed=False, floatvar=False):
        msg = self.command_messages()
        msg.add(GET_VAR(name, struct=struct, addr=addr, signed=signed, floatvar=floatvar))
        self.send(msg)
        return msg.results[0].value

    #
    # This function performs a poke command to the specified address.
    # This function is inefficient because it sends only one command in a message. It should be used
    # as a convienience where run-time is not important.
    #
    # Usage:
    #     device.poke_addr(0x200000, 0x12345678)
    #     device.poke_addr(0x200000, 0xff, mask=0xffff)
    #
    def poke_addr(self, addr, value, mask=0xffffffff):
        msg = self.command_messages()
        msg.add(MEMORY_CONTENT_CMD(addr, value, mask))
        self.send(msg)

    #
    # This function performs a poke command (of a variable).
    # This function is inefficient because it sends only one command in a message. It should be used
    # as a convienience where run-time is not important.
    #
    # Usage:
    #     device.poke_var('appStatus', 55)
    #     device.poke_var('device_speed', -77, signed = True)
    #     device.poke_var('g_fsh_systemConstants.uart_baud', 33, struct='tFshApplicationData')
    #     device.poke_var('?.uart_baud', 0xff, struct='tFshApplicationData', addr=0x20000432)
    #
    def poke_var(self, name, value, struct=None, addr=None, signed=False, floatvar=False):
        msg = self.command_messages()
        msg.add(SET_VAR(name, value, struct=struct, addr=addr, signed=signed, floatvar=floatvar))
        self.send(msg)

    #
    # Call the specified function.
    # This function is inefficient because it sends only one command in a message. It should be used
    # as a convienience where run-time is not important.
    #
    # Usage:
    #     result = device.call('nvmEraseEepromRow', [0])
    #
    def call_func(self, name, params=[]):
        msg = self.command_messages()
        msg.add(CALL(name, params))
        self.send(msg)
        return msg.results[0].result

    # Return a byte array of the current RAM copy of the error page.
    def get_error_data(self):
        error_data = bytearray()
        for i in range(16):
            msg = self.command_messages()
            msg.add(GET_ERROR_EEPROM_DATA(index = i))
            self.send(msg)
            for j in range(16):
                error_data.append(msg.results[0].data[j])
        return error_data

    def download_app(self, hex, iv):
        self.get_post_process_data(inhibitTimestampCheck=True)

        startAddr = self.post_process_data['bootloader_size']
        print("START_ADDR %.4x" % startAddr)

        # Send a reset cmd to put the device in bootloader mode
        print("Sending RESET_CMD")
        msg = self.command_messages()
        msg.add(RESET_CMD())
        self.send(msg, retries=-1)
        time.sleep(0.5)

        # Invalidate the validity flag. This flag is the first word of the application meta data.
        # We do not want to download the valid value and make a partial download think it is complete.
        hex[startAddr + 0] = 0xff
        hex[startAddr + 1] = 0xff
        hex[startAddr + 2] = 0xff
        hex[startAddr + 3] = 0xff

        lastChunkNo = -1
        RetransmissionCnt = 0
        chunkNo = 0
        chunkAddr = startAddr
        chunkLength = 64
        batch = 0xf0

        # Make the hex size a multiple of 64 bytes. The bootloader does not work with partial chunks.
        while (hex.maxaddr()+1 & 63) != 0:
            print("Padding %.8x" % (hex.maxaddr()+1))
            hex[hex.maxaddr()+1] = 0xff

        max_addr = hex.maxaddr()+1
        print("Max_Addr = %d  0x%x" % (max_addr,max_addr))
        max_chunk = (max_addr - startAddr) // chunkLength
        print("Max chunk = %d" % max_chunk)

        # Change the destination address to the bootloader destination address
        bootloader_addr = 2
        app_addr        = self.connection.destination_addr

        print("Send a START_UPDATE_CMD")
        payload = bytearray()
        payload.extend(int(batch).to_bytes(1, byteorder='little', signed=False))   # Batch number
        payload.extend(int(0x0104).to_bytes(2, byteorder='little', signed=False))  # START_UPDATE_CMD Command ID
        payload.extend(int(iv).to_bytes(8, byteorder='little', signed=False))      # IV
        payload.extend(int(0).to_bytes(4, byteorder='little', signed=False))       # Start chunk = 0
        self.connection.sendFrame(payload, destination_addr=bootloader_addr)

        running = True
        time_of_last_valid_packet = time.time()
        chunkAddr = startAddr + chunkNo*chunkLength
        length = chunkLength


        while running and not self.terminated:
            packet = self.connection.getFrame(timeout=0.5, destination_addr=bootloader_addr)
            if packet == None and time.time() > (time_of_last_valid_packet + 3):
                print("Timeout")
                return False
            if packet != None and packet.destination_addr == self.connection.source_addr and packet.source_addr == bootloader_addr:
                time_of_last_valid_packet = time.time()
                cmdId = int.from_bytes(packet.data[1:3], byteorder='little', signed=False)
                if cmdId == 0x0206:  #GET_CHUNK_CMD
                    chunkNo = int.from_bytes(packet.data[3:7], byteorder='little', signed=False)
                    retry_string = ""
                    if(chunkNo == lastChunkNo):
                        RetransmissionCnt+=1
                        retry_string = "RETRY"
                    lastChunkNo = chunkNo

                    chunkAddr = startAddr + chunkNo*chunkLength
                    print("GET_CHUNK_CMD %d of %d %s" % (chunkNo, max_chunk,retry_string))

                    if chunkAddr >= max_addr:
                        print("Zero chunk")
                        length = 0  # Transmit an empty chunk
                        running = False

                    chunk = bytearray()
                    for i in range(length):
                        chunk.append(hex[chunkAddr + i])

                    reply = bytearray()
                    reply.extend(int(batch).to_bytes(1, byteorder='little', signed=False))        # Batch number
                    reply.extend(int(0x0207).to_bytes(2, byteorder='little', signed=False))       # CHUNK_READ_RES
                    reply.extend(int(chunkNo).to_bytes(4, byteorder='little', signed=False))      # Chunk number
                    reply.extend(int(len(chunk)).to_bytes(2, byteorder='little', signed=False))   # Chunk length
                    reply.extend(chunk)                                                           # Chunk data
                    self.connection.sendFrame(reply, destination_addr=bootloader_addr)

                if cmdId == 0x2000:  #RESET_EVENT
                    # We should not get a reset event at this stage.
                    print("RESET_EVENT")
                    return False

                if cmdId == 0x2100:  #CHUNK_PROCESSED_EVENT
                    # This script ignores the 'chunk processed' event.
                    pass # print("CHUNK_PROCESSED_EVENT")

        time.sleep(0.5)
        print()
        cmd = bytearray()
        cmd.extend(int(batch).to_bytes(1, byteorder='little', signed=False))        # Batch number
        cmd.extend(int(0x0102).to_bytes(2, byteorder='little', signed=False))       # APP_START_CMD
        self.connection.sendFrame(cmd, destination_addr=bootloader_addr)
        time.sleep(0.5)
        print("Total Retranmsissions this download attempt = %d" % RetransmissionCnt)
        print("Waiting for final packet")

        packet = self.connection.getFrame(destination_addr=0xff)
        if packet == None:
            print("No response ")
            # return True No response and yet the app starts(this appears to be a feature of the V9 bootloader)
        elif packet.data[1:3] == b'\x03\x01':
            print("FAILURE: APP_START_RES 0x%02x" % packet.data[3])
            return True # fixme
        elif packet.source_addr != app_addr:
            print("Download complete")

        # Clear the input buffer by accepting any message
        time.sleep(0.5)
        while self.connection.getFrame(timeout=0.5, destination_addr=0xff) != None:
            pass

        # Send a message to illicit a response. This is in case the V10 is not in BMS mode and is just listening.
        print("Talking to application to ensure download was successful...")
        msg = self.command_messages()
        msg.add(SOFTWARE_VERSION_REQ())
        self.send(msg, retries=-1)

        # Get any responses
        # If the V10 is in BMS mode, we should hear a poll message
        # Doing this several times means we can get a bad frame but a subsequent good frame still works.
        response = self.connection.getFrame(timeout = 0.5, destination_addr=None)
        if response == None:
            response = self.connection.getFrame(timeout = 0.5, destination_addr=None)
        if response == None:
            response = self.connection.getFrame(timeout = 0.5, destination_addr=None)
        if response == None:
            response = self.connection.getFrame(timeout = 0.5, destination_addr=None)

        # Did we get no responses
        if response == None:
            print("No response from application.")
            time.sleep(1)
            raise Exception("No response from application")
        elif response.source_addr != app_addr:
            time.sleep(1)
            raise Exception("Unexpected application address !")
        print()
        return True

    def download_app_from_file(self, filename,retries=-1):
        import project_intelhex as intelhex
        if not os.path.isfile(filename):
            print("Can not find %s" % filename)
            return
        hex = intelhex.IntelHex(filename)

        # Default non secure IV
        iv = 0xF0DEBC9A78563412

        # Get JSON data
        self.get_post_process_data(inhibitTimestampCheck=True)

        # Set default xxtea key
        xxtea_int = 0xFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
        xxtea = xxtea_int.to_bytes(16, byteorder='little', signed=False)
        print("Check target XXTEA key...")
        try:
            # Sent get xxtea key command
            msg = self.command_messages()
            msg.add(GET_XXTEA_KEY())
            self.send(msg)
            target_xxtea = msg.results[0].data[0:16]
            # Compare xxtea key
            if(xxtea != target_xxtea):
                print("Wrong XXTEA key stored in target EEPROM.")
                print("Re-write XXTEA key into target EEPROM.")
                # Sent set xxtea key
                msg = self.command_messages()
                msg.add(WRITE_XXTEA_KEY(xxtea))
                msg.add(CALIBRATE_WRITE_CMD())
                self.send(msg)
                # Sent get xxtea key to check again
                msg = self.command_messages()
                msg.add(GET_XXTEA_KEY())
                self.send(msg)
                target_xxtea1 = msg.results[0].data[0:16]
                # Compare new stored xxtea key
                if(xxtea != target_xxtea1):
                    print("FAILURE: XXTEA write not succesful\n")
                    return 1
                else:
                    print("PASS: XXTEA write succesful.\n")
            else:
                print("PASS: Correct target XXTEA!\n")
        except:
            print("FAIL: Cannot read XXTEA key!\n")

        # Encypt firmware image
        from pythonxxtea import PythonXXTEA
        print("Encrypting Image...")
        # Set key
        key = 0x55AA55AA55EDCBEDCB0000006FA9B742
        key_bytes = key.to_bytes(16, byteorder='big', signed=False)
        # Generate Initalization Vector (IV)
        iv_bytes = bytes(PythonXXTEA.get_random_iv())
        iv = int.from_bytes(iv_bytes, byteorder='little', signed=False)
        print('Generated IV = 0x%s' % iv_bytes.hex())
        # Get image data
        app_data_bytes = bytearray()
        startAddr = self.post_process_data['bootloader_size']
        print("START_ADDR %.4x" % startAddr)
        for i in range((hex.maxaddr()+1) - startAddr):
            app_data_bytes.append(hex[startAddr+i])
        # Encypt image data
        xxtea = PythonXXTEA(key_bytes)
        xxtea.block_init('CTR', iv_bytes)
        e = xxtea.block_encrypt(app_data_bytes)
        # Check image encryption
        xxtea = PythonXXTEA(key_bytes)
        xxtea.block_init('CTR', iv_bytes)
        d = xxtea.block_encrypt(e)
        if(app_data_bytes != d):
            print("FAILURE: Encryption not succesful - Image data different from decrypted data\n")
            return 1
        for i in range(len(e)):
            hex[startAddr + i] = e[i]
        print("PASS: Encryption Successful.\n")

        # Check target and image bootloader
        print('Compare bootloader version...')
        # Get image bootloader
        bootloader_size = self.post_process_data['bootloader_size']
        bootloader_add  = bootloader_size - 12
        image_bootloader_ver  = hex[bootloader_add]
        image_bootloader_ver += hex[bootloader_add+1] << 8
        image_bootloader_ver += hex[bootloader_add+2] << 16
        image_bootloader_ver += hex[bootloader_add+3] << 24
        print('Image  bootloader version: 0x%08X' %image_bootloader_ver)
        # Get target bootloader
        # Send a reset cmd to put the device in bootloader mode
        msg = self.command_messages()
        msg.add(RESET_CMD())
        self.send(msg, retries=-1)
        time.sleep(0.5)
        msg = self.command_messages()
        msg.add(SOFTWARE_VERSION_REQ())
        self.send(msg)
        target_bootloader_ver = msg.results[0].version
        print('Target bootloader version: 0x%08X' %target_bootloader_ver)
        # Compare Target and Image bootloader
        if(target_bootloader_ver != image_bootloader_ver):
            print('WARNING: Target bootloader different from Image bootloader.\n')
        else:
            print('PASS: Target bootloader same as Image bootloader.\n')

        success = False
        while ((not success) and (retries!=0)):
            try:
                success = self.download_app(hex, iv)
            except:
                if self.terminated:
                    self.close()
                    return 1
                else:
                    print("Retry...")
            if(retries>0):
                retries-=1
        return 0


# Sets the behaviour flags
# Arguments  flags = a dictionary where if the flag name is present and non-zero, the flag will be set.
#     flag names are 'filter-interlock' - The filter interlock check (0=Check disabled)
#                    'de-rating'        - The de-rating flag (0=De-rating not enabled)
# Usage:
#     # Disable the interlock check
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_BEHAVIOUR_FLAGS())
#     device.send(msg)
#     msg.results[0].flags['filter-interlock'] = 0
#     msg2 = device.command_messages()
#     msg2.add(sc_protocol.SET_BEHAVIOUR_FLAGS(msg.results[0].flags))
#     device.send(msg2)
class SET_EOL_BEHAVIOUR_FLAGS(CONFIGURE_CMD):
    bits = [ 'fct_mode',
             'disable silent reset',
             'disable_calibration_write',
             'disable_ebox_hc_heartbeat']
    def __init__(self, flags=dict(), **kwargs):
        flags_int = 0
        for i in range(len(self.bits)):
            bit = self.bits[i]
            if (bit in flags) and (flags[bit] != 0): flags_int += 1 << i
        flags_int = kwargs.pop('mask', flags_int)
        CONFIGURE_CMD.__init__(self, config_id = CONFIG_ID_EOL_BEHAVIOUR_FLAGS, config_data = flags_int.to_bytes(1, byteorder='little', signed=False), name='SET_BEHAVIOUR_FLAGS', **kwargs)
    def process_response(self, msg, index):
        return CONFIGURE_CMD.process_response(self, msg, index)


# Gets the state of the behaviour flags.
# Arguments   None
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_BEHAVIOUR_FLAGS())
#     device.send(msg)
#     print("Filter interlock feature = %d" % msg.results[0].flags['filter-interlock'])
#     print("De-rating feature        = %d" % msg.results[0].flags['de-rating'])
class GET_EOL_BEHAVIOUR_FLAGS(CONFIGURE_REQ):
    bits = SET_EOL_BEHAVIOUR_FLAGS.bits
    def __init__(self, **kwargs):
        CONFIGURE_REQ.__init__(self, config_id = CONFIG_ID_EOL_BEHAVIOUR_FLAGS, name = 'GET_BEHAVIOUR_FLAGS', **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CONFIGURE_REQ.process_response(self, msg, index)
        flag_bits = int.from_bytes(self.config_data, byteorder='little', signed=False)
        self.flags = dict()
        for i in range(len(self.bits)):
            bit = self.bits[i]
            self.flags[bit] = (flag_bits >> i) & 1
        self.mask = flag_bits
        return index

# Sets the behaviour flags
# Arguments
# Usage:
class SET_EOL_ACC_DETACH_TIMEOUT(CONFIGURE_CMD):
    def __init__(self, eol_acc_detach_timeout, **kwargs):
        if eol_acc_detach_timeout >  0xFFFF: raise Exception("Out of range")
        CONFIGURE_CMD.__init__(self, config_id = CONFIG_ID_EOL_ACC_DETACH_TIMEOUT, config_data = eol_acc_detach_timeout.to_bytes(2, byteorder='little', signed=False), name='SET_EOL_ACC_DETACH_TIMEOUT', **kwargs)
    def process_response(self, msg, index):
        return CONFIGURE_CMD.process_response(self, msg, index)

# Gets the state of the behaviour flags.
# Arguments   None
# Usage:
class GET_EOL_ACC_DETACH_TIMEOUT(CONFIGURE_REQ):
    def __init__(self, **kwargs):
        CONFIGURE_REQ.__init__(self, config_id = CONFIG_ID_EOL_ACC_DETACH_TIMEOUT, name = 'GET_EOL_ACC_DETACH_TIMEOUT', **kwargs)
        self.eol_acc_detach_timeout= None
    def process_response(self, msg, index):
        index = CONFIGURE_REQ.process_response(self, msg, index)
        self.eol_acc_detach_timeout = int.from_bytes(self.config_data, byteorder='little', signed=False)
        return index

# Sends a INHIBIT_LAMP_UPDATES_EVT  the HC
#
#   Purpose: bootloader control
#
# Implements the INHIBIT_LAMP_UPDATES_EVT
# Arguments  None
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16 Command ID  - ENABLE_LAMP_UPDATES_EVT (0x8212)
# Response:  None
# Usage:
#     msg = device.command_messages()
#     msg.add(ui_protocol.INHIBIT_LAMP_UPDATES_EVT())
#     device.send(msg,retries=-1) # Don't wait for a response as it is a fire and forget event
class INHIBIT_LAMP_UPDATES_EVT(LecCommand):
    INHIBIT_LAMP_UPDATES_EVT = 0x8211
    name = 'ENABLE_LAMPS_EVT'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.INHIBIT_LAMP_UPDATES_EVT))
        return msg


# Sends a Enable_LAMP_Updates_EVT  the HC
#
#   Purpose: bootloader control
#
# Implements the ENABLE_LAMP_UPDATES_EVT event
# Arguments  None
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16 Command ID  - ENABLE_LAMP_UPDATES_EVT (0x8212)
# Response:  None
# Usage:
#     msg = device.command_messages()
#     msg.add(ui_protocol.ENABLE_LAMP_UPDATES_EVT())
#     device.send(msg,retries=-1) # Don't wait for a response as it is a fire and forget event
class ENABLE_LAMP_UPDATES_EVT(LecCommand):
    ENABLE_LAMP_UPDATES_EVT = 0x8212
    name = 'ENABLE_LAMPS_EVT'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.ENABLE_LAMP_UPDATES_EVT))
        return msg

# Sends a Heat_EVT button request to the SC
#
#   Purpose: Mimic UI
#
# Implements the HEAT_BUTTON_PRESS_EVT event
# Arguments  Event type (short, long, held or release)
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16 Command ID  - DIPC_HEAT_BUTTON_PRESS_EVT
# Response:  None
# Usage:
#     msg = device.command_messages()
#     msg.add(ui_protocol.HEAT_BUTTON_PRESS_EVT())
#     device.send(msg,retries=-1) # Don't wait for a response as it is a fire and forget event
class HEAT_BUTTON_PRESS_EVT(LecCommand):
    POWER_BUTTON_PRESS_EVT = 0x8200
    name = 'HEAT_EVT'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.POWER_BUTTON_PRESS_EVT))
        msg.extend(self.uint8(DIPCTX_HEAT_BUTTON_PRESS))
        msg.extend(self.uint8(DIPCTX_BUTTON_PRESS))   # send short press
        msg.extend(self.uint32(DIPCTX_BUTTON_SHORT_PRESS_MS))

        return msg


# Sends a Flow_Down_EVT button request to the SC
#
#   Purpose: Mimic UI
#
# Implements the FLOW_BUTTON_PRESS_EVT event
# Arguments  None
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16 Command ID  - BUTTON_PRESS_EVT (0x8200)
# Response:  None
# Usage:
#     msg = device.command_messages()
#     msg.add(ui_protocol.FLOW_BUTTON_PRESS_EVT())
#     device.send(msg,retries=-1) # Don't wait for a response as it is a fire and forget event
class FLOW_BUTTON_PRESS_EVT(LecCommand):
    POWER_BUTTON_PRESS_EVT = 0x8200
    name = 'FLOW_EVT'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.POWER_BUTTON_PRESS_EVT))
        msg.extend(self.uint8(DIPCTX_FLOW_BUTTON_PRESS))
        msg.extend(self.uint8(DIPCTX_BUTTON_PRESS))   # send short press
        msg.extend(self.uint32(DIPCTX_BUTTON_SHORT_PRESS_MS))
        return msg


# Sends a PowerButton_EVT button request to the SC
#
#   Purpose: Mimic UI
#
# Implements the POWER_BUTTON_PRESS_EVT event
# Arguments  None
# Command:   UINT16 Command ID  - DIPC_BUTTON_PRESS_EVT (0x8200)
# Response:  None
# Usage:
#     msg = device.command_messages()
#     msg.add(ui_protocol.POWER_BUTTON_PRESS_EVT())
#     device.send(msg,retries=-1) # Don't wait for a response as it is a fire and forget event
class POWER_BUTTON_PRESS_EVT(LecCommand):
    POWER_BUTTON_PRESS_EVT = 0x8200
    name = 'BUTTON_EVT'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.POWER_BUTTON_PRESS_EVT))
        msg.extend(self.uint8(DIPCTX_POWER_BUTTON_PRESS))        # send Power
        msg.extend(self.uint8(DIPCTX_BUTTON_PRESS))        # send short press
        msg.extend(self.uint32(DIPCTX_BUTTON_SHORT_PRESS_MS))
        return msg

# Sends a LONG PowerButton_EVT button request to the SC
#
#   Purpose: Mimic UI
#
# Implements the POWER_BUTTON_PRESS_EVT LONG event
# Arguments  None
# Command:   UINT16 Command ID  - DIPC_POWER_BUTTON_PRESS_EVT
# Response:  None
# Usage:
#     msg = device.command_messages()
#     msg.add(ui_protocol.POWER_BUTTON_PRESS_EVT())
#     device.send(msg,retries=-1) # Don't wait for a response as it is a fire and forget event
class POWER_BUTTON_LONGPRESS_EVT(LecCommand):
    POWER_BUTTON_PRESS_EVT = 0x8200
    name = 'POWER_EVT'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.POWER_BUTTON_PRESS_EVT))
        msg.extend(self.uint8(DIPCTX_POWER_BUTTON_PRESS))        # send power
        msg.extend(self.uint8(DIPCTX_BUTTON_PRESS))        # send long press
        msg.extend(self.uint32(DIPCTX_BUTTON_LONG_PRESS_MS))
        return msg


# Sends a ModeButton_EVT button request to the SC
#
#   Purpose: Mimic UI
#
# Implements the MODE_BUTTON_PRESS_EVT event
# Arguments  None
# Command:   UINT16 Command ID  - DIPC_BUTTON_PRESS_EVT (0x8200)
# Response:  None
# Usage:
#     msg = device.command_messages()
#     msg.add(ui_protocol.MODE_BUTTON_PRESS_EVT())
#     device.send(msg,retries=-1) # Don't wait for a response as it is a fire and forget event
class MODE_BUTTON_PRESS_EVT(LecCommand):
    POWER_BUTTON_PRESS_EVT = 0x8200
    name = 'MODE_BUTTON_EVT'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.POWER_BUTTON_PRESS_EVT))
        msg.extend(self.uint8(DIPCTX_MODE_BUTTON_PRESS))         # send MODE
        msg.extend(self.uint8(DIPCTX_BUTTON_PRESS))        # send short press
        msg.extend(self.uint32(DIPCTX_BUTTON_SHORT_PRESS_MS))
        return msg

# Sends a LONG ModeButton_EVT button request to the SC
#
#   Purpose: Mimic UI
#
# Implements the MODE_BUTTON_PRESS_EVT LONG event
# Arguments  None
# Command:   UINT16 Command ID  - DIPC_MODE_BUTTON_PRESS_EVT (0x8200)
# Response:  None
# Usage:
#     msg = device.command_messages()
#     msg.add(ui_protocol.MODE_BUTTON_LONGPRESS_EVT())
#     device.send(msg,retries=-1) # Don't wait for a response as it is a fire and forget event
class MODE_BUTTON_LONGPRESS_EVT(LecCommand):
    POWER_BUTTON_PRESS_EVT = 0x8200
    name = 'LONG MODE POWER_EVT'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.POWER_BUTTON_PRESS_EVT))
        msg.extend(self.uint8(DIPCTX_MODE_BUTTON_PRESS))        # send MODE
        msg.extend(self.uint8(DIPCTX_BUTTON_PRESS))        # send long press
        msg.extend(self.uint32(DIPCTX_BUTTON_LONG_PRESS_MS))
        return msg

# Sends a SensitivityButton_EVT button request to the SC
#
#   Purpose: Mimic UI
#
# Implements the COOLFIX_BUTTON_PRESS_EVT event
# Arguments  None
# Command:   UINT16 Command ID  - DIPC_BUTTON_PRESS_EVT (0x8200)
# Response:  None
# Usage:
#     msg = device.command_messages()
#     msg.add(ui_protocol.COOLFIX_BUTTON_PRESS_EVT())
#     device.send(msg,retries=-1) # Don't wait for a response as it is a fire and forget event
class COOLFIX_BUTTON_PRESS_EVT(LecCommand):
    POWER_BUTTON_PRESS_EVT = 0x8200
    name = 'COOLFIX BUTTON_EVT'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.POWER_BUTTON_PRESS_EVT))
        msg.extend(self.uint8(DIPCTX_SENS_BUTTON_PRESS))         # send sense
        msg.extend(self.uint8(DIPCTX_BUTTON_PRESS))        # send short press
        msg.extend(self.uint32(DIPCTX_BUTTON_SHORT_PRESS_MS))
        return msg

# Sends a LONG PowerButton_EVT button request to the SC
#
#   Purpose: Mimic UI
#
# Implements the COOLFIX_BUTTON_PRESS_EVT LONG event
# Arguments  None
# Command:   UINT16 Command ID  - DIPC_COOLFIX_BUTTON_PRESS_EVT (0x8200)
# Response:  None
# Usage:
#     msg = device.command_messages()
#     msg.add(ui_protocol.COOLFIX_BUTTON_PRESS_EVT())
#     device.send(msg,retries=-1) # Don't wait for a response as it is a fire and forget event
class COOLFIX_BUTTON_LONGPRESS_EVT(LecCommand):
    POWER_BUTTON_PRESS_EVT = 0x8200
    name = 'POWER_EVT'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.POWER_BUTTON_PRESS_EVT))
        msg.extend(self.uint8(DIPCTX_SENS_BUTTON_PRESS))        # send power
        msg.extend(self.uint8(DIPCTX_BUTTON_PRESS))        # send long press
        msg.extend(self.uint32(DIPCTX_BUTTON_LONG_PRESS_MS))
        return msg


# Sends an SHORT attach _EVT  to the HC
#
#   Purpose: Mimic UI
#
# Implements the DIPC_ACCESSORY_PRESENT_EVT event
# Arguments  short tag id (16bit)
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16 Command ID  - DIPC_ACCESSORY_PRESENT_EVT (0x8207)
# Response:  None
# Usage:
#     msg = device.command_messages()
#     msg.add(ui_protocol.DIPC_ACCESSORY_PRESENT_EVT())
#     device.send(msg,retries=-1) # Don't wait for a response as it is a fire and forget event
class TAG_ATTACH_EVT(LecCommand):
    DIPC_ACCESSORY_PRESENT_EVT = 0x8207
    name = 'SHOR_ATTACH_EVT'

    def __init__(self, tagId, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.result = None   # Default attribute value before response is None
        self.tagId = tagId
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.DIPC_ACCESSORY_PRESENT_EVT))
        msg.extend(self.uint16(self.tagId))        # send tag identifier
        return msg

# Sends an LONG attach _EVT  to the HC
#
#   Purpose: Mimic UI
#
# Implements the DIPC_ACCESSORY_PRESENT_LONG_EVT event
# Arguments  short tag id (16bit)
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16 Command ID  - DIPC_ACCESSORY_PRESENT_LONG_EVT (0x8208)
# Response:  None
# Usage:
#     msg = device.command_messages()
#     msg.add(ui_protocol.DIPC_ACCESSORY_PRESENT_LONG_EVT())
#     device.send(msg,retries=-1) # Don't wait for a response as it is a fire and forget event
class TAG_ATTACH_LONG_EVT(LecCommand):
    DIPC_ACCESSORY_PRESENT_LONG_EVT = 0x8208
    name = 'LONG_ATTACH_EVT'

    def __init__(self, tagId, power, heat, mode, flow, speed, uid, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.result = None   # Default attribute value before response is None
        self.tagId = tagId
        self.power = power
        self.heat  = heat
        self.mode  = mode
        self.flow  = flow
        self.speed = speed
        self.uid   = uid
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.DIPC_ACCESSORY_PRESENT_LONG_EVT))
        msg.extend(self.uint16(self.tagId))        # send tag identifier
        msg.extend(self.uint16(self.power))        # country id
        msg.extend(self.uint32(self.heat))         # heat x 4 bytes
        msg.extend(self.uint32(self.mode))         # mode x 4 bytes
        msg.extend(self.uint32(self.flow))         # flow rate x 4
        msg.extend(self.uint32(self.speed&0xffffffff)) # speed limit x 2
        msg.extend(self.uint32(self.speed>>32))    # speed limit x 2
        msg.extend(self.uint32(self.uid&0xffffffff)) # uid bottom 32
        msg.extend(self.uint32(self.uid>>32))      # uid top 32 bits
        return msg


# Sends a detach evt to the HC
#
#   Purpose: Mimic UI
#
# Implements the DIPC_ACCESSORY_NOT_PRESENT_EVT event
# Arguments  None
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16 Command ID  - DIPC_ACCESSORY_NOT_PRESENT_EVT (0x8206)
# Response:  None
# Usage:
#     msg = device.command_messages()
#     msg.add(ui_protocol.DIPC_ACCESSORY_NOT_PRESENT_EVT())
#     device.send(msg,retries=-1) # Don't wait for a response as it is a fire and forget event
class TAG_DETACH_EVT(LecCommand):
    DIPC_ACCESSORY_NOT_PRESENT_EVT = 0x8206
    name = 'POWER_EVT'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.DIPC_ACCESSORY_NOT_PRESENT_EVT))
        return msg

# Sends a ColdShot_EVT button request to the HC
#
#   Purpose: Mimic UI
#
# Implements the COLD_SHOT_BUTTON_PRESS_EVT event
# Arguments  None
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16 Command ID  - DIPC_COLD_SHOT_BUTTON_PRESS_EVT (0x8205)
# Response:  None
# Usage:
#     msg = device.command_messages()
#     msg.add(ui_protocol.COLD_SHOT_BUTTON_PRESS_EVT())
#     device.send(msg,retries=-1) # Don't wait for a response as it is a fire and forget event
class COLD_SHOT_BUTTON_PRESS_EVT(LecCommand):
    COLD_SHOT_BUTTON_PRESS_EVT = 0x8205
    name = 'COLD_SHOT_EVT'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.COLD_SHOT_BUTTON_PRESS_EVT))
        msg.extend(self.uint16(0))        # send short press
        return msg

# Sends a ColdShotHeld_EVT button request to the HC
#
#   Purpose: Mimic UI
#
# Implements the COLD_SHOT_BUTTON_PRESS_EVT event
# Arguments  None
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16 Command ID  - DIPC_COLD_SHOT_BUTTON_PRESS_EVT (0x8205)
# Response:  None
# Usage:
#     msg = device.command_messages()
#     msg.add(ui_protocol.COLD_SHOT_BUTTON_PRESS_EVT())
#     device.send(msg,retries=-1) # Don't wait for a response as it is a fire and forget event
class COLD_SHOT_BUTTON_HELD_EVT(LecCommand):
    COLD_SHOT_BUTTON_PRESS_EVT = 0x8205
    name = 'COLD_SHOT_EVT'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.COLD_SHOT_BUTTON_PRESS_EVT))
        msg.extend(self.uint16(2))        # send button held
        return msg

# Sends a parameter res to UI
#
#   Purpose: Mimic UI
#
# Implements the DIPC_PARAMETER_RES message
# Arguments  Parameter sub ID (16 bits unsigned)
# Results    None
# Command:   UINT16 Command ID  - DIPC_PARAMETER_RES (0x1001)
# Response:  None
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.DIPC_PARAMETER_RES(sc_protocol.PARAM_ID_SC_ERROR))
#     device.send(msg,retries=-1) # Don't wait for a response as it is a fire and forget event
class DIPC_PARAMETER_RES(LecCommand):
    DIPC_PARAMETER_RES = 0x1001
    name = 'DIPC_PARAMETER_RES'

    def __init__(self, paraSubId, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.result = None   # Default attribute value before response is None
        self.paraSubId = paraSubId
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.DIPC_PARAMETER_RES))
        msg.extend(self.uint16(self.paraSubId))         # Parameter sub ID
        msg.extend(self.uint16(0x02))                   # Parameter length
        msg.extend(self.uint16(0xAAAA))                 # Dummy data
        return msg

# Get the specified chunk of seesion log EEPROM data.
# There are 128 possible chunk numbers, each of 16 bytes making a total of 2k bytes.
# Arguments: index = eeprom chunk number. (0-127)
# Results  data = 16 byte bytearray of EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(hc_protocol.GET_SESSION_EEPROM_DATA(index=3))
#     device.send(msg)
#     print("The forth chunk of EEPROM data is ", msg.results[0].data)  # data is a byte array of 16 bytes
class GET_SESSION_EEPROM_DATA(CONFIGURE_REQ):
    def __init__(self, index, **kwargs):
        CONFIGURE_REQ.__init__(self, config_id = CONFIG_ID_SESSION_EEPROM_BASE+index, name='GET_SESSION_EEPROMDATA(%d)' % index, **kwargs)
        self.data = None
        self.index = index
    def process_response(self, msg, index):
        index = CONFIGURE_REQ.process_response(self, msg, index)
        self.data = self.config_data
        if self.debug_level > 20:
            print("GET_SESSION_EEPROM_DATA(%d) result " % self.index, self.data)
        return index

# Get the specified chunk of session log live data.
# There are 64 possible chunk numbers, each of 16 bytes making a total of 1k bytes.
# Arguments: index = eeprom chunk number. (0-63)
# Results  data = 16 byte bytearray of EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(hc_protocol.GET_SESSION_LIVE_DATA(index=3))
#     device.send(msg)
#     print("The forth chunk of EEPROM data is ", msg.results[0].data)  # data is a byte array of 16 bytes
class GET_SESSION_LIVE_DATA(CONFIGURE_REQ):
    def __init__(self, index, **kwargs):
        CONFIGURE_REQ.__init__(self, config_id = CONFIG_ID_SESSION_LIVE_BASE+index, name='GET_SESSION_LIVEDATA(%d)' % index, **kwargs)
        self.data = None
        self.index = index
    def process_response(self, msg, index):
        index = CONFIGURE_REQ.process_response(self, msg, index)
        self.data = self.config_data
        if self.debug_level > 20:
            print("GET_SESSION_LIVE_DATA(%d) result " % self.index, self.data)
        return index

# Get the specified chunk of raw EEPROM data.
# Arguments: index = This is a 12bit integer with the first 4 bites indicate which  block of 16 bytes
# and the msbyte represents the page number 0 - 32 (in the case of v10 - samc21 chipset)
# Results  data = 16 byte bytearray of EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_RAW_EEPROM_DATA(index=3))
#     device.send(msg)
#     print("The forth chunk of EEPROM data is ", msg.results[0].data)  # data is a byte array of 16 bytes
class GET_RAW_EEPROM_DATA(CONFIGURE_REQ):
    def __init__(self, index, **kwargs):
        CONFIGURE_REQ.__init__(self, config_id = CONFIG_ID_EEPROM_DATA_BASE+index, name='GET_EEPROM_DATA(%d)' % index, **kwargs)
        self.data = None
        self.index = index
    def process_response(self, msg, index):
        index = CONFIGURE_REQ.process_response(self, msg, index)
        self.data = self.config_data
        if self.debug_level > 20:
            print("GET_RAW_EEPROM_DATA(%d) result " % self.index, self.data)
        return index

# This function writes 16 bytes of data to eeprom.
#
# Arguments: index = This is a 12bit integer with the first 4 bites indicate which  block of 16 bytes
# and the msbyte represents the page number 0 - 32 (in the case of v10 - samc21 chipset)
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.WRITE_EEPROM_DATA(index=3))
#     device.send(msg)
class WRITE_EEPROM_DATA(CONFIGURE_CMD):
    def __init__(self, index, eeprom_data, **kwargs):
        CONFIGURE_CMD.__init__(self, config_id = CONFIG_ID_EEPROM_DATA_BASE+index, config_data = eeprom_data, name='WRITE_EEPROM_DATA(%x)'% index, **kwargs)
        self.data = None
        self.index = index
    def process_response(self, msg, index):
        self.data = self.config_data
        if self.debug_level > 20:
            print("WRITE_EEPROM_DATA(%x) result " % self.index, self.data)
        return CONFIGURE_CMD.process_response(self, msg, index)

# Get the specified chunk of error EEPROM data.
# There are 16 possible chunk numbers, each of 16 bytes making a total of 256 bytes.
# Arguments: index = eeprom chunk number. (0-15)
# Results  data = 16 byte bytearray of EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_ERROR_EEPROM_DATA(index=3))
#     device.send(msg)
#     print("The forth chunk of EEPROM data is ", msg.results[0].data)  # data is a byte array of 16 bytes
class GET_ERROR_EEPROM_DATA(CONFIGURE_REQ):
    def __init__(self, index, **kwargs):
        CONFIGURE_REQ.__init__(self, config_id = CONFIG_ID_ERROR_DATA_BASE+index, name='GET_EEPROM_DATA(%d)' % index, **kwargs)
        self.data = None
        self.index = index
    def process_response(self, msg, index):
        index = CONFIGURE_REQ.process_response(self, msg, index)
        self.data = self.config_data
        if self.debug_level > 20:
            print("GET_ERROR_EEPROM_DATA(%d) result " % self.index, self.data)
        return index


# Get the specified chunk of usage EEPROM data.
# There are 16 possible chunk numbers, each of 16 bytes making a total of 256 bytes.
# Arguments: index = eeprom chunk number. (0-15)
# Results  data = 16 byte bytearray of EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_USAGE_EEPROM_DATA(index=3))
#     device.send(msg)
#     print("The forth chunk of EEPROM data is ", msg.results[0].data)  # data is a byte array of 16 bytes
class GET_USAGE_EEPROM_DATA(CONFIGURE_REQ):
    def __init__(self, index, **kwargs):
        CONFIGURE_REQ.__init__(self, config_id = CONFIG_ID_USAGE_DATA_BASE+index, name='GET_EEPROM_DATA(%d)' % index, **kwargs)
        self.data = None
        self.index = index
    def process_response(self, msg, index):
        index = CONFIGURE_REQ.process_response(self, msg, index)
        self.data = self.config_data
        if self.debug_level > 20:
            print("GET_USAGE_EEPROM_DATA(%d) result " % self.index, self.data)
        return index


# Get the specified chunk of calibration EEPROM data.
# There are 16 possible chunk numbers, each of 16 bytes making a total of 256 bytes.
# Arguments: index = eeprom chunk number. (0-15)
# Results  data = 16 byte bytearray of EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_CALIBRATION_EEPROM_DATA(index=3))
#     device.send(msg)
#     print("The forth chunk of EEPROM data is ", msg.results[0].data)  # data is a byte array of 16 bytes
class GET_CALIBRATION_EEPROM_DATA(CONFIGURE_REQ):
    def __init__(self, index, **kwargs):
        CONFIGURE_REQ.__init__(self, config_id = CONFIG_ID_CALIBRATION_DATA_BASE+index, name='GET_EEPROM_DATA(%d)' % index, **kwargs)
        self.data = None
        self.index = index
    def process_response(self, msg, index):
        index = CONFIGURE_REQ.process_response(self, msg, index)
        self.data = self.config_data
        if self.debug_level > 20:
            print("GET_CALIBRATION_EEPROM_DATA(%d) result " % self.index, self.data)
        return index

# Get 16 bytes XXTEA key for security bootloader
# Results  data = 16 byte bytearray of XXTEA key
# Usage:
#     msg = device.command_messages()
#     msg.add(hc_protocol.GET_XXTEA_KEY())
#     device.send(msg)
#     xxteaKey = int.from_bytes(msg.results[0].data[0:16], 'little', signed=False)  # data is a byte array of 16 bytes
#     print("The XXTEA key is 0x%032x" %xxteaKey)
class GET_XXTEA_KEY(CONFIGURE_REQ):
    def __init__(self, **kwargs):
        CONFIGURE_REQ.__init__(self, config_id = CONFIG_ID_XXTEA_KEY, name='GET_XXTEA_KEY', **kwargs)
        self.data = None
    def process_response(self, msg, index):
        index = CONFIGURE_REQ.process_response(self, msg, index)
        self.data = self.config_data
        if self.debug_level > 20:
            print("GET_XXTEA_KEY result ", self.data)
        return index

# Write 16 bytes XXTEA key for security bootloader
# Arguments  xxteaKey  - buffer of 16 bytes data
# Results  data = 16 byte bytearray of EEPROM data
# Usage:
#     xxteaKey = bytearray(16) # need initialization
#     msg = device.command_messages()
#     msg.add(hc_protocol.WRITE_XXTEA_KEY(xxteaKey))
#     device.send(msg)
class WRITE_XXTEA_KEY(CONFIGURE_CMD):
    def __init__(self, xxteaKey, **kwargs):
        CONFIGURE_CMD.__init__(self, config_id = CONFIG_ID_XXTEA_KEY, config_data = xxteaKey, name='WRITE_XXTEA_KEY', **kwargs)
        self.data = None
    def process_response(self, msg, index):
        self.data = self.config_data
        if self.debug_level > 20:
            print("WRITE_XXTEA_KEY result ", self.data)
        return CONFIGURE_CMD.process_response(self, msg, index)

# Write left heater id to SC EEPROM
# Arguments  heater id  - max 32 bytes data
# Results  data = bytearray of left heater id from EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(hc_protocol.WRITE_HEATER_ID_LEFT(heater_id))
#     device.send(msg)
class WRITE_HEATER_ID_LEFT(PARAMETER_CMD):
    def __init__(self, id, **kwargs):
        PARAMETER_CMD.__init__(self, PARAM_ID_HEATER_ID_LEFT, id, name = 'WRITE_HEATER_ID_LEFT', **kwargs)
        self.heaterIdLeft = None
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.heaterIdLeft = self.data.decode()
        if self.debug_level > 20:
            print("WRITE_HEATER_ID_LEFT result ", self.heaterIdLeft)
        return index

# Write right heater id to SC EEPROM
# Arguments  heater id  - max 32 bytes data
# Results  data = bytearray of right heater id from EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(hc_protocol.WRITE_HEATER_ID_RIGHT(heater_id))
#     device.send(msg)
class WRITE_HEATER_ID_RIGHT(PARAMETER_CMD):
    def __init__(self, id, **kwargs):
        PARAMETER_CMD.__init__(self, PARAM_ID_HEATER_ID_RIGHT, id, name = 'WRITE_HEATER_ID_RIGHT', **kwargs)
        self.heaterId = None
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.heaterId = self.data.decode()
        if self.debug_level > 20:
            print("WRITE_HEATER_ID_RIGHT result ", self.heaterId)
        return index

# Write sc pcba revision to SC EEPROM
# Arguments  sc pcba revision  - max 32 bytes data
# Results  data = bytearray of sc pcba revision from EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(hc_protocol.WRITE_SC_PCBA_REV(pcba_rev))
#     device.send(msg)
class WRITE_SC_PCBA_REV(PARAMETER_CMD):
    def __init__(self, id, **kwargs):
        PARAMETER_CMD.__init__(self, PARAM_ID_SC_PCBA_REVISION, id, name = 'WRITE_SC_PCBA_REV', **kwargs)
        self.pcba_rev = None
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.pcba_rev = self.data.decode()
        if self.debug_level > 20:
            print("WRITE_SC_PCBA_REV result ", self.pcba_rev)
        return index

# Write ebox pcba revision to SC EEPROM
# Arguments  ebox pcba revision  - max 32 bytes data
# Results  data = bytearray of ebox pcba revision from EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(hc_protocol.WRITE_EBOX_PCBA_REV(pcba_rev))
#     device.send(msg)
class WRITE_EBOX_PCBA_REV(PARAMETER_CMD):
    def __init__(self, id, **kwargs):
        PARAMETER_CMD.__init__(self, PARAM_ID_EBOX_PCBA_REVISION, id, name = 'WRITE_EBOX_PCBA_REV', **kwargs)
        self.pcba_rev = None
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.pcba_rev = self.data.decode()
        if self.debug_level > 20:
            print("WRITE_EBOX_PCBA_REV result ", self.pcba_rev)
        return index

# Write relay pcba revision to SC EEPROM
# Arguments  relay pcba revision  - max 32 bytes data
# Results  data = bytearray of relay pcba revision from EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(hc_protocol.WRITE_RELAY_PCBA_REV(pcba_rev))
#     device.send(msg)
class WRITE_RELAY_PCBA_REV(PARAMETER_CMD):
    def __init__(self, id, **kwargs):
        PARAMETER_CMD.__init__(self, PARAM_ID_RELAY_PCBA_REVISION, id, name = 'WRITE_RELAY_PCBA_REV', **kwargs)
        self.pcba_rev = None
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.pcba_rev = self.data.decode()
        if self.debug_level > 20:
            print("WRITE_RELAY_PCBA_REV result ", self.pcba_rev)
        return index

# Read left heater id from SC EEPROM
# Results  data = bytearray of left heater id from EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(hc_protocol.READ_HEATER_ID_LEFT())
#     device.send(msg)
class READ_HEATER_ID_LEFT(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_HEATER_ID_LEFT, name = 'READ_HEATER_ID_LEFT', **kwargs)
        self.heaterId = None
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.heaterId = self.data.decode()
        if self.debug_level > 20:
            print("READ_HEATER_ID_LEFT result ", self.heaterId)
        return index

# Read right heater id from SC EEPROM
# Results  data = bytearray of right heater id from EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(hc_protocol.READ_HEATER_ID_RIGHT())
#     device.send(msg)
class READ_HEATER_ID_RIGHT(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_HEATER_ID_RIGHT, name = 'READ_HEATER_ID_RIGHT', **kwargs)
        self.heaterId = None
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.heaterId = self.data.decode()
        if self.debug_level > 20:
            print("READ_HEATER_ID_RIGHT result ", self.heaterId)
        return index

# Read sc pcba revision from SC EEPROM
# Results  data = bytearray of sc pcba revision from EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(hc_protocol.READ_SC_PCBA_REV())
#     device.send(msg)
class READ_SC_PCBA_REV(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_SC_PCBA_REVISION, name = 'READ_SC_PCBA_REV', **kwargs)
        self.pcba_rev = None
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.pcba_rev = self.data.decode()
        if self.debug_level > 20:
            print("READ_SC_PCBA_REV result ", self.pcba_rev)
        return index

# Read ebox pcba revision from SC EEPROM
# Results  data = bytearray of ebox pcba revision from EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(hc_protocol.READ_EBOX_PCBA_REV())
#     device.send(msg)
class READ_EBOX_PCBA_REV(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_EBOX_PCBA_REVISION, name = 'READ_EBOX_PCBA_REV', **kwargs)
        self.pcba_rev = None
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.pcba_rev = self.data.decode()
        if self.debug_level > 20:
            print("READ_EBOX_PCBA_REV result ", self.pcba_rev)
        return index

# Read relay pcba revision from SC EEPROM
# Results  data = bytearray of relay pcba revision from EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(hc_protocol.READ_RELAY_PCBA_REV())
#     device.send(msg)
class READ_RELAY_PCBA_REV(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_RELAY_PCBA_REVISION, name = 'READ_RELAY_PCBA_REV', **kwargs)
        self.pcba_rev = None
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.pcba_rev = self.data.decode()
        if self.debug_level > 20:
            print("READ_RELAY_PCBA_REV result ", self.pcba_rev)
        return index

# Sets the EOL_CAL_TIMESTAMP configuration setting in raw units.
# Arguments timestamp - 32 bit timestamp (1970 format)
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_PCB_CAL_RIG_ID(timestamp=123))
#     device.send(msg)
class SET_EOL_CAL_TIMESTAMP(CALIBRATE_CMD):
    def __init__(self, eol_cal_timestamp, **kwargs):
        if eol_cal_timestamp >  0xFFFFFFFF: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_CAL_TIMESTAMP, cal_data = timestamp.to_bytes(4, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the EOL_CAL_TIMESTAMP configuration setting in degrees.
# Results  value  - 32 bit timestamp (1970 format)
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_FCT_CAL_TIMESTAMP))
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_EOL_CAL_TIMESTAMP(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_CAL_TIMESTAMP, **kwargs)
        self.eol_cal_timestamp = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.eol_cal_timestamp = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the EOL_CAL_RIG_ID configuration setting in raw units.
# Arguments  value  - 32 bit rig id
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_EOL_CAL_RIG_ID(rig_id=123))
#     device.send(msg)
class SET_EOL_CAL_RIG_ID(CALIBRATE_CMD):
    def __init__(self, eol_cal_rig_id, **kwargs):
        if eol_cal_rig_id >  0xFFFFFFFF: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_CAL_RIG_ID, cal_data = eol_cal_rig_id.to_bytes(4, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the EOL_CAL_RIG_ID configuration setting in degrees.
# Results  value  - 32 bit rig id
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_PCB_EOL_RIG_ID))
#     device.send(msg)
#     print("value=%d" % msg.results[0].rig_id)
class GET_EOL_CAL_RIG_ID(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_CAL_RIG_ID, **kwargs)
        self.eol_cal_rig_id = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.eol_cal_rig_id = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the EOL_CAL_RIG_ID configuration setting in raw units.
# Arguments  value  - 32 bit rig id
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_EOL_CAL_RIG_ID(rig_id=123))
#     device.send(msg)
class SET_EOL_CAL_TIMESTAMP(CALIBRATE_CMD):
    def __init__(self, eol_cal_timestamp, **kwargs):
        if eol_cal_timestamp >  0xFFFFFFFF: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_CAL_TIMESTAMP, cal_data = eol_cal_timestamp.to_bytes(4, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the EOL_CAL_RIG_ID configuration setting in degrees.
# Results  value  - 32 bit rig id
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_PCB_EOL_RIG_ID))
#     device.send(msg)
#     print("value=%d" % msg.results[0].rig_id)
class GET_EOL_CAL_TIMESTAMP(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_CAL_TIMESTAMP, **kwargs)
        self.eol_cal_timestamp = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.eol_cal_timestamp = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the SECURITY_BIT parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_SECURITY_BIT())
#     device.send(msg)
class SET_SECURITY_BIT(CALIBRATE_CMD):
    def __init__(self, **kwargs):
        state = 1
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_FCT_SECURITY_BIT, cal_data = state.to_bytes(1, byteorder='little', signed=True), **kwargs)
        self.value = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        return index

# Gets the SECURITY_BIT configuration setting in degrees.
# Results  0=bit not set, 1=bit set
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_SECURITY_BIT()))
#     device.send(msg)
#     print("value=%d" % msg.results[0].security_bit)
class GET_SECURITY_BIT(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_FCT_SECURITY_BIT, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.security_bit = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the EOL_AIR_EXIT_TEMP_SLOPE configuration setting in raw units.
# Arguments  index 0-5
#            value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_PCB_AIR_EXIT_TEMP_SLOPE(index=0, value=123))
#     device.send(msg)
class SET_EOL_AIR_EXIT_TEMP_SLOPE(CALIBRATE_CMD):
    def __init__(self, index, eol_air_exit_temp_slope, **kwargs):
        if eol_air_exit_temp_slope >  0xFFFF: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_AIR_EXIT_TEMP_SLOPE_BASE+index, cal_data = eol_air_exit_temp_slope.to_bytes(2, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the EOL_AIR_EXIT_TEMP_SLOPE configuration setting in raw units
# Argument  index 0-5
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_PCB_AIR_EXIT_TEMP_SLOPE(index=0))
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_EOL_AIR_EXIT_TEMP_SLOPE(CALIBRATE_REQ):
    def __init__(self, index, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_AIR_EXIT_TEMP_SLOPE_BASE+index, **kwargs)
        self.eol_air_exit_slope = None
        self.index = index
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.eol_air_exit_temp_slope = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

    ########### Set Purging Delay Time Method ###############
class SET_EOL_PURGING_TIME_DELAY(PARAMETER_CMD):
    def __init__(self, eol_purging_delay_time_ms, **kwargs):
        if eol_purging_delay_time_ms >  0xFFFF: raise Exception("Out of range")
        PARAMETER_CMD.__init__(self, PARAM_ID_EOL_PURGING_TIME_DELAY , eol_purging_delay_time_ms.to_bytes(2, byteorder='little', signed=False), name = 'HEAT_MODE', **kwargs)
        self.eol_purging_delay_time_ms = None
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.eol_purging_delay_time_ms = int.from_bytes(self.data, byteorder='little', signed=False)
        return index

class GET_EOL_PURGING_TIME_DELAY(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_EOL_PURGING_TIME_DELAY, name = 'HEAT_MODE', **kwargs)
        self.eol_purging_delay_time_ms = None
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.eol_purging_delay_time_ms = self.get_uint16(msg, index+6)
        return index + 8

    ########### Set Purging Flow Method ###############
class SET_EOL_PURGING_FLOW_MODE(PARAMETER_CMD):
    def __init__(self, eol_purging_flow_mode, **kwargs):
        if eol_purging_flow_mode >  0xFFFF: raise Exception("Out of range")
        PARAMETER_CMD.__init__(self, PARAM_ID_EOL_PURGING_FLOW_MODE , eol_purging_flow_mode.to_bytes(2, byteorder='little', signed=False), name = 'HEAT_MODE', **kwargs)
        self.eol_purging_flow_mode = None
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.eol_purging_flow_mode = int.from_bytes(self.data, byteorder='little', signed=False)
        return index

class GET_EOL_PURGING_FLOW_MODE(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_EOL_PURGING_FLOW_MODE, name = 'HEAT_MODE', **kwargs)
        self.eol_purging_flow_mode = None
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.eol_purging_flow_mode = self.get_uint16(msg, index+6)
        return index + 8

    ########### Set EOL HC Method ###############
class SET_EOL_HEATER_CONTROL_METHOD(PARAMETER_CMD):
    def __init__(self,eol_hc_method_entry,**kwargs):
        if eol_hc_method_entry > 0xFFFF: raise Exception("Out of Range")
        PARAMETER_CMD.__init__(self,PARAM_ID_EOL_HEATER_CONTROL_METHOD,eol_hc_method_entry.to_bytes(1, byteorder='little', signed=False),name = "HEAT_MODE", **kwargs)
        self.eol_hc_method_entry = None
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.eol_hc_method_entry = int.from_bytes(self.data, byteorder='little', signed=False)
        return index


# Sets the EOL_AIR_EXIT_TEMP_OFFSET configuration setting in raw units.
# Arguments  index 0-5
#            value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_EOL_AIR_EXIT_TEMP_OFFSET(index=0, value=123))
#     device.send(msg)
class SET_EOL_AIR_EXIT_TEMP_OFFSET(CALIBRATE_CMD):
    def __init__(self, index, eol_air_exit_temp_offset, **kwargs):
        if eol_air_exit_temp_offset >  0x7fff: raise Exception("Out of range")
        if eol_air_exit_temp_offset < -0x8000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_AIR_EXIT_TEMP_OFFSET_BASE+index, cal_data = eol_air_exit_temp_offset.to_bytes(2, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the EOL_AIR_EXIT_TEMP_OFFSET configuration setting in raw units.
# Argument  index 0-5
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_EOL_AIR_EXIT_TEMP_OFFSET(index))
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_EOL_AIR_EXIT_TEMP_OFFSET(CALIBRATE_REQ):
    def __init__(self, index, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_AIR_EXIT_TEMP_OFFSET_BASE+index, **kwargs)
        self.eol_air_exit_temp_offset = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.eol_air_exit_temp_offset = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# Sets the COM_AET_FLOW_RATE_4_L_S configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_COM_AET_FLOW_RATE_4_L_S(value=123))
#     device.send(msg)
class SET_COM_AET_FLOW_RATE_4_L_S(CALIBRATE_CMD):
    def __init__(self, com_aet_flow_rate_4_l_s, **kwargs):
        if com_aet_flow_rate_4_l_s >  0x7fff: raise Exception("Out of range")
        if com_aet_flow_rate_4_l_s < -0x8000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_COM_AET_FLOW_RATE_4_L_S_BASE, cal_data = com_aet_flow_rate_4_l_s.to_bytes(2, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the COM_AET_FLOW_RATE_4_L_S configuration setting in raw units.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_COM_AET_FLOW_RATE_4_L_S())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_COM_AET_FLOW_RATE_4_L_S(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_COM_AET_FLOW_RATE_4_L_S_BASE, **kwargs)
        self.com_aet_flow_rate_4_l_s = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.com_aet_flow_rate_4_l_s = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# Sets the COM_AET_FLOW_RATE_6_L_S configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_COM_AET_FLOW_RATE_6_L_S(value=123))
#     device.send(msg)
class SET_COM_AET_FLOW_RATE_6_L_S(CALIBRATE_CMD):
    def __init__(self, com_aet_flow_rate_6_l_s, **kwargs):
        if com_aet_flow_rate_6_l_s >  0x7fff: raise Exception("Out of range")
        if com_aet_flow_rate_6_l_s < -0x8000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_COM_AET_FLOW_RATE_6_L_S_BASE, cal_data = com_aet_flow_rate_6_l_s.to_bytes(2, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the COM_AET_FLOW_RATE_6_L_S configuration setting in raw units.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_COM_AET_FLOW_RATE_6_L_S())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_COM_AET_FLOW_RATE_6_L_S(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_COM_AET_FLOW_RATE_6_L_S_BASE, **kwargs)
        self.com_aet_flow_rate_6_l_s = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.com_aet_flow_rate_6_l_s = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# Sets the COM_AET_FLOW_RATE_9_L_S configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_COM_AET_FLOW_RATE_9_L_S(value=123))
#     device.send(msg)
class SET_COM_AET_FLOW_RATE_9_L_S(CALIBRATE_CMD):
    def __init__(self, com_aet_flow_rate_9_l_s, **kwargs):
        if com_aet_flow_rate_9_l_s >  0x7fff: raise Exception("Out of range")
        if com_aet_flow_rate_9_l_s < -0x8000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_COM_AET_FLOW_RATE_9_L_S_BASE, cal_data = com_aet_flow_rate_9_l_s.to_bytes(2, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the COM_AET_FLOW_RATE_9_L_S configuration setting in raw units.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_COM_AET_FLOW_RATE_9_L_S())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_COM_AET_FLOW_RATE_9_L_S(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_COM_AET_FLOW_RATE_9_L_S_BASE, **kwargs)
        self.com_aet_flow_rate_9_l_s = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.com_aet_flow_rate_9_l_s = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# Sets the COM_AET_FLOW_RATE_12_L_S configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_COM_AET_FLOW_RATE_12_L_S(value=123))
#     device.send(msg)
class SET_COM_AET_FLOW_RATE_12_L_S(CALIBRATE_CMD):
    def __init__(self, com_aet_flow_rate_12_l_s, **kwargs):
        if com_aet_flow_rate_12_l_s >  0x7fff: raise Exception("Out of range")
        if com_aet_flow_rate_12_l_s < -0x8000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_COM_AET_FLOW_RATE_12_L_S_BASE, cal_data = com_aet_flow_rate_12_l_s.to_bytes(2, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the COM_AET_FLOW_RATE_12_L_S configuration setting in raw units.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_COM_AET_FLOW_RATE_12_L_S())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_COM_AET_FLOW_RATE_12_L_S(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_COM_AET_FLOW_RATE_12_L_S_BASE, **kwargs)
        self.com_aet_flow_rate_12_l_s = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.com_aet_flow_rate_12_l_s = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# Sets the EOL_FLOW_OFFSET configuration setting
# Arguments  index 0-5
#            flowOffset
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_EOL_FLOW_OFFSET(index=0, eolFlowOffset = 3))
#     device.send(msg)
class SET_EOL_FLOW_OFFSET(CALIBRATE_CMD):
    def __init__(self, index, flowOffset, **kwargs):
        if index > 5: raise Exception("Channel out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_FLOW_OFFSET_CAL_ID_BASE+index, cal_data = flowOffset.to_bytes(1, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the EOL_FLOW_OFFSET configuration setting
# Argument  index 0-5
# Results  flowOffset - flow offset for one flow rate
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_EOL_FLOW_OFFSET(index))
#     device.send(msg)
#     print("value=%d" % (msg.results[0].flowOffset))
class GET_EOL_FLOW_OFFSET(CALIBRATE_REQ):
    def __init__(self, index, **kwargs):
        if index > 5: raise Exception("Channel out of range")
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_FLOW_OFFSET_CAL_ID_BASE+index, **kwargs)
        self.flowOffset = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.flowOffset = self.cal_data[0]
        return index
        
# Sets the PCB_TRIAC_TEMP_OFFSET configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_PCB_TRIAC_TEMP_OFFSET(value=123))
#     device.send(msg)
class SET_FCT_TRIAC_TEMP_OFFSET(CALIBRATE_CMD):
    def __init__(self, fct_triac_temp_offset, **kwargs):
        if fct_triac_temp_offset >  0x7fff: raise Exception("Out of range")
        if fct_triac_temp_offset < -0x8000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_FCT_TRIAC_TEMP_OFFSET, cal_data = fct_triac_temp_offset.to_bytes(2, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the PCB_TRIAC_TEMP_OFFSET configuration setting in degrees.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_PCB_TRIAC_TEMP_OFFSET())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_FCT_TRIAC_TEMP_OFFSET(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_FCT_TRIAC_TEMP_OFFSET, **kwargs)
        self.fct_triac_temp_offset = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.fct_triac_temp_offset = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the PCB_TRIAC_TEMP_SLOPE configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_PCB_TRIAC_TEMP_SLOPE(value=123))
#     device.send(msg)
class SET_FCT_TRIAC_TEMP_SLOPE(CALIBRATE_CMD):
    def __init__(self, fct_triac_temp_slope, **kwargs):
        if fct_triac_temp_slope >  0x7fff: raise Exception("Out of range")
        if fct_triac_temp_slope < -0x8000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_FCT_TRIAC_TEMP_SLOPE, cal_data = fct_triac_temp_slope.to_bytes(2, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the PCB_TRIAC_TEMP_SLOPE configuration setting in degrees.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_PCB_TRIAC_TEMP_SLOPE())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_FCT_TRIAC_TEMP_SLOPE(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_FCT_TRIAC_TEMP_SLOPE, **kwargs)
        self.fct_triac_temp_slope = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.fct_triac_temp_slope = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the PCB_TRIAC_TEMP_TRIP configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_PCB_TRIAC_TEMP_OFFSET_K(value=123))
#     device.send(msg)
class SET_EOL_TRIAC_TEMP_TRIP_LIMIT_MV(CALIBRATE_CMD):
    def __init__(self, eol_triac_temp_trip_limit_mV, **kwargs):
        if eol_triac_temp_trip_limit_mV >  0xFFFF: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_TRIAC_TEMP_TRIP_LIMIT_MV, cal_data = eol_triac_temp_trip_limit_mV.to_bytes(2, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the PCB_TRIAC_TEMP_OFFSET configuration setting in degrees.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_PCB_TRIAC_TEMP_OFFSET())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_EOL_TRIAC_TEMP_TRIP_LIMIT_MV(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_TRIAC_TEMP_TRIP_LIMIT_MV, **kwargs)
        self.eol_triac_temp_trip_limit_mV = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.eol_triac_temp_trip_limit_mV = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the CALIB_ID_EOL_CURRENT_LIMIT_MA configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_EOL_CURRENT_LIMIT_MA(12000)
#     device.send(msg)
class SET_EOL_CURRENT_LIMIT_MA(CALIBRATE_CMD):
    def __init__(self, eol_current_limit_mA, **kwargs):
        if eol_current_limit_mA >  0xFFFF: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_CURRENT_LIMIT_MA, cal_data = eol_current_limit_mA.to_bytes(2, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the CALIB_ID_EOL_CURRENT_LIMIT_MA configuration setting in degrees.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_EOL_CURRENT_LIMIT_MA())
#     device.send(msg)
#     print("eol_current_limit_mA=%d" % msg.results[0].eol_current_limit_mA)
class GET_EOL_CURRENT_LIMIT_MA(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_CURRENT_LIMIT_MA, **kwargs)
        self.eol_current_limit_mA = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.eol_current_limit_mA  = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the CALIB_ID_EOL_CURRENT_RAMP_SLOPE configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_EOL_CURRENT_RAMP_SLOPE(12000)
#     device.send(msg)
class SET_EOL_CURRENT_RAMP_SLOPE(CALIBRATE_CMD):
    def __init__(self, eol_current_ramp_slope, **kwargs):
        if eol_current_ramp_slope >  0xFFFF: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_CURRENT_RAMP_SLOPE, cal_data = eol_current_ramp_slope.to_bytes(2, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the CALIB_ID_EOL_CURRENT_RAMP_SLOPE configuration setting in degrees.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_EOL_CURRENT_RAMP_SLOPE())
#     device.send(msg)
#     print("eol_current_ramp_slope=%d" % msg.results[0].eol_current_ramp_slope)
class GET_EOL_CURRENT_RAMP_SLOPE(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_CURRENT_RAMP_SLOPE, **kwargs)
        self.eol_current_limit_mA = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.eol_current_ramp_slope  = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Gets the CALIB_ID_POWER_CAP configuration setting in mW.
# Results  value  - 16bit value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_EOL_POWER_CAP())
#     device.send(msg)
#     print("eol_power_cap=%d" % msg.results[0].eol_power_cap)
class GET_EOL_POWER_CAP(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_POWER_CAP, **kwargs)
        self.eol_power_cap = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.eol_power_cap  = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the CALIB_ID_POWER_CAP configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_EOL_POWER_SLOPE(x)
#     device.send(msg)
class SET_EOL_POWER_CAP(CALIBRATE_CMD):
    def __init__(self, eol_power_cap, **kwargs):
        if eol_power_cap >  0xFFFF: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_POWER_CAP, cal_data = eol_power_cap.to_bytes(2, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the CALIB_ID_EOL_POWER_MOTOR_TUNING configuration setting in mW.
# Results  value  - 16bit value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_EOL_POWER_MOTOR_TUNING())
#     device.send(msg)
#     print("eol_power_motor_tuning=%d" % msg.results[0].eol_power_motor_tuning)
class GET_EOL_POWER_MOTOR_TUNING(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_POWER_MOTOR_TUNING, **kwargs)
        self.eol_power_motor_tuning = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.eol_power_motor_tuning  = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the CALIB_ID_EOL_POWER_MOTOR_TUNING configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_EOL_POWER_MOTOR_TUNING(x)
#     device.send(msg)
class SET_EOL_POWER_MOTOR_TUNING(CALIBRATE_CMD):
    def __init__(self, eol_power_motor_tuning, **kwargs):
        if eol_power_motor_tuning >  0xFFFF: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_POWER_MOTOR_TUNING, cal_data = eol_power_motor_tuning.to_bytes(2, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the CALIB_ID_EOL_POWER_R_HEATER_LARM configuration setting in ohms.
# Results  value  - 32bit value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_EOL_POWER_R_HEATER())
#     device.send(msg)
#     print("eol_power_r_heater=%d" % msg.results[0].eol_power_r_heater)
class GET_EOL_POWER_R_HEATER_LARM(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_POWER_R_HEATER_LARM, **kwargs)
        self.eol_power_r_heater_larm = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        value = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        self.eol_power_r_heater_larm  = value / 10000
        return index

# Gets the CALIB_ID_EOL_POWER_R_HEATER_RARM configuration setting in ohms.
# Results  value  - 32bit value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_EOL_POWER_R_HEATER())
#     device.send(msg)
#     print("eol_power_r_heater=%d" % msg.results[0].eol_power_r_heater)
class GET_EOL_POWER_R_HEATER_RARM(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_POWER_R_HEATER_RARM, **kwargs)
        self.eol_power_r_heater_rarm = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        value = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        self.eol_power_r_heater_rarm  = value / 10000
        return index


# Sets the CALIB_ID_EOL_POWER_R_HEATER_LARM configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_EOL_POWER_R_HEATER(x)
#     device.send(msg)
class SET_EOL_POWER_R_HEATER_LARM(CALIBRATE_CMD):
    def __init__(self, eol_power_r_heater_larm, **kwargs):
        value = int(eol_power_r_heater_larm * 10000)  # DIPC command format in 1000ohms
        if value >  0xFFFFFFFF: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_POWER_R_HEATER_LARM, cal_data = value.to_bytes(4, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)


# Sets the CALIB_ID_EOL_POWER_R_HEATER_RARM configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_EOL_POWER_R_HEATER(x)
#     device.send(msg)
class SET_EOL_POWER_R_HEATER_RARM(CALIBRATE_CMD):
    def __init__(self, eol_power_r_heater_rarm, **kwargs):
        value = int(eol_power_r_heater_rarm * 10000)  # DIPC command format in 1000ohms
        if value >  0xFFFFFFFF: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_POWER_R_HEATER_RARM, cal_data = value.to_bytes(4, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Sets the PCB_CAL_RIG_ID configuration setting in raw units.
# Arguments  value  - 32 bit rig id
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_PCB_CAL_RIG_ID(12345678998))
#     device.send(msg)
class SET_FCT_CAL_RIG_ID(CALIBRATE_CMD):
    def __init__(self, fct_cal_rig_id, **kwargs):
        if fct_cal_rig_id >  0xFFFFFFFF: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_FCT_CAL_RIG_ID, cal_data = fct_cal_rig_id.to_bytes(4, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the PCB_CAL_RIG_ID configuration setting in degrees.
# Results  value  - 32 bit rig id
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_PCB_CAL_RIG_ID))
#     device.send(msg)
#     print("fct_cal_rig_id=%d" % msg.results[0].fct_cal_rig_id)
class GET_FCT_CAL_RIG_ID(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_FCT_CAL_RIG_ID, **kwargs)
        self.fct_cal_rig_id = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.fct_cal_rig_id = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the FCT_CAL_TIMESTAMP configuration setting in raw units.
# Arguments  value  - 32 bit rig id
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_PCB_CAL_RIG_ID(timestamp=123))
#     device.send(msg)
class SET_FCT_CAL_TIMESTAMP(CALIBRATE_CMD):
    def __init__(self, fct_cal_timestamp, **kwargs):
        if fct_cal_timestamp >  0xFFFFFFFF: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_FCT_CAL_TIMESTAMP, cal_data = fct_cal_timestamp.to_bytes(4, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the FCT_CAL_TIMESTAMP configuration setting in degrees.
# Results  value  - 32 bit timestamp (1970 format)
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_FCT_CAL_TIMESTAMP))
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_FCT_CAL_TIMESTAMP(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_FCT_CAL_TIMESTAMP, **kwargs)
        self.fct_cal_timestamp = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.fct_cal_timestamp = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the PCB_PCBA_FCT_INFO configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_PCB_PCBA_FCT_INFO(value=123))
#     device.send(msg)
class SET_FCT_PCB_INFO(CALIBRATE_CMD):
    def __init__(self, fct_pcb_info, **kwargs):
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_FCT_PCB_INFO, cal_data = fct_pcb_info.to_bytes(6, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the PCB_PCBA_FCT_INFO configuration setting in raw units.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_PCB_PCBA_FCT_INFO())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_FCT_PCB_INFO(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_FCT_PCB_INFO, **kwargs)
        self.fct_pcb_info = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.fct_pcb_info = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index


# Sets the UI lamp brightness calibration
# Arguments  lamp_config[] - Array of brightness levels for each lamp
# Usage:
class SET_EOL_LAMP_UI_CAL(CALIBRATE_CMD):
    def __init__(self, lamp_config, **kwargs):
        self.eol_lamp_ui_cal_bytes = bytearray()
        for lamp in range (0,9):
            lamp_byte = lamp_config[lamp].to_bytes(1, byteorder='little', signed=False)
            self.eol_lamp_ui_cal_bytes.extend(lamp_byte)
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_LAMP_UI_CAL, cal_data = eol_lamp_ui_cal_bytes, **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the UI lamp brightness calibration for each lamp
# Results  Array of lamp data brightness levels
# Usage:
class GET_EOL_LAMP_UI_CAL(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_LAMP_UI_CAL, **kwargs)
        self.eol_lamp_ui_cal_data = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.eol_lamp_ui_cal_data = []
        for lamp in range (0,9):
            self.eol_lamp_ui_cal_data.append(int.from_bytes(self.cal_data[lamp:lamp+1], byteorder='little', signed=False))
        return index

# Gets the SECURITY_BIT configuration setting in degrees.
# Results  0=bit not set, 1=bit set
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_FCT_CAL_TIMESTAMP))
#     device.send(msg)
#     print("value=%d" % msg.results[0].security_bit)
class GET_FCT_SECURITY_BIT(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_FCT_SECURITY_BIT, **kwargs)
        self.fct_security_bit  = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.fct_security_bit = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index


# Sets the SECURITY_BIT parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.SET_SECURITY_BIT())
#     device.send(msg)
class SET_FCT_SECURITY_BIT(CALIBRATE_CMD):
    def __init__(self, **kwargs):
        CALIBRATE_CMD.__init__(self, CALIB_ID_FCT_SECURITY_BIT, state.to_bytes(1, byteorder='little', signed=True), name = 'DRIVE_MODE', **kwargs)
        self.value = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        return index

# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.DIPC_DBG_ZC_DUMP_CMD())
#     device.send(msg)
#     command_result    = msg.results[0].result
#     zcross_freq = msg.results[0].frequency
class DIPC_DBG_ZC_DUMP_CMD(LecCommand):
    DIPC_DBG_ZC_DUMP_CMD = 0x801D
    DIPC_DBG_ZC_DUMP_RES = 0x801E
    name = 'DIPC_DBG_ZC_DUMP_CMD'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.ticks = [None] *32
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.DIPC_DBG_ZC_DUMP_CMD))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.DIPC_DBG_ZC_DUMP_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.DIPC_DBG_ZC_DUMP_RES))
        index += 2

        for i in range(32):
            self.ticks[i] = self.get_uint16(msg, index)
            index += 2

        if self.debug_level > 20:
            print("Parsing %s: result=%d  0=Command OK, 1=Error, 2=Device cal locked" % (self.name, self.result))
        index += 3
        return index


# Implements the TST_OPEN_LOOP_POWER_CMD/TST_OPEN_LOOP_POWER_RES command/response.
# Arguments  none
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16     Command ID  - DIPC_TST_OPEN_LOOP_POWER_CMD (0x801B)
# Response:  UINT16     Command ID  - DIPC_TST_OPEN_LOOP_POWER_RES (0x801C)
#            UINT16     x 3 angles
#            UINT32     -ticks
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.FCT_ZCROSS_MEAS_CMD())
#     device.send(msg)
#     command_result    = msg.results[0].result
#     zcross_freq = msg.results[0].frequency
class TST_SET_OPEN_LOOP_POWER_CMD(LecCommand):
    DIPC_TST_OPEN_LOOP_POWER_CMD = 0x801B
    DIPC_TST_OPEN_LOOP_POWER_RES = 0x801C
    name = 'TST_OPEN_LOOP_POWER'

    def __init__(self, duty, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.duty = duty
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.DIPC_TST_OPEN_LOOP_POWER_CMD))
        self.duty = bytearray(struct.pack('f', self.duty))
        msg.extend(self.duty)
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.DIPC_TST_OPEN_LOOP_POWER_RES:
            print(cmd_id)
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.DIPC_FCT_ZC_ASSYM_MEAS_RES))
        index += 2
        self.duty = self.get_uint32(msg, index)
        self.duty = struct.unpack('f', self.duty.to_bytes(4, 'little'))[0]
        index += 4

        if self.debug_level > 20:
            print("Parsing %s: result=%d  0=Command OK, 1=Error, 2=Device cal locked" % (self.name, self.result))
        index += 3
        return index

# Implements the DIPCCMD_FCT_ZCROSS_MEAS_CMD/DIPCCMD_FCT_ZCROSS_MEAS_RES command/response.
# Arguments  none
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16     Command ID  - DIPC_FCT_ZC_ASSYM_MEAS_CMD (0x8019)
# Response:  UINT16     Command ID  - DIPC_FCT_ZC_ASSYM_MEAS_RED (0x801A)
#            UINT32     +ticks
#            UINT32     -ticks

# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.FCT_ZCROSS_MEAS_CMD())
#     device.send(msg)
#     command_result    = msg.results[0].result
#     zcross_freq = msg.results[0].frequency
class FCT_ZCROSS_ASSYM_MEAS_CMD(LecCommand):
    DIPC_FCT_ZC_ASSYM_MEAS_CMD = 0x8019
    DIPC_FCT_ZC_ASSYM_MEAS_RES = 0x801A
    name = 'FCT_ZC_ASSYM_MEAS_CMD'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.pticks = None
        self.nticks = None
        self.xticks = None
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.DIPC_FCT_ZC_ASSYM_MEAS_CMD))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.DIPC_FCT_ZC_ASSYM_MEAS_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.DIPC_FCT_ZC_ASSYM_MEAS_RES))
        index += 2
        self.pticks = self.get_uint32(msg, index)
        index += 4
        self.nticks = self.get_uint32(msg, index)
        index += 4
        self.xticks = self.get_uint32(msg, index)
        index += 4

        if self.debug_level > 20:
            print("Parsing %s: result=%d  0=Command OK, 1=Error, 2=Device cal locked" % (self.name, self.result))
        index += 3
        return index


# Implements the DIPCCMD_FCT_ZCROSS_MEAS_CMD/DIPCCMD_FCT_ZCROSS_MEAS_RES command/response.
# Arguments  none
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16     Command ID  - FCT_ZCROSS_MEAS_CMD (0x8011)
# Response:  UINT16     Command ID  - FCT_ZCROSS_MEAS_RES (0x8012)
#            UINT16     Dutycycle   - in Q12 format 0=0%; 4096=100%
#            UINT16     Frequency   - in Q8 format 12800=50Hz, maximum frequency is 256Hz
#            UINT8      Result      - 0x00=Success, 0x01=Error-not ready, 0x02=Error Command locked
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.FCT_ZCROSS_MEAS_CMD())
#     device.send(msg)
#     command_result    = msg.results[0].result
#     zcross_freq = msg.results[0].frequency
class FCT_ZCROSS_MEAS_CMD(LecCommand):
    FCT_ZCROSS_MEAS_CMD = 0x8011
    FCT_ZCROSS_MEAS_RES = 0x8012
    name = 'FCT_ZCROSS_MEAS_CMD'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.frequency = None
        self.dutycycle = None
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.FCT_ZCROSS_MEAS_CMD))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.FCT_ZCROSS_MEAS_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.FCT_ZCROSS_MEAS_RES))
        index += 2
        self.dutycycle = self.get_uint16(msg, index)
        index += 2
        self.frequency = self.get_uint16(msg, index)

        self.result = self.get_uint8(msg, index+2)

        if self.debug_level > 20:
            print("Parsing %s: result=%d  0=Command OK, 1=Error, 2=Device cal locked" % (self.name, self.result))
        index += 3
        return index


# Implements the FCT_TRIAC_TEST_START_CMD/FCT_TRIAC_TEST_START_RES command/response.
# Arguments  UINT16 TRIAC sequence number
#            UINT16 array: length = sequence number * 3, each item is phase angle 0-179, 256: stop
# Results    result - 0 = command ok, 1 = error
# Command:   UINT16 FCT_TRIAC_TEST_START_CMD (0x800D)
# Response:  UINT16 FCT_TRIAC_TEST_START_RES (0x800E)
#            UINT8  0x00 = Command executed ok, 0x01 = Error
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.FCT_TRIAC_TEST_START_CMD(sequence_number, phase_angle))
#     device.send(msg)
#     print("result=%d" % msg.results[0].result)
class FCT_TRIAC_TEST_START_CMD(LecCommand):
    FCT_TRIAC_TEST_START_CMD = 0x800D
    FCT_TRIAC_TEST_START_RES = 0x800E
    name = 'FCT_TRIAC_TEST_START_CMD'

    def __init__(self, sequence_number, phase_angle, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str    = None
        self.sequence_number = sequence_number
        self.phase_angle = phase_angle
        self.result       = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.FCT_TRIAC_TEST_START_CMD))
        msg.extend(self.uint16(self.sequence_number))
        for i in range(0,self.sequence_number*4):
            msg.extend(self.uint16(self.phase_angle[i]))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.FCT_TRIAC_TEST_START_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.FCT_TRIAC_TEST_START_RES))
        self.result = self.get_uint8(msg, index+2)
        if self.debug_level > 20:
            print("Parsing %s: result=%d  0=Command OK, 1=Error" % (self.name, self.result))
        index += 3
        return index

# Implements the FCT_TRIAC_TEST_STOP_CMD/FCT_TRIAC_TEST_STOP_RES command/response.
#
#   Purpose: To stop TRIACs testing
#
#   This function
#   1) Disable all TRIACs output
#
# Arguments  none
# Results    none
# Command:   UINT16     Command ID      - FCT_TRIAC_TEST_STOP_CMD (0x800F)
# Response:  UINT16     Command ID      - FCT_TRIAC_TEST_STOP_RES (0x8010)
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.FCT_TRIAC_TEST_STOP_CMD())
#     device.send(msg)
class FCT_TRIAC_TEST_STOP_CMD(LecCommand):
    FCT_TRIAC_TEST_STOP_CMD = 0x800F
    FCT_TRIAC_TEST_STOP_RES = 0x8010
    name = 'FCT_BB_DRIVE_STOP_MEAS_CMD'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.FCT_TRIAC_TEST_STOP_CMD))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.FCT_TRIAC_TEST_STOP_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.FCT_BB_DRIVE_STOP_MEAS_RES))
        return index+2

# Implements the ERASE_DATA_LOG_CMD/ERASE_DATA_LOG_RES command/response.
# Arguments  none
# Results    result - 0 = command ok, 1 = error-system not ready, 2 = device cal is locked
# Command:   UINT16     Command ID  - ERASE_DATA_LOG_CMD (0x802c)
# Response:  UINT16     Command ID  - ERASE_DATA_LOG_RES (0x802d)
#            UINT8      Result      - 0x00=Success, 0x01=Error-not ready, 0x02=Error Command locked
#
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.ERASE_DATA_LOG_CMD())
#     device.send(msg)
#     command_result    = msg.results[0].result
class ERASE_DATA_LOG_CMD(LecCommand):
    ERASE_DATA_LOG_CMD = 0x802C
    ERASE_DATA_LOG_RES = 0x802D
    name = 'ERASE_DATA_LOG_CMD'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.ERASE_DATA_LOG_CMD))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.ERASE_DATA_LOG_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.ERASE_DATA_LOG_RES))
        self.result = self.get_uint8(msg, index+2)
        if self.debug_level > 20:
            print("Parsing %s: result=%d  0=Command OK, 1=Error, 2=Device cal locked" % (self.name, self.result))
        index += 3
        return index


# Gets the MEMS_TEMPERATURE_PARAMETER parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_MEMS_TEMP())
#     device.send(msg)
#     print("Result = %f K" % msg.results[0].mems_temp_K)
#     print("Result = %f C" % msg.results[0].mems_temp_C)
class GET_MEMS_TEMP(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_TEMPERATURE_PARAM_ID, name = 'MEMS TEMP', **kwargs)
        self.mems_temp_K = None  # Value is not available until a response is parsed
        self.mems_temp_C = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))

        self.mems_temp_K = self.get_uint16(msg, index+6) /100
        self.mems_temp_C = self.mems_temp_K - 271.0
        return index + 8


# Gets the AIR_EXIT_TEMP_RAW_K parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_AIR_EXIT_TEMP_RAW_K(index=0))
#     device.send(msg)
#     print("Result = %f K" % msg.results[0].air_exit_temp_k)
class GET_AIR_EXIT_TEMP_RAW_K(PARAMETER_REQ):
    def __init__(self, index, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_AIR_EXIT_TEMP_RAW_K_BASE + index , name = 'AIR_EXIT_TEMP_RAW_K(%d)' % index, **kwargs)
        self.air_exit_temp_k = None  # Value is not available until a response is parsed
        self.index = index
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.air_exit_temp_k = self.get_uint16(msg, index+6)
        return index + 8


# Gets the AVG_A_AIR_EXIT_TEMP_RAW_K parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_AVG_A_AIR_EXIT_TEMP_RAW_K(index=0))
#     device.send(msg)
#     print("Result = %f K" % msg.results[0].avg_a_air_exit_temp_raw_k)
class GET_AVG_A_AIR_EXIT_TEMP_RAW_K(PARAMETER_REQ):
    def __init__(self, index=0, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_AVG_A_AIR_EXIT_TEMP_RAW_K_BASE + index , name = 'AVG_A_AIR_EXIT_TEMP_RAW_K(%d)' % index, **kwargs)
        self.avg_a_air_exit_temp_raw_k = None  # Value is not available until a response is parsed
        self.index = index
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.avg_a_air_exit_temp_raw_k = self.get_uint16(msg, index+6)
        return index + 8


# Gets the AVG_B_AIR_EXIT_TEMP_RAW_K parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_AVG_B_AIR_EXIT_TEMP_RAW_K(index=0))
#     device.send(msg)
#     print("Result = %f K" % msg.results[0].avg_b_air_exit_temp_raw_k)
class GET_AVG_B_AIR_EXIT_TEMP_RAW_K(PARAMETER_REQ):
    def __init__(self, index=0, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_AVG_B_AIR_EXIT_TEMP_RAW_K_BASE + index , name = 'AVG_B_AIR_EXIT_TEMP_RAW_K(%d)' % index, **kwargs)
        self.avg_b_air_exit_temp_raw_k = None  # Value is not available until a response is parsed
        self.index = index
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.avg_b_air_exit_temp_raw_k = self.get_uint16(msg, index+6)
        return index + 8


# Gets the DELTA_A_AIR_EXIT_TEMP_RAW_K parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_DELTA_A_AIR_EXIT_TEMP_RAW_K(index=0))
#     device.send(msg)
#     print("Result = %f K" % msg.results[0].delta_a_air_exit_temp_raw_k)
class GET_DELTA_A_AIR_EXIT_TEMP_RAW_K(PARAMETER_REQ):
    def __init__(self, index=0, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_DEL_A_AIR_EXIT_TEMP_RAW_K_BASE + index , name = 'DEL_A_AIR_EXIT_TEMP_RAW_K(%d)' % index, **kwargs)
        self.delta_a_air_exit_temp_raw_k = None  # Value is not available until a response is parsed
        self.index = index
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.delta_a_air_exit_temp_raw_k = self.get_uint16(msg, index+6)
        return index + 8


# Gets the DELTA_B_AIR_EXIT_TEMP_RAW_K parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_DELTA_B_AIR_EXIT_TEMP_RAW_K(index=0))
#     device.send(msg)
#     print("Result = %f K" % msg.results[0].delta_b_air_exit_temp_raw_k)
class GET_DELTA_B_AIR_EXIT_TEMP_RAW_K(PARAMETER_REQ):
    def __init__(self, index=0, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_DEL_B_AIR_EXIT_TEMP_RAW_K_BASE + index , name = 'DEL_B_AIR_EXIT_TEMP_RAW_K(%d)' % index, **kwargs)
        self.delta_b_air_exit_temp_raw_k = None  # Value is not available until a response is parsed
        self.index = index
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.delta_b_air_exit_temp_raw_k = self.get_uint16(msg, index+6)
        return index + 8


# Gets the AIR_EXIT_TEMP_K parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_AIR_EXIT_TEMP_K(index=0))
#     device.send(msg)
#     print("Result = %f K" % msg.results[0].air_exit_temp_k)
class GET_AIR_EXIT_TEMP_K(PARAMETER_REQ):
    def __init__(self, index, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_AIR_EXIT_TEMP_K_BASE + index , name = 'AIR_EXIT_TEMP_K(%d)' % index, **kwargs)
        self.air_exit_temp_k = None  # Value is not available until a response is parsed
        self.index = index
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.air_exit_temp_k = self.get_uint16(msg, index+6) / 16
        return index + 8

# Gets the AIR_EXIT_ALL_TEMP_K parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_AIR_EXIT_ALL_TEMP_RAW_K(index=0))
#     device.send(msg)
#     print("Result = %f K" % msg.results[0].air_exit_temp_k)
class GET_AIR_EXIT_ALL_TEMP_RAW_K(PARAMETER_REQ):
    NUMBER_OF_THERMISTOR = 8

    def __init__(self, index, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_AIR_EXIT_TEMP_ALL_K_RAW , name = 'AIR_EXIT_ALL_TEMP_K_RAW(%d)' % index, **kwargs)
        self.air_exit_all_temp_k = [''] * self.NUMBER_OF_THERMISTOR  # Value is not available until a response is parsed
        self.index = index
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        i = 0
        while i < self.NUMBER_OF_THERMISTOR:
            self.air_exit_all_temp_k[i] = self.get_uint16(msg, index+6+(2*i))
            i = i + 1
        return index + 22


# Gets the AVG_A_AIR_EXIT_TEMP_K parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_AVG_A_AIR_EXIT_TEMP_K(index=0))
#     device.send(msg)
#     print("Result = %f K" % msg.results[0].avg_a_air_exit_temp_k)
class GET_AVG_A_AIR_EXIT_TEMP_K(PARAMETER_REQ):
    def __init__(self, index, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_AVG_A_AIR_EXIT_TEMP_K_BASE + index , name = 'AVG_A_AIR_EXIT_TEMP_K(%d)' % index, **kwargs)
        self.avg_a_air_exit_temp_k = None  # Value is not available until a response is parsed
        self.index = index
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.avg_a_air_exit_temp_k = self.get_uint16(msg, index+6) / 16
        return index + 8


# Gets the AVG_B_AIR_EXIT_TEMP_K parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_AVG_B_AIR_EXIT_TEMP_K(index=0))
#     device.send(msg)
#     print("Result = %f K" % msg.results[0].avg_b_air_exit_temp_k)
class GET_AVG_B_AIR_EXIT_TEMP_K(PARAMETER_REQ):
    def __init__(self, index, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_AVG_B_AIR_EXIT_TEMP_K_BASE + index , name = 'AVG_B_AIR_EXIT_TEMP_K(%d)' % index, **kwargs)
        self.avg_b_air_exit_temp_k = None  # Value is not available until a response is parsed
        self.index = index
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.avg_b_air_exit_temp_k = self.get_uint16(msg, index+6) / 16
        return index + 8


# Gets the DELTA_A_AIR_EXIT_TEMP_K parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_DELTA_A_AIR_EXIT_TEMP_K(index=0))
#     device.send(msg)
#     print("Result = %f K" % msg.results[0].delta_a_air_exit_temp_k)
class GET_DELTA_A_AIR_EXIT_TEMP_K(PARAMETER_REQ):
    def __init__(self, index, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_DEL_A_AIR_EXIT_TEMP_K_BASE + index , name = 'DEL_A_AIR_EXIT_TEMP_K(%d)' % index, **kwargs)
        self.delta_a_air_exit_temp_k = None  # Value is not available until a response is parsed
        self.index = index
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.delta_a_air_exit_temp_k = self.get_uint16(msg, index+6) / 16
        return index + 8


# Gets the DELTA_B_AIR_EXIT_TEMP_K parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_DELTA_B_AIR_EXIT_TEMP_K(index=0))
#     device.send(msg)
#     print("Result = %f K" % msg.results[0].delta_b_air_exit_temp_k)
class GET_DELTA_B_AIR_EXIT_TEMP_K(PARAMETER_REQ):
    def __init__(self, index, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_DEL_B_AIR_EXIT_TEMP_K_BASE + index , name = 'DEL_B_AIR_EXIT_TEMP_K(%d)' % index, **kwargs)
        self.delta_b_air_exit_temp_k = None  # Value is not available until a response is parsed
        self.index = index
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.delta_b_air_exit_temp_k = self.get_uint16(msg, index+6) / 16
        return index + 8


# Gets the TRIAC_TEMP_MV parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_TRIAC_TEMP_MV())
#     device.send(msg)
#     print("Result = %f V" % msg.results[0].pressure_kPa)
class GET_TRIAC_TEMP_MV(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_TRIAC_TEMP_MV, name = 'TRIAC_TEMP_MV', **kwargs)
        self.triac_temp_mV = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.triac_temp_mV = self.get_uint32(msg, index+6)
        return index + 10

# Gets the PRESSURE parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_PRESSURE())
#     device.send(msg)
#     print("Result = %f V" % msg.results[0].pressure_kPa)
class GET_PRESSURE(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_PRESSURE, name = 'PRESSURE', **kwargs)
        self.pressure = None  # Value is not available until a response is parsed
        self.pressure_mB = None
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.pressure = self.get_uint32(msg, index+6)  # get pressure in 0.01 mB resolution
        self.pressure_mB = self.pressure / 100 # convert to milliBar
        return index + 10

# Implements the DIPC_MODE_CMD/DIPC_MODE_RES command/response.
# Arguments  ui_mode: 0 - inactive, 1 - roots, 2 - wet hair, 3 - dry hair, 4 - finishing
# Results    result - 0 = command ok, 1 = error
# Command:   UINT16 DIPC_MODE_CMD (0x8000)
# Response:  UINT16 DIPC_MODE_RES (0x8001)
#            UINT8  ui_mode = 0 ~ 5
#            UINT8  High temperature range, e.g. 137
#            UINT8  Medium temperature range, e.g. 100
#            UINT8  Low temperature range, e.g. 50
#            UINT8  High flow mode flow rate in deciliter/s, e.g. 135 = 13.5L/s
#            UINT8  Medium flow mode flow rate in decilitres/sec, e.g. 112 = 11.2L/s
#            UINT8  Sensitive mode temperature range, e.g. 60
#            UINT8  Sensitive mode flow rate in deciliter/s, e.g. 135 = 9L/s
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_UI_MODE(ui_mode))
#     device.send(msg)
#     print("return_ui_mode=%d, high_temp=%d, medium_temp=%d, low_temp=%d" % (msg.results[0].return_ui_mode, msg.results[0].h_temp, msg.results[0].m_temp, msg.results[0].l_temp))
class SET_UI_MODE(LecCommand):
    DIPC_MODE_CMD = 0x8000
    DIPC_MODE_RES = 0x8001
    name = 'DIPC_MODE_CMD'

    def __init__(self, ui_mode, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.ui_mode = ui_mode
        self.return_ui_mode = None
        self.ui_mode_name = None
        self.h_temp    = None
        self.m_temp    = None
        self.l_temp    = None
        self.flow_rate2 = None
        self.flow_rate1 = None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.DIPC_MODE_CMD))
        msg.extend(self.uint8(self.ui_mode))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.DIPC_MODE_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.DIPC_MODE_RES))
        self.return_ui_mode = self.get_uint8(msg, index+2)
        self.h_temp = self.get_uint8(msg, index+3)
        self.m_temp = self.get_uint8(msg, index+4)
        self.l_temp = self.get_uint8(msg, index+5)
        self.flow_rate2 = self.get_uint8(msg, index+6)
        self.flow_rate1 = self.get_uint8(msg, index+7)
        self.flow_rate2 /= 10.0
        self.flow_rate1 /= 10.0
        if self.return_ui_mode == 0:
            self.ui_mode_name = 'Inactive'
        elif self.return_ui_mode == 1:
            self.ui_mode_name = 'Wet'
        elif self.return_ui_mode == 2:
            self.ui_mode_name = 'Dry'
        if self.debug_level > 20:
            print("Parsing %s: return_ui_mode=%d, high_temp=%d, medium_temp=%d, low_temp=%d" % (self.name, self.return_ui_mode, self.h_temp, self.m_temp, self.l_temp))
        index += 10
        return index

# Implements the DIPC_MODE_REQ/DIPC_MODE_RES command/response.
# Arguments  None
# Results    result - 0 = command ok, 1 = error
# Command:   UINT16 DIPC_MODE_REQ (0x8002)
# Response:  UINT16 DIPC_MODE_RES (0x8001)
#            UINT8  ui_mode = 0 ~ 5
#            UINT8  High temperature range, e.g. 137
#            UINT8  Medium temperature range, e.g. 100
#            UINT8  Low temperature range, e.g. 50
#            UINT8  High flow mode flow rate in deciliter/s, e.g. 135 = 13.5L/s
#            UINT8  Medium flow mode flow rate in decilitres/sec, e.g. 112 = 11.2L/s
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_UI_MODE())
#     device.send(msg)
#     print("return_ui_mode=%d, high_temp=%d, medium_temp=%d, low_temp=%d" % (msg.results[0].return_ui_mode, msg.results[0].h_temp, msg.results[0].m_temp, msg.results[0].l_temp))
class GET_UI_MODE(LecCommand):
    DIPC_MODE_REQ = 0x8002
    DIPC_MODE_RES = 0x8001
    name = 'DIPC_MODE_REQ'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.return_ui_mode = None
        self.ui_mode_name = None
        self.h_temp    = None
        self.m_temp    = None
        self.l_temp    = None
        self.flow_rate2 = None
        self.flow_rate1 = None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.DIPC_MODE_REQ))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.DIPC_MODE_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.DIPC_MODE_RES))
        self.return_ui_mode = self.get_uint8(msg, index+2)
        self.h_temp = self.get_uint8(msg, index+3)
        self.m_temp = self.get_uint8(msg, index+4)
        self.l_temp = self.get_uint8(msg, index+5)
        self.flow_rate2 = self.get_uint8(msg, index+6)
        self.flow_rate1 = self.get_uint8(msg, index+7)
        self.flow_rate2 /= 10.0
        self.flow_rate1 /= 10.0
        if self.return_ui_mode == 0:
            self.ui_mode_name = 'Inactive'
        elif self.return_ui_mode == 1:
            self.ui_mode_name = 'Wet'
        elif self.return_ui_mode == 2:
            self.ui_mode_name = 'Dry'
        if self.debug_level > 20:
            print("Parsing %s: return_ui_mode=%d, high_temp=%d, medium_temp=%d, low_temp=%d" % (self.name, self.return_ui_mode, self.h_temp, self.m_temp, self.l_temp))
        index += 8
        return index

# Implements the DIPC_MODE_CONFIG_CMD/DIPC_MODE_CONFIG_RES command/response.
# Arguments  UINT8  mode-sensitive index:
#               0 = Inactive mode
#               1 = Roots mode, sensitive off
#               2 = Roots mode, sensitive on
#               3 = Wet to dry mode, sensitive off
#               4 = Wet to dry mode, sensitive on
#               5 = Straighting mode, sensitive off
#               6 = Straighting mode, sensitive on
#               7 = Finishing mode, sensitive off
#               8 = Finishing mode, sensitive on
#            UINT8  High temperature range, e.g. 137
#            UINT8  Medium temperature range, e.g. 100
#            UINT8  Low temperature range, e.g. 50
# Results    result - 0 = command ok, 1 = error
# Command:   UINT16 DIPC_MODE_CONFIG_CMD (0x801F)
# Response:  UINT16 DIPC_MODE_CONFIG_RES (0x8020)
#            UINT8  High temperature range, e.g. 137
#            UINT8  Medium temperature range, e.g. 100
#            UINT8  Low temperature range, e.g. 50
#            UINT8  High flow mode flow rate in deciliter/s, e.g. 135 = 13.5L/s
#            UINT8  Medium flow mode flow rate in decilitres/sec, e.g. 112 = 11.2L/s
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.MODE_CONFIG_CMD(index, target_h_temp, target_m_temp, target_l_temp, target_h_flow, target_m_flow))
#     device.send(msg)
#     print("return high_temp=%d, medium_temp=%d, low_temp=%d, high_flow=%d, medium_flow=%d" % (msg.results[0].h_temp, msg.results[0].m_temp, msg.results[0].l_temp, msg.results[0].h_flow, msg.results[0].m_flow))
class MODE_CONFIG_CMD(LecCommand):
    DIPC_MODE_CONFIG_CMD = 0x801F
    DIPC_MODE_CONFIG_RES = 0x8020
    name = 'DIPC_MODE_CONFIG_CMD'

    def __init__(self, index, target_h_temp, target_m_temp, target_l_temp, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.index = index
        self.target_h_temp = target_h_temp
        self.target_m_temp = target_m_temp
        self.target_l_temp = target_l_temp
        self.h_temp    = None
        self.m_temp    = None
        self.l_temp    = None
        self.flow_rate2 = None
        self.flow_rate1 = None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.DIPC_MODE_CONFIG_CMD))
        msg.extend(self.uint8(self.index))
        msg.extend(self.uint8(self.target_h_temp))
        msg.extend(self.uint8(self.target_m_temp))
        msg.extend(self.uint8(self.target_l_temp))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.DIPC_MODE_CONFIG_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.DIPC_MODE_CONFIG_RES))
        self.h_temp = self.get_uint8(msg, index+2)
        self.m_temp = self.get_uint8(msg, index+3)
        self.l_temp = self.get_uint8(msg, index+4)
        self.flow_rate2 = self.get_uint8(msg, index+5)
        self.flow_rate1 = self.get_uint8(msg, index+6)
        self.flow_rate2 /= 10.0
        self.flow_rate1 /= 10.0
        if self.debug_level > 20:
            print("Parsing %s: high_temp=%d, medium_temp=%d, low_temp=%d, high_flow=%d, medium_flow=%d" % (self.name, self.h_temp, self.m_temp, self.l_temp, self.flow_rate2, self.flow_rate1))
        index += 7
        return index

# Implements the DIPC_MODE_CONFIG_REQ/DIPC_MODE_CONFIG_RES command/response.
# Arguments  UINT8  mode-sensitive index:
#               0 = Inactive mode
#               1 = Roots mode, sensitive off
#               2 = Roots mode, sensitive on
#               3 = Wet to dry mode, sensitive off
#               4 = Wet to dry mode, sensitive on
#               5 = Straighting mode, sensitive off
#               6 = Straighting mode, sensitive on
#               7 = Finishing mode, sensitive off
#               8 = Finishing mode, sensitive on
# Results    result - 0 = command ok, 1 = error
# Command:   UINT16 DIPC_MODE_CONFIG_REQ (0x8021)
# Response:  UINT16 DIPC_MODE_CONFIG_RES (0x8020)
#            UINT8  High temperature range, e.g. 137
#            UINT8  Medium temperature range, e.g. 100
#            UINT8  Low temperature range, e.g. 50
#            UINT8  High flow mode flow rate in deciliter/s, e.g. 135 = 13.5L/s
#            UINT8  Medium flow mode flow rate in decilitres/sec, e.g. 112 = 11.2L/s
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.MODE_CONFIG_REQ(index))
#     device.send(msg)
#     print("return high_temp=%d, medium_temp=%d, low_temp=%d, high_flow=%d, medium_flow=%d" % (msg.results[0].h_temp, msg.results[0].m_temp, msg.results[0].l_temp, msg.results[0].h_flow, msg.results[0].m_flow))
class MODE_CONFIG_REQ(LecCommand):
    DIPC_MODE_CONFIG_REQ = 0x8021
    DIPC_MODE_CONFIG_RES = 0x8020
    name = 'DIPC_MODE_CONFIG_REQ'

    def __init__(self, index, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.index = index
        self.h_temp    = None
        self.m_temp    = None
        self.l_temp    = None
        self.flow_rate2 = None
        self.flow_rate1 = None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.DIPC_MODE_CONFIG_REQ))
        msg.extend(self.uint8(self.index))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.DIPC_MODE_CONFIG_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.DIPC_MODE_CONFIG_RES))
        self.h_temp = self.get_uint8(msg, index+2)
        self.m_temp = self.get_uint8(msg, index+3)
        self.l_temp = self.get_uint8(msg, index+4)
        self.flow_rate2 = self.get_uint8(msg, index+5)
        self.flow_rate1 = self.get_uint8(msg, index+6)
        self.flow_rate2 /= 10.0
        self.flow_rate1 /= 10.0
        if self.debug_level > 20:
            print("Parsing %s: high_temp=%d, medium_temp=%d, low_temp=%d, high_flow=%d, medium_flow=%d" % (self.name, self.h_temp, self.m_temp, self.l_temp, self.flow_rate2, self.flow_rate1))
        index += 7
        return index

        
# Implements the DIPC_ALL_MODE_CONFIG_REQ/DIPC_ALL_MODE_CONFIG_RES command/response.
# Arguments  UINT8  mode-sensitive index:
#               0 = EUUS Inactive mode
#               1 = EUUS Wet mode, coolfix off
#               2 = EUUS Wet mode, coolfix on
#               3 = EUUS Dry mode, coolFix off
#               4 = EUUS Dry mode, coolFix on
#               5 = JPN Inactive mode
#               6 = JPN Wet mode, coolfix off
#               7 = JPN Wet mode, coolfix on
#               8 = JPN Dry mode, coolFix off
#               9 = JPN Dry mode, coolFix on
# Results    result - 0 = command ok, 1 = error
# Command:   UINT16 DIPC_ALL_MODE_CONFIG_REQ (0x8030)
# Response:  UINT16 DIPC_ALL_MODE_CONFIG_RES (0x8031)
#            UINT8  High temperature range, e.g. 137
#            UINT8  Medium temperature range, e.g. 100
#            UINT8  Low temperature range, e.g. 50
#            UINT8  High flow mode flow rate in deciliter/s, e.g. 135 = 13.5L/s
#            UINT8  Medium flow mode flow rate in decilitres/sec, e.g. 112 = 11.2L/s
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.DIPC_ALL_MODE_CONFIG_REQ(index))
#     device.send(msg)
#     print("return high_temp=%d, medium_temp=%d, low_temp=%d, high_flow=%d, medium_flow=%d" % (msg.results[0].h_temp, msg.results[0].m_temp, msg.results[0].l_temp, msg.results[0].h_flow, msg.results[0].m_flow))
class ALL_MODE_CONFIG_REQ(LecCommand):
    DIPC_ALL_MODE_CONFIG_REQ = 0x8030
    DIPC_ALL_MODE_CONFIG_RES = 0x8031
    name = 'ALL_MODE_CONFIG_REQ'

    def __init__(self, index, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.index = index
        self.h_temp    = None
        self.m_temp    = None
        self.l_temp    = None
        self.flow_rate2 = None
        self.flow_rate1 = None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.DIPC_ALL_MODE_CONFIG_REQ))
        msg.extend(self.uint8(self.index))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.DIPC_ALL_MODE_CONFIG_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.DIPC_ALL_MODE_CONFIG_RES))
        self.h_temp = self.get_uint8(msg, index+2)
        self.m_temp = self.get_uint8(msg, index+3)
        self.l_temp = self.get_uint8(msg, index+4)
        self.flow_rate2 = self.get_uint8(msg, index+5)
        self.flow_rate1 = self.get_uint8(msg, index+6)
        self.flow_rate2 /= 10.0
        self.flow_rate1 /= 10.0
        if self.debug_level > 20:
            print("Parsing %s: high_temp=%d, medium_temp=%d, low_temp=%d, high_flow=%d, medium_flow=%d" % (self.name, self.h_temp, self.m_temp, self.l_temp, self.h_flow, self.m_flow))
        index += 7
        return index
        
        
# Implements the RESET_NON_RECOVERABLE_ERR_CMD/RESET_NON_RECOVERABLE_ERR_RES command/response.
# Arguments  None
# Results    result      0x00 - non-recoverable errors is reset successfully in eeprom
#                        0xfe - failed to reset non-recoverable errors in eeprom
# Command:   UINT16      RESET_NON_RECOVERABLE_ERR_CMD (0x8022)
# Response:  UINT16      RESET_NON_RECOVERABLE_ERR_RES (0x8023)
#            UINT8       result
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.RESET_NON_RECOVERABLE_ERR())
#     device.send(msg)
#     print("result = %d" % msg.results[0].result)
class RESET_NON_RECOVERABLE_ERR(LecCommand):
    RESET_NON_RECOVERABLE_ERR_CMD = 0x8022
    RESET_NON_RECOVERABLE_ERR_RES = 0x8023
    name = 'RESET_NON_RECOVERABLE_ERR'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.RESET_NON_RECOVERABLE_ERR_CMD))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.RESET_NON_RECOVERABLE_ERR_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.RESET_NON_RECOVERABLE_ERR_RES))
        self.result = self.get_uint8(msg, index+2)
        if self.debug_level > 20:
            print("Parsing %s: %d" % (self.name, self.result))
        index += 3
        return index

# Implements the DIPC_SET_TLC_ON_CMD/DIPC_SET_TLC_ON_RES command/response.
# Arguments  None
# Results    result      0x00 - Sucessfully Turned ON the TLC
#                        0xFE - Failed to Turn ON the TLC
# Command:   UINT16      DIPC_SET_TLC_ON_CMD(0x8024)
# Response:  UINT16      DIPC_SET_TLC_ON_RES(0x8025)
#            UINT8       result
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.DIPC_SET_TLC_ON())
#     device.send(msg)
#     print("result = %d" % msg.results[0].result)
class DIPC_SET_TLC_ON(LecCommand):
    DIPC_SET_TLC_ON_CMD = 0x8024
    DIPC_SET_TLC_ON_RES = 0x8025
    name = 'DIPC_SET_TLC_ON_REQ'

    def __init__(self, **kwargs,) :
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.DIPC_SET_TLC_ON_CMD))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.DIPC_SET_TLC_ON_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.DIPC_SET_TLC_ON_RES))
        self.result = self.get_uint8(msg, index+2)
        if self.debug_level > 20:
            print("Parsing %s: %d" % (self.name, self.result))
        index += 3
        return index

# Gets the HEAT_MODE parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_HEAT_MODE())
#     device.send(msg)
#     print("Heat mode = %d" % msg.results[0].heatMode)
class GET_HEAT_MODE(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_HEAT_MODE, name = 'HEAT_MODE', **kwargs)
        self.heatMode = None  # Value is not available until a response is parsed
        self.heatModeName = None
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.heatMode = self.get_uint8(msg, index+6)  # get heat mode
        if self.heatMode == 0:
            self.heatModeName = 'Off'
        elif self.heatMode == 1:
            self.heatModeName = 'Low'
        elif self.heatMode == 2:
            self.heatModeName = 'Medium'
        elif self.heatMode == 3:
            self.heatModeName = 'High'
        return index + 7

# Sets the HEAT_MODE parameter.
# Usage:
#     msg = device.command_messages()
#     modeIndex = 0-off, 1-low, 2-medium, 3-high
#     msg.add(dipc_protocol.SET_HEAT_MODE_PARAMETER(modeIndex))
#     device.send(msg)
#     print("New heat mode = %d" % msg.results[0].heatMode)
class SET_HEAT_MODE_PARAMETER(PARAMETER_CMD):
    def __init__(self, modeIndex, **kwargs):
        PARAMETER_CMD.__init__(self, PARAM_ID_HEAT_MODE, modeIndex.to_bytes(1, byteorder='little', signed=False), name = 'HEAT_MODE', **kwargs)
        self.heatMode = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.heatMode = int.from_bytes(self.data, byteorder='little', signed=False)
        return index

# Gets the FLOW_MODE parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_FLOW_MODE())
#     device.send(msg)
#     print("Flow mode = %d" % msg.results[0].flowMode)
class GET_FLOW_MODE(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_FLOW_MODE, name = 'FLOW_MODE', **kwargs)
        self.flowLevel = None  # Value is not available until a response is parsed
        self.flowLevelName = None
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.flowLevel = self.get_uint8(msg, index+6)  # get flow level
        if self.flowLevel == 0:
            self.flowLevelName = 'Off'
        elif self.flowLevel == 1:
            self.flowLevelName = 'Flow level 1'
        elif self.flowLevel == 2:
            self.flowLevelName = 'Flow level 2'
        return index + 7

# Sets the FLOW_MODE parameter.
# Usage:
#     msg = device.command_messages()
#     LevelIndex = 0 - Off, 1-Flow level 1, 2- Flow level 2
#     msg.add(dipc_protocol.SET_FLOW_MODE_PARAMETER(LevelIndex))
#     device.send(msg)
#     print("New flow mode = %d" % msg.results[0].flowMode)
class SET_FLOW_MODE_PARAMETER(PARAMETER_CMD):
    def __init__(self, LevelIndex, **kwargs):
        PARAMETER_CMD.__init__(self, PARAM_ID_FLOW_MODE, LevelIndex.to_bytes(1, byteorder='little', signed=False), name = 'FLOW_MODE', **kwargs)
        self.flowMode = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.flowMode = int.from_bytes(self.data, byteorder='little', signed=False)
        return index


### SENSITIVE labels on TCG changed to CoolFix; functions and parameters remain as sensitive. ###

# Gets the SENSITIVE parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_SENSITIVE())
#     device.send(msg)
#     print("Sensitive = %d" % msg.results[0].sensitive)
class GET_SENSITIVE(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_SENSITIVE, name = 'SENSITIVE', **kwargs)
        self.sensitive = None  # Value is not available until a response is parsed
        self.sensitive_text = None
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.sensitive = self.get_uint8(msg, index+6)  # get sensitive
        if self.sensitive == 0:
            self.sensitiveText = 'Off'
        elif self.sensitive == 1:
            self.sensitiveText = 'On'
        return index + 7

# Sets the SENSITIVE parameter.
# Usage:
#     msg = device.command_messages()
#     sensitiveValue = 0 - off, 1 - on
#     msg.add(dipc_protocol.SET_SENSITIVE_PARAMETER(sensitiveValue))
#     device.send(msg)
#     print("New sensitive = %d" % msg.results[0].sensitive)
class SET_SENSITIVE_PARAMETER(PARAMETER_CMD):
    def __init__(self, sensitiveValue, **kwargs):
        PARAMETER_CMD.__init__(self, PARAM_ID_SENSITIVE, sensitiveValue.to_bytes(1, byteorder='little', signed=False), name = 'SENSITIVE', **kwargs)
        self.sensitive = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.sensitive = int.from_bytes(self.data, byteorder='little', signed=False)
        return index


# Set the DISABLE_FILTER_CHECK parameter
class SET_DISABLE_FILTER_CHECK(PARAMETER_CMD):

    def __init__(self, set, **kwargs):
        super().__init__(PARAM_ID_DISABLE_FILTER_CHECK, int(set).to_bytes(1, byteorder='little', signed=False), name="DISABLE_FILTER_CHECK", **kwargs)
        self._expected = set
        self.disable_filter_check = None

    def process_response(self, msg, index):
        """
        Parse the returned value out of the response so we can check it was set correctly
        """
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.disable_filter_check = bool(int.from_bytes(self.data, byteorder='little', signed=False))
        if self._expected != self.disable_filter_check:
            raise ValueError("DISABLE FILTER CHECK parameter failed to set")
        return index

# Gets the DISABLE FILTER CHECK parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_DISABLE_FILTER_CHECK())
#     device.send(msg)
#     print("Disable filter check flag = %d" % msg.results[0].disableFilterCheckFlag)
class GET_DISABLE_FILTER_CHECK(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_DISABLE_FILTER_CHECK, name = 'DISABLE FILTER CHECK FLAG', **kwargs)
        self.disableFilterCheckFlag = None  # Value is not available until a response is parsed
        self.disableFilterCheckFlag_text = None
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.disableFilterCheckFlag = self.get_uint8(msg, index+6)  # get flag
        if self.disableFilterCheckFlag == 0:
            self.disableFilterCheckFlag_text = 'filter check enabled'
        elif self.disableFilterCheckFlag == 1:
            self.disableFilterCheckFlag_text = 'filter check disabled'
        return index + 7

# Set the Arm threshold values parameter
class SET_ARM_THRESHOLD_VALUES(CALIBRATE_CMD):
    def __init__(self, thresholds = [], **kwargs):
        cal_data = bytearray(0)
        for i in range(len(thresholds)):
            if i < 3:
                byte_size = BYTE_4
                max_num = int(2**(byte_size * BITS_8 - 1) - 1)
                if thresholds[i] > max_num or thresholds[i] < -max_num:
                    raise Exception("Out of range")
            else:
                byte_size = BYTE_2
                # compared against 12 bit sensor value
                max_num = int(2**(BITS_12 - 1) - 1)
                if thresholds[i] > max_num or thresholds[i] < -max_num:
                    raise Exception("Out of range")
            cal_data = b"".join((cal_data,thresholds[i].to_bytes( byte_size,
                                                                       byteorder='little',
                                                                       signed=True)))
        super().__init__(cal_id=CALIB_ID_IDLE_ARM_THRESHOLDS,
                          cal_data = cal_data,
                          **kwargs)
    def process_response(self, msg, index):
        """
        Parse the returned value out of the response so we can check it was set correctly
        """
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the ARM_POSITION_SENSOR_DATA parameters
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.EOL_GET_HEATER_CURRENT_POWER_DATA())
#     device.send(msg)
#     print("Result = %f V" % msg.results[0].pressure_kPa)
class EOL_GET_ARM_POSITION_SENSOR_DATA(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_EOL_ARM_POSITION_SENSOR_DATA,
                               name = 'GET_EOL_HEATER_POWER_DATA', **kwargs)
        self.SensorX     = None  # Value is not available until a response is parsed
        self.SensorY     = None  # Value is not available until a response is parsed
        self.SensorZ     = None  # Value is not available until a response is parsed
        self.SensorT     = None  # Value is not available until a response is parsed

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.SensorX    = self.get_int16(msg, index+6)
        self.SensorY    = self.get_int16(msg, index+8)
        self.SensorZ    = self.get_int16(msg, index+10)
        self.SensorT    = self.get_int16(msg, index+12)
        return index + 14

# Gets the EOL_GET_FILTER_SENSOR_DATA parameters
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.EOL_GET_FILTER_SENSOR_DATA())
#     device.send(msg)
class EOL_GET_FILTER_SENSOR_DATA(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_EOL_FILTER_SENSOR_DATA,
                               name = 'GET_ID_EOL_FILTER_SENSOR_DATA', **kwargs)
        self.SensorX     = None  # Value is not available until a response is parsed
        self.SensorY     = None  # Value is not available until a response is parsed
        self.SensorZ     = None  # Value is not available until a response is parsed
        self.SensorT     = None  # Value is not available until a response is parsed
        self.present = False

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.SensorX = self.get_int16(msg, index+6)
        self.SensorY = self.get_int16(msg, index+8)
        self.SensorZ = self.get_int16(msg, index+10)
        self.SensorT = self.get_uint16(msg, index+12)
        self.present = bool(self.get_uint8(msg, index+14))
        return index + 15


# get ARM_POSITION_MODE
class GET_ARM_POSITION_MODE(PARAMETER_REQ):
    def __init__(self):
        self._id = PARAM_ID_ARM_POSITION_MODE
        self._len = 1
        super().__init__(self._id, name="GET_ARM_POSITION_MODE")
        self.arm_position_mode = None

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        param_id = self.get_uint16(msg, index+2)
        len = self.get_uint16(msg, index+4)

        if ((cmd_id != self.PARAMETER_RES) or
            (param_id != self._id) or
            (len != self._len)):
            raise ValueError("Invalid response")

        self.arm_position_mode = self.get_uint8(msg, index+6)
        return index + 7


# set the ARM_POSITION_MODE parameter
class SET_ARM_POSITION_MODE(PARAMETER_CMD):
    def __init__(self, mode, **kwargs):
        super().__init__(PARAM_ID_ARM_POSITION_MODE, int(mode).to_bytes(1, byteorder='little', signed=False), name="SET_ARM_POSITION_MODE", **kwargs)
        self._expected = int(mode)
        self.arm_position_mode = None

    def process_response(self, msg, index):
        """
        Parse the returned value out of the response so we can check it was set correctly
        """
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.arm_position_mode = int.from_bytes(self.data, byteorder='little', signed=False)
        if self._expected != self.arm_position_mode:
            raise ValueError("ARM_POSITION_MODE parameter failed to set, expected {} got {}".format(self._expected, self.arm_position_mode))
        return index


# get the GET_AMB_READING_ERROR_MODE parameter
class GET_AMB_READING_ERROR_MODE(PARAMETER_REQ):
    def __init__(self):
        self._id = PARAM_ID_ABM_READING_ERROR
        self._len = 1
        super().__init__(self._id, name="GET_AMB_READING_ERROR_MODE")
        self.pressure_error = None

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        param_id = self.get_uint16(msg, index+2)
        len = self.get_uint16(msg, index+4)

        if ((cmd_id != self.PARAMETER_RES) or
            (param_id != self._id) or
            (len != self._len)):
            raise ValueError("Invalid response")

        self.pressure_error = self.get_uint8(msg, index+6)
        return index + 6


# set the SET_AMB_READING_ERROR_MODE parameter
class SET_AMB_READING_ERROR_MODE(PARAMETER_CMD):
    def __init__(self, mode, **kwargs):
        super().__init__(PARAM_ID_ABM_READING_ERROR, int(mode).to_bytes(1, byteorder='little', signed=False), name="SET_AMB_READING_ERROR_MODE", **kwargs)
        self._expected = int(mode)
        self.pressure_error = None

    def process_response(self, msg, index):
        """
        Parse the returned value out of the response
        """
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.pressure_error = int.from_bytes(self.data, byteorder='little', signed=False)
        return index

# get PARAM_ID_FILTER_MAINTENANCE
class GET_FILTER_MODE(PARAMETER_REQ):
    def __init__(self):
        self._id = PARAM_ID_FILTER_MAINTENANCE
        self._len = 1
        super().__init__(self._id, name="GET_FILTER_MODE")
        # self.filter_mode = None

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        param_id = self.get_uint16(msg, index+2)
        len = self.get_uint16(msg, index+4)

        if ((cmd_id != self.PARAMETER_RES) or
            (param_id != self._id) or
            (len != self._len)):
            raise ValueError("Invalid response")

        self.filter_maintenance_mode = self.get_uint8(msg, index+6)
        if self.filter_maintenance_mode == 0:
            self.filter_mode_name = 'Clean'
        elif self.filter_maintenance_mode == 1:
            self.filter_mode_name = 'Dirty'
        elif self.filter_maintenance_mode == 2:
            self.filter_mode_name = 'Blocked'
        return index + 7

# get PARAM_ID_FILTER_MODE
class GET_FILTER_FORCE_MODE(PARAMETER_REQ):
    def __init__(self):
        self._id = PARAM_ID_FILTER_MODE
        self._len = 1
        super().__init__(self._id, name="GET_FILTER_FORCE_MODE")
        self.filter_mode = None

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        param_id = self.get_uint16(msg, index+2)
        len = self.get_uint16(msg, index+4)

        if ((cmd_id != self.PARAMETER_RES) or
            (param_id != self._id) or
            (len != self._len)):
            raise ValueError("Invalid response")

        self.filter_mode = self.get_uint8(msg, index+6)
        return index + 7

# set the PARAM_ID_FILTER_MODE parameter
class SET_FILTER_FORCE_MODE(PARAMETER_CMD):
    def __init__(self, mode, **kwargs):
        super().__init__(PARAM_ID_FILTER_MODE, int(mode).to_bytes(1, byteorder='little', signed=False), name="SET_FILTER_FORCE_MODE", **kwargs)
        self._expected = int(mode)
        self.filter_mode = None

    def process_response(self, msg, index):
        """
        Parse the returned value out of the response so we can check it was set correctly
        """
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.filter_mode = int.from_bytes(self.data, byteorder='little', signed=False)
        if self._expected != self.filter_mode:
            raise ValueError("FILTER_MODE parameter failed to set, expected {} got {}".format(self._expected, self.filter_mode))
        return index

# Control EOL TEST MODE on the HC
#
#   Purpose: EOL HC control
#
# Implements the EOL_TEST_MODE cmd
# Arguments  UINT8 mode - 0 (off), 1..6 (on & emulate tag), 240 (finalize)
# Results    result - 0 = command ok, 1 = error
# Command:   UINT16 Command ID  - DIPC_EOL_TEST_MODE_CMD (0x8013)
# Response:  None
# Usage:
#     msg = device.command_messages()
#     msg.add(ui_protocol.EOL_TEST_MODE(x))
#     device.send(msg)
class EOL_TEST_MODE(LecCommand):
    DIPC_EOL_TEST_MODE_CMD = 0x8013
    DIPC_EOL_TEST_MODE_RES = 0x8014
    name = 'EOL_TEST_MODE'

    def __init__(self, mode, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.result = None   # Default attribute value before response is None
        self.mode   = mode
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.DIPC_EOL_TEST_MODE_CMD))
        msg.extend(self.uint8(self.mode))        # send control
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.DIPC_EOL_TEST_MODE_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.DIPC_EOL_TEST_MODE_RES))
        return msg


class SELF_DIAG_START_CMD(LecCommand):
    """Class for handling the DIPC_SELF_DIAG_START_CMD and response"""
    DIPC_SELF_DIAG_START_CMD = 0x8400
    DIPC_SELF_DIAG_ACTION_RESULT_RES = 0x8401
    LENGTH_INDEX = 2
    RESULTS_INDEX = 3

    class Results(Enum):
        """Enum to represent the response values"""
        NOT_DONE = 0x02
        DONE = 0x03

        def __str__(self):
            """support for str() function, makes displaying the results simple"""
            return "done" if self == self.DONE else "not done"

    def __init__(self, *args, **kwargs):
        """Initialise the instance"""
        super().__init__(*args, **kwargs)
        self.results = []

    def command_bytes(self):
        """Generate message to send"""
        return self.uint16(self.DIPC_SELF_DIAG_START_CMD)

    def process_response(self, msg, index):
        """
        parse the received message

        Args:
            msg: bytearray of received data
            index: msg index to read from

        Returns:
            msg
        """
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.DIPC_SELF_DIAG_ACTION_RESULT_RES:
            raise ValueError("Unexpected reponse to diag start command,"
                             f" expected {self.DIPC_SELF_DIAG_ACTION_RESULT_RES}"
                             f" got {cmd_id}")

        length = self.get_uint8(msg, index + self.LENGTH_INDEX)
        start = index + self.RESULTS_INDEX
        for index in range(start, start + length):
            self.results.append(self.Results(self.get_uint8(msg, index)))
        return msg

class SELF_DIAG_STOP_CMD(LecCommand):
    """Class for handling the DIPC_SELF_DIAG_STOP_CMD and response"""
    DIPC_SELF_DIAG_STOP_CMD = 0x8402
    DIPC_SELF_DIAG_TEST_ITEMS_RES = 0x8403
    LENGTH_INDEX = 2
    RESULTS_INDEX = 3

    class Results(Enum):
        """Enum to represent the response values"""
        FAIL = 0x00
        PASS = 0x01

        def __str__(self):
            """support for str() function, makes displaying the results simple"""
            return "pass" if self == self.PASS else "fail"

    def __init__(self, *args, **kwargs):
        """Initialise the instance"""
        super().__init__(*args, **kwargs)
        self.results = []

    def command_bytes(self):
        """Generate message to send"""
        return self.uint16(self.DIPC_SELF_DIAG_STOP_CMD)

    def process_response(self, msg, index):
        """
        parse the received message

        Args:
            msg: bytearray of received data
            index: msg index to read from

        Returns:
            msg
        """
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.DIPC_SELF_DIAG_TEST_ITEMS_RES:
            raise ValueError("Unexpected reponse to diag start command,"
                             f" expected {self.DIPC_SELF_DIAG_TEST_ITEMS_RES}"
                             f" got {cmd_id}")

        length = self.get_uint8(msg, index + self.LENGTH_INDEX)
        start = index + self.RESULTS_INDEX
        for index in range(start, start + length):
            self.results.append(self.Results(self.get_uint8(msg, index)))
        return msg

# Gets the HEATER_POWER_DATA parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_HEATER_POWER_DATA())
#     device.send(msg)
#     print("Result = %f V" % msg.results[0].pressure_kPa)
class GET_HEATER_POWER_DATA(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_DEBUG_HEATER_POWER_DATA, name = 'GET_HEATER_POWER_DATA', **kwargs)
        self.opDesired      = None  # Value is not available until a response is parsed
        self.opfDecimal     = None  # Value is not available until a response is parsed
        self.opfNumerator   = None  # Value is not available until a response is parsed
        self.opfDenominator = None  # Value is not available until a response is parsed

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.opDesired      = self.get_uint16(msg, index+6)
        self.opfDecimal     = self.get_uint16(msg, index+8) / 65536
        self.opfNumerator   = self.get_uint16(msg, index+10)
        self.opfDenominator = self.get_uint16(msg, index+12)
        return index + 14


# Gets the HEATER_POWER_DATA parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.EOL_GET_HEATER_CURRENT_POWER_DATA())
#     device.send(msg)
#     print("Result = %f V" % msg.results[0].pressure_kPa)
class EOL_GET_HEATER_CURRENT_POWER_DATA(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_EOL_HEATER_POWER_DATA, name = 'GET_EOL_HEATER_POWER_DATA', **kwargs)
        self.combinedPowerRatio     = None  # Value is not available until a response is parsed
        self.productPower_W         = None  # Value is not available until a response is parsed
        self.productCurrent_A       = None  # Value is not available until a response is parsed
        self.rHeaterAvg_O           = None  # Value is not available until a response is parsed
        self.acMainsVoltageRms_V    = None  # Value is not available until a response is parsed
        self.arm1pow                = None
        self.arm2pow                = None
        self.motorpow               = None
        self.rHeaterAvg_O2          = None
        self.arm1powRatio           = None
        self.arm2powRatio           = None

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.combinedPowerRatio     = self.get_uint32(msg, index+6)  / 65536 # Q16.16-->float
        self.productPower_W         = self.get_uint32(msg, index+10) / 65536
        self.productCurrent_A       = self.get_uint32(msg, index+14) / 65536
        self.rHeaterAvg_O           = self.get_uint32(msg, index+18) / 65536
        self.acMainsVoltageRms_V    = self.get_uint32(msg, index+22) / 65536
        self.arm1pow                = self.get_uint32(msg, index+26) / 65536
        self.arm2pow                = self.get_uint32(msg, index+30) / 65536
        self.motorpow               = self.get_uint32(msg, index+34) / 65536
        self.rHeaterAvg_O2          = self.get_uint32(msg, index+38) / 65536
        self.arm1powRatio           = self.get_uint32(msg, index+42) / 65536
        self.arm2powRatio           = self.get_uint32(msg, index+46) / 65536
        return index + 50

# Gets the ACCELERATION_DATA parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_ACCELERATION_DATA())
#     device.send(msg)
#     print("Result = %f V" % msg.results[0].x)
class GET_ACCELERATION_DATA(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_ACCELERATION_PARAM_ID, name = 'GET_ACCELERATION_DATA', **kwargs)
        self.x     = None  # Value is not available until a response is parsed
        self.y     = None  # Value is not available until a response is parsed
        self.z     = None  # Value is not available until a response is parsed

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.x     = self.get_int16(msg, index+6)
        self.y     = self.get_int16(msg, index+8)
        self.z     = self.get_int16(msg, index+10)
        return index + 12

# Gets the ACCELERATION_INT_STATE parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_ACCELERATION_INT_STATE())
#     device.send(msg)
#     print("Result = %f V" % msg.results[0].x)
class GET_ACCELERATION_INT_STATE(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_ACCELERATION_INT_STATE_PARAM_ID, name = 'GET_ACCELERATION_INT_STATE', **kwargs)
        self.x     = None  # Value is not available until a response is parsed
        self.y     = None  # Value is not available until a response is parsed
        self.z     = None  # Value is not available until a response is parsed

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.x     = self.get_int16(msg, index+6)
        self.y     = self.get_int16(msg, index+8)
        self.z     = self.get_int16(msg, index+10)
        self.int1  = self.get_int16(msg, index+12)
        self.int2  = self.get_int16(msg, index+14)
        self.apState = self.get_uint8(msg, index+16)        # ap internal state
        self.wakeupMode = self.get_uint8(msg, index+17)    # wakeup mode
        self.threshold = self.get_uint8(msg, index+18)    # wakeup mode
        self.pinStatus = self.get_uint8(msg, index+19)      # pinStatusApState
        self.timerElapsed = self.get_uint8(msg, index+20)
        return index + 21

# Gets the MAGNETOMETER_DATA parameter.                     # added at KXQ-134
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_MAGNETOMETER_DATA())
#     device.send(msg)
#     print("Result = %f V" % msg.results[0].x)
class GET_MAGNETOMETER_DATA(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_MAGNETOMETER_PARAM_ID, name = 'GET_MAGNETOMETER_DATA', **kwargs)
        self.x     = None  # Value is not available until a response is parsed
        self.y     = None  # Value is not available until a response is parsed
        self.z     = None  # Value is not available until a response is parsed

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.x     = self.get_int16(msg, index+6)
        self.y     = self.get_int16(msg, index+8)
        self.z     = self.get_int16(msg, index+10)
        return index + 12



# Gets the HEATER_STATUS.
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_HEATER_STATUS())
#     device.send(msg)
#     print("Result = %f V" % msg.results[0].pressure_kPa)
class GET_HEATER_STATUS(LecCommand):
    DIPC_GET_HEATER_REQ = 0x800B
    DIPC_GET_HEATER_RES = 0x800C
    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.heat   = None  # Value is not available until a response is parsed
        self.eboxFlowMode   = None  # Value is not available until a response is parsed
        self.eboxFlowModeName = None  # Value is not available until a response is parsed
        self.type   = None  # Value is not available until a response is parsed
        self.temp   = None  # Value is not available until a response is parsed
        self.offset = None  # Value is not available until a response is parsed
        self.error  = None  # Value is not available until a response is parsed
        self.state  = None  # Value is not available until a response is parsed
        self.flowRate = None  # Value is not available until a response is parsed

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.DIPC_GET_HEATER_REQ))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.DIPC_GET_HEATER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.eboxFlowMode   = self.get_uint8(msg, index+2)
        self.heat   = self.get_uint8(msg, index+3)
        self.type   = self.get_uint16(msg, index+4)
        self.temp   = self.get_uint8(msg, index+6)
        self.offset = self.get_uint8(msg, index+7)
        lo          = self.get_uint32(msg, index+8)
        hi          = self.get_uint32(msg, index+12)
        self.error  = lo | (hi<<32)
        self.flowRate = self.get_uint8(msg, index+16)
        self.state = self.get_uint8(msg, index+17)
        self.flowRate /= 10.0
        if self.eboxFlowMode == 0:
            self.eboxFlowModeName = 'Off'
        elif self.eboxFlowMode == 1:
            self.eboxFlowModeName = 'Low'
        elif self.eboxFlowMode == 2:
            self.eboxFlowModeName = 'Medium'
        elif self.eboxFlowMode == 3:
            self.eboxFlowModeName = 'High'
        return index + 18

# Calls the function of the given name
# Arguments  fn_name - Name of function to call
#            params  - array of up to 4 UINT32 (default [])
# Results    result - Returned value from function - if applicable
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.CALL('AddOne', [7]))
#     device.send(msg)
#     print("result=%d" % msg.results[0].result)
class CALL(LecCommand):
    def __init__(self, fn_name, params=[], **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.fn_name   = fn_name
        self.params    = params
        self.result    = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.fn_name, list(self.kwargs.keys())))

    def command_bytes(self):
        self.addr = self.protocol.get_function_addr(self.fn_name)
        if self.debug_level > 20:
            print("Adding CALL %s " % self.fn_name, end='')
            print(self.params)
        self.call  = EXECUTE_FUNCTION_CMD(self.addr, self.params)
        if self.debug_level > 20:
            print('CALL %s ' % self.fn_name, self.params)
        return self.call.command_bytes()

    def process_response(self, msg, index):
        index = self.call.process_response(msg, index)
        self.result = self.call.result
        if self.debug_level > 20:
            print('CALL %s ' % self.fn_name, self.params, ' Result = %d 0x%08x' % (self.result, self.result))
        return index

# Gets the variable value of the given name
# Arguments  var_name - Name of function to call
#            struct   - Optional: Type name of structure the variable is a part of (default None)
#            addr     - Optional: Actual address of start of structure
#            signed   - Optional: True if the value is signed (default False)
# Results    value    - Variable value
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.GET_VAR('appDebug0'))
#     msg.add(sc_protocol.GET_VAR('appDebug1', signed=True))
#     msg.add(sc_protocol.GET_VAR('g_fsh_systemConstants.uart_baud', struct='tFshApplicationData'))
#     msg.add(sc_protocol.GET_VAR('?.uart_baud', struct='tFshApplicationData', addr=0x20000432))
#     device.send(msg)
#     print("result=%d" % msg.results[0].value)
#     print("result=%d" % msg.results[1].value)
#     print("result=%d" % msg.results[2].value)
#     print("result=%d" % msg.results[3].value)
class GET_VAR(LecCommand):
    def __init__(self, var_name, struct=None, addr=None, signed=False, floatvar=False, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.var_name  = var_name
        self.struct    = struct
        self.addr      = addr
        self.signed    = signed
        self.value     = None   # Default attribute value before response is None
        self.floatvar  = floatvar
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        self.var_addr, self.var_size = self.protocol.get_variable_addr(self.var_name, self.struct, self.addr)
        if self.addr != None and self.var_name[0:2] != '?.':
            self.var_addr = self.addr
        if self.debug_level > 20:
            print("Adding GET_VAR %s " % self.var_name, " struct=", self.struct, " addr=", self.addr)
        self.peek = MEMORY_CONTENT_REQ(self.var_addr)
        return self.peek.command_bytes()

    def process_response(self, msg, index):
        index = self.peek.process_response(msg, index)
        self.value = self.peek.value
        if self.var_size == 1: self.value &= 0xff
        if self.var_size == 2: self.value &= 0xffff
        if self.var_size == 4: self.value &= 0xffffffff
        self.value = int.from_bytes(self.value.to_bytes(self.var_size, byteorder='little'), byteorder='little', signed=self.signed)
        if self.floatvar == True:
            self.value, = struct.unpack('f', self.peek.value.to_bytes(4, byteorder='little'))
            if self.debug_level > 20:
                print('GET_VAR %s = %f' % (self.var_name, self.value))
        elif self.debug_level > 20:
            print('GET_VAR %s = %d' % (self.var_name, self.value))
        return index


# Sets the variable value of the given name
# Arguments  var_name - Name of function to call
#            struct   - Optional: Type name of structure the variable is a part of (default None)
#            addr     - Optional: Actual address of start of structure
#            signed   - Optional: True if the value is signed (default False)
#            value    - Variable value (must be an integer)
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.SET_VAR('appDebug0', 5))
#     msg.add(sc_protocol.SET_VAR('appDebug1', -5, signed=True))
#     msg.add(sc_protocol.SET_VAR('g_fsh_systemConstants.uart_baud', 66, struct='tFshApplicationData'))
#     msg.add(sc_protocol.SET_VAR('?.uart_baud', 22, struct='tFshApplicationData', addr=0x20000432))
#     device.send(msg)
class SET_VAR(LecCommand):
    def __init__(self, var_name, value, struct=None, addr=None, mask=None, signed=False, floatvar=False, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.var_name  = var_name
        self.value     = value
        self.struct    = struct
        self.addr      = addr
        self.signed    = signed
        self.mask      = mask
        self.floatvar  = floatvar
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        self.var_addr, self.var_size = self.protocol.get_variable_addr(self.var_name, self.struct, self.addr)
        if self.addr != None:
            self.var_addr = self.addr
        if self.mask != None:     mask = self.mask
        elif self.var_size == 1:  mask = 0xff
        elif self.var_size == 2:  mask = 0xffff
        elif self.var_size == 3:  mask = 0xffffff
        elif self.var_size == 4:  mask = 0xffffffff
        elif self.floatvar:       mask = 0xffffffff
        else:                     mask = 0
        if self.debug_level > 20:
            print("Adding SET_VAR %s " % self.var_name, " struct=", self.struct, " addr=", self.var_addr, " value=", self.value, " mask=", mask)
        if self.floatvar == True:
            self.value = int.from_bytes(struct.pack('f', self.value), byteorder='little')
        self.peek = MEMORY_CONTENT_CMD(self.var_addr, self.value, mask)
        return self.peek.command_bytes()

    def process_response(self, msg, index):
        index = self.peek.process_response(msg, index)
        return index


# Converts ticks per revolution into krpm
def TPR_TO_KRPM(tpr):
    if tpr == 0: return 0
    tpr = tpr * 1.0  # Convert to float
    us_per_rev = tpr / TICKS_PER_US
    s_per_rev  = us_per_rev / 1000000.0
    rev_per_s  = 1.0 / s_per_rev
    rev_per_min= rev_per_s * 60.0
    krpm       = rev_per_min / 1000.0
    return krpm

def device_enum_value_to_name(device, state_type, minor_error_code):
    if device == None:
        return '%d' % minor_error_code
    return device.enum_value_to_name(state_type, minor_error_code)


#
# Get the error format details from the error data JSON file. Return object is a
# dict of the form
#      data['data'] : Error data gathered from source header files.
#      data['meta'] : Meta data about the gathered data.
#
error_data = None  # Cache the results to prevent multiple parsing of error format data file.
def get_error_format_data(hash):
    global error_data, meta_error_data
    # Check that the hash matches the current error data
    if error_data == None or error_data['meta']['hash'] != hash:
        error_data_file = os.path.abspath(os.environ['PROJECT_DIR'] + '/support_scripts/error_data.json')
        error_data = None
        try:
            f = open(error_data_file)
            json_data = json.load(f)
            f.close()
            data, meta_data = json_data['%d' % hash]
            error_data = dict()
            error_data['data'] = data
            error_data['meta'] = meta_data
            error_data['file'] = error_data_file
        except:
            raise Exception("The device hash 0x%08x can not be found in %s" % (hash, error_data_file))
    return error_data



# Convert extended error information into a human readable form.
# Arguments  data     - Byte array of data from EXTENDED_ERROR_REQ
#            detail   - Detail of message
#                          'terse'  Shortest message   e.g.  '3012'
#                          'basic'  Short message      e.g.  'UNDER_VOLTAGE'
#                          'normal' Normal message     e.g.  'System voltage too low.  (UNDER_VOLTAGE)'
#                          'full'   Multi-line message e.g.  'System voltage too low.  (UNDER_VOLTAGE)\n
#                                                            Running: voltage = 19238 mV'
#                          'extended' Multi-line message e.g.  'System voltage too low.  (UNDER_VOLTAGE)\n
#                                                               System voltage low.\n
#                                                               The system voltage is too low to start the motor.\n
#                                                               Running: voltage = 19238 mV'
# Note: If the supplied array is empty (i.e. no error), the responses are
#    terse:           '0'
#    basic:           'NO_ERROR'
#    normal message:  'No Error (NO_ERROR)'
#    full:            'No Error (NO_ERROR)'
# Returns    error message string
# Usage:
#     msg = device.command_messages()
#     msg.add(EXTENDED_ERROR_REQ())
#     device.send(msg)
#     data = msg.results[0].data[4:]
#     hash = int.from_bytes(msg.results[0].data[:4], byteorder='little', signed=False)
#     print("data = '%s'" % extended_error_str(data, hash, detail='basic'))
#
def extended_error_str(data, hash, detail='basic'):
    # If only the error data hash value was given, then there is no error.
    # Add the 'no error' error code so the function behaves correctly.
    if len(data) == 0:
        data = [0, 0]

    # Get the error format data
    error_format_data = get_error_format_data(hash)
    return extended_error_str_for_error_log_item(data, error_format_data, detail)


def extended_error_str_for_error_log_item(data, error_format_data, detail='basic'):
    meta_error_data = error_format_data['meta']
    error_data      = error_format_data['data']

    error_id = int.from_bytes(data[0:2], byteorder='little', signed=False)

    # Search the array to find the error ID
    index = None
    for i in range(len(error_data)):
        if error_data[i]['error_id'] == error_id:
            index = i
    if index == None:
        return 'Details of error %d not found in %s' % (error_id, error_format_data['file'])
    err_data = error_data[index]

    if detail == 'terse':
        return '%d' % error_id
    if detail == 'basic':
        return '%s' % err_data['name']
    if detail == 'normal':
        return '%s (%d)' % (err_data['name'], error_id)

    # Must be 'full' or 'extended'
    pos = 2
    error_str  = '%s (%d)\n' % (err_data['name'], error_id)
    if detail == 'extended':
        error_str += '%s\n' % err_data['long_name']
        error_str += '%s\n' % err_data['description']
    for src, data_type, err_str in err_data['log_params']:
        if data_type == 'I8':
            value = int.from_bytes(data[pos:pos+1], byteorder='little', signed=True)
            pos += 1
        elif data_type == 'U8':
            value = int.from_bytes(data[pos:pos+1], byteorder='little', signed=False)
            pos += 1
        elif data_type == 'I16':
            value = int.from_bytes(data[pos:pos+2], byteorder='little', signed=True)
            pos += 2
        elif data_type == 'U16':
            value = int.from_bytes(data[pos:pos+2], byteorder='little', signed=False)
            pos += 2
        elif data_type == 'I32':
            value = int.from_bytes(data[pos:pos+4], byteorder='little', signed=True)
            pos += 4
        elif data_type == 'U32':
            value = int.from_bytes(data[pos:pos+4], byteorder='little', signed=False)
            pos += 4
        elif data_type == 'FLOAT':
            value = int.from_bytes(data[pos:pos+4], byteorder='little', signed=False)
            value = struct.unpack('f', value)
            pos += 4
        elif data_type == 'SZ':
            old_pos = pos
            while data[pos] != 0:
                pos += 1
            value = data[old_pos:pos].decode("utf-8")
            pos += 1 # Skip over the null terminating byte
        else:
            value = None
        try:
            error_str += err_str % value
        except:
            error_str += 'Value=%r' % value
            error_str += '  DataType=%r' % data_type
            error_str += '  Str=%s' % err_str
        error_str += '\n'

    return error_str

# Given the raw bytearray, produce a dict with all of the error data in easily accessible form.
#
#   results['data']                   - Original byte array
#   results['hash']                   - integer   (hash value for the current data format)
#   results['write_count']            - Number of times the page has been written
#   results['error_log'] = array of dict()
#   results['error_log'][x]['terse']  - Terse string describing the log item
#   results['error_log'][x]['basic']  - Basic string describing the log item
#   results['error_log'][x]['normal'] - Normal string describing the log item
#   results['error_log'][x]['full']   - Full string describing the log item
#   results['error_log'][x]['data']   - Byte array of log element (excluding size byte)
#   results['flags']                  - Flags value
#   results['flags_str']              - String describing flags value
#   results['1_bit']                  - Array of 1 bit counter values (dicts)
#   results['1_bit'][x]['value']      - Count value
#   results['1_bit'][x]['names']      - List of error names associated with error.
#   results['8_bit']                  - Array of 1 bit counter values (dicts)
#   results['8_bit'][x]['value']      - Count value
#   results['8_bit'][x]['names']      - List of error names associated with error.
#   results['16_bit']                 - Array of 1 bit counter values (dicts)
#   results['16_bit'][x]['value']     - Count value
#   results['16_bit'][x]['names']     - List of error names associated with error.
#   results['32_bit']                 - Array of 1 bit counter values (dicts)
#   results['32_bit'][x]['value']     - Count value
#   results['32_bit'][x]['names']     - List of error names associated with error.
def interpret_raw_error_data(data):
    results = dict()
    # Extract the hash from the raw data - as a string
    hash = int.from_bytes(data[8:12], byteorder='little', signed=False)
    # Get the format data from the store of known data formats using the hash
    format_data = get_error_format_data(hash)
    results['hash'] = hash
    results['data'] = data
    results['write_count'] = int.from_bytes(data[4:7], byteorder='little', signed=False)

    # Interpret flags
    results['flags'] = data[7]
    results['flags_str'] = ''
    if results['flags'] & 1:
        results['flags_str'] += 'Invalid structure hash, '
    else:
        results['flags_str'] += 'Valid structure hash, '
    if results['flags'] & 2:
        results['flags_str'] += 'Invalid page 1 CRC, '
    else:
        results['flags_str'] += 'Valid page 1 CRC, '
    if results['flags'] & 4:
        results['flags_str'] += 'Invalid page 2 CRC, '
    else:
        results['flags_str'] += 'Valid page 2 CRC, '
    if (results['flags'] & 6) != 0:
        pass # Both pages are invalid, so the next flag is not used.
    elif results['flags'] & 8:
        results['flags_str'] += 'Data from error page 2, '
    else:
        results['flags_str'] += 'Data from error page 1, '


    # Interpret the error log data
    error_log = []
    pos = format_data['meta']['ERRD_LOG_POS']
    end = pos + format_data['meta']['ERRD_LOG_SIZE']
    while pos != None:
        next = pos + data[pos]   # Where is the position of the next item?
        if next >= end:          # Is the current data log item incomplete i.e. is the end of the record missing?
            pos = None
        elif pos == next:        # Are there no more items in the buffer?
            pos = None
        else:
            log_item = data[pos+1:pos + data[pos]]
            error_log_item = dict()
            error_log_item['terse']  = extended_error_str(log_item, hash, detail='terse')
            error_log_item['basic']  = extended_error_str(log_item, hash, detail='basic')
            error_log_item['normal'] = extended_error_str(log_item, hash, detail='normal')
            error_log_item['full']   = extended_error_str(log_item, hash, detail='full')
            error_log_item['data']   = log_item
            error_log.append(error_log_item)
            pos = next
    results['error_log'] = error_log


    # Interpret the 1 bit error counter
    counters = []
    for i in range(format_data['meta']['ERRD_COUNTER_SIZE_1_BIT'] * 8):
        counter = dict()
        pos = format_data['meta']['ERRD_COUNTER_POS_1_BIT'] + i
        bit = i & 7
        counter['value'] = (data[pos] >> bit) & 1
        names = ''
        for err in format_data['data']:
            if (err['bin_id_name'] == '1_BIT') and (err['bin_id_element']) == i:
                names += ' ' + err['name'] +  ' '
        counter['names'] = names
        counters.append(counter)
    results['1_bit'] = counters

    # Interpret the 8 bit error counter
    counters = []
    for i in range(format_data['meta']['ERRD_COUNTER_SIZE_8_BIT']):
        counter = dict()
        pos = format_data['meta']['ERRD_COUNTER_POS_8_BIT'] + i
        counter['value'] = data[pos]
        names = ''
        for err in format_data['data']:
            if (err['bin_id_name'] == '8_BIT') and (err['bin_id_element'] == i):
                names += ' ' + err['name'] +  ' '
        counter['names'] = names
        counters.append(counter)
    results['8_bit'] = counters

    # Interpret the 16 bit error counter
    counters = []
    for i in range(format_data['meta']['ERRD_COUNTER_SIZE_16_BIT']):
        counter = dict()
        pos = format_data['meta']['ERRD_COUNTER_POS_16_BIT'] + (i*2)
        counter['value'] = int.from_bytes(data[pos:pos+2], byteorder='little', signed=False)
        names = ''
        for err in format_data['data']:
            if (err['bin_id_name'] == '16_BIT') and (err['bin_id_element'] == i):
                names += ' ' + err['name'] +  ' '
        counter['names'] = names
        counters.append(counter)
    results['16_bit'] = counters

    # Interpret the 24 bit error counter
    counters = []
    for i in range(format_data['meta']['ERRD_COUNTER_SIZE_24_BIT'] // 3):
        counter = dict()
        pos = format_data['meta']['ERRD_COUNTER_POS_24_BIT'] + (i*3)
        counter['value'] = int.from_bytes(data[pos:pos+3], byteorder='little', signed=False)
        names = ''
        for err in format_data['data']:
            if (err['bin_id_name'] == '24_BIT') and (err['bin_id_element'] == i):
                names += ' ' + err['name'] +  ' '
        counter['names'] = names
        counters.append(counter)
    results['24_bit'] = counters
    return results

# Implements the DEV_RESET_CMD/RESET_EVT command/response.
#
# Note: This command should not be sent with other commands in a message. It causes an immediate reset.
# The bootloader is not invoked, the application is started immediately.
#
# Arguments  None
# Command:   UINT16 DEV_RESET_CMD (0x8037)
# Response:  UINT16 RESET_EVT (0x2000) + reset event data
#
# Usage:
#     msg = device.command_messages()
#     msg.add(sc_protocol.DEV_RESET_CMD())
#     device.send(msg)
class DEV_RESET_CMD(LecCommand):
    RESET_CMD = 0x8038
    RESET_EVT = 0x2000
    name = 'DEV_RESET_CMD'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.RESET_CMD))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.RESET_EVT:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.RESET_EVT))
        if self.debug_level > 20:
            print("Reset event")
        index += 2
        return index

# Implements the BOOTLOADER_VERSION_REQ/BOOTLOADER_VERSION_RES command/response.
# Arguments  None
# Results    version - uint32 of software version
# Command:   UINT16 BOOTLOADER_VERSION_REQ (0x8100)
# Response:  UINT16 BOOTLOADER_VERSION_RES (0x8101)
#            UINT32 VERSION   - Version number of software
# Usage:
#     msg = device.command_messages()
#     msg.add(dipc_protocol.BOOTLOADER_VERSION_REQ())
#     device.send(msg)
#     print("version=%d" % msg.results[0].version)
class BOOTLOADER_VERSION_REQ(LecCommand):
    BOOTLOADER_VERSION_REQ = 0x8100
    BOOTLOADER_VERSION_RES = 0x8101
    name = 'BOOTLOADER_VERSION_REQ'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.version   = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.BOOTLOADER_VERSION_REQ))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.BOOTLOADER_VERSION_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.BOOTLOADER_VERSION_RES))
        self.version   = self.get_uint32(msg, index+2)
        if self.debug_level > 20:
            print("Parsing %s: version=%d (0x%08x)" % (self.name, self.version, self.version))
        index += 6
        return index
