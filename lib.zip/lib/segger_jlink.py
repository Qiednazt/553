#-------------------------------------------------------------------------------
# Name:        Segger JLink
# Purpose:     Provide a class for a data link to the V10 debug device
#
# Author:      Mike Morgan
#
# Created:     29/01/2015
# Copyright:   (c) Dyson 2015
#-------------------------------------------------------------------------------

import glob
import os
import project_intelhex as IntelHex
import sys
import subprocess
import time

# Minimum version of SEGGER JLink for the script - JFlash file is backwards compatible,
# as per https://wiki.segger.com/UM08003_JFlash#Version_compatibility
# this value should not be lower than what is used as the JFlash file
min_version = "v510b"
data_file = os.environ.get('TEMP_DIR') + '/SAMD20.jflash'
SAMD20_JFLASH_FILE="""
  AppVersion = 51021
[GENERAL]
  ConnectMode = 0
  CurrentFile = ""
  DataFileSAddr = 0x00000000
  GUIMode = 0
  HostName = ""
  TargetIF = 1
  USBPort = 0
  USBSerialNo = 0x00000000
[JTAG]
  IRLen = 0
  MultipleTargets = 0
  NumDevices = 0
  Speed0 = 4000
  Speed1 = 4000
  TAP_Number = 0
  UseAdaptive0 = 0
  UseAdaptive1 = 0
  UseMaxSpeed0 = 0
  UseMaxSpeed1 = 0
[CPU]
  CheckCoreID = 1
  ChipName = "Atmel ATSAMD20G18"
  ClockSpeed = 0x00000000
  Core = 0x060000FF
  CoreID = 0x0BC11477
  CoreIDMask = 0x0F000FFF
  DeviceFamily = 0x00000006
  EndianMode = 0
  HasInternalFlash = 1
  InitStep0_Action = "Reset"
  InitStep0_Comment = "Reset and halt target"
  InitStep0_Value0 = 0x00000000
  InitStep0_Value1 = 0x00000000
  NumExitSteps = 0
  NumInitSteps = 1
  RAMAddr = 0x20000000
  RAMSize = 0x00008000
  ScriptFile = ""
  UseAutoSpeed = 0x00000001
  UseRAM = 1
  UseScriptFile = 0
[FLASH]
  aSectorSel[1025] = 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0
  AutoDetect = 0
  BankName = ""
  BankSelMode = 0
  BaseAddr = 0x00000000
  CheckId = 0
  CustomRAMCode = ""
  DeviceName = "ATSAMD20x18 internal"
  EndBank = 1023
  NumBanks = 1
  OrgNumBits = 32
  OrgNumChips = 1
  StartBank = 0
  UseCustomRAMCode = 0
[PRODUCTION]
  AutoPerformsErase = 1
  AutoPerformsHardLock = 0
  AutoPerformsHardUnlock = 0
  AutoPerformsProgram = 1
  AutoPerformsSecure = 0
  AutoPerformsSoftLock = 0
  AutoPerformsSoftUnlock = 1
  AutoPerformsStartApp = 0
  AutoPerformsUnsecure = 0
  AutoPerformsVerify = 1
  EnableProductionMode = 0
  EnableTargetPower = 1
  EraseType = 1
  MonitorVTref = 0
  MonitorVTrefMax = 0x0000157C
  MonitorVTrefMin = 0x000003E8
  OverrideTimeouts = 0
  ProductionDelay = 0x000001F4
  ProductionThreshold = 0x00000BB8
  ProgramSN = 0
  SerialFile = ""
  SNAddr = 0x00000000
  SNInc = 0x00000001
  SNLen = 0x00000008
  SNListFile = ""
  SNValue = 0x00000001
  StartAppType = 0
  TargetPowerDelay = 0x00000014
  TimeoutErase = 0x00003A98
  TimeoutProgram = 0x00002710
  VerifyType = 1
"""

#
# Determine the path to the jflash.exe program.
# Check if the SEGGER JLink application is installed
#
def test_for_app():
    global jlink_program

    exe_candidates = glob.glob("C:/Program Files*/SEGGER/JLink_*/JFlash.exe")

    for exe in exe_candidates:
      if not (os.path.isfile(exe)):
        continue # Not an executable, skip

      # Getting JLink_* of the path
      version = os.path.basename(os.path.dirname(exe))
      version = version[6:].lower() # Retrieving version number

      # This assumes that the version is sorted in lexicographic order
      if version < min_version:
        continue # Version is not supported

      jlink_program = '"' + exe + '"' # To account for the spaces in path

      # Write the data file
      f = open(data_file, 'w')
      f.write(SAMD20_JFLASH_FILE)
      f.close()
      return

    raise Exception("\n\nERROR: A supported version of SEGGER JLink application is not installed.\n"\
      "Install SEGGER JLink from Software Center or;\n"\
      "(If you have admin rights) Look for Segger.7z in\n"\
      "\\\\uk-mal-iar-01\\swdev\\Motors_tools\\Segger\n")

# Connect to the device, read the device ID words and return as a string.
# Throw an exception if the JFlash application is not installed.
def read_id():
    test_for_app()
    id = 'unknown'
    err = 1
    try:
        try:
            os.remove('id.hex')
        except:
            pass
        err = subprocess.call(jlink_program + ' -open"' + data_file + '" -readrange0080A00C,0080A00F -readrange0080A040,0080A04b -saveasid.hex -exit', shell=True)
        if err == 0:
            hex = IntelHex('id.hex')
            id = ''
            for i in range(hex.minaddr(), hex.maxaddr()+1, 4):
                id += '%02x' % hex[i+3]
                id += '%02x' % hex[i+2]
                id += '%02x' % hex[i+1]
                id += '%02x' % hex[i+0]
            err = 0
        try:
            os.remove('id.hex')
        except:
            pass
    except:
       pass
    if err == 1:
        id = None
    return id

# Connect to the device, read the KV10 flash and return as an IntelHex object or None if flash could not be read.
# Throw an exception if the JFlash application is not installed.
def read_flash():
    test_for_app()
    hex = None
    err = 1
    try:
        try:
            os.remove('id.hex')
        except:
            pass
        err = subprocess.call('start /min ' + jlink_program + ' -open"' + data_file + '" -readrange00000000,0001ffff -saveasid.hex -exit', shell=True)
        if err == 0:
            hex = IntelHex('id.hex')
        try:
            os.remove('id.hex')
        except:
            pass
    except:
       pass
    return hex

def peek_word(flash_data, addr):
    if addr > flash_data.maxaddr():
        return 0
    return flash_data[addr+0] + (flash_data[addr+1] << 8) + (flash_data[addr+2] << 16) + (flash_data[addr+3] << 24)

# err = 0 - No error
# err = 1 - Download failed
def download_app_from_file(filename):
    # The file may have attached JSON data, so create a pure hex file
    out_filename = os.environ['TEMP_DIR'] + '/segger.hex'
    out = open(out_filename, 'w')
    for line in open(filename):
        if len(line) > 0 and line[0] == ':':
            out.write(line)
    out.close()

    test_for_app()

    cmd = '{program} -openprj"{jflash_file}" -open"{datafile}" -erasesectors -programverify -startapp -exit'.format(
      program=jlink_program, jflash_file=data_file, datafile=out_filename)
    print("Running the following command:\n" + cmd)
    err = subprocess.call(cmd, shell=True)

    return err
