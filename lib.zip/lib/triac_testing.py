#-------------------------------------------------------------------------------
# Name:        Triac test
# Purpose:     This module allows control of the triacs in test mode
#              (see also openLoopPower.cmd).
#
# Authors:     Brian Weeks
#
# Created:     15/07/2019
# Copyright:   (c) Dyson Technology Ltd. 2019
#-------------------------------------------------------------------------------

import gui                      # Dyson Simple User Interface library
import sc_protocol as protocol  # Dyson N553 SC comms interface

# Import eeprom flag definitions.
# This import is meant to depend on the project number as returned by target via DIPC.
import sc_eeprom as eeprom      # Dyson N553 EEPROM flag definitions

APP_TITLE = "TRIACs testing GUI"
APP_HELP  = "This script allows the user to test TRIACs up to 6 sequencer.\n"

# Full stickiness for Tk controls
STICKY_NSEW = gui.N + gui.S + gui.E + gui.W

class this_app(gui.app):
    #
    # Define the controls
    #
    def __init__(self, *args, **kwargs):
        # Process arguments speficic to this application
        if 'device' in kwargs:
            self.device = kwargs['device']
            del kwargs['device']
            self.close_funcs.append(self.device.closing) # Give the application a function which will abort the connection
        else:
            gui.error("'device' is a required named parameter for this app.")
            
        if 'parent_data' in kwargs:            
            self.parent_data = kwargs['parent_data']
            print("Parent data received")
            del kwargs['parent_data']               

        # Initialise the base class
        gui.app.__init__(self, *args, **kwargs)

        # Read autostart value and behaviour flags from target

        self.NUMBER_ENTRY_WIDTH = 8
        self.NUMBER_OUTPUT_WIDTH = 12
        self.MAX_SEQUENCE_NO = 8;

        self.sequence_number = 1;
        
        self.add_text(text='TRIACs angle: 0-burst')
        self.newline()
        self.add_text(text='TRIACs angle: 1-179')
        self.newline()
        self.add_text(text='TRIACs angle: 256-off')
        self.newline()
        self.text_string_temp = "Sequence no (1-"
        self.text_string_temp += str(self.MAX_SEQUENCE_NO)
        self.text_string_temp += "):"
        self.add_text(self.text_string_temp)
        self.triac_sequence_no_entry = self.add_input(text=self.sequence_number, tooltip='Enter sequence number here')
        self.triac_sequence_no_entry.config(width = self.NUMBER_ENTRY_WIDTH)
        self.newline()
        self.add_text(text='Sequence')
        self.add_text(text='TRIAC1')
        self.add_text(text='TRIAC2')
        self.add_text(text='TRIAC3')
        self.add_text(text='TRIAC4')        
        self.newline()

        self.triac1_angle = []
        self.triac2_angle = []
        self.triac3_angle = []
        self.triac4_angle = []
        self.triac1_angle_entry = []
        self.triac2_angle_entry = []
        self.triac3_angle_entry = []
        self.triac4_angle_entry = []        
        
        for i in range(0,self.MAX_SEQUENCE_NO):
            self.triac1_angle.append(170)
            self.triac2_angle.append(170)
            self.triac3_angle.append(170)
            self.triac4_angle.append(170)            
            self.triac1_angle_entry.append(170)
            self.triac2_angle_entry.append(170)
            self.triac3_angle_entry.append(170)
            self.triac4_angle_entry.append(170)            
            self.text_string_temp = 'Sequence '
            self.text_string_temp += str(i+1);
            self.add_text(self.text_string_temp)
            self.triac1_angle_entry[i] = self.add_input(text=self.triac1_angle[i], tooltip='Enter TRIAC on angle here')
            self.triac1_angle_entry[i].config(width = self.NUMBER_ENTRY_WIDTH)
            self.triac2_angle_entry[i] = self.add_input(text=self.triac2_angle[i], tooltip='Enter TRIAC on angle here')
            self.triac2_angle_entry[i].config(width = self.NUMBER_ENTRY_WIDTH)
            self.triac3_angle_entry[i] = self.add_input(text=self.triac3_angle[i], tooltip='Enter TRIAC on angle here')
            self.triac3_angle_entry[i].config(width = self.NUMBER_ENTRY_WIDTH)
            self.triac4_angle_entry[i] = self.add_input(text=self.triac4_angle[i], tooltip='Enter TRIAC on angle here')
            self.triac4_angle_entry[i].config(width = self.NUMBER_ENTRY_WIDTH)
            
            self.newline()

        self.status = self.add_text(text='')
        self.newline()
        self.add_line(600, span=5)
        self.newline()

        self.add_button("Start TRIACs", self.start_triac, sticky=STICKY_NSEW)
        self.add_button("Stop TRIACs", self.stop_triac, sticky=STICKY_NSEW)

    # Add a radio button element to the dialog
    def add_radio_button(self, text='', variable=None, value=None, func=None, span=1, tooltip=None, sticky=gui.W+gui.N, padx=2, pady=2, justify=gui.LEFT):
        assert variable
        gui.Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = gui.Radiobutton(self, text=text, variable=variable, value=value, command=func, justify=justify)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        if tooltip != None: gui.createToolTip(x, tooltip)
        return x

    # Add a horizontal line
    def add_line(self, width=200, height=5, span=1, sticky=STICKY_NSEW, padx=2, pady=2):
        gui.Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = gui.Canvas(self, width=width, height=height)
        x.create_line(0, 2, width-1, 2)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        return x

    def stop_triac(self):
        self.status.change_text("Stop TRIAC testing.")
        self.parent_data.stop_triac_trigger=True    

    def start_triac(self):
        self.status.change_text("Start TRIAC testing.")
        self.parent_data.sequence_number = self.triac_sequence_no_entry.value()
        self.parent_data.triac_phase_angle = []
        for i in range(0, self.sequence_number):
            self.triac1_angle[i] = self.triac1_angle_entry[i].value()
            self.parent_data.triac_phase_angle.append(self.triac1_angle[i])
            self.triac2_angle[i] = self.triac2_angle_entry[i].value()
            self.parent_data.triac_phase_angle.append(self.triac2_angle[i])
            self.triac3_angle[i] = self.triac3_angle_entry[i].value()
            self.parent_data.triac_phase_angle.append(self.triac3_angle[i])
            self.triac4_angle[i] = self.triac4_angle_entry[i].value()
            self.parent_data.triac_phase_angle.append(self.triac4_angle[i])
        
        self.parent_data.start_triac_trigger=True        

    def reset(self):
        print("Reset to defaults.")
        self.parent_data.sc_behaviour = 0
        for button in self.behaviour_flag_buttons:
            button.set_value(0)
        self.send()


# Effectively a function closure
class BehaviourSetter:
    def __init__(self, app, bf):
        self.app = app
        self.bf = bf

    def __call__(self):
        flag = self.button.value()
        print("Behaviour:", self.bf[flag])
        mask = 1 << self.bf.bit_position
        self.app.behaviour = self.app.behaviour & ~mask | (flag * mask)
        self.app.send()

# Called by parent programs
def exec(parent_app,parent_data, device):
    app = this_app(parent=parent_app, parent_data=parent_data,device=device, title=APP_TITLE)
    return app

# Called by parent programs
def description():
    return APP_HELP

# This code starts the app if the file is executed rather than imported.
if __name__ == '__main__':
    # Get a connection to a device
    with sc_protocol.SC_Protocol(debug_level=0) as hc_device:
        # Run the script
        app = exec(None, hc_device)
        hc_device.close()
