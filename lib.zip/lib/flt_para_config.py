#-------------------------------------------------------------------------------
# Name:        Filter Register Read Write
# Purpose:     This module allows change Filter behavior save to eerpom
#
# Authors:     Kai Jie Teo
#
# Created:     07/07/2020
# Copyright:   (c) Dyson Technology Ltd. 2020
#-------------------------------------------------------------------------------

import gui                      # Dyson Simple User Interface library
import sc_protocol as protocol  # Dyson N553 SC comms interface
import struct
import array

APP_TITLE = "Filter configuration"
APP_HELP  = "This script allows the user to change Filter register value .\n"

# Full stickiness for Tk controls
STICKY_NSEW = gui.N + gui.S + gui.E + gui.W

class this_app(gui.app):
    #
    # Define the controls
    #
    def __init__(self, *args, **kwargs):
        # Process arguments speficic to this application
        if 'device' in kwargs:
            self.device = kwargs['device']
            del kwargs['device']
            self.close_funcs.append(self.device.closing) # Give the application a function which will abort the connection
        else:
            gui.error("'device' is a required named parameter for this app.")

        if 'parent_data' in kwargs:
            self.parent_data = kwargs['parent_data']
            print("Parent data received")
            del kwargs['parent_data']

        # Initialise the base class
        gui.app.__init__(self, *args, **kwargs)

        # Read autostart value and behaviour flags from target
        self.NUMBER_ENTRY_WIDTH = 16
        self.CURVE_Q_PER_MODE_NUMBER = 5
        self.DEFAULT_DP_EOL_VALUE = 89900
        self.filter_sample_write = []
        self.filter_idleWrite = []
        self.filter_idleRead = []
        self.filter_lowWrite = []
        self.filter_lowRead = []
        self.filter_mediumWrite = []
        self.filter_mediumRead = []
        self.filter_highWrite = []
        self.filter_highRead = []
        self.filter_eolWrite = []
        self.filter_eolRead = []
        self.initialise_reg = ['A', 'B', 'C', 'Q_trigger_1', 'Q_trigger_2', 'dp_EOL' ]

        self.filter_low_show = []
        self.filter_low_write = []

        self.add_text(text='State / Setting')
        self.newline()

        self.add_text('Sample')
        self.filter_level = self.add_text(text='')
        self.filter_level.config(width = self.NUMBER_ENTRY_WIDTH)
        self.filter_sample_write = self.add_input(text="%d" % self.parent_data.flt_parameter_level_config, tooltip='Enter number of sample')
        self.newline()
        self.add_line(1700, span=10)

        self.newline()
        self.add_text(text='Flow Mode Idle')
        self.newline()
        for i in range(0,self.CURVE_Q_PER_MODE_NUMBER):
            if i == 3:
                self.newline()
            self.add_text(self.initialise_reg[i])
            self.filter_idleWrite.append(self.parent_data.flt_parameter_idle_config[i])
            self.filter_idleRead.append(self.parent_data.flt_parameter_idle_config[i])
            self.filter_idleRead[i] = self.add_text(text="%.9f" %  self.parent_data.flt_parameter_idle_config[i])
            self.filter_idleRead[i].config(width = self.NUMBER_ENTRY_WIDTH)
            self.filter_idleWrite[i] = self.add_input(text="%.9f" %  self.parent_data.flt_parameter_idle_config[i], tooltip='Enter idle coefficient')

        self.newline()
        self.add_text('dp_EOL')
        self.filter_eolWrite.append(self.parent_data.eol_filter_cal[0])
        self.filter_dp_idle = self.add_text(text='')
        self.filter_dp_idle.config(width = self.NUMBER_ENTRY_WIDTH)
        self.filter_eolWrite[0] = self.add_input(text=self.parent_data.eol_filter_cal[0], tooltip='Enter number of sample')
        self.newline()

        self.add_line(1700, span=10)
        self.newline()
        self.add_text(text='Flow Mode Low')
        self.newline()

        for i in range(0,self.CURVE_Q_PER_MODE_NUMBER):
            if i == 3:
                self.newline()
            self.add_text(self.initialise_reg[i])
            self.filter_lowWrite.append(self.parent_data.flt_parameter_low_config[i])
            self.filter_lowRead.append(self.parent_data.flt_parameter_low_config[i])
            self.filter_lowRead[i] = self.add_text(text="%.9f" %  self.parent_data.flt_parameter_low_config[i])
            self.filter_lowRead[i].config(width = self.NUMBER_ENTRY_WIDTH)
            self.filter_lowWrite[i] = self.add_input(text="%.9f" %  self.parent_data.flt_parameter_low_config[i], tooltip='Enter low coefficient')

        self.newline()
        self.add_text('dp_EOL')
        self.filter_eolWrite.append(self.parent_data.eol_filter_cal[1])
        self.filter_dp_low = self.add_text(text='')
        self.filter_dp_low.config(width = self.NUMBER_ENTRY_WIDTH)
        self.filter_eolWrite[1] = self.add_input(text=self.parent_data.eol_filter_cal[1], tooltip='Enter number of sample')
        self.newline()

        self.add_line(1700, span=10)
        self.newline()
        self.add_text(text='Flow Mode Medium')
        self.newline()

        for i in range(0,self.CURVE_Q_PER_MODE_NUMBER):
            if i == 3:
                self.newline()
            self.add_text(self.initialise_reg[i])
            self.filter_mediumWrite.append(self.parent_data.flt_parameter_medium_config[i])
            self.filter_mediumRead.append(self.parent_data.flt_parameter_medium_config[i])
            self.filter_mediumRead[i] = self.add_text(text="%.9f" %  self.parent_data.flt_parameter_medium_config[i])
            self.filter_mediumRead[i].config(width = self.NUMBER_ENTRY_WIDTH)
            self.filter_mediumWrite[i] = self.add_input(text="%.9f" %  self.parent_data.flt_parameter_medium_config[i], tooltip='Enter medium coefficient')

        self.newline()
        self.add_text('dp_EOL')
        self.filter_eolWrite.append(self.parent_data.eol_filter_cal[2])
        self.filter_dp_medium = self.add_text(text='')
        self.filter_dp_medium.config(width = self.NUMBER_ENTRY_WIDTH)
        self.filter_eolWrite[2] = self.add_input(text=self.parent_data.eol_filter_cal[2], tooltip='Enter medium coefficient')
        # self.add_text("%.3f" % self.parent_data.flt_parameter_idle_config[0])
        self.newline()

        self.add_line(1700, span=10)
        self.newline()
        self.add_text(text='Flow Mode High')
        self.newline()

        for i in range(0,self.CURVE_Q_PER_MODE_NUMBER):
            if i == 3:
                self.newline()
            self.add_text(self.initialise_reg[i])
            self.filter_highWrite.append(self.parent_data.flt_parameter_high_config[i])
            self.filter_highRead.append(self.parent_data.flt_parameter_high_config[i])
            self.filter_highRead[i] = self.add_text(text="%.9f" %  self.parent_data.flt_parameter_high_config[i])
            self.filter_highRead[i].config(width = self.NUMBER_ENTRY_WIDTH)
            self.filter_highWrite[i] = self.add_input(text="%.9f" %  self.parent_data.flt_parameter_high_config[i], tooltip='Enter high coefficient')

        self.newline()
        self.add_text('dp_EOL')
        self.filter_eolWrite.append(self.parent_data.eol_filter_cal[3])
        self.filter_dp_high = self.add_text(text='')
        self.filter_dp_high.config(width = self.NUMBER_ENTRY_WIDTH)
        self.filter_eolWrite[3] = self.add_input(text=self.parent_data.eol_filter_cal[3], tooltip='Enter high coefficient')
        self.newline()

        self.add_line(1700, span=10)
        self.newline()
        self.status = self.add_text(text='', span=5)
        self.newline()

        # self.add_button("Apply to ram", self.apply_ram_button_pressed, tooltip="Apply config changes to RAM (temporary)", sticky=STICKY_NSEW)
        self.add_button("Apply to EE", self.apply_ee_button_pressed, tooltip="Apply config changes to RAM and save in EEPROM (permanent)", sticky=STICKY_NSEW)
        self.add_button("Default EEPROM Data", self.clear_eep, tooltip="Set Filter EEPROM Data to default value", sticky=STICKY_NSEW)
        self.add_button("Read EE filter RAM Data", self.read_eep, tooltip="Read Filter EEPROM RAM Data", sticky=STICKY_NSEW)
        self.after(200, self.periodic)                     # After X milliseconds, execute self.periodic()

    # Add a horizontal line
    def add_line(self, width=200, height=5, span=1, sticky=STICKY_NSEW, padx=2, pady=2):
        gui.Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = gui.Canvas(self, width=width, height=height)
        x.create_line(0, 2, width-1, 2)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        return x

    def apply_ee_button_pressed(self):
        self.apply_config_to_ram()
        self.parent_data.finalise_flt_config_store_trigger = True
        self.status.change_text("Filter config was finalised in EEPROM")

    def apply_ram_button_pressed(self):
        self.apply_config_to_ram()
        self.status.change_text("Filter config was updated to RAM")

    def apply_config_to_ram(self):
        # print( self.filter_idleWrite[0].value())
        for i in range(0,self.CURVE_Q_PER_MODE_NUMBER):
            self.parent_data.flt_parameter_idle_config[i] = self.filter_idleWrite[i].value()
            self.parent_data.flt_parameter_low_config[i] = self.filter_lowWrite[i].value()
            self.parent_data.flt_parameter_medium_config[i] = self.filter_mediumWrite[i].value()
            self.parent_data.flt_parameter_high_config[i] = self.filter_highWrite[i].value()

        for i in range(0, 4):
            self.parent_data.eol_filter_cal[i] = self.filter_eolWrite[i].value()
        self.parent_data.flt_parameter_level_config = self.filter_sample_write.value()

        self.parent_data.set_flt_config_trigger=True

    def clear_eep(self):
        for i in range(0, 4):
            self.parent_data.eol_filter_cal[i] = self.DEFAULT_DP_EOL_VALUE
        self.parent_data.clear_flt_eeprom_data_trigger=True

    def read_eep(self):
        self.parent_data.get_flt_config_trigger=True

    def periodic(self):
        self.filter_level.change_text( self.parent_data.flt_parameter_level_config)
        for i in range(0,self.CURVE_Q_PER_MODE_NUMBER):
            self.filter_idleRead[i].change_text("%.9f" % self.parent_data.flt_parameter_idle_config[i])
            self.filter_lowRead[i].change_text("%.9f" % self.parent_data.flt_parameter_low_config[i])
            self.filter_mediumRead[i].change_text("%.9f" % self.parent_data.flt_parameter_medium_config[i])
            self.filter_highRead[i].change_text("%.9f" % self.parent_data.flt_parameter_high_config[i])

        self.filter_dp_idle.change_text(self.parent_data.eol_filter_cal[0])
        self.filter_dp_low.change_text(self.parent_data.eol_filter_cal[1])
        self.filter_dp_medium.change_text(self.parent_data.eol_filter_cal[2])
        self.filter_dp_high.change_text(self.parent_data.eol_filter_cal[3])

        self.after(200, self.periodic)  # Call this function again

# Called by parent programs
def exec(parent_app, parent_data,device):
    app = this_app(parent=parent_app, parent_data=parent_data,device=device, title=APP_TITLE)
    return app

# Called by parent programs
def description():
    return APP_HELP

# This code starts the app if the file is executed rather than imported.
if __name__ == '__main__':
    # Get a connection to a device
    description()
    print("This is not a stand alone script")

