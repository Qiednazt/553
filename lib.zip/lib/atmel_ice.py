#-------------------------------------------------------------------------------
# Name:        atmel-ice
# Purpose:     Provides access to the programming utilities of the Atmel-ICE
#              programmer
#
# Author:      Mike Morgan
#
# Created:     16/03/2016
# Copyright:   (c) Dyson 2016
#-------------------------------------------------------------------------------

import sys
import os
import zipfile
import subprocess
import hex_file

ZIP_FILE    = os.environ['NETWORK_TOOLS_DIR'].replace('\\', '/') + '/Atmel/atprogram.zip'
DEST_FOLDER = os.environ['TOOLS_DIR'].replace('\\', '/') + '/atmel_flash_programmer'

def test_for_app():
    pass

class programmer():
    def __init__(self, device='ATSAMD20E15', interface='SWD', tool='atmelice', serial_no = None):
        err_str = ''
        # Is the Atmel USB driver installed
        if subprocess.call('driverquery | find "WinDriver6" >nul 2>&1', stderr=None, stdout=None, shell=True) != 0:
            err_str += 'Atmel USB driver not installed. '
            
        # Check to see if any one of a range of VC++ redistributions are installed.
        vc_installed = False
        for i in range(9, 20):
            if subprocess.call('reg query HKLM\SOFTWARE\Microsoft\VisualStudio\%d.0\VC\VCRedist >nul 2>&1' % i, shell=True) == 0:
                vc_installed = True
        if not vc_installed:
            err_str += 'Microsoft VC++ redistribution not installed. '
            
        if len(err_str) > 0:
            err_str += 'See\n http://confluence.dyson.global.corp/display/N248/Programming+V10+VAC+PCBs\nfor installation instructions.'
            raise BaseException(err_str)

        
        # Extract the atprogram files as required
        if not os.path.isdir(DEST_FOLDER):
            try:
                print("Installing Atmel atprogram to %s" % DEST_FOLDER)
                zip = zipfile.ZipFile(ZIP_FILE)
                for file in zip.namelist():
                    if file[:len('atprogram/atbackend/')] == 'atprogram/atbackend/':
                        zip.extract(file, DEST_FOLDER)
                    if file[:len('atprogram/atpackmanager/')] == 'atprogram/atpackmanager/':
                        zip.extract(file, DEST_FOLDER)
                    if file[:len('atprogram/tools/')] == 'atprogram/tools/':
                        zip.extract(file, DEST_FOLDER)
                    if file[:len('atprogram/packs/atmel/SAMC21_DFP')] == 'atprogram/packs/atmel/SAMC21_DFP':  # NOTE: Should only be loaded if device requires it
                        zip.extract(file, DEST_FOLDER)
                    if file[:len('atprogram/packs/atmel/SAMD09_DFP')] == 'atprogram/packs/atmel/SAMD09_DFP':  # NOTE: Should only be loaded if device requires it
                        zip.extract(file, DEST_FOLDER)
                    if file[:len('atprogram/packs/atmel/SAMD20_DFP')] == 'atprogram/packs/atmel/SAMD20_DFP':  # NOTE: Should only be loaded if device requires it
                        zip.extract(file, DEST_FOLDER)                        
            except:
                raise BaseException("Could not unzip '%s'" % ZIP_FILE)
            print("Installed. Programming...")
        
        self.device = device
        self.interface = interface
        self.tool = tool
        self.serial_no = serial_no
        
    #
    # Program the device with the specified hex file. Return True if there is a failure
    #
    def program_from_file(self, intel_hex_file):
        fail = True
        try:
            cmd = '"%s/atprogram/atbackend/atprogram" --tool %s --interface %s --device %s program -f "%s" 2>&1' % (DEST_FOLDER, self.tool, self.interface, self.device, intel_hex_file)
            proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.PIPE)
            while True:
                line = proc.stdout.readline()
                if line.strip() == "":
                    pass
                else:
                    print('%s' % line.strip().decode("utf-8"))
                if not line: break
            proc.wait()
        except:
            print("Error programming device")
        return fail
        
    #
    # Perform a full erase
    #
    def full_erase(self):
        fail = True
        try:
            cmd = '"%s/atprogram/atbackend/atprogram" --tool %s --interface %s --device %s chiperase 2>&1' % (DEST_FOLDER, self.tool, self.interface, self.device)
            output = ''
            with subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True, stderr=subprocess.STDOUT) as proc:
                line = proc.stdout.read().decode("utf-8")
                output += line
            if output.find('Erase completed successfully.') != -1:
                fail = False
            print(output)
        except:
            print("Error erasing device")
        return fail
        
    #
    # Program the device with the specified IntelHex object
    #
    def program(self, hex):
        filename = os.environ['TEMP'] + '/atmel-ice.hex'
        f = open(filename, 'w')
        hex.write_hex_file(f)
        f.close()
        self.program_from_file(filename)

        
# err = 0 - No error
# err = 1 - Download failed
def download_app_from_file(filename):
    # The file may have attached JSON data, so create a pure hex file
    out_filename = os.environ['TEMP_DIR'] + '/atmelice.hex'
    out = open(out_filename, 'w')
    for line in open(filename):
        if len(line) > 0 and line[0] == ':':
            out.write(line)
    out.close()
            
    p = programmer()
    p.program_from_file(out_filename)
    
    return 0
        