#
# This module pretends to be the xlrd library
# If the library is not available, it is installed from the 'python_install' folder.
# The environment 'python_install' points to a folder which contains the zip file for this library.
#
# Usage:
#   import project_xlrd as xlrd
#
# NOTE: If the library needs to be installed, the application will be restarted.

import zipfile
import os
import sys
import shutil

# Import the module

try:
    # If running in a window, stdout and stderr may be None, causing an issue. Assign them to dummy values because setuptools tries to use them.
    import io
    out = sys.stdout
    err = sys.stderr
    sys.stdout = io.StringIO()
    sys.stderr = sys.stdout
    from xlrd import *
    sys.stdout = out
    sys.stderr = err
    installed = True
except:
    sys.stdout = out
    sys.stderr = err
    installed = False

#try:
#    from xlrd import *
#    installed = True
#except:
#    installed = False

# Did it import?
if not installed:
    import project_setuptools # This module is required for the installation
    # The module did not load, we will have to install it
    name = 'xlrd-0.9.3'
    
    # Display install message window
    import tkinter
    top = tkinter.Tk()
    top.title("Installing")
    msg = tkinter.Message(top, text="\nInstalling library " + name + "\n")
    msg.pack()
    top.update()

    filename = os.environ['NETWORK_TOOLS_DIR'] + '/Python/' + name + '.zip'

    # Remove pre-existing install files
    shutil.rmtree(os.environ['TEMP'] + '/' + name, ignore_errors=True)

    errstr = None
    try:
        errstr = 'Installing ' + name + ': Could not open ' + filename
        zip = zipfile.ZipFile(filename)
        errstr = 'Installing ' + name + ': Could not open unzip ' + filename + '  to  ' + os.environ['TEMP']
        zip.extractall(os.environ['TEMP'])
        os.system('cd /d "' + os.environ['TEMP'] + '\\' + name + '" & "' + os.environ['PYTHON_EXEC_DIR'] + '\\python.exe" setup.py install')
        # Clean up
        errstr = 'Installing ' + name + ': Problem cleaning up'
        shutil.rmtree(os.environ['TEMP'] + '/' + name, ignore_errors=True)
        # For some reason, the library will not install until the script has been re-started.
        errstr = 'Installing ' + name + ': Problem restarting'
        print("\n\nFinished installing library " + name + "\n\n")
        errstr = None
        from xlrd import *
        ## Restart the app
        #str = ''
        #for arg in sys.argv:
        #    str += ' "%s" ' % arg
        #os.execlp(sys.executable, '-x',  '-x', str)
    except:
        pass

    if errstr != None:
        raise Exception(errstr)

    ## This is not actially required because of the use of os.execlp()
    #try:
    #    top.destroy()
    #except:
    #    pass
