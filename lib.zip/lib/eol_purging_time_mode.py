"""
Copywrite Dyson(C) 2021

API to force amb pressure/temp errors. This forces the product to go in the ambient pressure faults.
Note - This is a drop down list, which can have either state.
       But product can have both under pressure/over pressure alarm at the same moment - which is an unlikely scenario.
"""

from enum import Enum
from sc_protocol import SET_EOL_PURGING_TIME_DELAY, GET_EOL_PURGING_TIME_DELAY


class PurgingTimeModes(Enum):

    PURGING_DEFAULT_TIME = 0  # set default time which is 3s current
    PURGING_TIME_1S = 1000 
    PURGING_TIME_3S = 3000
    PURGING_TIME_5S = 5000
    PURGING_TIME_60S = 60000
    PURGING_DISABLE = 0XFFEE # set purging feature disable which is match with 553 FW PURGING_DURATION_DISABLE

    @classmethod
    def has_value(cls, value):
        return value in cls._value2member_map_


def update_mode(device, mode):
    """
    Update purging flow, does not write to eeprom.

    Args:
        device: sc_protocol device to communicate through
        mode: str, int or PurgingTimeModes mode to send

    Returns:
        None
    """
    if isinstance(mode, str):
        int_mode = PurgingTimeModes[mode].value
    elif isinstance(mode, PurgingTimeModes):
        int_mode = mode.value
    elif isinstance(mode, int) and (mode < len(PurgingTimeModes)):
        int_mode = mode
    else:
        raise ValueError("Invalid operating mode {}".format(mode))

    cmd = SET_EOL_PURGING_TIME_DELAY(int_mode)
    msg = device.command_messages()
    msg.add(cmd)
    device.send(msg)

def get_mode(device):
    """
    get current amb pressure error flag

    Args:
        device: sc_protocol device to communicate with

    Returns:
        PurgingTimeModes: index of the array of enum elements.
        This index is first stored by the Combo class of the Gui.

    Raises:
        ValueError: got a bad response
    """
    cmd = GET_EOL_PURGING_TIME_DELAY()
    msg = device.command_messages()
    msg.add(cmd)
    device.send(msg)

    if PurgingTimeModes.has_value(cmd.eol_purging_delay_time_ms):
        curr_purging_time = cmd.eol_purging_delay_time_ms
        print("SC purging flow received",  PurgingTimeModes(cmd.eol_purging_delay_time_ms))
    else:
        curr_purging_time = PurgingTimeModes.PURGING_DEFAULT_TIME.value
        print("SC purging flow received is invalid {}, set to default value {}".format(cmd.eol_purging_delay_time_ms, PurgingTimeModes(curr_purging_time)))
        
    for idx, i in enumerate(PurgingTimeModes):
        if i.value == curr_purging_time:
            return idx
