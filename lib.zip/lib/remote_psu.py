#-------------------------------------------------------------------------------
# Name:        remote_psu library
# Purpose:     Provide an api to interact with the power supply
#
# Author:      David Ansah
#
# Created:     05/01/2017
# Copyright:   (c) Dyson 2017
#-------------------------------------------------------------------------------

import sys
import os
import time
import subprocess
import struct
import time                       # Provides timing functions
import project_serial as serial         # This will install pyserial if not aleady available on the computer
from tkinter import messagebox   # Standard GUI library message box
import tkinter


ASCII_ZERO = 48


class RemotePSU():
    cmd_terminator = "\n"
    cmd_seperator = 0x3B
    response_terminator = "\r\n"
    ver_maj = 0
    ver_min = 1

    # This will open a com_port to the power supply
    #   name (default)  - description of the connection (eg. Remote PSU)
    #   com_port (default None) -  The port string is the serial port to use for the connection. It can be of the form 'com1:' but it should be
    #     of the form '\\.\COMx' to avoid issues with ports of high number e.g. COM22. If the value is None, the
    #     class will use a tkinter dialog (defined in the 'port_selection' module) to allow the user to select a com port.
    #     If this method is used, the class has the persistent 'user_data' dictionary defined which is saved to file when
    #     the class object closes.
    #   baudrate (default 9600) - Baud rate e.g. 19200. Format is 8 data bits, 1 start bit, no parity, XON/XOFF handshaking
    #   byteorder (default 'little')
    #     If 'little', numbers are sent in little endian order, otherwise, 'big' endian order

    def __init__(self, **kwargs):
        self.com_port   = kwargs.pop('com_port', None)
        self.baud       = kwargs.pop('baud', 9600)
        self.name       = kwargs.pop('name', 'Remote PSU Connection')
        self.debug_level      = kwargs.pop('debug_level', 0)
        self.byteorder  = kwargs.pop('byteorder', 'little')

        # If we still do not have a com port, ask the user
        self.user_data = None
        if self.com_port == None:
            import port_selection   # This is imported here so that tkinter is not required if the com port is specified.
            # Ask the user to select a com port
            self.user_data = port_selection.get_com_port(name=self.name, test_func=self.connection_test, baud=self.baud)
            #self.user_data = port_selection.get_com_port(name=self.name, baud=self.baud)
            self.com_port = self.user_data['com_port']

        # Open the com port
        try:
            self.ser = serial.Serial()
            self.ser.baudrate = self.baud
            self.ser.port = self.com_port                         # e.g. 'com1'
            self.ser.timeout = 5                                  # Set port timeout = 3s (datasheet suggested max time to be 5secs)
            self.ser.open()                                       # Open the serial port
            self.ser.flushInput()
            self.ser.flushOutput()
            if self.debug_level >= 30:
                print("%s.__init__(): %s opened" % (self.name, self.com_port))
        except IOError:
            self.ser = None
            print('ERROR!: Could not open ' + self.com_port)
            raise SystemExit(None)

    def tester(self):
        for x in range (0,10):
            print(x)

    #
    # This function tests the specified com port to see if it has a valid connection to a device. It is used by the port_selection.get_com_port
    # function when it is looking for a connection. The function returns True if a device is spotted and False if not.
    #
    """
    @TODO: Needs to be edited to send a connection to
    """
    def connection_test(self, com_port):
        if(self.debug_level > 0):
            print("DEBUG: connection_test : line 88")

    """
    # write str to the psu
    # command - the command string to send
    # resp_byte_size - the size of the response (in bytes) expected
    # response - feedback values from the psu
    # NOTE: The psu responds in ASCII. Response messages must be interrpretted in ASCII.
    """
    def write_cmd(self, command, resp_byte_size):
        psu_response = []
        if self.debug_level > 0:
            print("DEBUG: write_cmd() : line 100")
            print("DEBUG: command = %s" % command)



        for char in command:
            # send one characte at a time
            cmd = bytearray()
            if(char != '\n' or ord(char) != 42):
                cmd.append(ord(char))
                #print(cmd)
                self.ser.write(cmd) # I want to send a character at a time
                time.sleep(0)
            elif(ord(char) == 0x2a):
                temp = bytearray()
                temp.append(0x2a)
                self.ser.write(temp)

        # send line feed
        time.sleep(0)
        crg_rtn = bytearray()
        crg_rtn.append(0x0A)
        self.ser.write(crg_rtn)
        #print(crg_rtn)

        if(resp_byte_size != None):
            # remember the additional line feed and carriage return
            resp_byte_size += 2
            # get the response
            value = bytearray()
            t = time.clock()
            while self.ser.inWaiting() < 1:
                if((time.clock() - t) > 5):
                    print("Error: No response from PSU in 5 seconds")
                    sys.exit(1)

            # extract the actual data from response packet
            response =  self.ser.read(resp_byte_size)
            for data in response:
                # remove the line feed and the carriage return
                if(chr(data) != '\r' and chr(data) != '\n' ):
                    psu_response.append(data)

            # return the response
            return psu_response
        else:
            return True


    """
    # Get the contents of the event status register
    # NOTE: The response is returned in ASCII.
    """
    def get_status_register(self):
        if self.debug_level > 0:
            print("DEBUG: get_status_register : line 155")
        cmd = "*ESE?"
        status = self.write_cmd(cmd, 1)

        temp = ("%s" % chr(status[0]))
        val = int(temp)

        if(self.debug_level > 0):
            print("DEBUG: %d" % val)

        return val

    """
    # Check if the device output is on
    # @todo split response to return integer
    """
    def is_output_on(self):
        if self.debug_level > 0:
            print("DEBUG: is_output_on : line 173")
        cmd = "OP1?"
        output_status = self.write_cmd(cmd,1)

        if self.debug_level > 0:
            print("%s" % chr(output_status[0]))

        val = int(chr(output_status[0]))
        return val

    """
    # Query execution error register to know the last error encountered over the serial port.
    # NOTE: This reads the error register and clears the error.
    """
    def get_error_status(self):
        if self.debug_level > 0:
            print("DEBUG: get_error_status : line 189")
        cmd = "EER?"
        error_status = self.write_cmd(cmd, 3)

        data = ""
        for char in error_status:
            data +=("%s" % chr(char))

        err = int(data)

        if(err == 0):
            print("No system error.")
        elif(err > 0 and err < 10):
            print("ERROR!: Hardware Error!")
        elif(err == 100):
            print("ERROR!: Negative number used!")
        elif(err == 101):
            print("ERROR!: Data Corruption!")
        elif(err == 102):
            print("ERROR!: No setup data!")
        elif(err == 200):
            print("ERROR!: Attempt to write to read only memory!")

        if(self.debug_level > 0):
            print("%s" % error_status[0])

        return err

    """
    # Query limit event status and limit event status enable registers.
    """
    def get_limit_status(self):
        if self.debug_level > 0:
            print("DEBUG: get_limit_status : line 222")
        cmd = "LSE1?"
        limit_status = self.write_cmd(cmd, 1)

        val = int(limit_status[0])
        return val

    """
    # Reset the power supply
    """
    def reset(self):
        if(self.debug_level > 0):
            print ("DEBUG: reset : line 234")

        cmd = "*RST"
        err = self.ser.write_cmd(cmd, None)


    """
    # get the instruments id which includes the manufacture's name, model and the revision of software on the device.
    # return string name of device
    """
    def get_instrument_id(self):
        if(self.debug_level > 0):
            print ("DEBUG: get_instrument_id : line 246")

        cmd = "*IDN?"
        id = self.write_cmd(cmd, 48)
        id_str = ''
        for char in id:
            id_str += (chr(char))
        #print(id_str)

        if(self.debug_level > 0):
            print(id)

        return id_str

    """
    # Set the voltage of the output
    """
    def set_voltage(self, voltage):
        if(self.debug_level > 0):
            print ("DEBUG: set_voltage_level : line 265")

        try:
            _voltage = int(voltage)
            cmd = ("V1 %d" % voltage)
            self.write_cmd(cmd, None)
        except ValueError:
            print("ERROR!: Value entered is not a number.")
            print("TIP: Retry with an integer number.")
            print("TIP: All numbers are rounded up.")



    """
    # Get the voltage of the psu
    # NOTE: Values are returned as whole integers.
    """
    def get_voltage(self):
        if(self.debug_level > 0):
            print("DEBUG: get_voltage : line 284")

        cmd = "V1?"
        data = self.write_cmd(cmd,9)

        voltage = ''
        temp = []
        for char in data:
            voltage +=(chr(char))

        if(self.debug_level > 0):
            print("DEBUG: [%s]" % voltage)

        # return the voltage as integer
        temp = voltage.split(' ')
        val = float(temp[1])
        return val      # values from psu are always who integers....the remainder will always be 0

    """
    # Set over voltage trip value
    """
    def set_over_voltage_trip(self, voltage):
        if(self.debug_level > 0):
            print("DEBUG: set_over_voltage_trip : line 306")

        try:
            volts = int(voltage)
            cmd = ("OVP1 %d" % volts)
            self.write_cmd(cmd, None)
        except:
            print("ERROR!: Value entered is not a number.")
            print("TIP: Retry with a number.")
            print("TIP: All numbers are rounded up.")

            if(self.debug_level > 0):
                print("DEBUG: cmd = %s " % cmd)


    """
    # Get over voltage trip setting
    """
    def get_over_voltage_trip(self):
        if(self.debug_level > 0):
            print("DEBUG: get_over_voltage_trip : line 326")

        cmd = "OVP1?"
        over_trip_voltage = ''
        data = self.write_cmd(cmd, 10)
        for char in data:
            over_trip_voltage +=(chr(char))

        if(self.debug_level > 0):
            print("DEBUG: [%s]" % over_trip_voltage)

        # return the response as an integer
        temp = over_trip_voltage.split(' ')
        val = temp[1].split('.')
        return(int(val[0]))



    """
    # Set over current trip value
    """
    def set_over_current_trip(self, current):
        if(self.debug_level > 0):
            print("DEBUG: set_over_current_trip : line 349")

        try:
            volts = int(voltage)
            cmd = ("OCP1 %d" % current)
            self.write_cmd(cmd, None)
        except:
            print("ERROR!: Value entered is not a number.")
            print("TIP: Retry with a number.")
            print("TIP: All numbers are rounded up.")

            if(self.debug_level > 0):
                print("DEBUG: cmd = %s " % cmd)


    """
    # Get over current trip value
    """
    def get_over_current_trip(self):
        if(self.debug_level > 0):
            print("DEBUG: get_over_voltage_trip : line 369")

        cmd = "OCP1?"
        over_trip_current = ''
        data = self.write_cmd(cmd, 10)
        for char in data:
            over_trip_current +=(chr(char))

        if(self.debug_level > 0):
            print("DEBUG: [%s]" % over_trip_current)

        # return the response as an integer
        temp = over_trip_current.split(' ')
        val = temp[1].split('.')
        return(int(val[0]))


    """
    # Set current
    """
    def set_current(self, current):
        if(self.debug_level > 0):
            print("DEBUG: set_current : line 391")

        try:
            _current = int(current)
            cmd = ("I1 %d" % _current)
            self.write_cmd(cmd, None)
        except:
            print("ERROR!: Value entered is not a number.")
            print("TIP: Retry with a number.")
            print("TIP: All numbers are rounded up.")

    """
    # Get the current level of the psu output
    """
    def get_current(self):
        if(self.debug_level > 0):
            print("DEBUG: get_current : line 407")

        cmd = "I1?"
        data = self.write_cmd(cmd,9)

        current = ''
        for char in data:
            current +=(chr(char))

        if(self.debug_level > 0):
            print("DEBUG: [%s]" % data)

        #return response as integer
        temp = current.split(' ')
        val = float(temp[1])
        return val



    """
    # Turn on the output
    # return None
    """
    def turn_ON_output(self):
        if(self.debug_level > 0):
            print("DEBUG: turn_ON_output : line 432")

        cmd = "OP1 1"
        self.write_cmd(cmd,None)

        if(self.debug_level > 0):
            print("DEBUG: cmd = [%s]" % cmd)

    """
    # Turn off the output
    # return None
    """
    def turn_OFF_output(self):
        if(self.debug_level > 0):
            print("DEBUG: turn_OFF_output : line 446")

        cmd = "OP1 0"
        self.write_cmd(cmd,None)

        if(self.debug_level > 0):
            print("DEBUG: cmd = [%s]" % cmd)

    """
    # Set the voltage step
    # return None
    """
    def set_voltage_stepsize(self, step):
        if(self.debug_level > 0):
            print("DEBUG: set_voltage_stepsize : line 460")

        try:
            if(int(step)):
                _step = int(step)
                cmd =("DELTAV1 %d" % step)
                self.write_cmd(cmd,None)
            elif(float(step)):
                _step = float(step)
                cmd =("DELTAV1 %f" % step)
                self.write_cmd(cmd,None)
        except:
            print("ERROR!: Value entered is not a number.")
            print("TIP: Retry with a number.")
            print("TIP: All numbers are rounded up.")

        if(self.debug_level > 0):
            print("DEBUG: cmd = [%s]" % cmd)

    """
    # Set the current step
    # return None
    """
    def set_current_stepsize(self, step):
        if(self.debug_level > 0):
            print("DEBUG: set_current_stepsize : line 485")

        try:
            if(int(step)):
                _step = int(step)
                cmd =("DELTAI1 %d" % step)
                self.write_cmd(cmd,None)
            elif(float(step)):
                _step = float(step)
                cmd =("DELTAI1 %f" % step)
                self.write_cmd(cmd,None)
        except:
            print("ERROR!: Value entered is not a number.")
            print("TIP: Retry with a number.")
            print("TIP: All numbers are rounded up.")

        if(self.debug_level > 0):
            print("DEBUG: cmd = [%s]" % cmd)

    """
    # Get the current step size
    # @todo split response to return integer
    """
    def get_current_stepsize(self):
        if(self.debug_level > 0):
            print("DEBUG: get_current_stepsize : line 510")

        cmd = "DELTAI1?"
        data = self.write_cmd(cmd,14)

        current_stepsize = ''
        for char in data:
            current_stepsize +=(chr(char))

        if(self.debug_level > 0):
            print("DEBUG: [%s]" % data)

        #return response as integer
        temp = current_stepsize.split(' ')
        val = float(temp[1])
        return val


    """
    # Get the current step size
    # @todo split response to return integer
    """
    def get_voltage_stepsize(self):
        if(self.debug_level > 0):
            print("DEBUG: get_voltage_stepsize : line 534")

        cmd = "DELTAV1?"
        data = self.write_cmd(cmd,14)

        voltage_stepsize = ''
        for char in data:
            voltage_stepsize +=(chr(char))

        if(self.debug_level > 0):
            print("DEBUG: [%s]" % data)

        #return response as integer
        temp = current_stepsize.split(' ')
        val = float(temp[1])
        return val


    """
    # Increment output voltage by step size
    # return None
    """
    def inc_voltage(self):
        if(self.debug_level > 0):
            print("DEBUG: inc_voltage : line 558")

        cmd = "INCV1"
        self.write_cmd(cmd,None)

        if(self.debug_level > 0):
            print("DEBUG: cmd = [%s]" % cmd)

    """
    # Increment output current by step size
    # return None
    """
    def inc_current(self):
        if(self.debug_level > 0):
            print("DEBUG: inc_voltage : line 572")

        cmd = "INCI1"
        self.write_cmd(cmd,None)

        if(self.debug_level > 0):
            print("DEBUG: cmd = [%s]" % cmd)

    """
    # Decrement output voltage by step size
    # return None
    """
    def dec_voltage(self):
        if(self.debug_level > 0):
            print("DEBUG: dec_voltage : line 586")

        cmd = "DECV1"
        self.write_cmd(cmd,None)

        if(self.debug_level > 0):
            print("DEBUG: cmd = [%s]" % cmd)


    """
    # Decrement output current by step size
    # return None
    """
    def dec_current(self):
        if(self.debug_level > 0):
            print("DEBUG: dec_current : line 601")

        cmd = "DECI1"
        self.write_cmd(cmd,None)

        if(self.debug_level > 0):
            print("DEBUG: cmd = [%s]" % cmd)


    #
    # This function is used to close a connection. It will save connection data and close the com port.
    #
    def close(self):
        # Try to close the serial port
        try:
            self.ser.close()
            if self.debug_level >= 30:
                print("%s.close()" % self.name)
        except:
            pass
        # If the 'port_selection' module was used to open the serial port, save any user data in the 'port_selection' config file.
        # This allows the chosen com port to be automatically selected next time. Additionally, other user data is stored.
        if self.user_data != None:
            import port_selection   # This is imported here so that tkinter is not required if the com port is specified.
            port_selection.save_user_data(self.user_data)

"""
This code starts if the file is executed rather than imported.
"""
if __name__ == '__main__':
    # Get a connection to a device
    x = 1.0
    while x < 5:
        print(x)
        x += 0.1

"""
    psu = RemotePSU(baud=9600, debug_level=0)
    psu.get_instrument_id()
    psu.close()
"""
