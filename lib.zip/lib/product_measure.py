#-------------------------------------------------------------------------------
# Name:        product measurement
# Purpose:     This script provides Generic N553 product measurements
#
# Author:      Brian Weeks
#
# Created:     20/05/2018    (last updated 11/11/2019, by Dave Hawker)
#
# Copyright:   (c) Dyson 2019
#-------------------------------------------------------------------------------

APP_TITLE = "Generic N553 product measurement"
APP_HELP  = "This script allows the user to monitor/control the HC by mimicking the UI"

# The line below must be exact to allow the documentation to be picked up by the doxygen_create_user_scripts_doc.cmd script.
# Support Script Details
"""
This is the main motor control script.  It uses other scripts in the support_scripts folder to execute sub-tasks
usually accessed through buttons.
It periodically (every second) queries the device to get the current status.  This is either
      - OK status and the current speed
      - Error - Meaning the device is in error
      - Disconnected - Meaning the device is not responding to poll messages

You can hover the mouse over buttons to discover what they do. Here is a small list
      - About - Display version information about the software on the device
      - Stop - Stop the motor
      - Start - Start the motor without specifying a power mode
      - Drop down box - Start the motor whilst also specifying a power mode.

Note that the window is re-sizeable.
"""
# End Support Script Details


import time                      # Standard Python library
import imp                       # Standard Python library
import os                        # Standard Python library
import mode_config               # modify heat/flow setting of one mode
import gui                       # Dyson Simplified Graphical User Interface library
import sc_protocol               # Dyson V10 VAC motor comms interface
import v9_protocol               # Dyson Ebox motor comms interface
import tkinter
import sys
import subprocess
import datetime
#
# Over-ride the gui application
#

logfile_default_name = "553scProductMeasureLog"
logfile_extension = ".csv"

todays_date = datetime.date.today().strftime("%d%b%Y")
logfile_name = logfile_default_name + "_" + todays_date + logfile_extension

# Full stickiness for Tk controls
STICKY_NSEW = gui.N + gui.S + gui.E + gui.W

class this_app(gui.app):
    #
    # Initialise the application
    #
    send_para_res_request = 0
    current_heat_level = 0
    current_flow_level = 1
    current_sensitive_status = 0
    current_ui_mode = 0
    logging = False

    def __init__(self, *args, **kwargs):
        # Process arguments speficic to this application
        if 'device' in kwargs:
            self.device = kwargs['device']
            del kwargs['device']
            self.close_funcs.append(self.device.closing) # Give the application a function which will abort the connection
        else:
            gui.error("'device' is a required named parameter for this app.")

        if 'v9_device' in kwargs:
            self.v9_device = kwargs['v9_device']
            del kwargs['v9_device']

        if 'parent_data' in kwargs:            
            self.parent_data = kwargs['parent_data']
            del kwargs['parent_data']    

        self.BUTTON_WIDTH = 12
        self.NUMBER_ENTRY_WIDTH = 12
        self.NUMBER_OUTPUT_WIDTH = 12

        # Initialise the base class
        gui.app.__init__(self, *args, **kwargs)
        self.add_controls()
        self.update_controls()                              # Update all currently defined controls
        self.after(200, self.periodic)                      # After X milliseconds, execute self.periodic()
        if self.device != None:
            self.device.yeild = self.update                 # Tell the protocol to call this function when it enters a long loop

    #
    # Define the controls
    #
    def add_controls(self):
        self.add_text(text='Heater releated Measurements')
        self.newline()
        self.add_text(text='Traic thermistor Temp(mV):')
        self.triac_temp_mv_text  = self.add_text(text='')
        self.newline()

        self.add_text(text='Mems sensor pressure(mB):')
        self.pressure_text = self.add_text(text='')
        self.pressure_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.add_text(text='Mems sensor temperature (deg C):')
        self.mems_temp_text = self.add_text(text='')
        self.mems_temp_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()
        self.add_text(text='Product Current (A):')
        self.product_current_text = self.add_text(text='')
        self.product_current_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()

        self.add_line(1200, span=6)
        self.newline()
        self.add_text(text='Motor related measurements:')
        self.newline()
        self.add_text(text='Motor speed (krpm):')
        self.motor_speed_text = self.add_text(text='')
        self.motor_speed_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.add_text(text='Flow index:')
        self.flow_index_text = self.add_text(text='')
        self.flow_index_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()

        self.add_text(text='Upper Speed Limit (krpm):')
        self.upper_speed_limit_text = self.add_text(text='')
        self.upper_speed_limit_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.add_text(text='Lower Speed Limit (krpm):')
        self.lower_speed_limit_text = self.add_text(text='')
        self.lower_speed_limit_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.add_text(text='DC Link Voltage (mV):')
        self.dc_link_voltage_text = self.add_text(text='')
        self.dc_link_voltage_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()

        self.add_line(1200, span=6)
        self.newline()
        self.add_text(text='Sensors:')
        self.newline()
        self.add_text(text='Pause sensor (Accelerometer):')
        self.newline()
        self.add_text(text='X Acceleration (m/s2):')
        self.x_acceleration_text = self.add_text(text='')
        self.x_acceleration_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.add_text(text='Y Acceleration (m/s2):')
        self.y_acceleration_text = self.add_text(text='')
        self.y_acceleration_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.add_text(text='Z Acceleration (m/s2):')
        self.z_acceleration_text = self.add_text(text='')
        self.z_acceleration_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        
        self.newline()
        self.newline()
        self.add_text(text='Arm sensor (Magnetometer):')
        self.newline()
        self.add_text(text='X Field strength (mTesla - TBC):')
        self.x_field_text = self.add_text(text='')
        self.x_field_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.add_text(text='Y Field strength (mTesla - TBC):')
        self.y_field_text = self.add_text(text='')
        self.y_field_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.add_text(text='Z Field strength (mTesla - TBC):')
        self.z_field_text = self.add_text(text='')
        self.z_field_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()
        self.add_text(text='Temperature strengh (Deg C - TBC):')
        self.t_field_text = self.add_text(text='')
        self.t_field_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()

        self.add_line(1200, span=6)
        self.newline()
        self.add_text(text='Product measurements:')
        self.newline()
        self.add_text(text='AC Mains (V):')
        self.ac_mains_vol_text = self.add_text(text='')
        self.ac_mains_vol_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.add_text(text='AC Mains (Frequency):')
        self.ac_mains_freq_text = self.add_text(text='')
        self.ac_mains_freq_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.add_text(text='Product Power (W):')
        self.product_power_text = self.add_text(text='')
        self.product_power_text.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()

        self.add_line(1200, span=6)
        self.newline()
        self.log_button = self.log_button = self.add_button(text="Start logging", func=self.logon,  tooltip="Start Logging.")


    # This function catches the script being closed performs actions required before the app closes. E.g. logging data
    def destroy(self):
        gui.app.destroy(self)

    # Conversion from flux reading to mTesla for Flux X, Y and Z of ALS31300. See datasheet
    # 1 flux reading = 1/4 Gauss = 1/40 mTesla
    def als31300_flux_to_m_Tesla(self, flux):
        return ( flux/40 )

    # Conversion from Temperature reading to Celcius of ALS31300. See datasheet
    def als31300_tempReading_to_celcius(self, temperature):
        return ( 302*(temperature - 1708)/4096 )
        
    # This function is called periodically. If there has not been any communication with the device for over a second,
    # it sends a 'get error status' command.  This sets the status text to either 'OK', 'Error' or 'Disconnected'
    def periodic(self):


        self.pressure_text.change_text("%.3f" %  self.parent_data.pressure_mB)
        self.mems_temp_text.change_text("%.3f" %  self.parent_data.mems_temp_C)        
        self.triac_temp_mv_text.change_text(self.parent_data.triac_temp_mV)
        self.product_power_text.change_text("%.3f" %  self.parent_data.productPower_W)
        self.product_current_text.change_text("%.3f" %  self.parent_data.productCurrent_A)
        self.flow_index_text.change_text( self.parent_data.offset)
        self.ac_mains_vol_text.change_text("%.3f" %  self.parent_data.acMainsVoltageRms_V)
        self.x_acceleration_text.change_text("%.3f" % self.parent_data.Acceleration_X)
        self.y_acceleration_text.change_text("%.3f" % self.parent_data.Acceleration_Y)
        self.z_acceleration_text.change_text("%.3f" % self.parent_data.Acceleration_Z)
        self.x_field_text.change_text("%.3f" % self.als31300_flux_to_m_Tesla(self.parent_data.Flux_X))
        self.y_field_text.change_text("%.3f" % self.als31300_flux_to_m_Tesla(self.parent_data.Flux_Y))
        self.z_field_text.change_text("%.3f" % self.als31300_flux_to_m_Tesla(self.parent_data.Flux_Z))
        self.t_field_text.change_text("%.3f" % self.als31300_tempReading_to_celcius(self.parent_data.Flux_T))
        
        if self.parent_data.disable_motor_command == 0:
            self.motor_speed_text.change_text("%.3f" % self.parent_data.motor_speed_krpm)
            self.ac_mains_freq_text.change_text("%.3f" % self.parent_data.ac_mains_freq)
            self.dc_link_voltage_text.change_text("%.3f" % self.parent_data.dc_link_voltage)
     
        
        # This must be at the end - to prevent multiple threads
        if (os.path.isfile('log.opt') and self.logging == True):
            self.log_data(logfile_name)

        self.after(200, self.periodic)  # Call this function again
        
    def logon(self):
        if self.logging == False:
            self.logging = True
            self.log_button.config(text='Stop logging')
            
            logfile = open("log.opt", "a")
            log_entry = ""
            log_entry = ";Logging enabled"
            logfile.write(log_entry)
            logfile.close

            logfile = open(logfile_name, "a")  #Initialise logfile with labels
            log_entry = ""
            log_entry = log_entry + "Time HH:MM:SSSS"
            log_entry = log_entry + "," + "Traic thermistor Temp(mV)"
            log_entry = log_entry + "," + "Mems sensor pressure(mB)"
            log_entry = log_entry + "," + "Mems sensor temperature (deg C)"
            log_entry = log_entry + "," + "Product Current (A)"
            log_entry = log_entry + "," + "Motor speed (krpm)"
            log_entry = log_entry + "," + "Flow index"
            log_entry = log_entry + "," + "Upper Speed Limit (krpm)"
            log_entry = log_entry + "," + "Lower Speed Limit (krpm)"
            log_entry = log_entry + "," + "DC Link Voltage (mV)"
            log_entry = log_entry + "," + "X Acceleration (m/s2)"
            log_entry = log_entry + "," + "Y Acceleration (m/s2)"
            log_entry = log_entry + "," + "Z Acceleration (m/s2)"
            log_entry = log_entry + "," + "X Field strength (mT - TBC)"
            log_entry = log_entry + "," + "Y Field strength (mT - TBC)"
            log_entry = log_entry + "," + "Z Field strength (mT - TBC)"
            log_entry = log_entry + "," + "Temperature strengh (Deg C - TBC)"
            log_entry = log_entry + "," + "AC Mains (V)"
            log_entry = log_entry + "," + "AC Mains (Frequency)"
            log_entry = log_entry + "," + "Product Power (W)"
    
            # Append  linefeed
            log_entry = log_entry + "\n"

            logfile.write(log_entry)
            logfile.close
        else:
            self.log_button.config(text='Start logging')
            self.logging = False
        
    def log_data(self, file_name):
        logfile = open(file_name, "a")

        # Create a comma separated list from all the elements in the array - CR delimits entry.
        log_entry = ""
        # record is: time, traic_temp, pressure, mems temp, current, motor speed, voltage, accelerometer readings, flux readings, ac mains voltage, ac mains freq, power
        
        log_entry = log_entry + str(datetime.datetime.now().strftime("%H%M%S%f")[:-4])
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.triac_temp_mV )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.pressure_mB )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.mems_temp_C )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.productCurrent_A )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.motor_speed_krpm )
        log_entry = log_entry + "," + str( self.parent_data.current_flow_offset )
        log_entry = log_entry + ","
        log_entry = log_entry + ","
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.dc_link_voltage )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.Acceleration_X )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.Acceleration_Y )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.Acceleration_Z )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.Flux_X )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.Flux_Y )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.Flux_Z )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.Flux_T )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.acMainsVoltageRms_V )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.ac_mains_freq )
        log_entry = log_entry + "," + str( "%.3f" % self.parent_data.productPower_W )

        # Append  linefeed
        log_entry = log_entry + "\n"

        logfile.write(log_entry)
        logfile.close

    # Draw the GUI items
    # Add a horizontal line
    def add_line(self, width=200, height=5, span=1, sticky=STICKY_NSEW, padx=2, pady=2):
        gui.Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = gui.Canvas(self, width=width, height=height)
        x.create_line(0, 2, width-1, 2)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        return x

# This function allows other scripts to start this script. Other scripts expect to see an exec function in this module.
# The script may be called using the gui.exec() function.
def exec(parent_app,parent_data, device,v9_device):
    app = this_app(parent=parent_app,parent_data=parent_data, title=APP_TITLE, device=device, v9_device=v9_device)
    return app


# Called by parent programs
def description():
    return APP_HELP;



# This code starts the app if the file is executed rather than imported.
if __name__ == '__main__':
    print(APP_TITLE)
    print(APP_HELP)
    print()
    # Get a connection to a device
    with sc_protocol.HC_Protocol(debug_level=0) as device:
        with v9_protocol.V9_Protocol(com_object=device) as v9_device:
            # Run the script
            app = exec(tkinter.Tk(), device, v9_device)
            app.mainloop()
            self.device.close()
            self.v9_device.close()

# End of Python script --------------------------------------- */
