#-------------------------------------------------------------------------------
# Name:        v9_protocol.py
#
# Purpose:     Provide the N505/V9 application layer of the DIPC protocol.
#
# Authors:     Nikita Shmidt, Przemyslaw Smereczynski
# Created:     30/05/2017
# Copyright:   (c) 2017 Dyson Technology Ltd.
#-------------------------------------------------------------------------------

import os
import json
import dipc_connection
import struct
from lec_protocol import *

TICKS_PER_US = 48

# N505 FCT commands and responses
FCT_H_BRIDGE_TEST_CMD               = 0x8502
FCT_H_BRIDGE_TEST_RES               = 0x8503
FCT_SENSORLS_TEST_CMD               = 0x8504
FCT_SENSORLS_TEST_RES               = 0x8505
FCT_MEASURE_ISENSE_CMD              = 0x8506
FCT_MEASURE_ISENSE_RES              = 0x8507
FCT_MEASURE_ISENSE_REQ              = 0x8508
FCT_ISENSE_MEAS_NOT_READY           = 0
FCT_ISENSE_MEAS_OK                  = 1
FCT_ISENSE_MEAS_ERROR               = 2
FCT_ERROR_WRONG_STATE               = 3

# EOL and FCT specific DIPC parameters
CALIB_ID_EOL_HIGH_POWER_TRIM_PWR    = 0x0002
CALIB_ID_EOL_HIGH_POWER_TRIM_ADJ    = 0x0003
CALIB_ID_EOL_MEDIUM_POWER_TRIM_PWR  = 0x0004
CALIB_ID_EOL_MEDIUM_POWER_TRIM_ADJ  = 0x0005
CALIB_ID_EOL_LOW_POWER_TRIM_PWR     = 0x0006
CALIB_ID_EOL_LOW_POWER_TRIM_ADJ     = 0x0007
CALIB_ID_EOL_CAL_TIMESTAMP          = 0x000A
CALIB_ID_EOL_CAL_RIG_ID             = 0x000B
CALIB_ID_EOL_AUTO_START             = 0x000C
CALIB_ID_FCT_V_DC_OFFSET            = 0x0010
CALIB_ID_FCT_V_DC_SLOPE             = 0x0011
CALIB_ID_FCT_COMP_REF_SLOPE         = 0x0018
CALIB_ID_FCT_CAL_RIG_ID             = 0x0019
CALIB_ID_FCT_CAL_TIMESTAMP          = 0x001A
CALIB_ID_FCT_PCBA_FCT_INFO          = 0x001B
CALIB_ID_EOL_FW_REF_SPEED           = 0x001C
CALIB_ID_FCT_SECURITY_BIT           = 0x001D
CALIB_ID_EOL_RTD_TEMP_OFFSET        = 0x001E
CALIB_ID_EOL_RTD_TEMP_SLOPE         = 0x001F
CALIB_ID_EOL_FET_TEMP_TRIP_LIMIT    = 0x0021
CALIB_ID_FCT_VRMS_AC_OFFSET         = 0x0511
CALIB_ID_FCT_VRMS_AC_SLOPE          = 0x0512
CALIB_ID_EOL_MOT_IND                = 0x0514
CALIB_ID_EOL_BEMF_100K              = 0x0515
CALIB_ID_EOL_BEMF_NORM_CONST        = 0x0518
CALIB_ID_EOL_AET_OFFSET             = 0x0519
CALIB_ID_EOL_AET_SLOPE              = 0x051A
CALIB_ID_EOL_HC_RAMPUP_SLOPE        = 0x051B
CALIB_ID_EOL_HC_CURRENT_LIMIT       = 0x051C
CALIB_ID_EOL_HC_DETACH_TIME         = 0x051D
CALIB_ID_EOL_MOT_IND_ENABLE         = 0x051E
CALIB_ID_EOL_TUNING_BYTE            = 0x051F
CALIB_ID_HLC_HIGH_RTD_RAW           = 0x0520
CALIB_ID_HLC_LOW_RTD_RAW            = 0x0522

# Generic motor DIPC paramters
PARAM_ID_POWER                      = 0x0100
PARAM_ID_VOLTAGE                    = 0x0102
PARAM_ID_CURRENT                    = 0x0104
PARAM_ID_SPEED                      = 0x0106
PARAM_ID_TEMPERATURE                = 0x0108
PARAM_ID_DRIVE_MODE                 = 0x1100


# N505-specific product  parameters
PARAM_ID_FILTER_INTERLOCK           = 0x8001
PARAM_ID_MEMS_TEMPERATURE           = 0x8002
PARAM_ID_MEMS_PRESSURE              = 0x8003
PARAM_ID_MEMS_ATMOS_PRESSURE        = 0x800b
PARAM_ID_FILTER_WASH                = 0x8005
PARAM_ID_RTD_TEMP                   = 0x8603
PARAM_ID_AET_TEMP                   = 0x8605
PARAM_ID_EOL_RTD_TEMP_RAW           = 0x8600
PARAM_ID_EOL_AET_TEMP_RAW           = 0x8604
PARAM_ID_EOL_FET_TEMP_RAW           = 0x8601
PARAM_ID_MAINS_VOLTAGE_RMS          = 0x8500
PARAM_ID_FCT_MAINS_VOLTAGE_AVE_RAW  = 0x8501
PARAM_ID_FCT_VDC_RAW                = 0x8602
PARAM_ID_MAINS_PERIOD               = 0x8502
PARAM_ID_ISENSE_SAMPLE_COUNT        = 0x8504
PARAM_ID_ISENSE_VALUES              = 0x8506
PARAM_ID_ISENSE_FETCH_STATUS        = 0x8508
PARAM_ID_ISENSE_RESULT_ARRAY_PAGE   = 0x850A

# Configuration ID's for the Ebox
CONFIG_ID_POWER_MODES               = 0x0001
CONFIG_ID_BEHAVIOR_FLAGS            = 0x0002
CONFIG_ID_POWER_MODE_POWER_BASE     = 0x1000 
CONFIG_ID_USAGE_DATA_BASE           = 0x2000
CONFIG_ID_CALIBRATION_DATA_BASE     = 0x3000
CONFIG_ID_ERROR_DATA_BASE           = 0x4000
CONFIG_ID_EEPROM_DATA_BASE          = 0x5000
CONFIG_ID_XXTEA_KEY                 = 0x8102

class V9_Protocol(LecProtocol):

    # Cut and Paste from tAppErrorCode in app.h. This is done rather than analysing the header file to allow the enums to
    # be used without an accompanying hex file.
    ERROR_CODES = """
        APP_NO_ERROR_ID  = 0,                           //!<  0-No an error code, represents no error.
        APP_UNDER_SPEED_ERROR_ID,                       //!<  1-The speed has dropped below the bottom of the map in steady state
        APP_OVER_SPEED_ERROR_ID,                        //!<  2-The speed has gone above the top of the map in steady state
        APP_BLOCKAGE_SPEED_ERROR_ID,                    //!<  3-The vac motor is blocked and the speed is above the specified blockage speed.
        APP_UNDER_VOLTAGE_ERROR_ID,                     //!<  4-System voltage too low (either at start up or whilst running)
        APP_OVER_VOLTAGE_ERROR_ID,                      //!<  5-Too much system voltage (either at start up or whilst running)
        APP_CURRENT_ERROR_ID,                           //!<  6-A FET is stuck either short or open.
        APP_UNDER_TEMP_ERROR_ID,                        //!<  7-The MEMS temperature sensor is too cold.
        APP_OVER_TEMP_ERROR_ID,                         //!<  8-The MEMS temperature sensor is too hot.
        APP_FILTER_INTERLOCK_ERROR_ID,                  //!<  9-The filter has been removed during operation or is absent during startup
        APP_FAIL_TO_START_ERROR_ID,                     //!<  10-The motor is not moving on start up.  
        APP_FAIL_TO_ACCELERATE_ERROR_ID,                //!<  11-The motor has stopped accelerating before expected. 
        APP_HALL_WINDOW_ERROR_ID,                       //!<  12-Hall window errors 
        APP_UNKNOWN_POWER_MODE_ERROR_ID,                //!<  13-The requested power mode is not available
        APP_SOFTWARE_ERROR_ID,                          //!<  14-Internal SW related error
        APP_MEMS_READ_FAILURE_ID,                       //!<  15-Hard fault exception. address of hard fault ASSERT return stored in RAM    
        APP_WATCHDOG_ERROR_ID,                          //!<  16-Hardware watchdog was triggered. Parameter is where the last WATCHDOG_NOTE() macro was executed.
        APP_DERATING_ERROR_ID,                          //!<  17-Error codes for de-rating protections
        APP_RESYNC_ERROR_ID,                            //!<  18-Re-synchronisation failure
        APP_ZERO_CROSS_ERROR_ID,                        //!<  19-Zero cross detection failure
        APP_REVERSE_FLOW_PRESSURE_ERROR_ID              //!<  20-Reverse flow pressure error
    """

    # Cut and Paste from tAppSystemState in app.h. This is done rather than analysing the header file to allow the enums to
    # be used without an accompanying hex file.
    SYSTEM_STATES = """
        APP_RESET_SYSTEM_STATE  = 0,         //!<  0-Starting. The software has just reset. Comms not set up yet.
        APP_BOOTED_SYSTEM_STATE,             //!<  1-Starting. Default comms has been initialised.
        APP_CONFIG_SYSTEM_STATE,             //!<  2-Starting. App config data in flash has been verified.
        APP_EEPROM_SYSTEM_STATE,             //!<  3-Starting. EEPROM data hase been loaded.
        APP_HAL_INIT_SYSTEM_STATE,           //!<  4-Starting. Initialising HAL.
        APP_INIT_PROTECTIONS_SYSTEM_STATE,   //!<  5-Starting. Checking initial protections.
        APP_MAINS_SENSE_SYSTEM_STATE,        //!<  6-Starting. Checking mains AC frequency and doing soft start.
        APP_IDLE_SYSTEM_STATE,               //!<  7-Idling. The device is waiting to be told to start.
        APP_STATIONARY_START_SYSTEM_STATE,   //!<  8-Stationary Start. The device is attempting to start the motor.
        APP_ADAPTIVE_START_SYSTEM_STATE,     //!<  9-Adaptive start-up.
        APP_ACCELERATION_SYSTEM_STATE,       //!< 10-Single switch retarded control acceleration.
        APP_RESYNC_SYSTEM_STATE,             //!< 11-Resynchronisation state
        APP_STEADY_STATE_SYSTEM_STATE,       //!< 12-Steady state
        APP_SHUTDOWN_SYSTEM_STATE,           //!< 13-The motor is shutting down
        APP_TERMINATE_SYSTEM_STATE           //!<  X-Terminating the main loop.  Not in use.
    """

    def __init__(self, **kwargs):
        if not('timeout' in kwargs):
            kwargs['timeout']      = -1        
        kwargs['protocol_byte']    = kwargs.pop('protocol_byte', 0x00)    # 0 = (Data link version=2, Network version=2, Application version=2)
        kwargs['baud']             = kwargs.pop('baud', 115200)           # By default, the V10 protocol is 115200, 8 data bits, 1 stop bit, no parity
        kwargs['source_addr']      = kwargs.pop('source_addr', 0xf0)      # Lets choose a high source number for this library
        kwargs['destination_addr'] = kwargs.pop('destination_addr', 0x01) # By default, talk to the V10 VAC App (0x03) not the V10 VAC boot loader (0x83)
        LecProtocol.__init__(self, **kwargs)
        self.previous_function_addr = dict()
        self.previous_variable_addr = dict()
        self.enums = dict()
        self.process_enum(self.ERROR_CODES, 'ERROR_CODES')
        self.process_enum(self.SYSTEM_STATES, 'SYSTEM_STATES')
        self.power_mode_data = None
        self.post_process_data = None
        self.terminated = False        
        self.hex_file_name = kwargs.get('hex_file', '/emag_scripts/ddm_motor.hex')

    # returns the timeout flag (true if the connection timed out)
    def check_timeout(self):
        return self.connection.user_data['timeout']

    def terminate(self):
        self.terminated = True
        self.connection.close()
        
    # This function is used when the device disconnects and a possibly new bit of code re-connects.
    # Existing gathered information needs to ge forgotten
    def forget(self):
        self.previous_function_addr = dict()
        self.previous_variable_addr = dict()
        self.power_mode_data = None
        self.post_process_data = None

    # Take the enum string and parse. Add to self.enums for use by enum_name_to_value and enum_value_to_name.
    def process_enum(self, str, enum_name):
        enum_index = 0
        self.enums[enum_name] = dict()
        self.enums['array:' + enum_name] = []
        for line in str.split('\n'):
            parts = line.replace('/', ' ').replace(',', ' ').replace('=', ' ').split()
            if len(parts) > 0:
                name = parts[0]
                self.enums[enum_name][name] = enum_index
                self.enums['array:' + enum_name].append(name)
                enum_index += 1

    # Given an enum name ('ERROR_CODES' or 'SYSTEM_STATES') and enum entry name, return the value of the enum entry. E.g.
    #   i = device.enum_name_to_value('ERROR_CODES', 'APP_INVALID_CONFIG_ERROR_ID')
    def enum_name_to_value(self, enum_name, value_name):
        if not enum_name in self.enums:
            raise Exception('Unknown enum %s' % enum_name)
        if not value_name in self.enums[enum_name]:
            raise Exception('Unknown enum value %s in enum %s' % (value_name, enum_name))
        return self.enums[enum_name][value_name]

    # Given an enum name ('ERROR_CODES' or 'SYSTEM_STATES'), return the name of the enum entry or UNKNOWN if the value is incorrect. E.g.
    #   s = device.enum_value_to_name('ERROR_CODES', 7)
    def enum_value_to_name(self, enum_name, value):
        if not enum_name in self.enums:
            raise Exception('Unknown enum %s' % enum_name)
        if value >= len(self.enums['array:'+enum_name]):
            return 'UNKNOWN_ENUM'
        return self.enums['array:'+enum_name][value]

    def close(self):
        self.connection.close()

    # Reset the device without invoking the bootloader
    def reset_device(self):
        msg = self.command_messages()
        msg.add(DEV_RESET_CMD())
        self.send(msg, retries = -1)

    # Return True if there is access to debug commands (peek/poke)
    def debug_available(self):
        try:
            self.get_post_process_data()
        except:
            return False
        return True

    #
    # Load data about the build from the JSON data appended to the hex file. This is usually only done if
    # the calling code requires such information.
    #
    def get_post_process_data(self):
        err = None
        if self.post_process_data == None:
            try:
                # Get the build timestamp of the software
                msg = self.command_messages()
                msg.add(SOFTWARE_TIMESTAMP_REQ())   # Set the variable to a known value
                self.send(msg, retries=3)
                self.build_timestamp = msg.results[0].timestamp
                # Get the JSON data
                try:
                    f = open(os.environ['PROJECT_DIR'] + '/support_scripts/json.dat', 'r')
                    self.post_process_data = json.load(f)
                    f.close()
                except:
                    pass
                try:
                    filename = os.environ['PROJECT_DIR'] + '/' + self.hex_file_name
                    file = open(filename, 'r')
                    line = file.readline()
                    while line[0] == ':':
                        line = file.readline()
                    self.post_process_data = json.loads(line)
                    file.close()
                except:
                    pass
                # Is the timestamp of the data file different from the device timestamp
                if self.post_process_data['build_timestamp'] != self.build_timestamp:
                    # Having different timestamps make it very likely that the addresses will be incompatible.
                    err = "ERROR: The application data file %s has a different timestamp to the device." % filename
                # Add the structure data from an array to a dict for use by get_member_offset_size()
                structs_data = dict()
                for struct_name in self.post_process_data['structs']:
                    structs_data['key:'+struct_name] = dict()
                    for member in self.post_process_data['structs'][struct_name]:
                        structs_data['key:'+struct_name][member['name']] = member
                for key, value in structs_data.items():
                    self.post_process_data['structs'][key] = value

            except:
                err = "ERROR: Could not read or process application data file"
        if err != None:
            self.post_process_data = None
            raise BaseException(err)


    # Given a function name, this function will return the function address.
    def get_function_addr(self, name):
        # If we know this name already, just return the address
        if name in self.previous_function_addr:
            return self.previous_function_addr[name]
        # Have we loaded the post process data?
        self.get_post_process_data()
        # Is the function in the list of functions composed at compile time?
        if not name in self.post_process_data['functions']:
            err = "Could not find function '%s' in application data file." % name
            print(err)
            raise NameError(err)
        addr = self.post_process_data['functions'][name]['addr']
        self.previous_function_addr[name] = addr  # Next time we ask for this function, we will get it from previous_function_addr
        return addr


    # Given a variable name, this function will return the variable address and size.
    # E.g.
    #    addr,size = get_variable_addr('m_error_code'):
    #    addr,size = get_variable_addr('fshSystemConstants.uart_baud', struct='tFshSystemConstants'):
    #    addr,size = get_variable_addr('?.uart_baud', struct='tFshSystemConstants', addr=0x20000432):
    def get_variable_addr(self, name, struct=None, addr=None):
        if struct==None:
            struct = ''
        # If we know this name already, just return the address
        if addr == None and name+':'+struct in self.previous_variable_addr:
            return self.previous_variable_addr[name+':'+struct]
        # Is the variable in a structure and the structure not specified?
        if '.' in name and struct == '':
            err = "get_variable_addr('%s', struct=None): Structure variables must have the structure name specified." % name
            print(err)
            raise NameError(err)
        # Have we loaded the post process data?
        self.get_post_process_data()
        # If the variable is a structure variable, get the offset
        struct_offset = 0
        struct_size = 0
        if '.' in name:
            i = name.find('.')
            # Is the reference a multiple structure reference
            # E.g.    addr,size = get_variable_addr('fshSystemConstants.filter_wash.pressure_coef', struct='tFshSystemConstants.tFilterWashConstants'):
            if name.find('.', i+1) != -1:
                k = name.find('.', i+1)
                j = struct.find('.')
                first_struct  = struct[:j]      # tFshSystemConstants
                other_structs = struct[j+1:]    # tFilterWashConstants
                first_name    = name[:i]        # fshSystemConstants
                second_name   = name[i+1:k]     # filter_wash
                other_names   = name[k+1:]      # pressure_coef
                addr2, size2 = self.get_variable_addr(first_name+'.'+second_name, first_struct, addr=addr)
                struct_offset, struct_size = self.get_member_offset_size(first_struct, second_name)
                result, size = self.get_variable_addr('?.' + other_names, other_structs, addr=addr2)
                return result, size
            else:
                # A simple struct request
                # E.g.    addr,size = get_variable_addr('fshSystemConstants.filter_wash', struct='tFshSystemConstants'):
                struct_offset, struct_size = self.get_member_offset_size(struct, name[i+1:])
                name = name[:i]  # Remove the structure member name leaving just the data structure variable name
        # Is the function in the list of functions composed at compile time?
        if name == '?':
            if addr == None:
                err = "Structure address '%s' not specified." % name
                print(err)
                raise NameError(err)
        elif not name in self.post_process_data['variables']:
            err = "Could not find variable '%s' in application data file." % name
            print(err)
            raise NameError(err)
        else:
            addr = self.post_process_data['variables'][name]['addr']
            size = self.post_process_data['variables'][name]['size']
        if struct_size != 0:
            addr += struct_offset
            size = struct_size
        self.previous_variable_addr[name+':'+struct] = (addr, size)  # Next time we ask for this variable, we will get it from previous_variable_addr
        return addr, size

    # Get the release string. This may take several messages depending on the length of the release string
    def get_release_str(self):
        offset = 0
        length = 64
        finished = False
        str = ''
        while not finished:
            msg = self.command_messages()
            msg.add(SOFTWARE_RELSTR_REQ(offset, max_len=length))
            self.send(msg, retries=3)
            offset += length
            str += msg.results[0].str
            finished = msg.results[0].finished
        return str


    #
    # GetMemberOffset
    #   Given a structure name and member name, return the offset and size of the member.
    #
    def get_member_offset_size(self, struct_name, member_name):
        self.get_post_process_data()
        try:
            x = self.post_process_data['structs']['key:'+struct_name]
        except:
            print('V10VacDataLink.get_member_offset_size: ERROR: struct %s not found' % struct_name)
            return None
        try:
            x = x[member_name]
        except:
            print('V10VacDataLink.get_member_offset_size: ERROR: member %s of struct %s not found' % (member_name, struct_name))
            return None
        return x['offset'],x['size']

    #
    # This function performs a peek command (of an address).
    # This function is inefficient because it sends only one command in a message. It should be used
    # as a convienience where run-time is not important.
    #
    # Usage:
    #     value = device.peek_addr(addr)
    #
    def peek_addr(self, addr):
        msg = self.command_messages()
        msg.add(MEMORY_CONTENT_REQ(addr))
        self.send(msg)
        return msg.results[0].value

    #
    # This function performs a peek command (of a variable).
    # This function is inefficient because it sends only one command in a message. It should be used
    # as a convienience where run-time is not important.
    #
    # Usage:
    #     value = device.peek_var('appStatus')
    #     value = device.peek_var('device_speed', signed=True)
    #     value = device.peek_var('fshSystemConstants.uart_baud', struct='tFshSystemConstants')
    #     value = device.peek_var('?.uart_baud', struct='tFshSystemConstants', addr=0x20000432)
    #
    def peek_var(self, name, struct=None, addr=None, signed=False, floatvar=False):
        msg = self.command_messages()
        msg.add(GET_VAR(name, struct=struct, addr=addr, signed=signed, floatvar=floatvar))
        self.send(msg)
        return msg.results[0].value

    #
    # This function performs a poke command to the specified address.
    # This function is inefficient because it sends only one command in a message. It should be used
    # as a convienience where run-time is not important.
    #
    # Usage:
    #     device.poke_addr(0x200000, 0x12345678)
    #     device.poke_addr(0x200000, 0xff, mask=0xffff)
    #
    def poke_addr(self, addr, value, mask=0xffffffff):
        msg = self.command_messages()
        msg.add(MEMORY_CONTENT_CMD(addr, value, mask))
        self.send(msg)

    #
    # This function performs a poke command (of a variable).
    # This function is inefficient because it sends only one command in a message. It should be used
    # as a convienience where run-time is not important.
    #
    # Usage:
    #     device.poke_var('appStatus', 55)
    #     device.poke_var('device_speed', -77, signed = True)
    #     device.poke_var('fshSystemConstants.uart_baud', 33, struct='tFshSystemConstants')
    #     device.poke_var('?.uart_baud', 0xff, struct='tFshSystemConstants', addr=0x20000432)
    #
    def poke_var(self, name, value, struct=None, addr=None, signed=False, floatvar=False):
        msg = self.command_messages()
        msg.add(SET_VAR(name, value, struct=struct, addr=addr, signed=signed, floatvar=floatvar))
        self.send(msg)

    #
    # Call the specified function.
    # This function is inefficient because it sends only one command in a message. It should be used
    # as a convenience where run-time is not important.
    #
    # Usage:
    #     result = device.call('nvmEraseEepromRow', [0])
    #
    def call_func(self, name, params=[]):
        msg = self.command_messages()
        msg.add(CALL(name, params))
        self.send(msg)
        return msg.results[0].result


    # Get details of the power modes installed on the device.
    # Refunction returns an array of dictionaries holding power mode data (highest power first)
    # Currently, the only dictionary item is 'power' (Target power in watts)
    # E.g.
    #   number_of_power_modes = len(device.get_power_mode_data())
    #   first_power_mode_power = device.get_power_mode_data()[0]['power']
    #
    # Note: This function can only be used if debug data is available.
    #
    def get_power_mode_data(self):
        if self.power_mode_data != None:
            return self.power_mode_data

        # Get the number of power modes
        msg = self.command_messages()
        msg.add(GET_POWER_MODES())
        self.send(msg)
        number_of_power_modes = msg.results[0].value
        addr, size = self.get_variable_addr('fshSystemConstants.pModes', struct='tFshSystemConstants')

        # Get information about the power modes and add the power buttons
        self.power_mode_data = []
        for power_index in range(number_of_power_modes):
            self.power_mode_data.append(dict())
            msg = self.command_messages()
            msg.add(GET_POWER_MODE_POWER(power_index))
            msg.add(MEMORY_CONTENT_REQ(addr + 4 * power_index))
            self.send(msg)
            self.power_mode_data[power_index]['power'] = msg.results[0].power_W
            self.power_mode_data[power_index]['addr']  = msg.results[1].value    # The address of the power mode data structure
        return self.power_mode_data

    # Return a byte array of the current RAM copy of the error page.
    def get_error_data(self):
        error_data = bytearray()
        for i in range(16):
            msg = self.command_messages()
            msg.add(GET_ERROR_EEPROM_DATA(index = i))
            self.send(msg)
            for j in range(16):
                error_data.append(msg.results[0].data[j])
        return error_data
        
    def download_app(self, hex):
        startAddr = 0x2000   # Size of bootloader

        # Send a reset cmd to put the device in bootloader mode
        print("Sending RESET_CMD")
        msg = self.command_messages()
        msg.add(RESET_CMD())
        self.send(msg, retries=-1)
        time.sleep(0.5)
    
        # Invalidate the validity flag. This flag is the first word of the application meta data.
        # We do not want to download the valid value and make a partial download think it is complete.
        hex[startAddr + 0] = 0xff
        hex[startAddr + 1] = 0xff
        hex[startAddr + 2] = 0xff
        hex[startAddr + 3] = 0xff
    
        lastChunkNo = -1
        RetransmissionCnt = 0         
        chunkNo = 0
        chunkAddr = startAddr
        chunkLength = 64
        batch = 0xf0
        iv = 0xF0DEBC9A78563412
    
        # Make the hex size a multiple of 64 bytes. The bootloader does not work with partial chunks.
        while (hex.maxaddr()+1 & 63) != 0:
            print("Padding %.8x" % (hex.maxaddr()+1))
            hex[hex.maxaddr()+1] = 0xff
    
        max_addr = hex.maxaddr()+1
        print("Max_Addr = %d  0x%x" % (max_addr,max_addr))
        max_chunk = (max_addr - startAddr) // chunkLength
        print("Max chunk = %d" % max_chunk)
    
        # Change the destination address to the bootloader destination address
        bootloader_addr = 1
        app_addr        = self.connection.destination_addr
    
        print("Send a START_UPDATE_CMD")
        payload = bytearray()
        payload.extend(int(batch).to_bytes(1, byteorder='little', signed=False))   # Batch number
        payload.extend(int(0x0104).to_bytes(2, byteorder='little', signed=False))  # START_UPDATE_CMD Command ID
        payload.extend(int(iv).to_bytes(8, byteorder='little', signed=False))      # IV
        payload.extend(int(0).to_bytes(4, byteorder='little', signed=False))       # Start chunk = 0
        self.connection.sendFrame(payload, destination_addr=bootloader_addr)

        running = True
        time_of_last_valid_packet = time.time()
        chunkAddr = startAddr + chunkNo*chunkLength
        length = chunkLength

   
        while running and not self.terminated:
            packet = self.connection.getFrame(timeout=0.5, destination_addr=bootloader_addr)
            if packet == None and time.time() > (time_of_last_valid_packet + 3):
                print("Timeout")
                return False
            if packet != None and packet.destination_addr == self.connection.source_addr and packet.source_addr == bootloader_addr:
                time_of_last_valid_packet = time.time()
                cmdId = int.from_bytes(packet.data[1:3], byteorder='little', signed=False)
                if cmdId == 0x0206:  #GET_CHUNK_CMD
                    chunkNo = int.from_bytes(packet.data[3:7], byteorder='little', signed=False)
                    retry_string = ""
                    if(chunkNo == lastChunkNo):
                        RetransmissionCnt+=1
                        retry_string = "RETRY"
                    lastChunkNo = chunkNo    

                    chunkAddr = startAddr + chunkNo*chunkLength
                    print("GET_CHUNK_CMD %d of %d %s" % (chunkNo, max_chunk,retry_string))
                
                    if chunkAddr >= max_addr:
                        print("Zero chunk")
                        length = 0  # Transmit an empty chunk
                        running = False
                    
                    chunk = bytearray()
                    for i in range(length):
                        chunk.append(hex[chunkAddr + i])
                
                    reply = bytearray()
                    reply.extend(int(batch).to_bytes(1, byteorder='little', signed=False))        # Batch number
                    reply.extend(int(0x0207).to_bytes(2, byteorder='little', signed=False))       # CHUNK_READ_RES
                    reply.extend(int(chunkNo).to_bytes(4, byteorder='little', signed=False))      # Chunk number
                    reply.extend(int(len(chunk)).to_bytes(2, byteorder='little', signed=False))   # Chunk length
                    reply.extend(chunk)                                                            # Chunk data
                    self.connection.sendFrame(reply, destination_addr=bootloader_addr)
    
                if cmdId == 0x2000:  #RESET_EVENT
                    # We should not get a reset event at this stage.
                    print("RESET_EVENT")
                    return False
                
                if cmdId == 0x2100:  #CHUNK_PROCESSED_EVENT
                    # This script ignores the 'chunk processed' event.
                    pass # print("CHUNK_PROCESSED_EVENT")

        time.sleep(0.5)
        print()
        cmd = bytearray()
        cmd.extend(int(batch).to_bytes(1, byteorder='little', signed=False))        # Batch number
        cmd.extend(int(0x0102).to_bytes(2, byteorder='little', signed=False))       # APP_START_CMD
        self.connection.sendFrame(cmd, destination_addr=bootloader_addr)
        time.sleep(0.5)  
        print("Total Retranmsissions this download attempt = %d" % RetransmissionCnt)        
        print("Waiting for final packet")

        packet = self.connection.getFrame(destination_addr=0xff)
        if packet == None:
            print("No response ")
            # return True No response and yet the app starts(this appears to be a feature of the V9 bootloader)
        elif packet.data[1:3] == b'\x03\x01':
            print("FAILURE: APP_START_RES 0x%02x" % packet.data[3])
            return True # fixme
        elif packet.source_addr != app_addr:
            print("Download complete")
        
        # Clear the input buffer by accepting any message
        time.sleep(0.5)
        while self.connection.getFrame(timeout=0.5, destination_addr=0xff) != None:
            pass

        # Send a message to illicit a response. This is in case the V10 is not in BMS mode and is just listening.
        print("Talking to application to ensure download was successful...")
        msg = self.command_messages()
        msg.add(SOFTWARE_VERSION_REQ())
        self.send(msg, retries=-1)

        # Get any responses
        # If the V10 is in BMS mode, we should hear a poll message
        # Doing this several times means we can get a bad frame but a subsequent good frame still works.
        response = self.connection.getFrame(timeout = 0.5, destination_addr=None)
        if response == None:
            response = self.connection.getFrame(timeout = 0.5, destination_addr=None)
        if response == None:
            response = self.connection.getFrame(timeout = 0.5, destination_addr=None)
        if response == None:
            response = self.connection.getFrame(timeout = 0.5, destination_addr=None)
        
        # Did we get no responses
        if response == None:
            print("No response from application.")
            time.sleep(1)
            raise Exception("No response from application")
        elif response.source_addr != app_addr:
            time.sleep(1)        
            raise Exception("Unexpected application address !")
        print()
        return True  
        
    def download_app_from_file(self, filename,retries=-1):
        import project_intelhex as intelhex
        if not os.path.isfile(filename):
            print("Can not find %s" % filename)
            return
        hex = intelhex.IntelHex(filename)
        success = False
        while ((not success) and (retries!=0)):
            try:
                success = self.download_app(hex)
            except:
                if self.terminated:
                    self.close()
                    return 1
                else:
                    print("Retry...")
            if(retries>0):
                retries-=1
        return 0        

#
# V10 specific protocol commands
#

# Sets the autostart configuration setting.
# Arguments  value = 0:          Use power mode selection switches,
#                    1:          Motor does not start on power up
#                    'switches': Use power mode selection switches,
#                    'no_start': Motor does not start on power up
#                    Otherwise:  Value is an integer of the desired Power level in Watts.
#                    If exact power can not be found, the next lower power level is used.
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_AUTOSTART(value='switches'))
#     device.send(msg)
# or
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_AUTOSTART(value=525))
#     device.send(msg)
class SET_AUTOSTART(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        val = 0
        if   value == 'switches':  val = 0
        elif value == 'no_start':  val = 1
        else: val = value
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_AUTO_START, cal_data = val.to_bytes(2, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)


# Gets the autostart configuration setting.
# Results  value = 0-Use switches, 1-No motor start otherwise value is desired Power level in Watts.
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_AUTOSTART())
#     device.send(msg)
#     print("autostart=%s" % msg.results[0].value)
class GET_AUTOSTART(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_AUTO_START, **kwargs)
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index




# Sets the behaviour flags
# Arguments  flags = a dictionary where if the flag name is present and non-zero, the flag will be set.
#     flag names are 'filter-interlock' - The filter interlock check (0=Check disabled)
#                    'de-rating'        - The de-rating flag (0=De-rating not enabled)
# Usage:
#     # Disable the interlock check
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_BEHAVIOUR_FLAGS())
#     device.send(msg)
#     msg.results[0].flags['filter-interlock'] = 0
#     msg2 = device.command_messages()
#     msg2.add(v9_protocol.SET_BEHAVIOUR_FLAGS(msg.results[0].flags))
#     device.send(msg2)
class SET_BEHAVIOUR_FLAGS(CONFIGURE_CMD):
    bits = [ 'disable braking',
             'disable current trip',
             'disable relay check',
             'fct_mode',
             'enable reverse flow',
             'disable_calibration_write',
             'disable_turn_off_relay',
             'disable_ebox_hc_heartbeat']
    def __init__(self, flags=dict(), **kwargs):
        flags_int = 0
        for i in range(len(self.bits)):
            bit = self.bits[i]
            if (bit in flags) and (flags[bit] != 0): flags_int += 1 << i
        flags_int = kwargs.pop('mask', flags_int)
        CONFIGURE_CMD.__init__(self, config_id = CONFIG_ID_BEHAVIOR_FLAGS, config_data = flags_int.to_bytes(1, byteorder='little', signed=False), name='SET_BEHAVIOUR_FLAGS', **kwargs)
    def process_response(self, msg, index):
        return CONFIGURE_CMD.process_response(self, msg, index)


# Gets the state of the behaviour flags.
# Arguments   None
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_BEHAVIOUR_FLAGS())
#     device.send(msg)
#     print("Filter interlock feature = %d" % msg.results[0].flags['filter-interlock'])
#     print("De-rating feature        = %d" % msg.results[0].flags['de-rating'])
class GET_BEHAVIOUR_FLAGS(CONFIGURE_REQ):
    bits = SET_BEHAVIOUR_FLAGS.bits
    def __init__(self, **kwargs):
        CONFIGURE_REQ.__init__(self, config_id = 2, name = 'GET_BEHAVIOUR_FLAGS', **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CONFIGURE_REQ.process_response(self, msg, index)
        flag_bits = int.from_bytes(self.config_data, byteorder='little', signed=False)
        self.flags = dict()
        for i in range(len(self.bits)):
            bit = self.bits[i]
            self.flags[bit] = (flag_bits >> i) & 1
        self.mask = flag_bits
        return index


# Gets the number of available power modes.
# Results  value = 1, 2, 3...
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_POWER_MODES())
#     device.send(msg)
#     print("Number of power modes = %s" % msg.results[0].value)
class GET_POWER_MODES(CONFIGURE_REQ):
    def __init__(self, **kwargs):
        CONFIGURE_REQ.__init__(self, config_id = CONFIG_ID_POWER_MODES, name='GET_POWER_MODES', **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CONFIGURE_REQ.process_response(self, msg, index)
        self.value = self.config_data[0]
        if self.debug_level > 20:
            print("Adding GET_POWER_MODES result (%d)" % self.value)
        return index


# Get the target power of the specified power mode.
# Results  value = power of mode in Watts
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_POWER_MODE_POWER(index=0))
#     device.send(msg)
#     print("Target power of power mode index 0 = %f W" % msg.results[0].power_W)
class GET_POWER_MODE_POWER(CONFIGURE_REQ):
    def __init__(self, index, **kwargs):
        CONFIGURE_REQ.__init__(self, config_id = CONFIG_ID_POWER_MODE_POWER_BASE +index, name='GET_POWER_MODE_POWER(%d)' % index, **kwargs)
        self.value = None
        self.index = index
    def process_response(self, msg, index):
        index = CONFIGURE_REQ.process_response(self, msg, index)
        self.power_W = int.from_bytes(self.config_data, byteorder='little', signed=True) / 1000.0
        if self.debug_level > 20:
            print("Adding GET_POWER_MODE_POWER(%d) result (%f W)" % (self.index, self.power_W))
        return index

# Get the specified chunk of raw EEPROM data.
# Arguments: index = This is a 12bit integer with the first 4 bites indicate which  block of 16 bytes
# and the msbyte represents the page number 0 - 32 (in the case of v10 - samc21 chipset)
# Results  data = 16 byte bytearray of EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_RAW_EEPROM_DATA(index=3))
#     device.send(msg)
#     print("The forth chunk of EEPROM data is ", msg.results[0].data)  # data is a byte array of 16 bytes
class GET_RAW_EEPROM_DATA(CONFIGURE_REQ):
    def __init__(self, index, **kwargs):
        CONFIGURE_REQ.__init__(self, config_id = CONFIG_ID_EEPROM_DATA_BASE+index, name='GET_EEPROM_DATA(%d)' % index, **kwargs)
        self.data = None
        self.index = index
    def process_response(self, msg, index):
        index = CONFIGURE_REQ.process_response(self, msg, index)
        self.data = self.config_data
        if self.debug_level > 20:
            print("GET_RAW_EEPROM_DATA(%d) result " % self.index, self.data)
        return index


# This function writes 16 bytes of data to eeprom.
#
# Arguments: index = This is a 12bit integer with the first 4 bites indicate which  block of 16 bytes
# and the msbyte represents the page number 0 - 32 (in the case of v10 - samc21 chipset)
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.WRITE_EEPROM_DATA(index=3))
#     device.send(msg)
class WRITE_EEPROM_DATA(CONFIGURE_CMD):
    def __init__(self, index, eeprom_data, **kwargs):
        CONFIGURE_CMD.__init__(self, config_id = CONFIG_ID_EEPROM_DATA_BASE+index, config_data = eeprom_data, name='WRITE_EEPROM_DATA(%x)'% index, **kwargs)
        self.data = None
        self.index = index
    def process_response(self, msg, index):
        self.data = self.config_data
        if self.debug_level > 20:
            print("WRITE_EEPROM_DATA(%x) result " % self.index, self.data)
        return CONFIGURE_CMD.process_response(self, msg, index)

# Get the specified chunk of error EEPROM data.
# There are 16 possible chunk numbers, each of 16 bytes making a total of 256 bytes.
# Arguments: index = eeprom chunk number. (0-15)
# Results  data = 16 byte bytearray of EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_ERROR_EEPROM_DATA(index=3))
#     device.send(msg)
#     print("The forth chunk of EEPROM data is ", msg.results[0].data)  # data is a byte array of 16 bytes
class GET_ERROR_EEPROM_DATA(CONFIGURE_REQ):
    def __init__(self, index, **kwargs):
        CONFIGURE_REQ.__init__(self, config_id = CONFIG_ID_ERROR_DATA_BASE+index, name='GET_EEPROM_DATA(%d)' % index, **kwargs)
        self.data = None
        self.index = index
    def process_response(self, msg, index):
        index = CONFIGURE_REQ.process_response(self, msg, index)
        self.data = self.config_data
        if self.debug_level > 20:
            print("GET_ERROR_EEPROM_DATA(%d) result " % self.index, self.data)
        return index

# Get the specified chunk of Config EEPROM data.
# There are 16 possible chunk numbers, each of 16 bytes making a total of 256 bytes.
# Arguments: index = eeprom chunk number. (0-15)
# Results  data = 16 byte bytearray of EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_CONFIG_EEPROM_DATA(index=3))
#     device.send(msg)
#     print("The forth chunk of EEPROM data is ", msg.results[0].data)  # data is a byte array of 16 bytes
class GET_CONFIG_EEPROM_DATA(CONFIGURE_REQ):
    def __init__(self, index, **kwargs):
        CONFIGURE_REQ.__init__(self, config_id = CONFIG_ID_USAGE_DATA_BASE + index, name='GET_EEPROM_DATA(%d)' % index, **kwargs)
        self.data = None
        self.index = index
    def process_response(self, msg, index):
        index = CONFIGURE_REQ.process_response(self, msg, index)
        self.data = self.config_data
        if self.debug_level > 20:
            print("GET_CONFIG_EEPROM_DATA(%d) result " % self.index, self.data)
        return index

# Get the specified chunk of calibration EEPROM data.
# There are 16 possible chunk numbers, each of 16 bytes making a total of 256 bytes.
# Arguments: index = eeprom chunk number. (0-15)
# Results  data = 16 byte bytearray of EEPROM data
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_CALIBRATION_EEPROM_DATA(index=3))
#     device.send(msg)
#     print("The forth chunk of EEPROM data is ", msg.results[0].data)  # data is a byte array of 16 bytes
class GET_CALIBRATION_EEPROM_DATA(CONFIGURE_REQ):
    def __init__(self, index, **kwargs):
        CONFIGURE_REQ.__init__(self, config_id = CONFIG_ID_CALIBRATION_DATA_BASE+index, name='GET_EEPROM_DATA(%d)' % index, **kwargs)
        self.data = None
        self.index = index
    def process_response(self, msg, index):
        index = CONFIGURE_REQ.process_response(self, msg, index)
        self.data = self.config_data
        if self.debug_level > 20:
            print("GET_CALIBRATION_EEPROM_DATA(%d) result " % self.index, self.data)
        return index
        
# Get 16 bytes XXTEA key for security bootloader
# Results  data = 16 byte bytearray of XXTEA key
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_XXTEA_KEY())
#     device.send(msg)
#     xxteaKey = int.from_bytes(msg.results[0].data[0:16], 'little', signed=False)  # data is a byte array of 16 bytes
#     print("The XXTEA key is 0x%032x" %xxteaKey)  
class GET_XXTEA_KEY(CONFIGURE_REQ):
    def __init__(self, **kwargs):
        CONFIGURE_REQ.__init__(self, config_id = CONFIG_ID_XXTEA_KEY, name='GET_XXTEA_KEY', **kwargs)
        self.data = None
    def process_response(self, msg, index):
        index = CONFIGURE_REQ.process_response(self, msg, index)
        self.data = self.config_data
        if self.debug_level > 20:
            print("GET_XXTEA_KEY result ", self.data)
        return index
        
# Write 16 bytes XXTEA key for security bootloader
# Arguments  xxteaKey  - buffer of 16 bytes data
# Results  data = 16 byte bytearray of EEPROM data
# Usage:
#     xxteaKey = bytearray(16) # need initialization
#     msg = device.command_messages()
#     msg.add(v9_protocol.WRITE_XXTEA_KEY(xxteaKey))
#     device.send(msg)
class WRITE_XXTEA_KEY(CONFIGURE_CMD):
    def __init__(self, xxteaKey, **kwargs):
        CONFIGURE_CMD.__init__(self, config_id = CONFIG_ID_XXTEA_KEY, config_data = xxteaKey, name='WRITE_XXTEA_KEY', **kwargs)
        self.data = None
    def process_response(self, msg, index):
        self.data = self.config_data
        if self.debug_level > 20:
            print("WRITE_XXTEA_KEY result ", self.data)
        return CONFIGURE_CMD.process_response(self, msg, index)

# Sets the EOL_CAL_TIMESTAMP configuration setting in raw units.
# Arguments timestamp - 32 bit timestamp (1970 format)
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_FCT_CAL_RIG_ID(timestamp=123))
#     device.send(msg)
class SET_EOL_CAL_TIMESTAMP(CALIBRATE_CMD):
    def __init__(self, timestamp, **kwargs):
        if timestamp >  0xFFFFFFFF: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_CAL_TIMESTAMP, cal_data = timestamp.to_bytes(4, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the EOL_CAL_TIMESTAMP configuration setting in degrees.
# Results  value  - 32 bit timestamp (1970 format)
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_FCT_CAL_TIMESTAMP))
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_EOL_CAL_TIMESTAMP(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_CAL_TIMESTAMP, **kwargs)
        self.timestamp = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.timestamp = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the EOL_CAL_RIG_ID configuration setting in raw units.
# Arguments  value  - 32 bit rig id
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_EOL_CAL_RIG_ID(rig_id=123))
#     device.send(msg)
class SET_EOL_CAL_RIG_ID(CALIBRATE_CMD):
    def __init__(self, rig_id, **kwargs):
        if rig_id >  0xFFFFFFFF: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_CAL_RIG_ID, cal_data = rig_id.to_bytes(4, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the EOL_CAL_RIG_ID configuration setting in degrees.
# Results  value  - 32 bit rig id
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_FCT_EOL_RIG_ID))
#     device.send(msg)
#     print("value=%d" % msg.results[0].rig_id)
class GET_EOL_CAL_RIG_ID(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_CAL_RIG_ID, **kwargs)
        self.rig_id = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.rig_id = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the SECURITY_BIT parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(hc_protocol.SET_SECURITY_BIT())
#     device.send(msg)
class SET_SECURITY_BIT(CALIBRATE_CMD):
    def __init__(self, **kwargs):
        state = 1
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_FCT_SECURITY_BIT, cal_data = state.to_bytes(1, byteorder='little', signed=True), **kwargs)
        self.value = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        return index

# Gets the SECURITY_BIT configuration setting in degrees.
# Results  0=bit not set, 1=bit set
# Usage:
#     msg = device.command_messages()
#     msg.add(hc_protocol.GET_SECURITY_BIT()))
#     device.send(msg)
#     print("value=%d" % msg.results[0].security_bit)
class GET_SECURITY_BIT(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_FCT_SECURITY_BIT, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.security_bit = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index
        
# Sets the power trim for high power modes.
# Arguments  trim_us  - Extra advance in uS
#            power    - Power trim is applied at in Watts
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_EOL_HIGH_POWER_TRIM(trim_us = 1.25, power_W=500.0))
#     device.send(msg)
class SET_EOL_HIGH_POWER_TRIM(CALIBRATE_CMD):
    def __init__(self, trim_us, power_W, **kwargs):
        self.error_str = None
        self.processing_time = 0
        value = int(trim_us * TICKS_PER_US)
        if value >  0x7fff: raise Exception("Out of range")
        if value < -0x8000: raise Exception("Out of range")
        self.trim_raw = value
        value = int(power_W)
        if value >  0x7fff: raise Exception("Out of range")
        if value < -0x8000: raise Exception("Out of range")
        self.power_W = int(value)
    def command_bytes(self):
        msg = bytearray()
        self.pwr  = CALIBRATE_CMD(cal_id = CALIB_ID_EOL_HIGH_POWER_TRIM_PWR, cal_data = self.power_W.to_bytes(2, byteorder='little', signed=False))
        self.trim = CALIBRATE_CMD(cal_id = CALIB_ID_EOL_HIGH_POWER_TRIM_ADJ, cal_data = self.trim_raw.to_bytes(2, byteorder='little', signed=True))
        msg = self.pwr.command_bytes()
        msg.extend(self.trim.command_bytes())
        return msg
    def process_response(self, msg, index):
        index = self.pwr.process_response(msg, index)
        index = self.trim.process_response(msg, index)
        return index

# Gets the power trim for high power modes.
# Results    trim_us  - Extra advance in uS
#            power    - Power trim is applied at in Watts
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_EOL_HIGH_POWER_TRIM())
#     device.send(msg)
#     print("trim=%f us" % msg.results[0].trim_us)
#     print("power=%d W" % msg.results[0].power_W)
class GET_EOL_HIGH_POWER_TRIM(CONFIGURE_CMD):
    def __init__(self, **kwargs):
        self.error_str = None
        self.processing_time = 0
        self.power_W   = None
        self.trim_us = None
    def command_bytes(self):
        msg = bytearray()
        self.pwr  = CALIBRATE_REQ(cal_id = CALIB_ID_EOL_HIGH_POWER_TRIM_PWR)
        self.trim = CALIBRATE_REQ(cal_id = CALIB_ID_EOL_HIGH_POWER_TRIM_ADJ)
        msg = self.pwr.command_bytes()
        msg.extend(self.trim.command_bytes())
        return msg
    def process_response(self, msg, index):
        index = self.pwr.process_response(msg, index)
        index = self.trim.process_response(msg, index)
        self.power_W = float(int.from_bytes(self.pwr.cal_data, byteorder='little', signed=False))
        self.trim_us = int.from_bytes(self.trim.cal_data, byteorder='little', signed=True) / TICKS_PER_US
        return index

# Sets the power trim for medium power modes.
# Arguments  trim_us  - Extra advance in uS
#            power    - Power trim is applied at in Watts
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_EOL_MEDIUM_POWER_TRIM(trim_us = 1.25, power_W=500.0))
#     device.send(msg)
class SET_EOL_MEDIUM_POWER_TRIM(CALIBRATE_CMD):
    def __init__(self, trim_us, power_W, **kwargs):
        self.error_str = None
        self.processing_time = 0
        value = int(trim_us * TICKS_PER_US)
        if value >  0x7fff: raise Exception("Out of range")
        if value < -0x8000: raise Exception("Out of range")
        self.trim_raw = value
        value = int(power_W)
        if value >  0x7fff: raise Exception("Out of range")
        if value < -0x8000: raise Exception("Out of range")
        self.power_W = int(value)
    def command_bytes(self):
        msg = bytearray()
        self.pwr  = CALIBRATE_CMD(cal_id = CALIB_ID_EOL_MEDIUM_POWER_TRIM_PWR, cal_data = self.power_W.to_bytes(2, byteorder='little', signed=False))
        self.trim = CALIBRATE_CMD(cal_id = CALIB_ID_EOL_MEDIUM_POWER_TRIM_ADJ, cal_data = self.trim_raw.to_bytes(2, byteorder='little', signed=True))
        msg = self.pwr.command_bytes()
        msg.extend(self.trim.command_bytes())
        return msg
    def process_response(self, msg, index):
        index = self.pwr.process_response(msg, index)
        index = self.trim.process_response(msg, index)
        return index

# Gets the power trim for medium power modes.
# Results    trim_us  - Extra advance in uS
#            power    - Power trim is applied at in Watts
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_EOL_MEDIUM_POWER_TRIM())
#     device.send(msg)
#     print("trim=%f us" % msg.results[0].trim_us)
#     print("power=%f W" % msg.results[0].power_W)
class GET_EOL_MEDIUM_POWER_TRIM(CONFIGURE_CMD):
    def __init__(self, **kwargs):
        self.error_str = None
        self.processing_time = 0
        self.power_W = None
        self.trim_us = None
    def command_bytes(self):
        msg = bytearray()
        self.pwr  = CALIBRATE_REQ(cal_id = CALIB_ID_EOL_MEDIUM_POWER_TRIM_PWR)
        self.trim = CALIBRATE_REQ(cal_id = CALIB_ID_EOL_MEDIUM_POWER_TRIM_ADJ)
        msg = self.pwr.command_bytes()
        msg.extend(self.trim.command_bytes())
        return msg
    def process_response(self, msg, index):
        index = self.pwr.process_response(msg, index)
        index = self.trim.process_response(msg, index)
        self.power_W = float(int.from_bytes(self.pwr.cal_data, byteorder='little', signed=False))
        self.trim_us = int.from_bytes(self.trim.cal_data, byteorder='little', signed=True) / TICKS_PER_US
        return index

# Sets the power trim for low power modes.
# Arguments  trim_us  - Extra advance in uS
#            power    - Power trim is applied at in Watts
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_EOL_LOW_POWER_TRIM(trim_us = 1.25, power_W=500.0))
#     device.send(msg)
class SET_EOL_LOW_POWER_TRIM(CALIBRATE_CMD):
    def __init__(self, trim_us, power_W, **kwargs):
        self.error_str = None
        self.processing_time = 0
        value = int(trim_us * TICKS_PER_US)
        if value >  0x7fff: raise Exception("Out of range")
        if value < -0x8000: raise Exception("Out of range")
        self.trim_raw = value
        value = int(power_W)
        if value >  0x7fff: raise Exception("Out of range")
        if value < -0x8000: raise Exception("Out of range")
        self.power_W = int(value)
    def command_bytes(self):
        msg = bytearray()
        self.pwr  = CALIBRATE_CMD(cal_id = CALIB_ID_EOL_LOW_POWER_TRIM_PWR, cal_data = self.power_W.to_bytes(2, byteorder='little', signed=False))
        self.trim = CALIBRATE_CMD(cal_id = CALIB_ID_EOL_LOW_POWER_TRIM_ADJ, cal_data = self.trim_raw.to_bytes(2, byteorder='little', signed=True))
        msg = self.pwr.command_bytes()
        msg.extend(self.trim.command_bytes())
        return msg
    def process_response(self, msg, index):
        index = self.pwr.process_response(msg, index)
        index = self.trim.process_response(msg, index)
        return index

# Gets the power trim for low power modes.
# Results    trim_us  - Extra advance in uS
#            power    - Power trim is applied at in Watts
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_EOL_LOW_POWER_TRIM())
#     device.send(msg)
#     print("trim=%f us" % msg.results[0].trim_us)
#     print("power=%f W" % msg.results[0].power_W)
class GET_EOL_LOW_POWER_TRIM(CONFIGURE_CMD):
    def __init__(self, **kwargs):
        self.error_str = None
        self.processing_time = 0
        self.power_W = None
        self.trim_us = None
    def command_bytes(self):
        msg = bytearray()
        self.pwr  = CALIBRATE_REQ(cal_id = CALIB_ID_EOL_LOW_POWER_TRIM_PWR)
        self.trim = CALIBRATE_REQ(cal_id = CALIB_ID_EOL_LOW_POWER_TRIM_ADJ)
        msg = self.pwr.command_bytes()
        msg.extend(self.trim.command_bytes())
        return msg
    def process_response(self, msg, index):
        index = self.pwr.process_response(msg, index)
        index = self.trim.process_response(msg, index)
        self.power_W = float(int.from_bytes(self.pwr.cal_data, byteorder='little', signed=False))
        self.trim_us = int.from_bytes(self.trim.cal_data, byteorder='little', signed=True) / TICKS_PER_US
        return index

# Sets the MOT_IND_CAL configuration setting.
# Arguments  value  - Motor winding inductance in uH
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_MOTOR_INDUCTANCE(value=2200))
#     device.send(msg)
class SET_EOL_MOTOR_INDUCTANCE(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  0xffffffff: raise Exception("Out of range")
        if value <  0: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_MOT_IND, cal_data = value.to_bytes(4, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the MOT_IND_CAL configuration setting.
# Results  value  - Motor winding inductance in uH
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_MOTOR_INDUCTANCE())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_EOL_MOTOR_INDUCTANCE(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_MOT_IND, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# Sets the MOT_IND_ENABLE_CAL configuration setting.
# Arguments  value  - value of inductance measurement enable flag (0=disable, >0=enable)
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_EOL_MOTOR_INDUCTANCE_MEAS_ENABLE(value=1))
#     device.send(msg)
class SET_EOL_MOTOR_INDUCTANCE_MEAS_ENABLE(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  0x7fff: raise Exception("Out of range")
        if value < -0x8000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_MOT_IND_ENABLE, cal_data = value.to_bytes(1, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the MOT_IND_ENABLE_CAL configuration setting.
# Results  value  - inductance measurement enable flag
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_EOL_MOTOR_INDUCTANCE_MEAS_ENABLE())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_EOL_MOTOR_INDUCTANCE_MEAS_ENABLE(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_MOT_IND_ENABLE, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index
        
# Sets the TUNING_BYTE_CAL configuration setting.
# Arguments  value  - value of tuning byte status (0x00=virgin product, 0xfe=fail to tune, 0xff=product tuned)
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_EOL_TUNING_BYTE(value=0x00))
#     device.send(msg)
class SET_EOL_TUNING_BYTE(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  0xFF: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_TUNING_BYTE, cal_data = value.to_bytes(1, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the TUNING_BYTE_CAL configuration setting.
# Results  value  - value of tuning byte status (0x00=virgin product, 0xfe=fail to tune, 0xff=product tuned)
# Usage:
#     msg = device.command_messages()
#     msg.add(9_protocol.GET_EOL_TUNING_BYTE())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_EOL_TUNING_BYTE(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_TUNING_BYTE, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the MOT_BEMF_100K_CAL configuration setting.
# Arguments  value  - Back emf value in mV measured at 100kRPM
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_MOTOR_BEMF_100K(value=122000))
#     device.send(msg)
class SET_EOL_MOTOR_BEMF_100K(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  0x7fffffff: raise Exception("Out of range")
        if value < -0x80000000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_BEMF_100K, cal_data = value.to_bytes(4, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the MOT_BEMF_100K_CAL configuration setting.
# Results  value  - Back emf value in mV measured at 100kRPM
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_MOTOR_BEMF_100K())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_EOL_MOTOR_BEMF_100K(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_BEMF_100K, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# Sets the BEMF_NORM_CONST_CAL configuration setting.
# Arguments  value  - back emf normalisation constant
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_BEMF_NORM_CONST(value=492))
#     device.send(msg)
class SET_EOL_BEMF_NORM_CONST(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  0x7fffffff: raise Exception("Out of range")
        if value < -0x80000000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_BEMF_NORM_CONST, cal_data = value.to_bytes(4, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the BEMF_NORM_CONST_CAL configuration setting.
# Results  value  - back emf normalisation constant
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_BEMF_NORM_CONST())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_EOL_BEMF_NORM_CONST(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_BEMF_NORM_CONST, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# Sets the PCB_V_DC_OFFSET configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_FCT_V_DC_OFFSET(value=123))
#     device.send(msg)
class SET_FCT_V_DC_OFFSET(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  0x7fff: raise Exception("Out of range")
        if value < -0x8000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_FCT_V_DC_OFFSET, cal_data = value.to_bytes(2, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the PCB_V_DC_OFFSET configuration setting in raw units.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_FCT_V_DC_OFFSET())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_FCT_V_DC_OFFSET(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_FCT_V_DC_OFFSET, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# Sets the PCB_V_DC_SLOPE configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_FCT_V_DC_SLOPE(value=123))
#     device.send(msg)
class SET_FCT_V_DC_SLOPE(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  0x7fff: raise Exception("Out of range")
        if value < -0x8000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_FCT_V_DC_SLOPE, cal_data = value.to_bytes(2, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the PCB_V_DC_SLOPE configuration setting in degrees.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_FCT_V_DC_SLOPE())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_FCT_V_DC_SLOPE(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_FCT_V_DC_SLOPE, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the PCB_RTD_TEMP_OFFSET configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_FCT_RTD_TEMP_OFFSET(value=123))
#     device.send(msg)
class SET_EOL_RTD_TEMP_OFFSET(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  0x7fff: raise Exception("Out of range")
        if value < -0x8000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_RTD_TEMP_OFFSET, cal_data = value.to_bytes(2, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the PCB_RTD_TEMP_OFFSET configuration setting in raw units.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_FCT_RTD_TEMP_OFFSET())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_EOL_RTD_TEMP_OFFSET(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = 
        EOL_RTD_TEMP_OFFSET, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# Sets the PCB_RTD_TEMP_SLOPE configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_FCT_RTD_TEMP_SLOPE(value=123))
#     device.send(msg)
class SET_EOL_RTD_TEMP_SLOPE(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  0x7fff: raise Exception("Out of range")
        if value < -0x8000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_RTD_TEMP_SLOPE, cal_data = value.to_bytes(2, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the PCB_RTD_TEMP_SLOPE configuration setting in degrees.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_FCT_RTD_TEMP_SLOPE())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_EOL_RTD_TEMP_SLOPE(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_RTD_TEMP_SLOPE, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the EOL_RTD_TEMP_OFFSET configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_EOL_RTD_TEMP_OFFSET(value=123))
#     device.send(msg)
class SET_EOL_RTD_TEMP_OFFSET(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  0x7fff: raise Exception("Out of range")
        if value < -0x8000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_RTD_TEMP_OFFSET, cal_data = value.to_bytes(2, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the EOL_RTD_TEMP_OFFSET configuration setting in raw units.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_EOL_RTD_TEMP_OFFSET())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_EOL_RTD_TEMP_OFFSET(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_RTD_TEMP_OFFSET, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# Sets the PCB_COMP_REF_SLOPE configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_FCT_COMP_REF_SLOPE(value=123))
#     device.send(msg)
class SET_FCT_COMP_REF_SLOPE(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  0xffff: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_FCT_COMP_REF_SLOPE, cal_data = value.to_bytes(2, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the PCB_COMP_REF_SLOPE configuration setting in degrees.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_FCT_COMP_REF_SLOPE())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_FCT_COMP_REF_SLOPE(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_FCT_COMP_REF_SLOPE, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index


# Sets the PCB_CAL_RIG_ID configuration setting in raw units.
# Arguments  value  - 32 bit rig id
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_FCT_CAL_RIG_ID(value=123))
#     device.send(msg)
class SET_FCT_CAL_RIG_ID(CALIBRATE_CMD):
    def __init__(self, rig_id, **kwargs):
        if rig_id >  0xFFFFFFFF: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_FCT_CAL_RIG_ID, cal_data = rig_id.to_bytes(4, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the PCB_CAL_RIG_ID configuration setting in degrees.
# Results  value  - 32 bit rig id
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_FCT_CAL_RIG_ID))
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_FCT_CAL_RIG_ID(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_FCT_CAL_RIG_ID, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.rig_id = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the PCB_CAL_TIMESTAMP configuration setting in raw units.
# Arguments  value  - 32 bit rig id
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_FCT_CAL_RIG_ID(timestamp=123))
#     device.send(msg)
class SET_FCT_CAL_TIMESTAMP(CALIBRATE_CMD):
    def __init__(self, timestamp, **kwargs):
        if timestamp >  0xFFFFFFFF: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_FCT_CAL_TIMESTAMP, cal_data = timestamp.to_bytes(4, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the PCB_CAL_TIMESTAMP configuration setting in degrees.
# Results  value  - 32 bit timestamp (1970 format)
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_FCT_CAL_TIMESTAMP))
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_FCT_CAL_TIMESTAMP(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_FCT_CAL_TIMESTAMP, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.timestamp = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the PCB_PCBA_FCT_INFO configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_FCT_PCBA_FCT_INFO(value=123))
#     device.send(msg)
class SET_FCT_PCBA_FCT_INFO(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_FCT_PCBA_FCT_INFO, cal_data = value.to_bytes(6, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the PCB_PCBA_FCT_INFO configuration setting in raw units.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_FCT_PCBA_FCT_INFO())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_FCT_PCBA_FCT_INFO(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_FCT_PCBA_FCT_INFO, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index


# Sets the EOL_FW_REF_SPEED (Filter Wash reference speed) configuration setting in Watts.
# I know the speed is specified in Watts - That's what NPI wanted.
# Arguments  value  - in Watts
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_EOL_FW_REF_SPEED(value=123))
#     device.send(msg)
class SET_EOL_FW_REF_SPEED(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_FW_REF_SPEED, cal_data = value.to_bytes(2, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)


# Gets the EOL_FW_REF_SPEED (Filter Wash reference speed) configuration setting in Watts.
# I know the speed is specified in Watts - That's what NPI wanted.
# Results  value  - in Watts
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_EOL_FW_REF_SPEED())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_EOL_FW_REF_SPEED(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_FW_REF_SPEED, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index


# Sets the PCB_FET_TEMP_OFFSET configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_FCT_FET_TEMP_OFFSET(value=123))
#     device.send(msg)
class SET_EOL_FET_TEMP_TRIP_LIMIT(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  0x7fff: raise Exception("Out of range")
        if value < -0x8000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_FET_TEMP_TRIP_LIMIT, cal_data = value.to_bytes(2, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the PCB_FET_TEMP_OFFSET configuration setting in raw units.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_EOL_FET_TEMP_TRIP_LIMIT())
#     device.send(msg)
#     print("value=%d" % msg.results[0].eol_fet_temp_trip_limit)
class GET_EOL_FET_TEMP_TRIP_LIMIT(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_FET_TEMP_TRIP_LIMIT, **kwargs)
        self.eol_fet_temp_trip_limit = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.eol_fet_temp_trip_limit = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index



# Sets the HC_DETACH_TIME configuration setting in multiples of 50ms.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_HC_DETACH_TIME(value=123))
#     device.send(msg)
class SET_HC_DETACH_TIME(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  0xffff: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_HC_DETACH_TIME, cal_data = value.to_bytes(2, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the HC_DETACH_TIME configuration setting in multiples of 50ms.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_HC_DETACH_TIME())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_HC_DETACH_TIME(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_HC_DETACH_TIME, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# Sets the HC_CURRENT_LIMIT configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_HC_CURRENT_LIMIT(value=123))
#     device.send(msg)
class SET_HC_CURRENT_LIMIT(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  0xffff: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_HC_CURRENT_LIMIT, cal_data = value.to_bytes(2, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the HC_CURRENT_LIMIT configuration setting in raw units.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_HC_CURRENT_LIMIT())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_HC_CURRENT_LIMIT(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_HC_CURRENT_LIMIT, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# Sets the HC_RAMPUP_SLOPE configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_HC_RAMPUP_SLOPE(value=123))
#     device.send(msg)
class SET_HC_RAMPUP_SLOPE(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  0xffff: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_HC_RAMPUP_SLOPE, cal_data = value.to_bytes(2, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the HC_RAMPUP_SLOPE configuration setting in raw units.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_HC_RAMPUP_SLOPE())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_HC_RAMPUP_SLOPE(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_HC_RAMPUP_SLOPE, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# Sets the AET_OFFSET configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_AET_OFFSET(value=123))
#     device.send(msg)
class SET_AET_OFFSET(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  0x7fff: raise Exception("Out of range")
        if value < -0x8000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_AET_OFFSET, cal_data = value.to_bytes(2, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the AET_OFFSET configuration setting in raw units.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_AET_OFFSET())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_AET_OFFSET(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_AET_OFFSET, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# Sets the AET_SLOPE configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_AET_SLOPE(value=123))
#     device.send(msg)
class SET_AET_SLOPE(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  65535: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_EOL_AET_SLOPE, cal_data = value.to_bytes(2, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the AET_SLOPE configuration setting in raw units.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_AET_SLOPE())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_AET_SLOPE(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_EOL_AET_SLOPE, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# LEC Standard command LEC_FET_DRIVE_START_CMD
#
#   Purpose: To calibrate the VSENSE and Current Chop DAC Reference
#
#   This function
#   1) Bootstraps the FET drive
#   2) Enable the current chop circuit with a RAW DAC value of 800
#   2) Starts a positive or negative conduction
#   3) Wait for a sufficient time for the VSENSE measurement to settle
#   4) Report the VSENSE measurement
#   5) Disable the FET drive
#
# Implements the FET_DRIVE_START_CMD/FET_DRIVE_START_RES command/response.
# Arguments  UINT8 pulse direction - Direction of the pulse (positive (S1+S4) or negative (S2+S3)
#            UINT32 chop level - Current chop threshold during the pulse (in mA)
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16 Command ID  - LEC_FET_DRIVE_START_CMD (0x800D)
# Response:  UINT16 Command ID  - LEC_FET_DRIVE_START_RES (0x800E)
#            UINT16 vsense_raw   - Raw VSENSE result (un averaged given already slow hardware filtered)
#            UINT8  Result      - 0x00=Success, 0x01=Error-not ready, 0x02=Error Command locked
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.FET_DRIVE_START_CMD(drive_dir=0,raw_dac_value=800))
#     device.send(msg)
#     print("result=%d, VSENSE RAW Value=%0x.4x" % (msg.results[0].result,msg.results[0].raw_value))
class FET_DRIVE_START_CMD(LecCommand):
    FET_DRIVE_START_CMD = 0x800D
    FET_DRIVE_START_RES = 0x800E
    name = 'FET_DRIVE_START_CMD'

    def __init__(self, drive_dir,chop_level, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.drive_dir   = drive_dir
        self.chop_level  = chop_level
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.FET_DRIVE_START_CMD))
        msg.extend(self.int8(self.drive_dir))
        msg.extend(self.uint32(self.chop_level))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.FET_DRIVE_START_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.FET_DRIVE_START_RES))
        self.vsense_raw = self.get_uint16(msg, index+2)
        self.result = self.get_uint8(msg, index+4)
        if self.debug_level > 20:
            print("Parsing %s: result=%d  0=Command OK, 1=Error, 2=Device cal locked" % (self.name, self.result))
        return index+5

# FCT specific command FCT_TEST_GPIO_CMD
#
#   Purpose: To test all the GPIO ports in V9 PCBA boards
#
#   This function
#   1) Convert input parameter to the GPIO port groups selection
#   2) Configure any GPIO port group one port as input the other as output
#   3) Send and receive pre-defined pulse signals
#   4) Verified OK then send success status otherwise send out fail code
#
# Implements the DIPCCMD_FCT_TEST_GPIO_CMD/DIPCCMD_FCT_TEST_GPIO_RES command/response.
# Arguments  None
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16 Command ID  - FCT_TEST_GPIO_CMD (0x8024)
#            UINT8  Port Selection - 8-bit Port Selection for specifying which IOs go for test
# Response:  UINT16 Command ID  - FCT_TEST_GPIO_RES (0x8025)
#            UINT8  RESPOND     - 0x00=Success, 0x01=Error-not ready, 0x02=Error Command locked
#            UINT16  TestResult - 0xFFFF= Invalid Input, 0x0000 = Test Success, otherwise Test failed
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.FCT_TEST_GPIO_CMD())
#     device.send(msg)
#
class FCT_TEST_GPIO_CMD(LecCommand):
    FCT_TEST_GPIO_CMD = 0x8024
    FCT_TEST_GPIO_RES = 0x8025
    name = 'FCT_TEST_GPIO_CMD'

    def __init__(self, gpio_map, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.gpio_map = gpio_map
        self.result = None   # Default attribute value before response is None
        self.TestResult = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.FCT_TEST_GPIO_CMD))
        msg.extend(self.uint8(self.gpio_map))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.FCT_TEST_GPIO_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.FCT_TEST_GPIO_RES))
        self.result = self.get_uint8(msg, index+2)
        self.TestResult = self.get_uint16(msg, index+3)
        if self.debug_level > 20:
            print("Parsing %s: result=%d  0=Command OK, 1=Error, 2=Device cal locked" % (self.name, self.TestResult))
        return index+5

# Implements the POWER_TUNE_CMD/POWER_TUNE_RES command/response.
# Arguments  step - New value for power tune
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16 POWER_TUNE_CMD (0x8005)
#            INT8   power step - typically -5 to +5
# Response:  UINT16 POWER_TUNE_RES (0x8006)
#            UINT8  0x00 = Command executed ok, 0x01 = Error, 0x02 = Device calibration locked
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.POWER_TUNE_CMD(step = -3))
#     device.send(msg)
#     print("result=%d" % msg.results[0].result)
class POWER_TUNE_CMD(LecCommand):
    POWER_TUNE_CMD = 0x8005
    POWER_TUNE_RES = 0x8006
    name = 'POWER_TUNE_CMD'

    def __init__(self, step, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.step   = step
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.POWER_TUNE_CMD))
        msg.extend(self.int8(self.step))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.POWER_TUNE_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.POWER_TUNE_RES))
        self.result = self.get_uint8(msg, index+2)
        if self.debug_level > 20:
            print("Parsing %s: result=%d  0=Command OK, 1=Error, 2=Device cal locked" % (self.name, self.result))
        index += 3
        return index

# Implements the FCT_HALL_MEAS_CMD/FCT_HALL_MEAS_RES command/response.
# Arguments  none
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16     Command ID  - FCT_HALL_MEAS_CMD (0x8022)
# Response:  UINT16     Command ID  - FCT_HALL_MEAS_RES (0x8023)
#            UINT8      Dutycycle   - in Q8 format 0=0%; 256=100%
#            UINT16     Frequency   - in Q4 format 800=50Hz, maximum frequency is 4096Hz=245krpm
#            UINT8      Result      - 0x00=Success, 0x01=Error-not ready, 0x02=Error Command locked
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.FCT_HALL_MEAS_CMD())
#     device.send(msg)
#     command_result    = msg.results[0].result
#     hall_pulse_widths = msg.results[0].pulses
class FCT_HALL_MEAS_CMD(LecCommand):
    FCT_HALL_MEAS_CMD = 0x8022
    FCT_HALL_MEAS_RES = 0x8023
    name = 'FCT_HALL_MEAS_CMD'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.frequency = None
        self.dutycycle = None
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.FCT_HALL_MEAS_CMD))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.FCT_HALL_MEAS_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.FCT_HALL_MEAS_RES))
        index += 2
        self.dutycycle = self.get_uint8(msg, index)
        index += 1
        self.frequency = self.get_uint16(msg, index)

        self.result = self.get_uint8(msg, index+2)

        if self.debug_level > 20:
            print("Parsing %s: result=%d  0=Command OK, 1=Error, 2=Device cal locked" % (self.name, self.result))
        index += 3
        return index

# Implements the FCT_BMS_COMMS_TEST_START_CMD/FCT_BMS_COMMS_TEST_START_RES command/response.
# Arguments  none
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16     Command ID  - FCT_BMS_COMMS_TEST_START_CMD (0x8020)
#            UINT8      Test Byte   - Byte to transmit
#            UINT8      Byte count  - Number of times to transmit the byte
# Response:  UINT16     Command ID  - FCT_BMS_COMMS_TEST_START_RES (0x8021)
#            INT8       Test result - 1=Test message received correctly, 0=No test message received, -1=Test message received incorrectly
#            UINT8      Result      - 0x00=Success, 0x01=Error-not ready, 0x02=Error Command locked
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.FCT_BMS_COMMS_TEST_START_CMD())
#     device.send(msg)
#     command_result    = msg.results[0].result
#     test_result       = msg.results[0].testresult
class FCT_BMS_COMMS_TEST_START_CMD(LecCommand):
    FCT_BMS_COMMS_TEST_START_CMD = 0x8020
    FCT_BMS_COMMS_TEST_START_RES = 0x8021
    name = 'FCT_BMS_COMMS_TEST_START_CMD'

    def __init__(self, testbyte, bytecount, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.testbyte = testbyte
        self.bytecount = bytecount
        self.testresult = None
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.FCT_BMS_COMMS_TEST_START_CMD))
        msg.extend(self.uint8(self.testbyte))
        msg.extend(self.uint8(self.bytecount))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.FCT_BMS_COMMS_TEST_START_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.FCT_BMS_COMMS_TEST_START_RES))
        self.testresult = self.get_int8(msg, index+2)

        self.result = self.get_uint8(msg, index+3)

        if self.debug_level > 20:
            print("Parsing %s: result=%d  0=Command OK, 1=Error, 2=Device cal locked" % (self.name, self.result))
        index += 4
        return index

# Implements the FCT_TEST_UI34_CMD/FCT_TEST_UI34_RES command/response.
# Arguments  none
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16     Command ID  - FCT_TEST_UI34_CMD (0x8024)
#            UINT8      Test Byte   - value to shift out
#            UINT8      Pulse width - output data pulse width
# Response:  UINT16     Command ID  - FCT_TEST_UI34_RES (0x8025)
#            UINT8      Result      - 0x00=Success, 0x01=Error-not ready, 0x02=Error Command locked
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.FCT_HALL_MEAS_CMD())
#     device.send(msg)
#     command_result    = msg.results[0].result
class FCT_TEST_UI34_CMD(LecCommand):
    FCT_TEST_UI34_CMD = 0x8024
    FCT_TEST_UI34_RES = 0x8025
    name = 'FCT_TEST_UI34_CMD'

    def __init__(self, testbyte, pulsewidth, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.testbyte = testbyte
        self.pulsewidth = pulsewidth
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.FCT_TEST_UI34_CMD))
        msg.extend(self.uint8(self.testbyte))
        msg.extend(self.uint8(self.pulsewidth))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.FCT_TEST_UI34_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.POWER_TUNE_RES))
        self.result = self.get_uint8(msg, index+2)

        if self.debug_level > 20:
            print("Parsing %s: result=%d  0=Command OK, 1=Error, 2=Device cal locked" % (self.name, self.result))
        index += 3
        return index

# Implements the HEARTBEAT_CMD/HEARTBEAT_RES command/response.
# Arguments  none
# Command:   UINT16     Command ID  - HEARTBEAT_CMD (0x8026)
# Response:  UINT16     Command ID  - HEARTBEAT_RES (0x8027)
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.HEARTBEAT_CMD())
#     device.send(msg)
class HEARTBEAT_CMD(LecCommand):
    HEARTBEAT_CMD = 0x8026
    HEARTBEAT_RES = 0x8027
    name = 'HEARTBEAT_CMD'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.HEARTBEAT_CMD))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.HEARTBEAT_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.HEARTBEAT_RES))

        if self.debug_level > 20:
            print("Parsing %s" % (self.name))
        index += 2
        return index

# Implements the FCT_BB_DRIVE_START_MEAS_CMD/FCT_BB_DRIVE_START_MEAS_RES command/response.
#
#   Purpose: To calibrate the brush bar current BB_I slope
#
#   This function
#   1) Disables DC on the BB_EN line to enalbe the brsuh bar
#   2) After 300ms enables brush bar measurements, (300ms is purposed for FCT device settlements)
#   3) Wait for a sufficient time for the RAW BB_I average (x16) to settle
#   4) Disable the brush bar BB_EN line after 5 seconds automatically
#
# Arguments  None
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16 Command ID  - FCT_BB_DRIVE_START_MEAS_CMD (0x8028)
# Response:  UINT16 Command ID  - FCT_BB_DRIVE_START_MEAS_RES (0x8029)
#            UINT8  Result      - 0x00=Success, 0x01=Error-not ready, 0x02=Error Command locked
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.FCT_BB_DRIVE_START_MEAS_CMD())
#     device.send(msg)
#     command_result    = msg.results[0].result
class FCT_BB_DRIVE_START_MEAS_CMD(LecCommand):
    FCT_BB_DRIVE_START_MEAS_CMD = 0x8028
    FCT_BB_DRIVE_START_MEAS_RES = 0x8029
    name = 'FCT_BB_DRIVE_START_MEAS_CMD'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.FCT_BB_DRIVE_START_MEAS_CMD))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.FCT_BB_DRIVE_START_MEAS_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.FCT_BB_DRIVE_START_MEAS_RES))
        self.result = self.get_uint8(msg, index+2)
        if self.debug_level > 20:
            print("Parsing %s: result=%d  0=Command OK, 1=Error, 2=Device cal locked" % (self.name, self.result))
        return index+3

# Implements the FCT_BB_DRIVE_STOP_MEAS_CMD/FCT_BB_DRIVE_STOP_MEAS_RES command/response.
#
#   Purpose: To calibrate the brush bar current BB_I slope
#
#   This function
#   1) Disables DC on the BB_EN line to enalbe the brsuh bar
#   2) Report the averages RAW brush bar measurement
#
# Arguments  none
# Results    result - 0 = command ok, 1 = error, 2 = device cal is locked
# Command:   UINT16     Command ID      - FCT_BB_DRIVE_STOP_MEAS_CMD (0x802A)
#            UINT8      Test Byte       - Byte to transmit
#            UINT8      Byte count      - Number of times to  the byte
# Response:  UINT16     Command ID      - FCT_BB_DRIVE_STOP_MEAS_RES (0x802B)
#            UINT8      Result          - 0x00=Success, 0x01=Error-not ready, 0x02=Error Command locked
#            UINT8      BB_Cur_RawData  - if BB_Cur_RawData=0, it means the rawdata is not valid
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.FCT_BB_DRIVE_STOP_MEAS_CMD())
#     device.send(msg)
#     command_result    = msg.results[0].result
#     BB_Cur_RawData    = msg.results[0].BB_Cur_RawData
class FCT_BB_DRIVE_STOP_MEAS_CMD(LecCommand):
    FCT_BB_DRIVE_STOP_MEAS_CMD = 0x802A
    FCT_BB_DRIVE_STOP_MEAS_RES = 0x802B
    name = 'LEC_FCT_BB_DRIVE_STOP_MEAS_CMD'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.BB_Cur_RawData = None
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.FCT_BB_DRIVE_STOP_MEAS_CMD))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.FCT_BB_DRIVE_STOP_MEAS_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.FCT_BB_DRIVE_STOP_MEAS_RES))
        self.result = self.get_uint8(msg, index+2)
        self.BB_Cur_RawData = self.get_uint16(msg, index+3)
        if self.debug_level > 20:
            print("Parsing %s: result=%d  0=Command OK, 1=Error, 2=Device cal locked" % (self.name, self.result))
        return index+5

# Implements the ERASE_DATA_LOG_CMD/ERASE_DATA_LOG_RES command/response.
# Arguments  none
# Results    result - 0 = command ok, 1 = error-system not ready, 2 = device cal is locked
# Command:   UINT16     Command ID  - ERASE_DATA_LOG_CMD (0x802c)
# Response:  UINT16     Command ID  - ERASE_DATA_LOG_RES (0x802d)
#            UINT8      Result      - 0x00=Success, 0x01=Error-not ready, 0x02=Error Command locked
#
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.ERASE_DATA_LOG_CMD())
#     device.send(msg)
#     command_result    = msg.results[0].result
class ERASE_DATA_LOG_CMD(LecCommand):
    ERASE_DATA_LOG_CMD = 0x802C
    ERASE_DATA_LOG_RES = 0x802D
    name = 'ERASE_DATA_LOG_CMD'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.ERASE_DATA_LOG_CMD))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.ERASE_DATA_LOG_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.ERASE_DATA_LOG_RES))
        self.result = self.get_uint8(msg, index+2)
        if self.debug_level > 20:
            print("Parsing %s: result=%d  0=Command OK, 1=Error, 2=Device cal locked" % (self.name, self.result))
        index += 3
        return index
        
# Implements the DIPC_ERASE_HLC_LOG_CMD/DIPC_ERASE_HLC_LOG_RES command/response.
# Arguments  none
# Results    result - 0 = command ok, 1 = error-system not ready, 2 = device cal is locked
# Command:   UINT16     Command ID  - DIPC_ERASE_HLC_LOG_CMD (0x802e)
# Response:  UINT16     Command ID  - DIPC_ERASE_HLC_LOG_RES (0x802f)
#            UINT8      Result      - 0x00=Success, 0x01=Error-not ready, 0x02=Error Command locked
#
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.DIPC_ERASE_HLC_LOG_CMD())
#     device.send(msg)
#     command_result    = msg.results[0].result
class DIPC_ERASE_HLC_LOG_CMD(LecCommand):
    DIPC_ERASE_HLC_LOG_CMD = 0x802E
    DIPC_ERASE_HLC_LOG_RES = 0x802F
    name = 'DIPC_ERASE_HLC_LOG_CMD'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.result = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.DIPC_ERASE_HLC_LOG_CMD))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.DIPC_ERASE_HLC_LOG_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.DIPC_ERASE_HLC_LOG_RES))
        self.result = self.get_uint8(msg, index+2)
        if self.debug_level > 20:
            print("Parsing %s: result=%d  0=Command OK, 1=Error, 2=Device cal locked" % (self.name, self.result))
        index += 3
        return index
# Gets the MEMS_TEMPERATURE_PARAMETER parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_MEMS_TEMPERATURE_PARAMETER())
#     device.send(msg)
#     print("Result = %f V" % msg.results[0].mems_Temp)
class GET_MEMS_TEMPERATURE_PARAMETER(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, 0x8002, name = 'MEMS_TEMPERATURE', **kwargs)
        self.mems_Temp = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        resp_len = self.get_uint16(msg, index+4)
        index += 6
        if resp_len == 2:
            self.mems_Temp = self.get_uint16(msg, index)
            index += 2
        elif resp_len == 4:
            self.mems_Temp = self.get_uint32(msg, index)
            index += 4
        else:
            raise Exception('Unexpected response length %d at %d, expected 2 or 4' % (resp_len, index-2))
        return index

# Gets the PRESSURE_PARAMETER parameter
# Usage:
#     msg = device.command_messages()
#     msg.add(hc_protocol.GET_PRESSURE_PARAMETER())
#     device.send(msg)
#     print("Result = %f V" % msg.results[0].pressure_kPa)
class GET_PRESSURE_PARAMETER(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_MEMS_PRESSURE, name = 'PRESSURE', **kwargs)
        self.pressure_kPa = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.pressure_kPa = self.get_uint32(msg, index+6)/1000
        return index + 10

# Gets the PRESSURE_PARAMETER parameter
# Usage:
#     msg = device.command_messages()
#     msg.add(hc_protocol.GET_ATMOSPHERIC_PRESSURE_PARAMETER())
#     device.send(msg)
#     print("Result = %f V" % msg.results[0].pressure_kPa)
class GET_ATMOSPHERIC_PRESSURE_PARAMETER(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_MEMS_ATMOS_PRESSURE, name = ' ATMOSPHERIC PRESSURE PARAMETER', **kwargs)
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.atmospheric_pressure_Pa = self.get_uint32(msg, index+6)/1000
        return index + 10

# Gets the FILTER_INTERLOCK_PARAMETER parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_FILTER_INTERLOCK_PARAMETER())
#     device.send(msg)
#     print("Filter State = %d " % msg.results[0].filter_interlock_state)
class GET_FILTER_INTERLOCK_PARAMETER(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_FILTER_INTERLOCK, name = 'FILTER INTERLOCK', **kwargs)
        self.filter_interlock_state = None  # Value is not available until a response is parsed

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.filter_interlock_state = self.get_uint8(msg, index+6)
        return index + 7

# Gets the FILTER_WASH parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_FILTER_WASH())
#     device.send(msg)
#     print("Filter State = %d " % msg.results[0].filter_state)  # 0= clean, 1=dirty
class GET_FILTER_WASH(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_FILTER_WASH, name = 'PARAM_ID_FILTER_WASH', **kwargs)
        self.filter_state = None  # Value is not available until a response is parsed

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.filter_state = self.get_uint8(msg, index+6)
        return index + 7

# Gets the Vdc RAW ADC voltage measurement parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_FCT_VDC_RAW())
#     device.send(msg)
#     print("Blockage State = %d " % msg.results[0].fct_vdc_raw)
class GET_FCT_VDC_RAW(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, param_id=PARAM_ID_FCT_VDC_RAW, name = 'GET_FCT_VDC_RAW', **kwargs)
        self.fct_vdc_raw = None  # Value is not available until a response is parsed

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.fct_vdc_raw = self.get_uint16(msg, index+6)
        return index + 8

# Gets the Raw Air Exit temperature. note this is not the RAW ADC value rather the  ADC to ideal temp LUT prior to offset/slope calibration
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_EOL_AET_TEMP_RAW())
#     device.send(msg)
#     print("AET TE = %d " % msg.results[0].eol_aet_temp_raw)
class GET_EOL_AET_TEMP_RAW(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, param_id = PARAM_ID_EOL_AET_TEMP_RAW, name = 'GET_EOL_AET_TEMP_RAW', **kwargs)
        self.eol_aet_temp_raw = None  # Value is not available until a response is parsed

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.eol_aet_temp_raw = self.get_uint16(msg, index+6)
        return index + 8

# Gets the Air Exit Thermistor calibration temperature result.
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_AET_TEMP())
#     device.send(msg)
#     print("Blockage State = %d " % msg.results[0].fct_rtd_temp_raw)
class GET_AET_TEMP(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, param_id = PARAM_ID_AET_TEMP, name = 'AET_TEMP', **kwargs)
        self.aet_temp = None  # Value is not available until a response is parsed

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.aet_temp = self.get_int16(msg, index+6)
        return index + 8

# Gets the HLC high RTD RAW temperature threshold for logging purpose.
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_HLC_HIGH_RTD_LIMIT())
#     device.send(msg)
#     print("HLC Trip RTD Raw Threshold = %d " % msg.results[0].hlc_trip_rtd_raw_limit)
class GET_HLC_HIGH_RTD_LIMIT(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_HLC_HIGH_RTD_RAW, **kwargs)
        self.hlc_high_rtd_limit = None  # Value is not available until a response is parsed

    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# Sets the HLC high RTD RAW temperature threshold for logging purpose.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_HLC_HIGH_RTD_LIMIT(value=0x0520))
#     device.send(msg)
class SET_HLC_HIGH_RTD_LIMIT(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        #if value >  0xffff: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_HLC_HIGH_RTD_RAW, cal_data = value.to_bytes(2, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the HLC Low RTD RAW temperature threshold for logging purpose.
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_HLC_LOW_RTD_LIMIT())
#     device.send(msg)
#     print("HLC Low RTD Raw Threshold = %d " % msg.results[0].hlc_trip_rtd_raw_limit)
class GET_HLC_LOW_RTD_LIMIT(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_HLC_LOW_RTD_RAW, **kwargs)
        self.hlc_low_rtd_limit = None  # Value is not available until a response is parsed

    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# Sets the HLC low RTD RAW temperature threshold for logging purpose.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_HLC_HIGH_RTD_LIMIT(value=0x0520))
#     device.send(msg)
class SET_HLC_LOW_RTD_LIMIT(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        #if value >  0xffff: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_HLC_LOW_RTD_RAW, cal_data = value.to_bytes(2, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)
        
# Gets the RTD temperature RAW ADC measurement parameter. Note this represents the RAW ADC value
# to any slope/offset calibration
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_EOL_RTD_TEMP_RAW())
#     device.send(msg)
#     print("Blockage State = %d " % msg.results[0].fct_rtd_temp_raw)
class GET_EOL_RTD_TEMP_RAW(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, param_id = PARAM_ID_EOL_RTD_TEMP_RAW, name = 'GET_FCT_RTD_TEMP_RAW', **kwargs)
        self.eol_rtd_temp_raw = None  # Value is not available until a response is parsed

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.eol_rtd_temp_raw = self.get_uint16(msg, index+6)
        return index + 8

# Gets the calibrated RTD temperature fed as input into the heater control algorithm.
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_FCT_RTD_TEMP_RAW())
#     device.send(msg)
#     print("Blockage State = %d " % msg.results[0].fct_rtd_temp_raw)
class GET_RTD_TEMP(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, param_id = PARAM_ID_RTD_TEMP, name = 'RTD_TEMP_DEG_C', **kwargs)
        self.rtd_temp = None  # Value is not available until a response is parsed

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.rtd_temp = self.get_int16(msg, index+6)
        return index + 8        

# Gets the FET temperature RAW ADC measurement parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_FCT_FET_TEMP_RAW())
#     device.send(msg)
#     print("Blockage State = %d " % msg.results[0].blocked_state)  # 0=not blocked, 1=blocked
class GET_EOL_FET_TEMP_RAW(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, param_id = PARAM_ID_EOL_FET_TEMP_RAW, name = 'EOL_FET_TEMP_RAW', **kwargs)
        self.eol_fet_temp_raw = None  # Value is not available until a response is parsed

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.eol_fet_temp_raw = self.get_uint16(msg, index+6)
        return index + 8

# Gets the GET_DEVICE_TEMPERATURE_PARAMETER parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_DEVICE_TEMPERATURE_PARAMETER())
#     device.send(msg)
#     print("Result = %f Dec C" % msg.results[0].temperature)
class GET_DEVICE_TEMPERATURE_PARAM_REQ(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_TEMPERATURE, name = 'DEVICE TEMPERATURE', **kwargs)
        self.temperature = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.PARAMETER_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.PARAMETER_RES))
        self.temperature = self.get_uint32(msg, index+6)  / 1000
        return index + 10

# Calls the function of the given name
# Arguments  fn_name - Name of function to call
#            params  - array of up to 4 UINT32 (default [])
# Results    result - Returned value from function - if applicable
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.CALL('AddOne', [7]))
#     device.send(msg)
#     print("result=%d" % msg.results[0].result)
class CALL(LecCommand):
    def __init__(self, fn_name, params=[], **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.fn_name   = fn_name
        self.params    = params
        self.result    = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.fn_name, list(self.kwargs.keys())))

    def command_bytes(self):
        self.addr = self.protocol.get_function_addr(self.fn_name)
        if self.debug_level > 20:
            print("Adding CALL %s " % self.fn_name, end='')
            print(self.params)
        self.call  = EXECUTE_FUNCTION_CMD(self.addr, self.params)
        if self.debug_level > 20:
            print('CALL %s ' % self.fn_name, self.params)
        return self.call.command_bytes()

    def process_response(self, msg, index):
        index = self.call.process_response(msg, index)
        self.result = self.call.result
        if self.debug_level > 20:
            print('CALL %s ' % self.fn_name, self.params, ' Result = %d 0x%08x' % (self.result, self.result))
        return index

# Gets the variable value of the given name
# Arguments  var_name - Name of function to call
#            struct   - Optional: Type name of structure the variable is a part of (default None)
#            addr     - Optional: Actual address of start of structure
#            signed   - Optional: True if the value is signed (default False)
# Results    value    - Variable value
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_VAR('appDebug0'))
#     msg.add(v9_protocol.GET_VAR('appDebug1', signed=True))
#     msg.add(v9_protocol.GET_VAR('fshSystemConstants.uart_baud', struct='tFshSystemConstants'))
#     msg.add(v9_protocol.GET_VAR('?.uart_baud', struct='tFshSystemConstants', addr=0x20000432))
#     device.send(msg)
#     print("result=%d" % msg.results[0].value)
#     print("result=%d" % msg.results[1].value)
#     print("result=%d" % msg.results[2].value)
#     print("result=%d" % msg.results[3].value)
class GET_VAR(LecCommand):
    def __init__(self, var_name, struct=None, addr=None, signed=False, floatvar=False, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.var_name  = var_name
        self.struct    = struct
        self.addr      = addr
        self.signed    = signed
        self.value     = None   # Default attribute value before response is None
        self.floatvar  = floatvar
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        self.var_addr, self.var_size = self.protocol.get_variable_addr(self.var_name, self.struct, self.addr)
        if self.addr != None and self.var_name[0:2] != '?.':
            self.var_addr = self.addr
        if self.debug_level > 20:
            print("Adding GET_VAR %s " % self.var_name, " struct=", self.struct, " addr=", self.addr)
        self.peek = MEMORY_CONTENT_REQ(self.var_addr)
        return self.peek.command_bytes()

    def process_response(self, msg, index):
        index = self.peek.process_response(msg, index)
        self.value = self.peek.value
        if self.var_size == 1: self.value &= 0xff
        if self.var_size == 2: self.value &= 0xffff
        if self.var_size == 4: self.value &= 0xffffffff
        self.value = int.from_bytes(self.value.to_bytes(self.var_size, byteorder='little'), byteorder='little', signed=self.signed)
        if self.floatvar == True:
            self.value, = struct.unpack('f', self.peek.value.to_bytes(4, byteorder='little'))
            if self.debug_level > 20:
                print('GET_VAR %s = %f' % (self.var_name, self.value))
        elif self.debug_level > 20:
            print('GET_VAR %s = %d' % (self.var_name, self.value))
        return index


# Sets the variable value of the given name
# Arguments  var_name - Name of function to call
#            struct   - Optional: Type name of structure the variable is a part of (default None)
#            addr     - Optional: Actual address of start of structure
#            signed   - Optional: True if the value is signed (default False)
#            value    - Variable value (must be an integer)
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.SET_VAR('appDebug0', 5))
#     msg.add(v9_protocol.SET_VAR('appDebug1', -5, signed=True))
#     msg.add(v9_protocol.SET_VAR('fshSystemConstants.uart_baud', 66, struct='tFshSystemConstants'))
#     msg.add(v9_protocol.SET_VAR('?.uart_baud', 22, struct='tFshSystemConstants', addr=0x20000432))
#     device.send(msg)
class SET_VAR(LecCommand):
    def __init__(self, var_name, value, struct=None, addr=None, mask=None, signed=False, floatvar=False, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        self.var_name  = var_name
        self.value     = value
        self.struct    = struct
        self.addr      = addr
        self.signed    = signed
        self.mask      = mask
        self.floatvar  = floatvar
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        self.var_addr, self.var_size = self.protocol.get_variable_addr(self.var_name, self.struct, self.addr)
        if self.addr != None:
            self.var_addr = self.addr
        if self.mask != None:     mask = self.mask
        elif self.var_size == 1:  mask = 0xff
        elif self.var_size == 2:  mask = 0xffff
        elif self.var_size == 3:  mask = 0xffffff
        elif self.var_size == 4:  mask = 0xffffffff
        elif self.floatvar:       mask = 0xffffffff
        else:                     mask = 0
        if self.debug_level > 20:
            print("Adding SET_VAR %s " % self.var_name, " struct=", self.struct, " addr=", self.var_addr, " value=", self.value, " mask=", mask)
        if self.floatvar == True:
            self.value = int.from_bytes(struct.pack('f', self.value), byteorder='little')
        self.peek = MEMORY_CONTENT_CMD(self.var_addr, self.value, mask)
        return self.peek.command_bytes()

    def process_response(self, msg, index):
        index = self.peek.process_response(msg, index)
        return index


# Converts ticks per revolution into krpm
def TPR_TO_KRPM(tpr):
    if tpr == 0: return 0
    tpr = tpr * 1.0  # Convert to float
    us_per_rev = tpr / TICKS_PER_US
    s_per_rev  = us_per_rev / 1000000.0
    rev_per_s  = 1.0 / s_per_rev
    rev_per_min= rev_per_s * 60.0
    krpm       = rev_per_min / 1000.0
    return krpm

def device_enum_value_to_name(device, state_type, minor_error_code):
    if device == None:
        return '%d' % minor_error_code
    return device.enum_value_to_name(state_type, minor_error_code)


#
# Get the error format details from the error data JSON file. Return object is a
# dict of the form
#      data['data'] : Error data gathered from source header files.
#      data['meta'] : Meta data about the gathered data.
#
error_data = None  # Cache the results to prevent multiple parsing of error format data file.
def get_error_format_data(hash):
    global error_data, meta_error_data
    # Check that the hash matches the current error data
    if error_data == None or error_data['meta']['hash'] != hash:
        error_data_file = os.path.abspath(os.environ['PROJECT_DIR'] + '/support_scripts/error_data.json')
        error_data = None
        try:
            f = open(error_data_file)
            json_data = json.load(f)
            f.close()
            data, meta_data = json_data['%d' % hash]
            error_data = dict()
            error_data['data'] = data
            error_data['meta'] = meta_data
            error_data['file'] = error_data_file
        except:
            raise Exception("The device hash 0x%08x can not be found in %s" % (hash, error_data_file))
    return error_data

# Convert extended error information into a human readable form.
# Arguments  data     - Byte array of data from EXTENDED_ERROR_REQ
#            detail   - Detail of message
#                          'terse'  Shortest message   e.g.  '3012'
#                          'basic'  Short message      e.g.  'UNDER_VOLTAGE'
#                          'normal' Normal message     e.g.  'System voltage too low.  (UNDER_VOLTAGE)'
#                          'full'   Multi-line message e.g.  'System voltage too low.  (UNDER_VOLTAGE)\n
#                                                            Running: voltage = 19238 mV'
#                          'extended' Multi-line message e.g.  'System voltage too low.  (UNDER_VOLTAGE)\n
#                                                               System voltage low.\n
#                                                               The system voltage is too low to start the motor.\n
#                                                               Running: voltage = 19238 mV'
# Note: If the supplied array is empty (i.e. no error), the responses are
#    terse:           '0'
#    basic:           'NO_ERROR'
#    normal message:  'No Error (NO_ERROR)'
#    full:            'No Error (NO_ERROR)'
# Returns    error message string
# Usage:
#     msg = device.command_messages()
#     msg.add(EXTENDED_ERROR_REQ())
#     device.send(msg)
#     data = msg.results[0].data[4:]
#     hash = int.from_bytes(msg.results[0].data[:4], byteorder='little', signed=False)
#     print("data = '%s'" % extended_error_str(data, hash, detail='basic'))
#
def extended_error_str(data, hash, detail='basic'):
    # If only the error data hash value was given, then there is no error.
    # Add the 'no error' error code so the function behaves correctly.
    if len(data) == 0:
        data = [0, 0]

    # Get the error format data
    error_format_data = get_error_format_data(hash)
    return extended_error_str_for_error_log_item(data, error_format_data, detail)

def extended_error_str_for_error_log_item(data, error_format_data, detail='basic'):
    meta_error_data = error_format_data['meta']
    error_data      = error_format_data['data']

    error_id = int.from_bytes(data[0:2], byteorder='little', signed=False)

    # Search the array to find the error ID
    index = None
    for i in range(len(error_data)):
        if error_data[i]['error_id'] == error_id:
            index = i
    if index == None:
        return 'Details of error %d not found in %s' % (error_id, error_format_data['file'])
    err_data = error_data[index]

    if detail == 'terse':
        return '%d' % error_id
    if detail == 'basic':
        return '%s' % err_data['name']
    if detail == 'normal':
        return '%s (%d)' % (err_data['name'], error_id)

    # Must be 'full' or 'extended'
    pos = 2
    error_str  = '%s (%d)\n' % (err_data['name'], error_id)
    if detail == 'extended':
        error_str += '%s\n' % err_data['long_name']
        error_str += '%s\n' % err_data['description']
    for src, data_type, err_str in err_data['log_params']:
        if data_type == 'I8':
            value = int.from_bytes(data[pos:pos+1], byteorder='little', signed=True)
            pos += 1
        elif data_type == 'U8':
            value = int.from_bytes(data[pos:pos+1], byteorder='little', signed=False)
            pos += 1
        elif data_type == 'S16':
            value = int.from_bytes(data[pos:pos+2], byteorder='little', signed=True)
            pos += 2
        elif data_type == 'U16':
            value = int.from_bytes(data[pos:pos+2], byteorder='little', signed=False)
            pos += 2
        elif data_type == 'S32':
            value = int.from_bytes(data[pos:pos+4], byteorder='little', signed=True)
            pos += 4
        elif data_type == 'U32':
            value = int.from_bytes(data[pos:pos+4], byteorder='little', signed=False)
            pos += 4
        elif data_type == 'FLOAT':
            value = int.from_bytes(data[pos:pos+4], byteorder='little', signed=False)
            value = struct.unpack('f', value)
            pos += 4
        elif data_type == 'SZ':
            old_pos = pos
            while data[pos] != 0:
                pos += 1
            value = data[old_pos:pos].decode("utf-8")
            pos += 1 # Skip over the null terminating byte
        else:
            value = None
        try:
            error_str += err_str % value
        except:
            error_str += 'Value=%r' % value
            error_str += '  DataType=%r' % data_type
            error_str += '  Str=%s' % err_str
        error_str += '\n'

    return error_str

# Given the raw bytearray, produce a dict with all of the error data in easily accessible form.
#
#   results['data']                   - Original byte array
#   results['hash']                   - integer   (hash value for the current data format)
#   results['write_count']            - Number of times the page has been written
#   results['error_log'] = array of dict()
#   results['error_log'][x]['terse']  - Terse string describing the log item
#   results['error_log'][x]['basic']  - Basic string describing the log item
#   results['error_log'][x]['normal'] - Normal string describing the log item
#   results['error_log'][x]['full']   - Full string describing the log item
#   results['error_log'][x]['data']   - Byte array of log element (excluding size byte)
#   results['flags']                  - Flags value
#   results['flags_str']              - String describing flags value
#   results['1_bit']                  - Array of 1 bit counter values (dicts)
#   results['1_bit'][x]['value']      - Count value
#   results['1_bit'][x]['names']      - List of error names associated with error.
#   results['8_bit']                  - Array of 1 bit counter values (dicts)
#   results['8_bit'][x]['value']      - Count value
#   results['8_bit'][x]['names']      - List of error names associated with error.
#   results['16_bit']                 - Array of 1 bit counter values (dicts)
#   results['16_bit'][x]['value']     - Count value
#   results['16_bit'][x]['names']     - List of error names associated with error.
#   results['32_bit']                 - Array of 1 bit counter values (dicts)
#   results['32_bit'][x]['value']     - Count value
#   results['32_bit'][x]['names']     - List of error names associated with error.
def interpret_raw_error_data(data):
    results = dict()
    # Extract the hash from the raw data - as a string
    hash = int.from_bytes(data[8:12], byteorder='little', signed=False)
    # Get the format data from the store of known data formats using the hash
    format_data = get_error_format_data(hash)
    results['hash'] = hash
    results['data'] = data
    results['write_count'] = int.from_bytes(data[4:7], byteorder='little', signed=False)

    # Interpret flags
    results['flags'] = data[7]
    results['flags_str'] = ''
    if results['flags'] & 1:
        results['flags_str'] += 'Invalid structure hash, '
    else:
        results['flags_str'] += 'Valid structure hash, '
    if results['flags'] & 2:
        results['flags_str'] += 'Invalid page 1 CRC, '
    else:
        results['flags_str'] += 'Valid page 1 CRC, '
    if results['flags'] & 4:
        results['flags_str'] += 'Invalid page 2 CRC, '
    else:
        results['flags_str'] += 'Valid page 2 CRC, '
    if (results['flags'] & 6) != 0:
        pass # Both pages are invalid, so the next flag is not used.
    elif results['flags'] & 8:
        results['flags_str'] += 'Data from error page 2, '
    else:
        results['flags_str'] += 'Data from error page 1, '


    # Interpret the error log data
    error_log = []
    pos = format_data['meta']['ERRD_LOG_POS']
    end = pos + format_data['meta']['ERRD_LOG_SIZE']
    while pos != None:
        next = pos + data[pos]   # Where is the position of the next item?
        if next >= end:          # Is the current data log item incomplete i.e. is the end of the record missing?
            pos = None
        elif pos == next:        # Are there no more items in the buffer?
            pos = None
        else:
            log_item = data[pos+1:pos + data[pos]]
            error_log_item = dict()
            error_log_item['terse']  = extended_error_str(log_item, hash, detail='terse')
            error_log_item['basic']  = extended_error_str(log_item, hash, detail='basic')
            error_log_item['normal'] = extended_error_str(log_item, hash, detail='normal')
            error_log_item['full']   = extended_error_str(log_item, hash, detail='full')
            error_log_item['data']   = log_item
            error_log.append(error_log_item)
            pos = next
    results['error_log'] = error_log


    # Interpret the 1 bit error counter
    counters = []
    for i in range(format_data['meta']['ERRD_COUNTER_SIZE_1_BIT'] * 8):
        counter = dict()
        pos = format_data['meta']['ERRD_COUNTER_POS_1_BIT'] + (i//8)
        bit = i & 7
        counter['value'] = (data[pos] >> bit) & 1
        names = ''
        for err in format_data['data']:
            if (err['bin_id_name'] == '1_BIT') and (err['bin_id_element']) == i:
                names += ' ' + err['name'] +  ' '
        counter['names'] = names
        counters.append(counter)
    results['1_bit'] = counters

    # Interpret the 8 bit error counter
    counters = []
    for i in range(format_data['meta']['ERRD_COUNTER_SIZE_8_BIT']):
        counter = dict()
        pos = format_data['meta']['ERRD_COUNTER_POS_8_BIT'] + i
        counter['value'] = data[pos]
        names = ''
        for err in format_data['data']:
            if (err['bin_id_name'] == '8_BIT') and (err['bin_id_element'] == i):
                names += ' ' + err['name'] +  ' '
        counter['names'] = names
        counters.append(counter)
    results['8_bit'] = counters

    # Interpret the 16 bit error counter
    counters = []
    for i in range(format_data['meta']['ERRD_COUNTER_SIZE_16_BIT']):
        counter = dict()
        pos = format_data['meta']['ERRD_COUNTER_POS_16_BIT'] + (i*2)
        counter['value'] = int.from_bytes(data[pos:pos+2], byteorder='little', signed=False)
        names = ''
        for err in format_data['data']:
            if (err['bin_id_name'] == '16_BIT') and (err['bin_id_element'] == i):
                names += ' ' + err['name'] +  ' '
        counter['names'] = names
        counters.append(counter)
    results['16_bit'] = counters

    # Interpret the 24 bit error counter
    counters = []
    for i in range(format_data['meta']['ERRD_COUNTER_SIZE_24_BIT'] // 3):
        counter = dict()
        pos = format_data['meta']['ERRD_COUNTER_POS_24_BIT'] + (i*3)
        counter['value'] = int.from_bytes(data[pos:pos+3], byteorder='little', signed=False)
        names = ''
        for err in format_data['data']:
            if (err['bin_id_name'] == '24_BIT') and (err['bin_id_element'] == i):
                names += ' ' + err['name'] +  ' '
        counter['names'] = names
        counters.append(counter)
    results['24_bit'] = counters
    return results

# Gets the MAINS_VOLTAGE_RMS parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_MAINS_VOLTAGE_RMS_PARAMETER())
#     device.send(msg)
#     print("Result = %f Volts" % msg.results[0].voltage_V)
class GET_MAINS_VOLTAGE_RMS_PARAMETER(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_MAINS_VOLTAGE_RMS, name = 'MAINS VOLTAGE RMS', **kwargs)
        self.voltage_rms_mV = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.voltage_rms_mV = int.from_bytes(self.data, byteorder='little', signed=True) / 1000
        return index

# Gets the MAINS_VOLTAGE Mparameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_MAINS_VOLTAGE_MAG_AVE_RAW_PARAMETER())
#     device.send(msg)
#     print("Result = %f Volts" % msg.results[0].voltage_V)
class GET_FCT_MAINS_VOLTAGE_MAG_AVE_RAW_PARAMETER(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_FCT_MAINS_VOLTAGE_AVE_RAW, name = 'MAINS VOLTAGE MAG AVE RAW', **kwargs)
        self.voltage_mag_ave_raw = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.voltage_mag_ave_raw = int.from_bytes(self.data, byteorder='little', signed=True) / 1000
        return index        
        
# Gets the MAINS_PERIOD parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(v9_protocol.GET_MAINS_PERIOD_PARAMETER())
#     device.send(msg)
#     print("Result = %f ms" % msg.results[0].period_ms)
#     print("Result = %f Hz" % msg.results[0].frequency_Hz)
class GET_MAINS_PERIOD_PARAMETER(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_MAINS_PERIOD, name = 'MAINS PERIOD', **kwargs)
        self.period_ms = None  # Value is not available until a response is parsed
        self.frequency_Hz = None
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.period_ms = int.from_bytes(self.data, byteorder='little', signed=False) / 1000.
        self.frequency_Hz = 0 if self.period_ms == 0 else 1000. / self.period_ms
        return index

# Sets the PCB_VRMS_AC_OFFSET configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(SET_FCT_VRMS_AC_OFFSET(123))
#     device.send(msg)
class SET_FCT_VRMS_AC_OFFSET(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  0x7fff: raise Exception("Out of range")
        if value < -0x8000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_FCT_VRMS_AC_OFFSET,
                cal_data = value.to_bytes(2, byteorder='little', signed=True), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the PCB_VRMS_AC_OFFSET configuration setting in raw units.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(GET_FCT_VRMS_AC_OFFSET())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_FCT_VRMS_AC_OFFSET(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_FCT_VRMS_AC_OFFSET, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=True)
        return index

# Sets the ISENSE_RESULT_ARRAY_PAGE parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(dipc.SET_ISENSE_RESULT_ARRAY_PAGE(0))
#     device.send(msg)
#     print("Result = %d" % msg.results[0].array_page)
class SET_ISENSE_RESULT_ARRAY_PAGE(PARAMETER_CMD):
    def __init__(self, fetch_status=1, **kwargs):
        PARAMETER_CMD.__init__(self, PARAM_ID_ISENSE_RESULT_ARRAY_PAGE, fetch_status.to_bytes(1, byteorder='little', signed=False), name = 'ISENSE_RESULT_ARRAY_PAGE', **kwargs)
    def process_response(self, msg, index):
        index = PARAMETER_CMD.process_response(self, msg, index)
        self.array_page = int.from_bytes(self.data, byteorder='little', signed=False)
        return index


# Sets the ISENSE_FETCH_STATUS parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(dipc.SET_ISENSE_FETCH_STATUS(fetch_status=1))
#     device.send(msg)
#     print("Result = %d" % msg.results[0].fetch_status)
class SET_ISENSE_FETCH_STATUS(PARAMETER_CMD):
    def __init__(self, fetch_status=1, **kwargs):
        PARAMETER_CMD.__init__(self, PARAM_ID_ISENSE_FETCH_STATUS, fetch_status.to_bytes(1, byteorder='little', signed=False), name = 'ISENSE_FETCH_STATUS', **kwargs)
    def process_response(self, msg, index):
        index = PARAMETER_CMD.process_response(self, msg, index)
        self.fetch_status = int.from_bytes(self.data, byteorder='little', signed=False)
        return index

# Gets the ISENSE_FETCH_STATUS parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(dipc.GET_ISENSE_FETCH_STATUS())
#     device.send(msg)
#     print("Result = %d" % msg.results[0].fetch_status)
class GET_ISENSE_FETCH_STATUS(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_ISENSE_FETCH_STATUS, name = 'ISENSE_FETCH_STATUS', **kwargs)
        self.fetch_status = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.fetch_status = int.from_bytes(self.data, byteorder='little', signed=False)
        return index

# Gets the ISENSE_SAMPLE_COUNT parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(dipc.GET_ISENSE_SAMPLE_COUNT())
#     device.send(msg)
#     print("Result = %d" % msg.results[0].sample_count)
class GET_ISENSE_SAMPLE_COUNT(PARAMETER_REQ):
    def __init__(self, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_ISENSE_SAMPLE_COUNT, name = 'ISENSE SAMPLE COUNT', **kwargs)
        self.sample_count = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.sample_count = int.from_bytes(self.data, byteorder='little', signed=False)
        return index


# Gets the ISENSE_SAMPLE_VALUES parameter.
# Usage:
#     msg = device.command_messages()
#     msg.add(dipc.GET_ISENSE_SAMPLE_VALUES(64))
#     device.send(msg)
#     print("Result = %d" % msg.results[0].isense_values)
class GET_ISENSE_SAMPLE_VALUES(PARAMETER_REQ):
    def __init__(self, sample_count, **kwargs):
        PARAMETER_REQ.__init__(self, PARAM_ID_ISENSE_VALUES, name = 'ISENSE VALUES', **kwargs)
        self.samplecount = sample_count
        self.isense_values = None  # Value is not available until a response is parsed
    def process_response(self, msg, index):
        index = PARAMETER_REQ.process_response(self, msg, index)
        self.isense_values = []
        for i in range (self.samplecount):
            self.isense_values.append(int.from_bytes(self.data[i*2:(i+1)*2], byteorder='little', signed=False))
        return index

# Sets the PCB_VRMS_AC_SLOPE configuration setting in raw units.
# Arguments  value  - Raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(SET_FCT_VRMS_AC_SLOPE(123))
#     device.send(msg)
class SET_FCT_VRMS_AC_SLOPE(CALIBRATE_CMD):
    def __init__(self, value, **kwargs):
        if value >  0x7fff: raise Exception("Out of range")
        if value < -0x8000: raise Exception("Out of range")
        CALIBRATE_CMD.__init__(self, cal_id = CALIB_ID_FCT_VRMS_AC_SLOPE,
                cal_data = value.to_bytes(2, byteorder='little', signed=False), **kwargs)
    def process_response(self, msg, index):
        return CALIBRATE_CMD.process_response(self, msg, index)

# Gets the PCB_VRMS_AC_SLOPE configuration setting in raw units.
# Results  value  - raw value
# Usage:
#     msg = device.command_messages()
#     msg.add(GET_FCT_VRMS_AC_SLOPE())
#     device.send(msg)
#     print("value=%d" % msg.results[0].value)
class GET_FCT_VRMS_AC_SLOPE(CALIBRATE_REQ):
    def __init__(self, **kwargs):
        CALIBRATE_REQ.__init__(self, cal_id = CALIB_ID_FCT_VRMS_AC_SLOPE, **kwargs)
        self.value = None
    def process_response(self, msg, index):
        index = CALIBRATE_REQ.process_response(self, msg, index)
        self.value = int.from_bytes(self.cal_data, byteorder='little', signed=False)
        return index

# Sets the POWER_PARAMETER parameter.
# This overrides the definition in lec_protocol.py because we are not using Watts.
# Usage:
#     msg = device.command_messages()
#     msg.add(SET_POWER_PARAMETER(flow_mode=0, adjustment=0))
#     device.send(msg)
#     print("Result = flow_mode %d, adjustment %d" % (msg.results[0].flow_mode, msg.results[0].adjustment))
class SET_POWER_PARAMETER(PARAMETER_CMD):
    def __init__(self, upper_speed=0, lower_speed=0, flow_mode=0, adjustment=0, **kwargs):
        power = (upper_speed & 0xff) << 24 | (lower_speed & 0xff) << 16 | (flow_mode & 0xff) << 8 | (adjustment & 0xff)
        PARAMETER_CMD.__init__(self, 0x0100, power.to_bytes(4, byteorder='little'), name = 'POWER', **kwargs)
    def process_response(self, msg, index):
        index = PARAMETER_CMD.process_response(self, msg, index)
        power = int.from_bytes(self.data, byteorder='little')
        self.upper_speed = (power >> 24) & 0xff
        self.lower_speed = (power >> 16) & 0xff
        self.flow_mode   = (power >> 8) & 0xff
        self.adjustment  = power & 0xff
        return index

class MEASURE_ISENSE(LecCommand):
    def __init__(self, cmd_id, **kwargs):
        self.cmd_id = cmd_id
        self.name = "MEASURE_ISENSE"
        LecCommand.__init__(self, cmd_name=self.name, **kwargs)

    def command_bytes(self):
        if self.debug_level > 20:
            print("Adding %s 0x%04x" % (self.name, self.cmd_id))
        return self.uint16(self.cmd_id)

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != CALIB_ID_FCT_MEASURE_ISENSE_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, FCT_MEASURE_ISENSE_RES))
        self.status = self.get_uint8(msg, index+2)
        self.current_a = self.get_uint32(msg, index+3) / 1000.
        self.address = self.get_uint32(msg, index+7)
        self.num_samples = self.get_uint16(msg, index+11)
        if self.debug_level > 20:
            print("Parsing %s: status %d, address %#x, num_samples %d" %
                    (self.name, self.status, self.address, self.num_samples))
        return index + 13

class MEASURE_ISENSE_CMD(MEASURE_ISENSE):
    def __init__(self, **kwargs):
        MEASURE_ISENSE.__init__(self, cmd_id=FCT_MEASURE_ISENSE_CMD, **kwargs)

class MEASURE_ISENSE_REQ(MEASURE_ISENSE):
    def __init__(self, **kwargs):
        MEASURE_ISENSE.__init__(self, cmd_id=FCT_MEASURE_ISENSE_REQ, **kwargs)


# Implements the DEV_RESET_CMD/RESET_EVT command/response.
#
# Note: This command should not be sent with other commands in a message. It causes an immediate reset.
# The bootloader is not invoked, the application is started immediately.
#
# Arguments  None
# Command:   UINT16 DEV_RESET_CMD (0x8037)
# Response:  UINT16 RESET_EVT (0x2000) + reset event data
#
# Usage:
#     msg = device.command_messages()
#     msg.add(lec_protocol.DEV_RESET_CMD())
#     device.send(msg)
class DEV_RESET_CMD(LecCommand):
    RESET_CMD = 0x8038
    RESET_EVT = 0x2000
    name = 'DEV_RESET_CMD'

    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.error_str = None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))

    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.RESET_CMD))
        return msg

    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.RESET_EVT:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.RESET_EVT))
        if self.debug_level > 20:
            print("Reset event")
        index += 2
        return index
        
        
# Implements the BOOTLOADER_VERSION_REQ/BOOTLOADER_VERSION_RES command/response.
# Arguments  None
# Results    version - uint32 of software version
# Command:   UINT16 BOOTLOADER_VERSION_REQ (0x8100)
# Response:  UINT16 BOOTLOADER_VERSION_RES (0x8101)
#            UINT32 VERSION   - Version number of software
# Usage:
#     msg = device.command_messages()
#     msg.add(dipc_protocol.BOOTLOADER_VERSION_REQ())
#     device.send(msg)
#     print("version=%d" % msg.results[0].version)
class BOOTLOADER_VERSION_REQ(LecCommand):
    BOOTLOADER_VERSION_REQ = 0x8100
    BOOTLOADER_VERSION_RES = 0x8101
    name = 'BOOTLOADER_VERSION_REQ'
    
    def __init__(self, **kwargs):
        LecCommand.__init__(self, **kwargs)
        self.version   = None   # Default attribute value before response is None
        if len(self.kwargs) != 0:
            raise Exception('%s: Unexepected parameters: %s' % (self.name, list(self.kwargs.keys())))
        
    def command_bytes(self):
        msg = bytearray()
        if self.debug_level > 20:
            print("Adding %s" % self.name)
        msg.extend(self.uint16(self.BOOTLOADER_VERSION_REQ))
        return msg
        
    def process_response(self, msg, index):
        cmd_id = self.get_uint16(msg, index)
        if cmd_id != self.BOOTLOADER_VERSION_RES:
            raise Exception('Unexpected response 0x%04x at %d, expected 0x%04x' % (cmd_id, index, self.BOOTLOADER_VERSION_RES))
        self.version   = self.get_uint32(msg, index+2)
        if self.debug_level > 20:
            print("Parsing %s: version=%d (0x%08x)" % (self.name, self.version, self.version))
        index += 6
        return index        
