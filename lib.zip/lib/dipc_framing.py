import os
import sys

# Do not import this module, import the module ./dipc_framing/dipc_framing.py

# Add the folder to tune import path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + '/dipc_framing')

# Delete this import of the library from the modules so the other module may be added
sys.modules.pop('dipc_framing', None)

# Import the module
import dipc_framing

