#-------------------------------------------------------------------------------
# Name:        Behaviour Configuration
# Purpose:     This module allows the user to set or query the start behaviour
#              of motor.  It can be run as a standalone application.
#
# Authors:     Mike Morgan, Nikita Shmidt
#
# Created:     15/03/2018
# Copyright:   (c) Dyson Technology Ltd. 2018
#-------------------------------------------------------------------------------

import gui                      # Dyson Simple User Interface library
import sc_protocol as protocol  # Dyson N553 SC comms interface

# Import eeprom flag definitions.
# This import is meant to depend on the project number as returned by target via DIPC.
# Currently, only N553 SC is supported.
import sc_eeprom as eeprom      # Dyson N505 EEPROM flag definitions

APP_TITLE = "Set board behaviour"
APP_HELP  = "This script allows the user to set the board behaviour.\n" + \
            "The behaviour is stored in non-volatile memory and should be persistent\n" + \
            " between reboots/reprogramming."

# Full stickiness for Tk controls
STICKY_NSEW = gui.N + gui.S + gui.E + gui.W

class this_app(gui.app):
    #
    # Define the controls
    #
    def __init__(self, *args, **kwargs):
        # Process arguments speficic to this application
        if 'device' in kwargs:
            self.device = kwargs['device']
            del kwargs['device']
            self.close_funcs.append(self.device.closing) # Give the application a function which will abort the connection
        else:
            gui.error("'device' is a required named parameter for this app.")

        if 'parent_data' in kwargs:
            self.parent_data = kwargs['parent_data']
            print("Parent data received")
            del kwargs['parent_data']

        # Initialise the base class
        gui.app.__init__(self, *args, **kwargs)

        # Read autostart value and behaviour flags from target
        self.recv()

        self.add_text('Behaviour flags:')
        self.newline()
        self.behaviour_flag_buttons = []
        for bf in eeprom.behaviour_flags:
            tooltip = "Off: %s.\nOn: %s." % tuple(bf)
            func = BehaviourSetter(self, bf)
            button = self.add_tick_box(text=bf.text, func=func, span=2, tooltip=tooltip)
            button.set_value(self.parent_data.sc_behaviour >> bf.bit_position & 1)
            func.button = button
            self.behaviour_flag_buttons.append(button)
            self.newline()

        self.add_line(300, span=2)
        self.newline()

        self.disableFilterCheckButton = self.add_tick_box(text="Disable filter check", func=self.disableFilterCheckSetter, span=2, tooltip=None)
        self.disableFilterCheckButton.set_value(self.parent_data.sc_disableFilterFlag)

        self.newline()
        self.eboxShutDownButton = self.add_tick_box(text="Disable ebox shutdown", func=self.eboxShutDownSetter, span=2, tooltip=None)
        self.eboxShutDownButton.set_value(self.parent_data.sc_eboxShutDown)

        self.newline()
        self.disableL2cErrorsButton = self.add_tick_box(text="Disable L2C errors", func=self.disableL2cErrorsSetter, span=2, tooltip=None)
        self.disableL2cErrorsButton.set_value(self.parent_data.sc_disableL2cErrors)

        self.newline()
        self.add_line(300, span=2)
        self.newline()

        self.add_button("Write to EEPROM", self.write, sticky=STICKY_NSEW)
        self.add_button("Reset", self.reset, sticky=STICKY_NSEW)

    # Add a radio button element to the dialog
    def add_radio_button(self, text='', variable=None, value=None, func=None, span=1, tooltip=None, sticky=gui.W+gui.N, padx=2, pady=2, justify=gui.LEFT):
        assert variable
        gui.Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = gui.Radiobutton(self, text=text, variable=variable, value=value, command=func, justify=justify)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        if tooltip != None: gui.createToolTip(x, tooltip)
        return x

    # Add a horizontal line
    def add_line(self, width=200, height=5, span=1, sticky=STICKY_NSEW, padx=2, pady=2):
        gui.Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = gui.Canvas(self, width=width, height=height)
        x.create_line(0, 2, width-1, 2)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        return x

    def recv(self):
        self.parent_data.get_sc_behavior_flags_trigger=True
        self.parent_data.get_sc_usageConfig_eboxShutDown_trigger=True
        self.parent_data.get_sc_disableFilterFlag_trigger=True
        self.parent_data.get_sc_usageConfig_disableL2cErrors_trigger=True

    def send(self):
        self.parent_data.set_sc_behavior_flags_trigger=True
        self.parent_data.set_sc_usageConfig_eboxShutDown_trigger = True
        self.parent_data.set_sc_disableFilterFlag_trigger=True
        self.parent_data.set_sc_usageConfig_disableL2cErrors_trigger=True

    def write(self):
        self.parent_data.finalise_sc_calibration_trigger=True

    def reset(self):
        print("Reset to defaults.")
        self.parent_data.sc_behaviour = 0
        for button in self.behaviour_flag_buttons:
            button.set_value(0)
        self.parent_data.sc_disableFilterFlag = 0
        self.parent_data.sc_disableL2cErrors = 0
        self.parent_data.sc_eboxShutDown = 0
        self.eboxShutDownButton.set_value(0)
        self.disableFilterCheckButton.set_value(0)
        self.disableL2cErrorsButton.set_value(0)
        self.send()

    def disableFilterCheckSetter(self):
        self.parent_data.sc_disableFilterFlag = self.disableFilterCheckButton.value()
        if self.parent_data.sc_disableFilterFlag == 0:
            print("Filter check is enabled")
        else:
            print("Filter check is disabled")
        self.parent_data.set_sc_disableFilterFlag_trigger=True

    def eboxShutDownSetter(self):
        self.parent_data.sc_eboxShutDown = self.eboxShutDownButton.value()
        if self.parent_data.sc_eboxShutDown == 0:
            print("Usage Config: Ebox shutdown is enabled")
        else:
            print("Usage Config: Ebox shutdown is disabled")
        self.parent_data.set_sc_usageConfig_eboxShutDown_trigger=True

    def disableL2cErrorsSetter(self):
        self.parent_data.sc_disableL2cErrors = self.disableL2cErrorsButton.value()
        if self.parent_data.sc_disableL2cErrors == 0:
            print("Usage Config: L2C errors are enabled")
        else:
            print("Usage Config: L2C errors are disabled")
        self.parent_data.set_sc_usageConfig_disableL2cErrors_trigger=True

# Effectively a function closure
class BehaviourSetter:
    def __init__(self, app, bf):
        self.app = app
        self.bf = bf

    def __call__(self):
        flag = self.button.value()
        print("Behaviour:", self.bf[flag])
        mask = 1 << self.bf.bit_position
        self.app.parent_data.sc_behaviour = self.app.parent_data.sc_behaviour & ~mask | (flag * mask)
        self.app.parent_data.set_sc_behavior_flags_trigger=True



# Called by parent programs
def exec(parent_app, parent_data,device):
    app = this_app(parent=parent_app, parent_data=parent_data, device=device, title=APP_TITLE)
    return app

# Called by parent programs
def description():
    return APP_HELP


# This code starts the app if the file is executed rather than imported.
if __name__ == '__main__':
    # Get a connection to a device
    device = protocol.HC_Protocol()
    # Run the script
    app = exec(gui.Tk(), device)
    app.mainloop()
    device.close()
