#-------------------------------------------------------------------------------
# Name:        env
# Purpose:     Provides the project environment information to Python scripts
#
# Author:      Mike Morgan
#
# Created:     17/02/2018
# Copyright:   (c) Dyson 2018
#-------------------------------------------------------------------------------

# This library provides a method to allow Python scripts to discover details of the project file. This can also be altered/extended with
# command line options provided by the calling script.

import os
import re
import sys
import copy
import glob
import json
import time
import getpass
import subprocess


#        
# Software repository data. This is where the software release zip file is places on Artifactory.
#
software_rel_repo   = 'https://artifactory.dyson.global.corp/artifactory/N553 - MPS/n553_sc'
flash_image_rel_repo= 'https://artifactory.dyson.global.corp/artifactory/N553 - MPS/n553_sc'
arti_read_username  = 'generic_ddm_leads'  # User name to read from software_rel_repo
arti_write_username = 'generic_ddm_tests'  # User name to read and write to flash_image_rel_repo

bitbucket_repo      = 'https://stash.dyson.global.corp/projects/KWG/repos/n553_sc'
bitbucket_scf_repo  = 'https://stash.dyson.global.corp/projects/KWG/repos/n553_sc'

# Targets
# Details of each target the software can be built for
#
targets = dict()
targets['D20J'] = dict()
targets['D20J']['hal_folders'] = ['hal']                           # C include folders
targets['D20J']['hw_file']     = 'hw.h'                            # The hw.h with target specific macros
targets['D20J']['bootloader']  = 'bootloader_with_metadata.hex'    # Bootloader for this target, relative to /bootloader
targets['D20J']['dfp_define']  = '__SAMD20G16__'                   # MCU DFP define for linting
targets['D20J']['dfp_include'] = 'Keil/SAMD20_DFP/1.1.0/Device/SAMD20/Include' # MCU DFP include folder for linting
targets['D20J']['scf_code']    = '01'                              # Compatible System Constants File

# Command line options:
#   build_no=N        : The variable BUILD_NO is set to N. N is a string, usually a number e.g. '12'or a tag e.g. '248SP.01.001'  Default is ''
#   git=<hex>         : The variable GIT is set to the git revision sctring. Default is ''
#   branch=<text>     : The variable BRANCH is set to the branch name. E.g.  'feature/DHJ-9-Fix_the_bug'. Default is ''
#   pcb=<text>        : The variable PCB is set to the platform name. E.g.  'N248J_DDM_PCB_V1'. There is no default.
#   build_type=<type> : The variable BUILD_TYPE is set to the build setting. Either 'DEV' (development build) or 'PROD' (production build). Default 'DEV'
#   sys_const=<file>  : The variable SYS_CONSTANTS_FILE is set to the test System Constants file to use. Default emag_scripts/SoftwareDevSystemConstants.xlsx
#   target=<text>     : The variable TARGET is set to the uVision target to use.
#   variant=<text>    : The variable VARIANT.  This is a two digit id identifying the software build variant.

# Define the value names and default value. A variable and environment variable of the same name is defined.
# The values comes from the command line  (VAR_NAME=VALUE).
# If the value is nor defined from the command line, the value will come from any existing environment variable.
# If the is no defined environment variable, the value will come from the default value in the list.
# Some values have no default value because they are always defined by lib/setup_project.cmd    

#
# Project environment settings
# These values are typically set in lib/setup_project.cmd (in environment variables) but can be over-ridded
# by the command line. In fact any argument on the command line will over-write the environment variable and
# also create a library variable. For example,  
#    script.cmd  TEMP_DIR=c:\temp
# would (for sub-scripts) over-write the environemnt variable TEMP_DIR and create a library variable env.TEMP_DIR.
# 
# The variables in this list will always be created (with the default value if there is no environment variable or command line value)
#

#          Value name                  Default value
values = [('PROJECT_NAME',             ''), 
          ('PROJECT_NUMBER',           ''),
          ('PROJECT_COMPONENT_NUMBER', ''),
          ('PROJECT_DIR',              ''),
          ('TEMP_DIR',                 ''),
          ('TOOLS_DIR',                ''),
          ('NETWORK_TOOLS_DIR',        ''),
          ('FORCE_BUILD',              '0'),
          ('BUILD_NO',                 'local'),
          ('BRANCH',                   ''),
          ('GIT',                      ''),
          ('BUILD_TYPE',               'DEV'),   # DEV or PROD
          ('VARIANT',                  '00'),
          ('TARGET',                   '')]
          
# Record the number of parameters
noOfParams = len(sys.argv) - 1

# Check to see if the command line has var=value, if it does, create an environment variable and library variable.
args = [ sys.argv[0] ]
for arg in sys.argv[1:]:
    if '=' in arg:
        parts = arg.split('=', 1)
        option_name = parts[0]
        option_value = parts[1]
        os.environ[option_name] = option_value
        exec(option_name + '="' + option_value.replace('\\','/') + '"')


# Ensure that the values in 'values' have a corresponding environment variable and library variable
for var_name,default in values:
    if not var_name in os.environ:
        # Make a library variable using the value name and the environment variable value
        os.environ[var_name] = default
    exec(var_name + ' = "' + os.environ[var_name].replace('\\', '/') + '"')


# Define possible PCB targets that this project may build for    
allTargetNames = []
for key in targets:
    allTargetNames.append(key)
    

# Special case for TARGET
# The TARGET option is sometimes specified as a folder path where the last folder is the target name. 
# e.g. C:\my_project\Objects\N240_PCB\
# In this case, change TARGET to just the target name
# e.g. N240_PCB
TARGET = TARGET.replace('\\', '/')
if TARGET == '':                          # Special case where TARGET is not specified, choose the first one in the list
    TARGET = allTargetNames[0] + '/'
if '/' in TARGET:
    TARGET = TARGET.split('/')[-2]
    os.environ['TARGET'] = TARGET


# Find the default SCF file for each target. It's located in emag_scripts
for target in targets:
    scf_code = targets[target]['scf_code']
    file_wildcard = PROJECT_DIR + '/system_scripts/SoftwareDevSystemConstants*.xlsx'
    scf_files = glob.glob(file_wildcard)
    targets[target]['default_scf'] = scf_files[0]   # There shouldn't be multiple files, but if there is, just choose the first file
    

# Make env.target a dictionary item with all the required data about the target
# target = targets[TARGET]


# Return a dictionary of all the macros in hw.h
# Parse the file if required
hw_macros_list = None
def hw_macros():
    global hw_macros_list
    if hw_macros_list == None:
        hw_macros_list = dict()
        pattern = re.compile('#define +(HW_[A-Z_0-9]+) +([0-9][0-9a-fA-FxX]*)')
        with open(PROJECT_DIR + '/source/' + target['hw_file'], 'r') as f:
            for line in f:
                match = pattern.match(line)
                if match:
                    hw_macros_list[match.group(1)] = eval(match.group(2))
    return hw_macros_list


# Return a macro value defined in hw.h
def hw_macro(name):
    return hw_macros()[name]


#
# This function returns True if the script is currently running on the Bamboo build server.
# The build server is identified when an environment variable 'THIS_IS_BUILD_SERVER' is present.
#
# Example use:
#     import env as b:
#     if b.running_on_build_server():
#         print("Running on build server")
#        
def running_on_build_server():
    return 'THIS_IS_BUILD_SERVER' in os.environ


#
# Get an Artifactory password based on the username.
# If the password is not stored in a local JSON file,
# ask the user to supply it.
# A check is made with Artifactory to ensure the password is correct.
# If not, the user will be asked to enter the password.
#
# The function returns the correct password as a string.
#
def getPassword(username, repoName = 'Artifactory'):
    # Import (and install if required) Python external 'requests' library to access Artifactory
    try:
        import requests
    except:
        package = 'requests'
        import subprocess
        import sys
        subprocess.call([sys.executable, "-m", "pip", "install", package])
        import requests

    # We are accessing Artifactory in an insecure was (very basic authentication implemented on server)
    # So we want to prevent the warning produced by the Python library
    # Note: urllib3 is imported with 'requests'
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)    

    # Read the password data
    try:
        f = open(os.environ['USERPROFILE'] + '/artifactory_passwords.json', 'r')
        passwords = f.read()
        f.close()
        passwords = json.loads(passwords)
    except:
        passwords = dict()

    # Get the password from the password data
    import base64
    # Encode password

    password = None
    if username in passwords:
        password = base64.b64decode(passwords[username].encode('utf8')).decode("utf-8")

    if repoName == 'Artifactory':
        url = 'https://artifactory.dyson.global.corp/artifactory/'
    elif repoName == 'Stash':
        url = 'https://stash.dyson.global.corp/projects'
    else:
        raise Exception('Unknown repository ' + repoName)

    passwordCorrect = False
    while not passwordCorrect:
        if password == None:
            password  = getpass.getpass("Enter %s password for '%s' (no echo): " % (repoName, username))
        # Test the password
        response = requests.get(url, auth=(username, password), verify=False)
        passwordCorrect = (response.status_code == requests.codes.ok)
        if  'Bad credentials'   in response.text: passwordCorrect = False
        if  'Permission denied' in response.text: passwordCorrect = False
        if not passwordCorrect:
            print("Incorrect")
            password = None

    # Write to the password data
    try:
        passwords[username] = base64.b64encode(password.encode("utf-8")).decode('utf8')
        f = open(os.environ['USERPROFILE'] + '/artifactory_passwords.json', 'w')
        f.write(json.dumps(passwords))
        f.close()
    except:
        pass
    
    return password


# Get the data for the specified URL
#   url - The URL of the page to get
#   auth - Tuple of username and password
def getUrl(url, auth):
    # Import (and install if required) Python external 'requests' library to access Artifactory
    try:
        import requests
    except:
        package = 'requests'
        import subprocess
        import sys
        subprocess.call([sys.executable, "-m", "pip", "install", package])
        import requests

    return requests.get(url, auth=auth, verify=False)
    

# Run the operating system command and capture the output and return code
# Param cmd - System command to execute
# Returns a tuple  (output text string, return code)
def execute(cmd):
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return r.stdout.decode('utf-8'), r.returncode


#
# Return a path to a browser application.
# Priority is
#   Chrome
#   Firefox
#   Edge?
#
def browserPath():
    # Find Program Files
    if 'ProgramFiles(x86)' in os.environ:
        programFiles = os.environ['ProgramFiles(x86)']
    else:
        programFiles = os.environ['ProgramFiles']

    # Try chrome
    cmd = programFiles + '\\Google\\Chrome\\Application\\chrome.exe'
    if os.path.isfile(cmd):
        return cmd

    # Try Firefox
    cmd = programFiles + '\\Mozilla Firefox\\firefox.exe'
    if os.path.isfile(cmd):
        return cmd

    print("Either Chrome or Firefox needs to be installed.")
    time.sleep(3)
    sys.exit(1)


#
# Return the path to git.exe 
#
gitPathStore = None
def gitPath():
    global gitPathStore
    if gitPathStore == None:
        gitPathStore,r = execute('where git.exe')
        if r != 0:
            raise Exception('Could not find git.exe')
        gitPathStore = gitPathStore.replace('\n', '').replace('\r', '')
    return gitPathStore
    

#
# Return the path to curl.exe 
# This assumes Git for Windows is installed
#
def curlPath():
    # C:\Program Files\Git\bin\git.exe
    # changes to
    # C:\Program Files\Git\mingw64\bin\\curl.exe
    return gitPath()[:-11] + 'mingw64\\bin\\curl.exe'
    

#
# Delete a folder even if it has a .git folder in it.
# shutil.rmtree does not do this.
#
def rmFolder(folder):
    os.system('cmd.exe /c rmdir /s/q "%s" 1>NUL 2>NUL' % folder.replace('/', '\\'))
    

#
# Provide a safe error function
#
def error(errStr):
    print("ERROR: " + errStr)
    sys.exit(1)