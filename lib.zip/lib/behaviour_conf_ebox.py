#-------------------------------------------------------------------------------
# Name:        Behaviour Configuration
# Purpose:     This module allows the user to set or query the start behaviour
#              of motor.  It can be run as a standalone application.
#
# Authors:     Mike Morgan, Nikita Shmidt
#
# Created:     01/09/2017
# Copyright:   (c) Dyson Technology Ltd. 2017
#-------------------------------------------------------------------------------

import gui                      # Dyson Simple User Interface library
import v9_protocol as protocol  # Dyson V9 DDM comms interface

# Import eeprom flag definitions.
# This import is meant to depend on the project number as returned by target via DIPC.
# Currently, only V9/N505 is supported.
import v9_eeprom as eeprom      # Dyson V9/N505 EEPROM flag definitions

APP_TITLE = "Set board behaviour"
APP_HELP  = "This script allows the user to set the board behaviour.\n" + \
            "The behaviour is stored in non-volatile memory and should be persistent\n" + \
            " between reboots/reprogramming."

# Full stickiness for Tk controls
STICKY_NSEW = gui.N + gui.S + gui.E + gui.W

class this_app(gui.app):
    #
    # Define the controls
    #
    def __init__(self, *args, **kwargs):
        # Process arguments speficic to this application
        if 'v9_device' in kwargs:
            self.v9_device = kwargs['v9_device']
            del kwargs['v9_device']
        else:
            gui.error("'v9_device' is a required named parameter for this app.")
            
        if 'parent_data' in kwargs:            
            self.parent_data = kwargs['parent_data']
            print("Parent data received")
            del kwargs['parent_data']         

        # Initialise the base class
        gui.app.__init__(self, *args, **kwargs)

        # Read autostart value and behaviour flags from target
        self.recv()

        self.add_text('Automatic start on power up:')
        self.newline()

        self.autostart_var = gui.IntVar()
        self.autostart_var.set(self.parent_data.v9_autostart)

        for ao in eeprom.autostart_options:
            self.add_radio_button(text=ao.text,
                    variable=self.autostart_var,
                    value=ao.value,
                    span=2,
                    func=self.set_autostart,
                    tooltip=ao.on)
            self.newline()
        self.autostart_text = self.add_text('', span=2)
        # self.set_autostart()    # update autostart_text
        self.newline()

        self.add_line(300, span=2)
        self.newline()

        self.add_text('Behaviour flags:')
        self.newline()
        self.behaviour_flag_buttons = []
        for bf in eeprom.behaviour_flags:
            tooltip = "Off: %s.\nOn: %s." % tuple(bf)
            func = BehaviourSetter(self, bf)
            button = self.add_tick_box(text=bf.text, func=func, span=2, tooltip=tooltip)
            button.set_value(self.parent_data.v9_behaviour >> bf.bit_position & 1)
            func.button = button
            self.behaviour_flag_buttons.append(button)
            self.newline()

        self.add_line(300, span=2)
        self.newline()

        self.add_button("Write to EEPROM", self.write, sticky=STICKY_NSEW)
        self.add_button("Reset", self.reset, sticky=STICKY_NSEW)

    # Add a radio button element to the dialog
    def add_radio_button(self, text='', variable=None, value=None, func=None, span=1, tooltip=None, sticky=gui.W+gui.N, padx=2, pady=2, justify=gui.LEFT):
        assert variable
        gui.Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = gui.Radiobutton(self, text=text, variable=variable, value=value, command=func, justify=justify)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        if tooltip != None: gui.createToolTip(x, tooltip)
        return x

    # Add a horizontal line
    def add_line(self, width=200, height=5, span=1, sticky=STICKY_NSEW, padx=2, pady=2):
        gui.Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = gui.Canvas(self, width=width, height=height)
        x.create_line(0, 2, width-1, 2)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        return x

    def set_autostart(self):
        value = self.autostart_var.get()
        self.parent_data.v9_autostart = value
        self.autostart_text.change_text(eeprom.decode_autostart(value))
        print("Autostart:", eeprom.decode_autostart(value))
        self.send(autostart=True)

    def recv(self):
        self.get_v9_behavior_flags_trigger=True

    def send(self, autostart=False, behaviour=False, both=False):
        if autostart or both:
            self.parent_data.set_v9_auto_start_trigger=True
        if behaviour or both:
            self.set_v9_behavior_flags_trigger=True

    def write(self):
        self.parent_data.finalise_v9_calibration_trigger=True

    def reset(self):
        print("Reset to defaults.")
        self.parent_data.v9_autostart = 0
        self.parent_data.v9_behaviour = 0
        self.autostart_var.set(0)
        for button in self.behaviour_flag_buttons:
            button.set_value(0)
        self.send(both=True)


# Effectively a function closure
class BehaviourSetter:
    def __init__(self, app, bf):
        self.app = app
        self.bf = bf

    def __call__(self):
        flag = self.button.value()
        print("Behaviour:", self.bf[flag])
        mask = 1 << self.bf.bit_position
        self.app.parent_data.v9_behaviour = self.app.parent_data.v9_behaviour & ~mask | (flag * mask)
        self.app.send(behaviour=True)

# Called by parent programs
def exec(parent_app, parent_data, v9_device):
    app = this_app(parent=parent_app,parent_data=parent_data,v9_device=v9_device, title=APP_TITLE)
    return app

# Called by parent programs
def description():
    return APP_HELP


# This code starts the app if the file is executed rather than imported.
if __name__ == '__main__':
    # Get a connection to a device
    v9_device = protocol.V9_Protocol()
    # Run the script
    app = exec(gui.Tk(), v9_device)
    app.mainloop()
    device.close()
