#-------------------------------------------------------------------------------
# Name:        FID Status Read
# Purpose:     This module READ ONLY FID related status
#
# Copyright:   (c) Dyson Technology Ltd. 2021
#-------------------------------------------------------------------------------

import gui                      # Dyson Simple User Interface library
import sc_protocol as protocol  # Dyson N553 SC comms interface

APP_TITLE = "FID Status Reading"
APP_HELP  = "This script allows the user to get latest FID status .\n"

# Full stickiness for Tk controls
STICKY_NSEW = gui.N + gui.S + gui.E + gui.W

class this_app(gui.app):
    #
    # Define the controls
    #
    def __init__(self, *args, **kwargs):
        # Process arguments speficic to this application
        if 'device' in kwargs:
            self.device = kwargs['device']
            del kwargs['device']
            self.close_funcs.append(self.device.closing) # Give the application a function which will abort the connection
        else:
            gui.error("'device' is a required named parameter for this app.")

        if 'parent_data' in kwargs:
            self.parent_data = kwargs['parent_data']
            print("Parent data received")
            del kwargs['parent_data']

        # Initialise the base class
        gui.app.__init__(self, *args, **kwargs)

        self.add_text(text='Variable')
        self.add_text(text='Value')
        self.newline()
        self.add_line(500, span=8)
        self.newline()
        self.add_text(text="FID Param")

        self.showFidData = []
        self.NUMBER_OUTPUT_WIDTH = 12
        self.newline()

        for i in range(0,self.parent_data.totalFidInfo):
            self.add_text(self.parent_data.fidDataList[i][0])
            self.showFidData.append("-")
            self.showFidData[i] = self.add_text(text='')
            self.showFidData[i].config(width = self.NUMBER_OUTPUT_WIDTH)
            self.newline()
        self.newline()
        self.add_line(500, span=8)
        self.newline()
        self.add_text(text="output blockage")
        self.showOutputBlockage = self.add_text(text='')
        self.showOutputBlockage.config(width = self.NUMBER_OUTPUT_WIDTH)
        self.newline()
        self.update_controls()
        self.after(200, self.periodic)

    def periodic(self):
        for i in range(0,self.parent_data.totalFidInfo):
            self.showFidData[i].change_text("%i" % self.parent_data.fidDataList[i][1])

        self.showOutputBlockage.change_text("%s" % self.parent_data.filterOutputBlockageStatus)
        self.after(200, self.periodic)  # Call this function again

    # Add a horizontal line
    def add_line(self, width=200, height=5, span=1, sticky=STICKY_NSEW, padx=2, pady=2):
        gui.Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = gui.Canvas(self, width=width, height=height)
        x.create_line(0, 2, width-1, 2)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        return x

# Called by parent programs
def exec(parent_app, parent_data,device):
    app = this_app(parent=parent_app, parent_data=parent_data,device=device, title=APP_TITLE)
    return app

# Called by parent programs
def description():
    return APP_HELP

# This code starts the app if the file is executed rather than imported.
if __name__ == '__main__':
    # Get a connection to a device
    description()
    print("This is not a atandalone script")

