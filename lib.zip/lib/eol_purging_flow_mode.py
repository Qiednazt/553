"""
Copywrite Dyson(C) 2021

API to force amb pressure/temp errors. This forces the product to go in the ambient pressure faults.
Note - This is a drop down list, which can have either state.
       But product can have both under pressure/over pressure alarm at the same moment - which is an unlikely scenario.
"""

from enum import Enum
from sc_protocol import SET_EOL_PURGING_FLOW_MODE, GET_EOL_PURGING_FLOW_MODE


class PurgingFlowModes(Enum):

    UI_FLOW_RATE_4L_S = 1  
    UI_FLOW_RATE_6L_S = 2 
    UI_FLOW_RATE_9L_S = 3
    UI_FLOW_RATE_12L_S = 4

    @classmethod
    def has_value(cls, value):
        return value in cls._value2member_map_


def update_mode(device, mode):
    """
    Update purging flow, does not write to eeprom.

    Args:
        device: sc_protocol device to communicate through
        mode: str, int or PurgingFlowModes mode to send

    Returns:
        None
    """
    if isinstance(mode, str):
        int_mode = PurgingFlowModes[mode].value
    elif isinstance(mode, PurgingFlowModes):
        int_mode = mode.value
    elif isinstance(mode, int) and (mode < len(PurgingFlowModes)):
        int_mode = mode
    else:
        raise ValueError("Invalid operating mode {}".format(mode))

    cmd = SET_EOL_PURGING_FLOW_MODE(int_mode)
    msg = device.command_messages()
    msg.add(cmd)
    device.send(msg)

def get_mode(device):
    """
    get current amb pressure error flag

    Args:
        device: sc_protocol device to communicate with

    Returns:
        PurgingFlowModes: index of the array of enum elements.
        This index is first stored by the Combo class of the Gui.

    Raises:
        ValueError: got a bad response
    """
    cmd = GET_EOL_PURGING_FLOW_MODE()
    msg = device.command_messages()
    msg.add(cmd)
    device.send(msg)

    if PurgingFlowModes.has_value(cmd.eol_purging_flow_mode):
        curr_purging_flow = cmd.eol_purging_flow_mode
        print("SC purging flow received",  PurgingFlowModes(cmd.eol_purging_flow_mode))
    else:
        curr_purging_flow = PurgingFlowModes.UI_FLOW_RATE_12L_S.value
        print("SC purging flow received is invalid {}, set to default value {}".format(cmd.eol_purging_flow_mode, PurgingFlowModes(curr_purging_flow)))
        
    for idx, i in enumerate(PurgingFlowModes):
        if i.value == curr_purging_flow:
            return idx
