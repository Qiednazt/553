#-------------------------------------------------------------------------------
# Name:        v9_eeprom.py
# Purpose:     This module defines EEPROM flags for V9/N505.
#
# Author:      Nikita Shmidt
#
# Created:     30/08/2017
# Copyright:   (c) Dyson Technology Ltd. 2017
#-------------------------------------------------------------------------------

class BehaviourFlag(list):
    def __init__(self, **kwargs):
        self.append(kwargs["off"])
        self.append(kwargs["on"])
        del kwargs["off"]
        del kwargs["on"]
        self.__dict__.update(kwargs)

behaviour_flags = (
        BehaviourFlag(
            bit_position = 0,
            name = "EEP_BEHAVIOUR_DISABLE_BRAKING_BIT_MASK",
            text = "Disable active braking",
            off = "Active electric braking will be applied on stop command",
            on = "Motor will run down without braking on stop command"
        ),
        BehaviourFlag(
            bit_position = 1,
            name = "EEP_BEHAVIOUR_DISABLE_CURRENT_TRIP_BIT_MASK",
            text = "disable current trip",
            off = "Current trip is enabled",
            on = "Current trip is disabled"
        ),
        BehaviourFlag(
            bit_position = 2,
            name = "EEP_BEHAVIOUR_DISABLE_RELAY_CHECKS_BIT_MASK",
            text = "Disable relay checks",
            off = "Relay short/open checks will be performed",
            on = "Relay short/open checks will not be performed"
        ),
        BehaviourFlag(
            bit_position = 3,
            name = "EEP_BEHAVIOUR_ENABLE_FCT_MODE_BIT_MASK",
            text = "Enable FCT mode",
            off = "The motor starts in the application (normal) mode",
            on = "The motor starts in the FCT mode"
        ),
        BehaviourFlag(
            bit_position = 4,
            name = "EEP_BEHAVIOUR_DISABLE_REVERSE_FLOW_PROTECTION_BIT_MASK",
            text = "Disable reverse flow protection",
            off = "The motor will be allowed to spin backwards. NOTE: This is DANGEROUS if you don't know what you're doing.",
            on = "When detected the motor will raise an error"
        ),
        BehaviourFlag(
            bit_position = 5,
            name = "EEP_BEHAVIOUR_CAL_WRITE_DISABLE_BIT_MASK",
            text = "Disable calibration write",
            off = "Calibration write is enabled",
            on = "Calibration write is disabled"
        ),
        BehaviourFlag(
            bit_position = 6,
            name = "EEP_BEHAVIOUR_DISABLE_TURN_OFF_RELAY_BIT_MASK",
            text = "Disable turn off relay control",
            off = "Relay control is enabled",
            on = "Relay control is disabled"
        ),
        BehaviourFlag(
            bit_position = 7,
            name = "EEP_BEHAVIOUR_DISABLE_EBOX_HC_HEARTBEAT_BIT_MASK",
            text = "Disable Ebox heater heartbeat",
            off = "Ebox HC hearbeat is enabled",
            on = "Ebox HC hearbeat is disabled"
        ),
)

HIGH_FLOW = 0
MEDIUM_FLOW = 1
LOW_FLOW = 2

class AutostartOption:
    APP_ENABLE_AUTOSTART_BIT_MASK = 0x8000

    def __init__(self, auto, mode=0, text="", on=""):
        self.value = self.APP_ENABLE_AUTOSTART_BIT_MASK if auto else 0
        self.value |= mode << 8     # attachment adjustment is 0
        self.text = text
        if auto:
            self.on = "Motor will start in " + text + " mode on power up"
        else:
            self.on = on

autostart_options = (
        AutostartOption(False,
            text = "Off (default)",
            on = "Motor will not start automatically on power up"
        ),
        AutostartOption(True, HIGH_FLOW, "High flow"),
        AutostartOption(True, MEDIUM_FLOW, "Medium flow"),
        AutostartOption(True, LOW_FLOW, "Low flow"),
)

autostart_options_dict = { ao.value: ao for ao in autostart_options }

def decode_autostart(value):
    try:
        return autostart_options_dict[value].on
    except KeyError:
        return "Unknown autostart setting"
