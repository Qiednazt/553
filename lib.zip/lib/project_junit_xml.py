#
# This module pretends to be the junit_xml library
# If the library is not available, it is installed from the 'python_install' folder.
# The environment 'python_install' points to a folder which contains the zip file for this library.
#
# Usage:
#   from project_junit_xml import TestSuite, TestCase
#

import tarfile
import os
import shutil

# Import the module

try:
    from junit_xml import TestSuite, TestCase
    installed = True
except:
    installed = False

# Did it import?
if not installed:
    import project_setuptools # This module is required for the installation
    # The module did not load, we will have to install it
    name = 'junit-xml-1.7'
    
    # Display install message window
    import tkinter
    top = tkinter.Tk()
    top.title("Installing")
    msg = tkinter.Message(top, text="\nInstalling library " + name + "\n")
    msg.pack()
    top.update()

    filename = os.environ['NETWORK_TOOLS_DIR'] + '/Python/' + name + '.tar.gz'

    # Remove pre-existing install files
    shutil.rmtree(os.environ['TEMP'] + '/' + name, ignore_errors=True)

    errstr = None
    try:
        errstr = 'Installing ' + name + ': Could not open ' + filename
        targz = tarfile.open(filename)
        errstr = 'Installing ' + name + ': Could not open unzip ' + filename + '  to  ' + os.environ['TEMP']
        targz.extractall(os.environ['TEMP'])
        os.system('cd /d "' + os.environ['TEMP'] + '\\' + name + '" & "' + os.environ['PYTHON_EXEC_DIR'] + '\\python.exe" setup.py install')
        errstr = 'Installing ' + name + ': Failed to install'
        from junit_xml import TestSuite, TestCase
        os.system('pause')
        errstr = None
        print("\n\nFinished installing library " + name + "\n\n")
        # Restart the app
        str = ''
        for arg in sys.argv:
            str += ' "%s" ' % arg
        os.execlp(sys.executable, '-x',  '-x', str)
    except:
        pass

    if errstr != None:
        raise Exception(errstr)

    # Clean up
    shutil.rmtree(os.environ['TEMP'] + '/' + name, ignore_errors=True)
    
    # Close the info window
    try:
        top.destroy()
    except:
        pass

