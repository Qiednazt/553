#-------------------------------------------------------------------------------
# Name:        Standby Configuration
# Purpose:     This module allow to change standby configuration
#
# Created:     04/11/2020
# Copyright:   (c) Dyson Technology Ltd. 2019
#-------------------------------------------------------------------------------

import time                     # Standard Python library
import os                       # Standard Python library
import gui                      # Dyson Simple User Interface library
import sc_protocol as protocol  # Dyson N553 SC comms interface
import binascii
from enum import Enum

APP_TITLE = "N553 Standby Configuration GUI"
APP_HELP  = "This script allow to change standby configuration .\n"

# Full stickiness for Tk controls
STICKY_NSEW = gui.N + gui.S + gui.E + gui.W

class StandbyTimerConf(Enum):
    """
    Standby timer configuration, must match tUi_standbyTimerConf from ui_management.h
    """
    default = 0
    two_min = 2
    three_min = 3
    four_min = 4
    disabled = 5
    
    @classmethod
    def has_value(cls, value):
        return value in cls._value2member_map_

class this_app(gui.app):
    #
    # Define the controls
    #
    def __init__(self, *args, **kwargs):
        # Process arguments specific to this application
        if 'device' in kwargs:
            self.device = kwargs['device']
            del kwargs['device']
            self.close_funcs.append(self.device.closing) # Give the application a function which will abort the connection
        else:
            gui.error("'device' is a required named parameter for this app.")

        if 'parent_data' in kwargs:
            self.parent_data = kwargs['parent_data']
            del kwargs['parent_data']

        # Initialize the base class
        gui.app.__init__(self, *args, **kwargs)

        # Read standby configuration from target
        self.read()

        self.add_text(text='Note: This should be used for debugging/testing purpose ONLY!!')
        self.newline()
        self.add_line(600, span=10)
        self.newline()
        self.add_text(text='Select \'Default\' to use default standby timer value set in SC')
        self.newline()
        self.add_text(text='Select \'Disabled\' to disable standby')
        self.newline()
        self.add_text(text='Hit \'Apply to EEPROM\' button and power cycle')
        self.newline()
        self.add_line(600, span=10)
        self.newline()
        self.add_text(text="Standby Timer Configuration")
        self.standby_timer_conf = self.add_combo(text=[i.name for i in StandbyTimerConf],
                                        tooltip="select standby timer configuration")
        self.standby_timer_conf.current(self.get_index(self.parent_data.sc_standby_timer_conf))
        self.standby_timer_conf.func = lambda: self.send()
        self.newline()
        self.add_button("Apply to EEPROM", self.apply_ee_button_pressed, tooltip="Save config in EEPROM (permanent)")
        self.after(200, self.periodic)

    # This function is called periodically. If there has not been any communication with the device for over a second,
    # it sends a 'get error status' command.  This sets the status text to either 'OK', 'Error' or 'Disconnected'
    def periodic(self):
        self.after(200, self.periodic)  # Call this function again

    # Add a horizontal line
    def add_line(self, width=200, height=5, span=1, sticky=STICKY_NSEW, padx=2, pady=2):
        gui.Grid.columnconfigure(self, self.dialog_col, weight = 1)
        x = gui.Canvas(self, width=width, height=height)
        x.create_line(0, 2, width-1, 2)
        x.grid(row = self.dialog_row, column = self.dialog_col, columnspan = span, sticky = sticky, padx=padx, pady=pady)
        self.dialog_col = self.dialog_col + span
        return x

    def read(self):
        self.parent_data.get_sc_standby_timer_trigger=True

    def send(self):
        self.parent_data.sc_standby_timer_conf = StandbyTimerConf[self.standby_timer_conf.get()].value
        self.parent_data.set_sc_standby_timer_trigger = True

    def apply_ee_button_pressed(self):
        self.parent_data.finalise_sc_calibration_trigger = True

    def get_index(self, value):
        for idx, i in enumerate(StandbyTimerConf):
            if i.value == value:
                return idx 

# Called by parent programs
def exec(parent_app, parent_data, device):
    app = this_app(parent=parent_app, parent_data=parent_data, device=device, title=APP_TITLE)
    return app

# Called by parent programs
def description():
    return APP_HELP

# This code starts the app if the file is executed rather than imported.
if __name__ == '__main__':
    # Get a connection to a device
    with sc_protocol.SC_Protocol(debug_level=0) as hc_device:
        # Run the script
        app = exec(None, hc_device)
        hc_device.close()
