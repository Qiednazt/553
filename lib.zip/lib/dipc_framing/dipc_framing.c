
// https://docs.microsoft.com/en-us/windows/desktop/DevIO/communications-functions

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <windows.h>
#include <winioctl.h>

typedef struct portData_s
{
    HANDLE     hComm;
    OVERLAPPED overlapped;      // We have to use overlapped I/O because we are using threads.
    uint8_t portName[80];       // Used for debug
    uint8_t rxBuffer[256];      // Temporary buffer for getting data from serial port buffer
    int     bytesInRxBuffer;    // Temporary buffer for getting data from serial port buffer
    int     bytesInRxBufferIdx; // Temporary buffer for getting data from serial port buffer
    int     failLine;           // Line number for failure of some sort
    int     totalGoodRxBytes;   // Total number of bytes which have been valid
    int     totalBadRxBytes;    // Total number of bytes which have been invalid
    int     rxCount;            // Used when calculating totalGoodRxBytes and totalBadRxBytes
    int     errorLine;          // When an error happens, this is the line number
    int     errorCode;          // When an error happens, this is the GetLastError() value
    int     debugLevel;         // >=90 and the tx, rx bytes are sent to stdout
    bool    terminate;          // Set to true when trying to terminate
} portData_t;


// These are the protocol special data values
enum
{
    DLE_BYTE         = 0x12,
    ESC_BYTE         = 0xdb,
    ESCAPED_ESC_BYTE = 0xdd,
    ESCAPED_DLE_BYTE = 0xde,
};


// State value
enum
{
    WAITING_FOR_DATA_BYTE,    // When getting a frame - waiting for a normal byte
    WAITING_FOR_ESCAPE_BYTE   // When getting a frame - waiting for an escaped byte
};


enum
{
    CRC32_INITIAL_VALUE  = 0xffffffffU,   // Initial CRC value to be used before any CRC bytes calculated.
    CRC32_FINAL_XOR      = 0xffffffffU,   // Final XOR value to be applied when all crc bytes calculated.
};

//! CRC data used while calculating the CRC for a message.
typedef struct
{
    uint32_t crc;        //!< CRC value updated as new bytes are calculated.
    uint32_t data;       //!< Temporary store for systems that do hardware accelerated block CRC calculations.
    uint8_t  count;      //!< Number of bytes calculated. Used to ensure padding bytes are added if the number of bytes is not divisible by 4.
} tDipccrc_crc32;


// Private functions //////////////////////////////////////////////////////////////////////////////



//
// Global function definitions
//

static void dipccrc_initCrc32(tDipccrc_crc32* crcData)
{
    crcData->crc   = CRC32_INITIAL_VALUE;  // Input CRC value (DIPC standard)
    crcData->count = 0U;                   // Number of bytes counted. We are only interested in bits 0 and 1
}


static void dipccrc_newCrc32Byte(tDipccrc_crc32* crcData, const uint8_t byte)
{
    // This function implements the DIPC CRC without any hardware acceleration.
    // This particular implementation of the function is thread safe. Other implementations are not.
    
    // Table for DIPC 32 bit CRC.
    // Polynomial (reverse representation) 0xEDB88320
    // This table may be generated with the following Python
    //   for r in range(256):
    //     if (r & 7) == 0:  print('\n        ', end='')
    //     for j in range(8):
    //       if (r & 1) != 0:
    //         r = (r >> 1) ^ 0xEDB88320
    //       else:
    //         r = r >> 1
    //     print('0x%08xU, ' % r, end='')
    //
    static const uint32_t m_dipccrc_crc32_table[256] = 
    {
        0x00000000U, 0x77073096U, 0xee0e612cU, 0x990951baU, 0x076dc419U, 0x706af48fU, 0xe963a535U, 0x9e6495a3U,
        0x0edb8832U, 0x79dcb8a4U, 0xe0d5e91eU, 0x97d2d988U, 0x09b64c2bU, 0x7eb17cbdU, 0xe7b82d07U, 0x90bf1d91U,
        0x1db71064U, 0x6ab020f2U, 0xf3b97148U, 0x84be41deU, 0x1adad47dU, 0x6ddde4ebU, 0xf4d4b551U, 0x83d385c7U,
        0x136c9856U, 0x646ba8c0U, 0xfd62f97aU, 0x8a65c9ecU, 0x14015c4fU, 0x63066cd9U, 0xfa0f3d63U, 0x8d080df5U,
        0x3b6e20c8U, 0x4c69105eU, 0xd56041e4U, 0xa2677172U, 0x3c03e4d1U, 0x4b04d447U, 0xd20d85fdU, 0xa50ab56bU,
        0x35b5a8faU, 0x42b2986cU, 0xdbbbc9d6U, 0xacbcf940U, 0x32d86ce3U, 0x45df5c75U, 0xdcd60dcfU, 0xabd13d59U,
        0x26d930acU, 0x51de003aU, 0xc8d75180U, 0xbfd06116U, 0x21b4f4b5U, 0x56b3c423U, 0xcfba9599U, 0xb8bda50fU,
        0x2802b89eU, 0x5f058808U, 0xc60cd9b2U, 0xb10be924U, 0x2f6f7c87U, 0x58684c11U, 0xc1611dabU, 0xb6662d3dU,
        0x76dc4190U, 0x01db7106U, 0x98d220bcU, 0xefd5102aU, 0x71b18589U, 0x06b6b51fU, 0x9fbfe4a5U, 0xe8b8d433U,
        0x7807c9a2U, 0x0f00f934U, 0x9609a88eU, 0xe10e9818U, 0x7f6a0dbbU, 0x086d3d2dU, 0x91646c97U, 0xe6635c01U,
        0x6b6b51f4U, 0x1c6c6162U, 0x856530d8U, 0xf262004eU, 0x6c0695edU, 0x1b01a57bU, 0x8208f4c1U, 0xf50fc457U,
        0x65b0d9c6U, 0x12b7e950U, 0x8bbeb8eaU, 0xfcb9887cU, 0x62dd1ddfU, 0x15da2d49U, 0x8cd37cf3U, 0xfbd44c65U,
        0x4db26158U, 0x3ab551ceU, 0xa3bc0074U, 0xd4bb30e2U, 0x4adfa541U, 0x3dd895d7U, 0xa4d1c46dU, 0xd3d6f4fbU,
        0x4369e96aU, 0x346ed9fcU, 0xad678846U, 0xda60b8d0U, 0x44042d73U, 0x33031de5U, 0xaa0a4c5fU, 0xdd0d7cc9U,
        0x5005713cU, 0x270241aaU, 0xbe0b1010U, 0xc90c2086U, 0x5768b525U, 0x206f85b3U, 0xb966d409U, 0xce61e49fU,
        0x5edef90eU, 0x29d9c998U, 0xb0d09822U, 0xc7d7a8b4U, 0x59b33d17U, 0x2eb40d81U, 0xb7bd5c3bU, 0xc0ba6cadU,
        0xedb88320U, 0x9abfb3b6U, 0x03b6e20cU, 0x74b1d29aU, 0xead54739U, 0x9dd277afU, 0x04db2615U, 0x73dc1683U,
        0xe3630b12U, 0x94643b84U, 0x0d6d6a3eU, 0x7a6a5aa8U, 0xe40ecf0bU, 0x9309ff9dU, 0x0a00ae27U, 0x7d079eb1U,
        0xf00f9344U, 0x8708a3d2U, 0x1e01f268U, 0x6906c2feU, 0xf762575dU, 0x806567cbU, 0x196c3671U, 0x6e6b06e7U,
        0xfed41b76U, 0x89d32be0U, 0x10da7a5aU, 0x67dd4accU, 0xf9b9df6fU, 0x8ebeeff9U, 0x17b7be43U, 0x60b08ed5U,
        0xd6d6a3e8U, 0xa1d1937eU, 0x38d8c2c4U, 0x4fdff252U, 0xd1bb67f1U, 0xa6bc5767U, 0x3fb506ddU, 0x48b2364bU,
        0xd80d2bdaU, 0xaf0a1b4cU, 0x36034af6U, 0x41047a60U, 0xdf60efc3U, 0xa867df55U, 0x316e8eefU, 0x4669be79U,
        0xcb61b38cU, 0xbc66831aU, 0x256fd2a0U, 0x5268e236U, 0xcc0c7795U, 0xbb0b4703U, 0x220216b9U, 0x5505262fU,
        0xc5ba3bbeU, 0xb2bd0b28U, 0x2bb45a92U, 0x5cb36a04U, 0xc2d7ffa7U, 0xb5d0cf31U, 0x2cd99e8bU, 0x5bdeae1dU,
        0x9b64c2b0U, 0xec63f226U, 0x756aa39cU, 0x026d930aU, 0x9c0906a9U, 0xeb0e363fU, 0x72076785U, 0x05005713U,
        0x95bf4a82U, 0xe2b87a14U, 0x7bb12baeU, 0x0cb61b38U, 0x92d28e9bU, 0xe5d5be0dU, 0x7cdcefb7U, 0x0bdbdf21U,
        0x86d3d2d4U, 0xf1d4e242U, 0x68ddb3f8U, 0x1fda836eU, 0x81be16cdU, 0xf6b9265bU, 0x6fb077e1U, 0x18b74777U,
        0x88085ae6U, 0xff0f6a70U, 0x66063bcaU, 0x11010b5cU, 0x8f659effU, 0xf862ae69U, 0x616bffd3U, 0x166ccf45U,
        0xa00ae278U, 0xd70dd2eeU, 0x4e048354U, 0x3903b3c2U, 0xa7672661U, 0xd06016f7U, 0x4969474dU, 0x3e6e77dbU,
        0xaed16a4aU, 0xd9d65adcU, 0x40df0b66U, 0x37d83bf0U, 0xa9bcae53U, 0xdebb9ec5U, 0x47b2cf7fU, 0x30b5ffe9U,
        0xbdbdf21cU, 0xcabac28aU, 0x53b39330U, 0x24b4a3a6U, 0xbad03605U, 0xcdd70693U, 0x54de5729U, 0x23d967bfU,
        0xb3667a2eU, 0xc4614ab8U, 0x5d681b02U, 0x2a6f2b94U, 0xb40bbe37U, 0xc30c8ea1U, 0x5a05df1bU, 0x2d02ef8dU,
    };
    
    uint32_t crc = crcData->crc;
    crcData->crc = (m_dipccrc_crc32_table[(uint8_t) crc ^ byte]) ^ (crc >> 8);
    crcData->count++;
}


static uint32_t dipccrc_finishCrc32(tDipccrc_crc32* crcData)
{
    // Ensure the CRC is calculated over a multiple of 4 bytes. (DIPC standard)
    while((crcData->count & 3U) != 0U)
    {
        dipccrc_newCrc32Byte(crcData, 0U);
    }
    return crcData->crc ^ CRC32_FINAL_XOR; // Apply final XOR word (DIPC standard)
}


static uint8_t dipccrc_calcCrc8(const uint16_t length)
{
    const uint8_t poly     = 0xe0U;   // 0xe0 is the reflected value of 0x07
    const uint8_t finalXor = 0xffU;
    
    uint8_t crc = 0xffU;   // Initial CRC value
    uint32_t i;
    
    crc ^= (uint8_t) length;  // Add the first byte
    for(i=8U; i != 0U; --i)
    {
        if((crc & 0x01U) != 0U)
        {
            crc = (crc >> 1U) ^ poly;
        }
        else
        {
            crc >>= 1U;
        }
    }
    crc ^= (uint8_t) (length >> 8);  // Add the second byte
    for(i=8U; i != 0U; --i)
    {
        if((crc & 0x01U) != 0U)
        {
            crc = (crc >> 1U) ^ poly;
        }
        else
        {
            crc >>= 1U;
        }
    }
    return crc ^ finalXor;
}


static bool frameValid(portData_t* obj, uint8_t* buffer, const int bufferSize)
{
    // Every frame should have at least two size bytes, a size CRC8 byte and 4 CRC32 bytes.
    if(bufferSize < 2)
    {
        // We do not update obj->failLine because this can get caused by erronous hardware bytes at the end of a transmitted packet.
        return false;
    }

    // Do the size bytes not match the buffer size?
    int size = buffer[0] + (256 * buffer[1]);
    if(size != (bufferSize-3))  // Subtract 3 because size+crc8 is not counted
    {
        obj->failLine = __LINE__;  // The packet length bytes do not match the number of de-stuffed bytes between DLEs.
        return false;
    }

    // Check the size CRC
    uint8_t sizeCrc8 = dipccrc_calcCrc8(size);
    if(sizeCrc8 != buffer[2])
    {
        obj->failLine = __LINE__;  // The packet length bytes and CRC8 do not match.
        return false;
    }

    // Check the frame CRC
    tDipccrc_crc32 crcData;
    dipccrc_initCrc32(&crcData);
    for(int i = 3; i < bufferSize-4; i++)  // Calculate from 3 because size+crc8 is not part of CRC32
    {
        dipccrc_newCrc32Byte(&crcData, buffer[i]);
    }
    uint32_t crc32 = dipccrc_finishCrc32(&crcData);
    uint32_t crc32_msg = 0U;
    crc32_msg += buffer[bufferSize-1];
    crc32_msg <<= 8;
    crc32_msg += buffer[bufferSize-2];
    crc32_msg <<= 8;
    crc32_msg += buffer[bufferSize-3];
    crc32_msg <<= 8;
    crc32_msg += buffer[bufferSize-4];
    if(crc32_msg != crc32)
    {
        obj->failLine = __LINE__; // The CRC32 value does noy match the data
        return false;
    }

    // The frame has passed all the tests and must be valid.
    return true;
}


//
// @brief Non-blocking function for processing rx bytes. 
//
// This function performs the byte de-stuffing and DLE termination detection. Once a terminating
// DLE byte is detected, frameValid() is called to ensure the frame is valid.
// 
// Because DIPC specifies that there may be just one DLE byte between frames, the state is
// either 'waiting for data byte' or 'waiting for escaped data byte'. There is no
// 'waiting for DLE byte'.
// 
// @param obj[in,out]    - Ptr to the com port object.
// @param buffer[out]    - Frame buffer.
// @param bufferSize[in] - Maximum size of any frame. Excludes DLE bytes and stuffed bytes.
// @param byte[in]       - New byte to process.
// @param state[in,out]  - State variable for rx state machine.
// @param index[in,out]  - Current size of frame in buffer.
// @return true if a complete valid frame is in the buffer, false otherwise.
static bool processByte(portData_t* obj, uint8_t* buffer, const int bufferSize, 
                        uint8_t byte, int* state, int* index)
{
    // Keep a record of the number of bytes so we may know the level of data corruption.
    obj->rxCount++;

    // We now need to deal with the byte
    if(*state == WAITING_FOR_DATA_BYTE)
    {
        // Have we encountered a delimiter byte?
        if(byte == DLE_BYTE)
        {
            // Is the frame a valid frame?
            if(frameValid(obj, buffer, *index))
            {
                // Indicate that we have a valid frame in the buffer
                obj->totalGoodRxBytes += obj->rxCount;
                obj->rxCount = 0;
                return true;
            }
            else
            {
                // If this is not the start of a frame DLE then add the bytes to the bad bytes count
                if(*index != 0)
                {
                    // Throw away all data recieved so far
                    *index = 0;
                    obj->totalBadRxBytes += obj->rxCount;
                    obj->rxCount = 0;
                }
            }
        }
        // Is the buffer full?
        else if(*index == bufferSize)
        {
            // Throw away all data recieved so far
            obj->totalBadRxBytes += obj->rxCount;
            obj->rxCount = 0;
            *index = 0;
            obj->failLine = __LINE__;  // The packet was too big for the buffer.
        }
        // Is the byte an escape byte?
        else if(byte == ESC_BYTE)
        {
            *state = WAITING_FOR_ESCAPE_BYTE;
        }
        // Just a normal byte
        else
        {
            buffer[*index] = byte;
            *index += 1;
        }
    }
    // Must be waiting for an escaped byte
    else
    {
        if(byte == ESCAPED_DLE_BYTE)
        {
            buffer[*index] = DLE_BYTE;
            *index += 1;
        }
        else if(byte == ESCAPED_ESC_BYTE)
        {
            buffer[*index] = ESC_BYTE;
            *index += 1;
        }
        // No other bytes should follow an escape byte, so it is an invalid frame
        else
        {
            *index = 0;
            obj->totalBadRxBytes += obj->rxCount;
            obj->rxCount = 0;
        }
        *state = WAITING_FOR_DATA_BYTE;
    }

    // Indicate we do not yet have a frame
    return false;
}


// Send the given byte to the serial port. Do not check if it was sent successfully.
static void writeByteRaw(portData_t* obj, uint8_t byte)
{
    DWORD written;
    
    WriteFile(obj->hComm, &byte, 1, &written, &obj->overlapped);

    if(obj->debugLevel >= 90)
    {
        printf(" %02x", (unsigned int) byte);
    }
}


// Send the given byte to the serial port. Do not check if it was sent successfully.
static void writeByte(portData_t* obj, uint8_t byte)
{
    if(byte == DLE_BYTE)
    {
        writeByteRaw(obj, ESC_BYTE);
        writeByteRaw(obj, ESCAPED_DLE_BYTE);
    }
    else if(byte == ESC_BYTE)
    {
        writeByteRaw(obj, ESC_BYTE);
        writeByteRaw(obj, ESCAPED_ESC_BYTE);
    }
    else // A normal byte
    {
        writeByteRaw(obj, byte);
    }
}




// Return the number of bytes waiting in the os buffer.
static int bytesInRxBuffer(portData_t* obj)
{
    // Are we terminating?
    if(obj->hComm == NULL)
    {
        return 0;
    }
    // Use ClearCommError to get the number of bytes in the os rx buffer.
    COMSTAT status;
    DWORD errorFlags;
    if(!ClearCommError(obj->hComm, &errorFlags, &status))
    {
        // The error was probably generated during shutdown. Just return 0
        return 0;
    }
    return status.cbInQue;
}


// Get the specified number of bytes from the os rx buffer
static int readBytesFromRxBuffer(portData_t* obj, uint8_t* buffer, int bytesToRead)
{
    DWORD bytesRead = 0;
    (void) ReadFile(obj->hComm, buffer, bytesToRead, &bytesRead, &obj->overlapped);
    if(bytesRead > 0)
    {
        if(obj->debugLevel >= 90)
        {
            printf("DipcFraming: %s: Raw Rx:", obj->portName);
            for(int i = 0; i < bytesRead; i++)
            {
                printf(" %02x", buffer[i]);
            }
            printf("\n");
        }
    }
    return (int) bytesRead;
}


// Public functions ///////////////////////////////////////////////////////////////////////////////

void closeComPort(portData_t* obj)
{
    if(obj == NULL)
    {
        return;
    }
    CloseHandle(obj->overlapped.hEvent);
    if(obj->hComm != NULL)
    {
        PurgeComm(obj->hComm, PURGE_RXABORT | PURGE_TXABORT | PURGE_RXCLEAR | PURGE_TXCLEAR);
        BOOL result = CloseHandle(obj->hComm);
    }
    // We do not free the obj object yet
}


// Free the memory object.  It is assummed that all handles have been closed by closeComPort().
void freeComPort(portData_t* obj)
{
    free(obj);
}


// Open the specified com port
portData_t* openComPort(char* name, int debugLevel)
{
    int result;

    // Create the port object
    portData_t* obj = malloc(sizeof(portData_t));
    if(obj == NULL)
    {
        return NULL;
    }

    obj->terminate        = false;
    obj->failLine         = 0; // No error yet
    obj->totalGoodRxBytes = 0; // No bytes yet
    obj->totalBadRxBytes  = 0; // No bytes yet
    obj->rxCount          = 0; // No bytes yet
    obj->bytesInRxBuffer  = 0; // No bytes yet
    obj->errorLine        = 0; // No error yet
    obj->errorCode        = 0; // No error yet
    obj->debugLevel       = debugLevel;
    strncpy(obj->portName, name, sizeof(obj->portName)-1);

    // Open the port object
    memset(&obj->overlapped, 0, sizeof(OVERLAPPED));
    obj->overlapped.hEvent = CreateEventA(NULL, TRUE, FALSE, NULL);
    if(obj->overlapped.hEvent == NULL)
    {
        obj->errorLine = __LINE__;  // Failure to create an rx event for handle.
        obj->errorCode = (int) GetLastError();
        return obj;
    }

    // Try to open the port. Note that we are getting problems when opening a port immediately after closing it.
    // We get 'access denied' unless we wait a while. Windows pah!
    int count = 0;
    do
    {
        // Use the full Windows comport name e.g.  COM46  -->  \\.\COM46
        char full_name[20];
        strcpy(full_name, "\\\\.\\");
        strcat(full_name, name);

        obj->hComm = CreateFile(full_name, GENERIC_READ | GENERIC_WRITE, 
                                0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED, NULL);
        if(obj->hComm == INVALID_HANDLE_VALUE)
        {
            if(count == 5)
            {
                obj->errorLine = __LINE__;  // Could not open com port
                obj->errorCode = (int) GetLastError();
                closeComPort(obj);
                return obj;
            }
            count++;
            Sleep(100);
        }
    } while(obj->hComm == INVALID_HANDLE_VALUE);
    
    // Set comms baud etc
    DCB dcbSerialParams = { 0 }; // Initializing DCB structure
    dcbSerialParams.DCBlength = sizeof(dcbSerialParams);
    result = GetCommState(obj->hComm, &dcbSerialParams);
    if(result == 0)
    {
        obj->errorLine = __LINE__;  // GetCommState() failure on opening com port
        obj->errorCode = (int) GetLastError();
        closeComPort(obj);
        return obj;
    }
    dcbSerialParams.BaudRate          = CBR_115200;
    dcbSerialParams.ByteSize          = 8;
    dcbSerialParams.StopBits          = ONESTOPBIT;
    dcbSerialParams.Parity            = NOPARITY;
    dcbSerialParams.fBinary           = TRUE;
    dcbSerialParams.fDtrControl       = DTR_CONTROL_DISABLE; 
    dcbSerialParams.fOutxCtsFlow      = FALSE; // No CTS flow control
    dcbSerialParams.fOutxDsrFlow      = FALSE; // No DSR flow control
    dcbSerialParams.fTXContinueOnXoff = TRUE;  // No XON/XOFF output flow control
    dcbSerialParams.fInX              = FALSE; // No XON/XOFF input flow control
    dcbSerialParams.fNull             = FALSE; // NULL bytes treated as any other byte
    dcbSerialParams.fRtsControl       = RTS_CONTROL_DISABLE;
    dcbSerialParams.fAbortOnError     = FALSE; // Do not abort on error

    result = SetCommState(obj->hComm, &dcbSerialParams);
    if(result == 0)
    {
        obj->errorLine = __LINE__;  // SetCommState() failure on opening com port
        obj->errorCode = (int) GetLastError();
        closeComPort(obj);
        return obj;
    }
    COMMTIMEOUTS timeouts = { 0 };
    result = GetCommTimeouts(obj->hComm, &timeouts);
    if(result == 0)
    {
        obj->errorLine = __LINE__;  // GetCommTimeouts() failure on opening com port
        obj->errorCode = (int) GetLastError();
        closeComPort(obj);
        return obj;
    }
    
    // We will be reading a byte at a time. We don't mind waiting for the byte since we are going to
    // be running in another thread - so we don't want to hog the processor time.  However, we
    // have to quit reading periodically to check if the thread is going to quit.
    timeouts.ReadIntervalTimeout         = 100; // in milliseconds
    timeouts.ReadTotalTimeoutConstant    = 0;   // in milliseconds
    timeouts.ReadTotalTimeoutMultiplier  = 0;   // in milliseconds
    // We will not be using flow control so no timeouts are required
    timeouts.WriteTotalTimeoutConstant   = 0;   // in milliseconds
    timeouts.WriteTotalTimeoutMultiplier = 0;   // in milliseconds

    result = SetCommTimeouts(obj->hComm, &timeouts);
    if(result == 0)
    {
        obj->errorLine = __LINE__;  // SetCommTimeouts() failure on opening com port
        obj->errorCode = (int) GetLastError();
        closeComPort(obj);
        return obj;
    }
    
    return obj;
}


// Efficiently wait for a byte, or until the comms handle is closed
void waitForByte(portData_t* obj)
{
    // Wait forever for a byte
    (void) SetCommMask(obj->hComm, EV_RXCHAR | EV_ERR);
    DWORD dwCommEvent;
    (void) WaitCommEvent(obj->hComm, &dwCommEvent, NULL);
}


static int readByte(portData_t* obj)
{
    // Are there no bytes in the library buffer?
    if(obj->bytesInRxBuffer == 0)
    {
        // Try to get bytes from the os rx buffer. Ask how many bytes are in the os rx buffer.
        int bytes = bytesInRxBuffer(obj);
        // Too many for our local buffer?
        if(bytes > sizeof(obj->rxBuffer))
        {
            bytes = sizeof(obj->rxBuffer);
        }
        // Transfer bytes from os rx buffer to local rx buffer.
        if(bytes > 0)
        {
            bytes = readBytesFromRxBuffer(obj, obj->rxBuffer, bytes);
            obj->bytesInRxBuffer = bytes;
            obj->bytesInRxBufferIdx = 0;
        }
    }
    // Do we have no bytes at all?
    if(obj->bytesInRxBuffer == 0)
    {
        // Wait until a byte enters the buffer
        waitForByte(obj);
        if(obj->hComm == NULL)
        {
            return -1;
        }
    }
    int byte;
    if(obj->bytesInRxBuffer == 0)
    {
        byte = -1;
    }
    else
    {
        byte = obj->rxBuffer[obj->bytesInRxBufferIdx];
        obj->bytesInRxBufferIdx++;
        if(obj->bytesInRxBufferIdx == obj->bytesInRxBuffer)
        {
            obj->bytesInRxBuffer = 0;
        }
    }

    return byte;
}


//
// @brief Wait until we see a valid frame
//
// The function may also be terminated by terminateRx(). The function will return
// a frame with zero for the length bytes to indicate to the calling Python function
// that the rx thread should shut down.
//
void getFrame(portData_t* obj, uint8_t* buffer, const int bufferSize)
{
    int state = WAITING_FOR_DATA_BYTE;
    int index = 0;

    DWORD start = GetTickCount();

    while(true)
    {
        // Read the next serial byte
        int byte = readByte(obj);
        // Did we read a byte?
        if(byte >= 0)
        {
            // Process the byte - do we have a frame?
            if(processByte(obj, buffer, bufferSize, (uint8_t) byte, &state, &index))
            {
                // We have a valid frame, quit so it may be processed.
                return;
            }
        }
        // Has a thread thermination been signalled?
        if(obj->hComm == NULL || obj->terminate)
        {
            // We are aborting, so return an empty data frame to indicate termination
            buffer[0] = 0;
            buffer[1] = 0;
            return;
        }
        if((GetTickCount() - start) > 900)
        {
            // We are aborting, so return a special data frame to indicate termination
            buffer[0] = 1;
            buffer[1] = 0;
            return;
        }
    }
    // The software should never reach this point.
}


// Return the line number of the last failure. This helps determine what is going wrong.
int getFailLine(portData_t* obj)
{
    int line = obj->failLine;
    obj->failLine = 0;   // Clear the fail line for the next enquiry
    return line;
}


// Return the number of bytes recieved that have gone into valid frames
int getGoodRxByteCount(portData_t* obj)
{
    return obj->totalGoodRxBytes;
}


// Return the number of bytes recieved that have been discarded
int getBadRxByteCount(portData_t* obj)
{
    return obj->totalBadRxBytes;
}


// Cause getFrame to finish even if it does not have a valid frame.
void terminateRx(portData_t* obj)
{
    BOOL result = CloseHandle(obj->hComm); // This will terminate waiting events
    if(result)
    {
        // Success
        obj->hComm = NULL;
    }
    else
    {
        // Make a note of this error
        obj->errorLine = __LINE__;  // CloseHandle() failure
        obj->errorCode = GetLastError();
    }
    obj->terminate = true;
}


// This function allows Python to determine the error location
int getErrorLine(portData_t* obj)
{
    int line = obj->errorLine;
    obj->errorLine = 0;
    return line;
}


// This function allows Python to determine the error reason
int getErrorCode(portData_t* obj)
{
    int code = obj->errorCode;
    obj->errorCode = 0;
    return code;
}

// Send the given buffer as a DIPC frame.  The buffer does not include the
// delimiter bytes, frame length bytes, length CRC8 or the CRC32 bytes.
void sendFrame(portData_t* obj, uint8_t* buffer, int size)
{
    if(obj == NULL)
    {
        return;
    }
    if(obj->debugLevel >= 90)
    {
        printf("DipcFraming: %s: Raw Tx:", obj->portName);
    }

    writeByteRaw(obj, DLE_BYTE);                // DLE byte
    int msg_size = size + 4;                    // Add 4 for CRC32
    writeByte(obj, msg_size & 0xff);            // Length lsb
    writeByte(obj, msg_size >> 8);              // Length msb
    writeByte(obj, dipccrc_calcCrc8(msg_size)); // Length crc8

    tDipccrc_crc32 crcData;
    dipccrc_initCrc32(&crcData);

    for(int i = 0; i < size; i++)
    {
        uint8_t byte = buffer[i];
        dipccrc_newCrc32Byte(&crcData, byte);
        writeByte(obj, byte);
    }
    uint32_t crc32 = dipccrc_finishCrc32(&crcData);

    writeByte(obj, crc32 & 0xff);
    crc32 >>= 8;
    writeByte(obj, crc32 & 0xff);
    crc32 >>= 8;
    writeByte(obj, crc32 & 0xff);
    crc32 >>= 8;
    writeByte(obj, crc32 & 0xff);

    writeByteRaw(obj, DLE_BYTE);                   // Terminating DLE byte

    if(obj->debugLevel >= 90)
    {
        printf("\n");
    }
}


