var searchData=
[
  ['16_5fbit_20counter_20allocations',['16_BIT counter allocations',['../a00005.html',1,'']]],
  ['1_5fbit_20counter_20allocations',['1_BIT counter allocations',['../a00003.html',1,'']]]
];
