var searchData=
[
  ['8_5fbit_20counter_20allocations',['8_BIT counter allocations',['../a00004.html',1,'']]]
];
