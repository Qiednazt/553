var searchData=
[
  ['24_5fbit_20counter_20allocations',['24_BIT counter allocations',['../a00006.html',1,'']]]
];
