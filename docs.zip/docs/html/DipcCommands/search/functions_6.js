var searchData=
[
  ['selfdiagstartcmd',['selfDiagStartCmd',['../a00016.html#ga1c0536d359d98218f1e56966ff957e06',1,'dipccmd.c']]],
  ['selfdiagstopcmd',['selfDiagStopCmd',['../a00016.html#ga7ee961ae26b6f2b5e40f674b675bdbc2',1,'dipccmd.c']]],
  ['settlcon',['setTLCOn',['../a00016.html#ga02604ffdbb8446d0a5068aac266f6ca9',1,'dipccmd.c']]],
  ['shutdowncfm',['shutdownCfm',['../a00015.html#ga595d508dc393d908362d9272aec2b245',1,'dipccmd.c']]],
  ['sleeprequest',['sleepRequest',['../a00015.html#ga10f6236b963ede299ed5d9e284a9e23e',1,'dipccmd.c']]]
];
