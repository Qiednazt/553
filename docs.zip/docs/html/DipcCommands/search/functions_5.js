var searchData=
[
  ['resetnonrecoverableerrors',['resetNonRecoverableErrors',['../a00016.html#ga19e181221dcc961fa0eb2c26eb2e9211',1,'dipccmd.c']]]
];
