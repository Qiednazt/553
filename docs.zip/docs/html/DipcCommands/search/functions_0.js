var searchData=
[
  ['activestaterequest',['activeStateRequest',['../a00015.html#ga50d22f59be802930ef44990515b4d158',1,'dipccmd.c']]],
  ['autopausestaterequest',['autoPauseStateRequest',['../a00015.html#ga810e64e149ccfadaa007bae809b5e8dc',1,'dipccmd.c']]]
];
