var searchData=
[
  ['unsupported_5fres_28res_5fid_3d0x0001_29',['UNSUPPORTED_RES(res_id=0x0001)',['../a00172.html',1,'']]],
  ['usage_5fdata_20_28config_5fid_3d0x2000_20_2b_20blk_29',['USAGE_DATA (CONFIG_ID=0x2000 + BLK)',['../a00044.html',1,'']]]
];
