var indexSectionsWithContent =
{
  0: "abcdefghimoprstuv",
  1: "aefgprsu",
  2: "abcdefghimoprstuv"
};

var indexSectionNames =
{
  0: "all",
  1: "functions",
  2: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Functions",
  2: "Modules"
};

